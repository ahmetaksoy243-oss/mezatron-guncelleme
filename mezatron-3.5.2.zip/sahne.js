'use strict';
// Sahne listesi: o günkü canlı yayında satılacak ürünler.
// Stok sayımından AYRIDIR: buradaki hiçbir işlem envantere (urunDeposu) yazmaz.
// Asistan envanterden işaretleyerek aktarır, hazırlık ekibi telefondan eksik beden/ürün ekler,
// liste "Yayına hazır" yapılınca canlı satış programı (Evrensel) bu listeyi alır.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CESITLER = [
  ['Ayakkabı', /ayakkab|sneaker|bot\b|çizme|cizme|terlik|sandalet|babet|loafer/],
  ['Tişört', /ti[şs][öo]rt|t-shirt|tshirt|polo/],
  ['Gömlek', /g[öo]mlek/],
  ['Pantolon', /pantolon|jean|kot\b|e[şs]ofman|tayt/],
  ['Şort', /[şs]ort\b/],
  ['Sweatshirt', /sweat|hoodie|kap[şs]onlu/],
  ['Kazak', /kazak|triko|h[ıi]rka/],
  ['Mont', /mont|ceket|kaban|yelek|parka/],
  ['Elbise', /elbise|etek|tunik|bluz/],
  ['Parfüm', /parf[üu]m|edp|edt|deodorant|kolonya/],
  ['Saat', /saat/],
  ['Cüzdan', /c[üu]zdan|kartl[ıi]k/],
  ['Kemer', /kemer/],
  ['Çanta', /[çc]anta/],
  ['Gözlük', /g[öo]zl[üu]k/],
  ['Takı', /kolye|bileklik|k[üu]pe|y[üu]z[üu]k/]
];

function cesitBul(urun) {
  const s = String(urun || '').toLocaleLowerCase('tr-TR');
  for (const [ad, re] of CESITLER) if (re.test(s)) return ad;
  return 'Diğer';
}

const temizMetin = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);

function satirlariTemizle(satirlar) {
  if (!Array.isArray(satirlar)) return [];
  const birlesik = new Map();
  for (const s of satirlar.slice(0, 200)) {
    const renk = temizMetin(s && s.renk, 30).toLocaleUpperCase('tr-TR');
    const beden = temizMetin(s && s.beden, 20).toLocaleUpperCase('tr-TR');
    const adet = Number(s && s.adet);
    if (!Number.isInteger(adet) || adet < 0 || adet > 100000) continue;
    const a = `${renk}|${beden}`;
    const onceki = birlesik.get(a);
    if (onceki) onceki.adet += adet;
    else birlesik.set(a, { renk, beden, adet, ...(s && s.yok ? { yok: true } : {}) });
  }
  return [...birlesik.values()];
}

function fiyatTemizle(v) {
  if (v === undefined || v === null || v === '') return null;
  let ham = typeof v === 'string' ? v.trim() : v;
  if (typeof ham === 'string') {
    if (/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(ham)) ham = ham.replace(/\./g, '').replace(',', '.');
    else if (/^\d+,\d+$/.test(ham)) ham = ham.replace(',', '.');
  }
  const n = Number(ham);
  return Number.isFinite(n) && n >= 0 && n <= 1e7 ? n : NaN;
}

function sahneKur(dataDir) {
  const klasor = path.join(dataDir, 'sahne');

  const dosya = gun => path.join(klasor, `${gun}.json`);
  function oku(gun) {
    try {
      const v = JSON.parse(fs.readFileSync(dosya(gun), 'utf8'));
      return { gun, hazir: Boolean(v.hazir), hazirlayan: v.hazirlayan || '', hazirMs: v.hazirMs || 0, kalemler: Array.isArray(v.kalemler) ? v.kalemler : [], surum: v.surum || 0 };
    } catch (_) {
      return { gun, hazir: false, hazirlayan: '', hazirMs: 0, kalemler: [], surum: 0 };
    }
  }
  function yaz(liste) {
    fs.mkdirSync(klasor, { recursive: true });
    liste.surum = (liste.surum || 0) + 1;
    const hedef = dosya(liste.gun);
    fs.writeFileSync(`${hedef}.tmp`, JSON.stringify(liste, null, 1));
    fs.renameSync(`${hedef}.tmp`, hedef);
    return liste;
  }

  function eksikler(liste) {
    const out = [];
    for (const k of liste.kalemler) {
      if (k.fiyat == null || !(k.fiyat > 0)) out.push({ id: k.id, urun: k.urun, eksik: 'fiyat' });
      if (!k.satirlar.length || k.satirlar.every(s => !s.adet)) out.push({ id: k.id, urun: k.urun, eksik: 'adet' });
      if (!k.numune) out.push({ id: k.id, urun: k.urun, eksik: 'numune' });
    }
    return out;
  }

  function ozet(gun) {
    const liste = oku(gun);
    const gruplar = {};
    for (const k of liste.kalemler) (gruplar[k.cesit] = gruplar[k.cesit] || []).push(k);
    const toplamAdet = liste.kalemler.reduce((t, k) => t + k.satirlar.reduce((a, s) => a + (s.adet || 0), 0), 0);
    return { ...liste, gruplar, eksikler: eksikler(liste), toplamUrun: liste.kalemler.length, toplamAdet };
  }

  function yeniKalem({ urun, fiyat, satirlar, kaynakId = null, ekleyen = '' }) {
    const ad = temizMetin(urun, 120);
    if (!ad) return { hata: 'Ürün adı boş.' };
    const f = fiyatTemizle(fiyat);
    if (Number.isNaN(f)) return { hata: 'Fiyat geçerli bir sayı olmalı.' };
    return {
      kalem: {
        id: crypto.randomUUID(), kaynakId: kaynakId ? String(kaynakId).slice(0, 100) : null,
        urun: ad, cesit: cesitBul(ad), fiyat: f, satirlar: satirlariTemizle(satirlar),
        numune: false, ekleyen: temizMetin(ekleyen, 40), zamanMs: Date.now(), degistiren: '', degistiMs: 0, surum: 1
      }
    };
  }

  // Asistan envanterden işaretleyip aktarır; aynı envanter kaydı iki kez aktarılmaz
  function aktar(gun, envanterKayitlari, { fiyatlar = {}, ekleyen = '' } = {}) {
    const liste = oku(gun);
    const eklenen = [];
    const atlanan = [];
    for (const kayit of envanterKayitlari) {
      if (liste.kalemler.some(k => k.kaynakId && k.kaynakId === kayit.id)) { atlanan.push(kayit.urun); continue; }
      const fiyat = fiyatlar[kayit.id] !== undefined && fiyatlar[kayit.id] !== '' ? fiyatlar[kayit.id] : kayit.fiyat;
      const r = yeniKalem({ urun: kayit.urun, fiyat, satirlar: kayit.satirlar, kaynakId: kayit.id, ekleyen });
      if (r.hata) { atlanan.push(`${kayit.urun} (${r.hata})`); continue; }
      liste.kalemler.push(r.kalem);
      eklenen.push(r.kalem);
    }
    if (eklenen.length) yaz(liste); // yayın sırasında da eklenebilir: "hazır" durumu bozulmaz
    return { success: true, eklenen: eklenen.length, atlanan, liste: ozet(gun) };
  }

  function ekle(gun, girdi, ekleyen) {
    const liste = oku(gun);
    const r = yeniKalem({ ...girdi, ekleyen });
    if (r.hata) return { success: false, error: r.hata };
    liste.kalemler.push(r.kalem);
    yaz(liste);
    return { success: true, kalem: r.kalem, liste: ozet(gun) };
  }

  // Aynı kalemi iki kişi aynı anda değiştirirse ikincisine uyarı: sürüm tutmazsa kaydedilmez
  function guncelle(gun, girdi, degistiren) {
    const liste = oku(gun);
    const k = liste.kalemler.find(x => x.id === girdi.id);
    if (!k) return { success: false, kod: 404, error: 'Sahne listesinde bu ürün yok.' };
    if (!girdi.zorla && Number(girdi.surum) !== k.surum) {
      return { success: false, kod: 409, cakisma: true, mevcut: k, error: `${k.urun} siz düzeltirken ${k.degistiren || k.ekleyen || 'başkası'} tarafından değiştirildi. Listeyi yenileyip tekrar deneyin.` };
    }
    if (girdi.urun !== undefined) {
      const ad = temizMetin(girdi.urun, 120);
      if (!ad) return { success: false, kod: 400, error: 'Ürün adı boş.' };
      k.urun = ad; k.cesit = cesitBul(ad);
    }
    if (girdi.fiyat !== undefined) {
      const f = fiyatTemizle(girdi.fiyat);
      if (Number.isNaN(f)) return { success: false, kod: 400, error: 'Fiyat geçerli bir sayı olmalı.' };
      k.fiyat = f;
    }
    if (girdi.satirlar !== undefined) k.satirlar = satirlariTemizle(girdi.satirlar);
    if (girdi.ekSatirlar !== undefined) k.satirlar = satirlariTemizle([...k.satirlar, ...satirlariTemizle(girdi.ekSatirlar)]);
    if (girdi.numune !== undefined) k.numune = Boolean(girdi.numune);
    if (girdi.cesit !== undefined && (girdi.cesit === 'Diğer' || CESITLER.some(([ad]) => ad === girdi.cesit))) k.cesit = girdi.cesit;
    k.degistiren = temizMetin(degistiren, 40);
    k.degistiMs = Date.now();
    k.surum += 1;
    yaz(liste);
    return { success: true, kalem: k, liste: ozet(gun) };
  }

  function sil(gun, id) {
    const liste = oku(gun);
    const once = liste.kalemler.length;
    liste.kalemler = liste.kalemler.filter(k => k.id !== id);
    if (liste.kalemler.length === once) return { success: false, kod: 404, error: 'Sahne listesinde bu ürün yok.' };
    yaz(liste);
    return { success: true, liste: ozet(gun) };
  }

  function hazirYap(gun, hazir, kim) {
    const liste = oku(gun);
    if (hazir) {
      const e = eksikler(liste).filter(x => x.eksik !== 'numune');
      if (!liste.kalemler.length) return { success: false, kod: 409, error: 'Sahne listesi boş.' };
      if (e.length) return { success: false, kod: 409, eksikler: e, error: `${e.length} eksik var (fiyat ya da adet). Önce tamamlayın.` };
    }
    liste.hazir = Boolean(hazir);
    liste.hazirlayan = hazir ? temizMetin(kim, 40) : '';
    liste.hazirMs = hazir ? Date.now() : 0;
    yaz(liste);
    return { success: true, liste: ozet(gun) };
  }

  return { oku, ozet, aktar, ekle, guncelle, sil, hazirYap, cesitBul, CESIT_ADLARI: [...CESITLER.map(c => c[0]), 'Diğer'] };
}

module.exports = { sahneKur, cesitBul };
