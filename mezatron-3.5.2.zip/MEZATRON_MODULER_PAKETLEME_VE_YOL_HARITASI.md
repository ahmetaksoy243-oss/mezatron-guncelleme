# MEZATRON MODÜLER TİCARİ MİMARİ VE YOL HARİTASI
**Sürüm:** 1.0  
**Tarih:** 13 Kasım 2026  
**Strateji:** Fahiş ERP Lisanslarına Alternatif, Kendi İçinde Eksiksiz, 4 Katmanlı Modüler Perakende ve Mezat Ekosistemi

---

## 1. YÖNETİCİ ÖZETİ VE VİZYON

Türkiye perakende pazarında (özellikle hazır giyim, butik ve toptan sektöründe) **Nebim, Logo, Mikro** gibi geleneksel ERP yazılımları; temel bir SQL okuma için dahi yüz binlerce lira ek lisans talep eden, eğitim videolarını bile ücretli kılan ve günlük yüksek servis ücretleri koyan tekelci bir yapı kurmuştur.

**Mezatron'un Ticari Felsefesi:**
1. **Esnaf Dostu ve Adil:** Müşteri en temel paketi aldığında dahi "Bu program yarım kaldı, işimi görmedi" demeyecek; temel paket kendi içinde eksiksiz bir mağaza yönetim sistemi olacaktır.
2. **Lego Modeli (À la Carte):** Müşteri sadece ihtiyacı olan modülleri sepetine ekleyecek, kullanmadığı özelliğe para ödemeyecektir.
3. **Pazarlıkta Esneklik:** Fiyat kırmak yerine modül eksiltilerek/artırılarak firmanın bütçesine göre satış kapatılacaktır.
4. **Dene & Satın Al (Upsell Gücü):** Üst modüller arayüzde zarif kilit rozetleriyle duracak; müşteri talep ettiğinde 3-7 günlük geçici deneme açılarak bağımlılık yaratılacaktır.

---

## 2. MODÜLER PAKET MİMARİSİ (4 ANA KATMAN)

```
+-------------------------------------------------------------------------+
|                  4. CANLI MEZAT & YAYIN KOKPİTİ                          |
|  - Asistanlı Mod / Otonom Ses Modu                                      |
|  - FB/IG DM Otomatik Butonlu Beden Seçimi                                |
|  - Telegram Mini App Sıfır Hatalı Sipariş                               |
+-------------------------------------------------------------------------+
                                    ▲
+-------------------------------------------------------------------------+
|              3. YAPAY ZEKÂ İRSALİYE & MAL KABUL MODÜLÜ                  |
|  - Gemini 3.5 Flash ile El Yazısı & Çetele Okuma                         |
|  - Sayım Fark & Eksik/Fazla Mutabakat Tutanağı                          |
|  - e-İrsaliye (.XML) ve Metin Çözücü                                    |
+-------------------------------------------------------------------------+
                                    ▲
+-------------------------------------------------------------------------+
|              2. HIZLI MOBİL & SESLİ DEPO EKSTRESİ                        |
|  - Mikrofondan Konuşarak Stok Girişi (WebSpeech)                        |
|  - Cepten Doğrudan Bluetooth Taşınabilir Termal Yazıcıya Basım          |
|  - Çevrimdışı (Bilgisayarsız / Sığınak-Bodrum) Mobil Depo Sayımı         |
+-------------------------------------------------------------------------+
                                    ▲
+-------------------------------------------------------------------------+
|         1. STANDART MAĞAZA & BARKOD İSTASYONU (TEMEL ÇEKİRDEK)          |
|  - Kamera veya USB Lazer ile Fabrika/Ürün Barkodu Okutma                |
|  - Fiyat Belirleme, Satıştan Anında Düşme (Kasa İstasyonu)              |
|  - Canlı Mağaza Mal Varlığı (Toplam Adet + Toplam Maliyet Değeri)       |
|  - Masaüstü Termal Barkod Yazıcıdan Etiket Basımı                       |
|  - Excel'e Aktar / Excel'den Toplu Stok Yükle                           |
+-------------------------------------------------------------------------+
```

---

### 🟢 1. MODÜL: STANDART MAĞAZA & BARKOD İSTASYONU (TEMEL ÇEKİRDEK)
* **Kime Hitap Eder:** Sadece dükkanını, askısını, deposunu ve kasasını takip etmek isteyen butik ve mağazalar.
* **Müşterinin Kazancı:** Nebim vb. hantal programlara yüz binlerce lira vermeden mağazasını eksiksiz yönetir.
* **Özellikleri (Kendi İçinde %100 Tamdır):**
  1. **Barkod Okutma:** Ürünün üzerindeki hazır fabrika barkodunu (EAN-13, EAN-8) veya otomatik sistem barkodunu kamera veya USB el okuyucuyla tanır.
  2. **Stok & Fiyatlandırma:** Alış fiyatı, satış fiyatı, renk ve beden adetlerini klavyeyle kolayca girer.
  3. **Canlı Envanter Değeri:** Mağazada anlık kaç parça ürün var ve toplam maliyet/raf değeri ne kadar, anında gösterir.
  4. **Satıştan Düşme (Kasa Modu):** Kasada ürün satıldıkça barkod okutarak stoktan anında düşülür.
  5. **Masaüstü Barkod Basımı:** Bilgisayara bağlı standart barkod yazıcıdan tek veya çoklu etiket basar.
  6. **Excel Entegrasyonu:** Dışarıdan Excel stoğu içeri aktarılır; mevcut stok tek tuşla Excel'e indirilir.

---

### 🔵 2. MODÜL: HIZLI MOBİL & SESLİ DEPO EKSTRESİ
* **Kime Hitap Eder:** Depoda veya reyon aralarında gezen, klavyeyle yazmak yerine konuşarak hızlı stok girmek isteyen işletmeler.
* **Müşteriye Satış Cümlesi:** *"Personeliniz rafta klavye başında beklemez; söyler geçer, kemerindeki yazıcıdan etiketi anında yapıştırır."*
* **Özellikleri:**
  1. **Sesli Envanter:** *"Nike spor ayakkabı siyah 40'tan 2, 41'den 3 tane, fiyat 1200"* diyerek saniyeler içinde tabloyu doldurma.
  2. **Bluetooth Mobil Etiket:** Bilgisayara gitmeden, telefon başındayken kemerdeki taşınabilir Bluetooth termal yazıcıya anında etiket basımı.
  3. **Çevrimdışı Mobil Depo:** Bilgisayar kapalıyken veya internet çekmeyen bodrum katta telefon hafızasında sayım yapıp sonradan bilgisayarla eşleşme.

---

### 🟣 3. MODÜL: YAPAY ZEKÂ İRSALİYE & MAL KABUL
* **Kime Hitap Eder:** Toptancıdan haftalık koli koli mal kabul eden, elle yazılmış çeki listeleri ve irsaliyelerle uğraşan satıcılar.
* **Müşteriye Satış Cümlesi:** *"Toptancının tükenmez kalemle karaladığı 300 parçalık irsaliyeyi tek tek girmeyin; fotoğrafını çekin, yapay zekâ 3 saniyede stoka döksün."*
* **Özellikleri:**
  1. **Google Gemini 3.5 Flash Vision El Yazısı Motoru:** Tükenmez kalem, çetele işaretleri (`|`, `||`, `|||`, `IIII`), seri dağılımları (`1-2-2-1`) ve tekstil kısaltmalarını (`Trk`, `Pnt`, `Syh`) hatasız okuma.
  2. **Sayım Fark & Mutabakat Tutanağı:** İrsaliyede yazan ile koliden çıkan arasındaki farkı (örn. "+2 Fazla / -1 Eksik") çıkarır, tek tuşla toptancıya WhatsApp mutabakat raporu atar.
  3. **e-İrsaliye (.XML) Çözücü:** GİB formatındaki fatura/irsaliyeleri sisteme doğrudan aktarır.

---

### 🔴 4. MODÜL: CANLI MEZAT & YAYIN KOKPİTİ
* **Kime Hitap Eder:** Instagram, Facebook, TikTok veya Telegram üzerinden canlı satış/mezat yapan yayıncılar.
* **Müşteriye Satış Cümlesi:** *"Yayında sipariş kaçırmaz, beden kavgası yaşamazsınız. İster asistanınız yönetsin, ister sesinizi dinleyen otopilot yönetsin."*
* **İki Farklı Çalışma Kipi:**
  - **Kip A (Asistanlı Mod):** Sistem siparişi hazırlar; masadaki asistan ekrandan onaylamadıkça kesinleşmez (sıfır risk).
  - **Kip B (Otonom Ses Modu - Tek Kişilik Dev Kadro):** Yayıncının *"Verdim", "Hayırlı olsun", "Sardım"* sözlerini Gemini/ASR yakalar; 4 saniyelik emniyet geri sayımının ardından siparişi kendi kendine kesinleştirip etiketi basar.
* **Amiral Gemisi Sipariş Otomasyonu (Meta & Telegram Entegrasyonu):**
  1. **Telegram Mini App / Buton:** Yayındaki müşteriye sıfır hatayla renk ve beden seçtiren, sıfır maliyetli ve %100 kesin sipariş motoru.
  2. **Facebook & Instagram DM:** Yorum yapan müşterinin DM kutusuna Meta'nın 24 saatlik ücretsiz pencere kuralıyla anında `[ Siyah ]`, `[ 42 ]` butonları göndererek adresi ve bedeni hatasız kapatma.

---

## 3. TEKNİK ALTYAPI VE LİSANSLAMA MİMARİSİ

Sistemin kod tabanı bölünmez; tek bir program olarak dağıtılır. Müşterinin yetkileri `lisans.json` dosyası veya şifreli lisans anahtarı üzerinden dinamik kontrol edilir:

```json
{
  "musteri": "Trend Butik",
  "paket": "STANDART",
  "lisansBitis": "2027-11-13",
  "moduller": {
    "temel_stok_ve_barkod": true,
    "sesli_asistan": false,
    "bluetooth_mobil_yazici": false,
    "irsaliye_ai": false,
    "canli_mezat_asistanli": false,
    "canli_mezat_otonom": false,
    "sosyal_dm_otomasyonu": false
  }
}
```

* **Arayüz Davranışı:** Yetkisi olmayan modülün düğmesi arayüzde gizlenebilir veya üzerinde küçük bir kilit rozeti ile *"Bu özellik PRO pakette mevcuttur (Denemek için tıklayın)"* uyarısı gösterilir.
* **Lisans Kapatma:** Müşteri ödemesini aksatırsa merkezi sunucudan anahtar pasife çekilerek yazılım kilitlenebilir.

---

## 4. DÜNYA STANDARTLARI VE KÜRESEL KIYASLAMA

| Kriter | CommentSold (ABD) | Nebim / Geleneksel ERP (TR) | Mezatron Modüler Sistem |
| :--- | :--- | :--- | :--- |
| **İş Modeli** | Aylık 149$ - 400$ Modüler | 800.000 TL + Yıllık Fahiş Lisans | Makul Giriş + Kullandıkça Ekle |
| **Canlı Yayın** | "SOLD 104" Robotik Yorum | Yok | Doğal Türkçe Konuşma + NLP |
| **Hatasız Beden** | Web Sepeti / SMS | Yok | Telegram Mini App + FB/IG DM |
| **Mal Kabul** | Manuel / Barkod | Modül başına +150.000 TL | Gemini 3.5 Flash ile El Yazısı OCR |
| **Donanım** | Özel Terminal | Pahalı El Terminali | Standart Cep Telefonu + BT Yazıcı |

---

## 5. SAHA RİSKLERİ VE ALINACAK EMNİYET TEDBİRLERİ

1. **Sesli Otonom Onay Riski (Yanlış Satış):**
   - *Risk:* Canlı yayındaki arka plan gürültüsü veya espriyle söylenen bir söz yanlış sipariş açabilir.
   - *Tedbir:* Otonom modda **5 saniyelik görsel geri sayım barı** konulur. Yayıncı "Geri al" demezse sipariş kesinleşir.
2. **Karmaşık Kurulum Riski:**
   - *Risk:* Standart paketi alan dükkan sahibine sosyal medya entegrasyonu anlatılırsa müşteri sistemi karmaşık bulur.
   - *Tedbir:* Standart pakette Facebook/Telegram ayarları tamamen gizlenir; sistem tak-çalıştır masaüstü programı olarak açılır.
3. **Müşteri Teknik Destek Yükü:**
   - *Risk:* Her küçük arıza için telefonla destek verilirse kâr marjı erir.
   - *Tedbir:* Sisteme 2 dakikalık sessiz, animasyonlu "Nasıl Kullanılır?" rehberleri gömülür.

---

## 6. GEÇİŞ VE UYGULAMA YOL HARİTASI

- [x] **Adım 1:** Gemini 3.5 Flash altyapısı ve el yazısı / çetele promptları sisteme bağlandı.
- [x] **Adım 2:** Mobil bağımsız çalışma ve API anahtarı senkronizasyonu tamamlandı.
- [ ] **Adım 3:** `lisans.json` modül kilit mimarisinin arayüz butonlarına (`urun-girisi.html` ve `asistan.html`) bağlanması.
- [ ] **Adım 4:** Telegram Bot & Mini App beden seçim prototipinin test edilmesi.
- [ ] **Adım 5:** iPad Safari arayüz kaymaları ve responsive dokunmatik iyileştirmelerinin yapılması.
