# 👗 Mezatron Sektörel Barkod Bankası & Ürün Sözlüğü: Tekstil, Giyim & Moda

Bu dosya, **Tekstil, Butik, Hazır Giyim ve Moda Mağazaları** için hazırlanmıştır.
Standart **Bedenler (XS, S, M, L, XL, XXL, 3XL, 36-46)**, **Kumaş Renkleri** ve **Yaka / Kalıp Tipleri** içerir.

---

## 1. Popüler Markalar ve Telaffuz Rehberi

| Doğru Marka Adı | Türkçe Okunuşları ve Ses Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Zara** | zara | Hızlı Moda |
| **Bershka** | berşka, berşika | Genç Moda |
| **Pull&Bear** | pulenber, pul en ber, pul end bir | Günlük Giyim |
| **Massimo Dutti** | masimo duti, masimodutti | Şık & Klasik |
| **Lacoste** | lakost, lakoste | Polo & Spor Şık |
| **Tommy Hilfiger** | tomi hilfigır, tomi hilfaygır | Premium Casual |
| **Ralph Lauren** | ralf loren, relf loren | Premium Polo |
| **Calvin Klein** | kelvin kleyn, kalvin kleyn | İç Giyim & Denim |
| **Mavi** | mavi, mavi jeans | Denim & Casual |
| **Koton** | koton | Kadın / Erkek Giyim |
| **LC Waikiki** | elsivaykiki, elsi vaykiki | Aile Giyim |
| **DeFacto** | defakto, de fakto | Aile Giyim |

---

## 2. Hazır Barkod Bankası & Popüler Ürün Listesi

| Barkod | Ürün Adı | Renk | Beden | Tavsiye Fiyat (TL) |
| :--- | :--- | :--- | :--- | :--- |
| **MZU-GM001** | Lacoste Klasik Polo Yaka Tişört | BEYAZ | M | 950 |
| **MZU-GM002** | Tommy Hilfiger Slim Fit Düğmeli Gömlek | AÇIK MAVİ | L | 1150 |
| **MZU-GM003** | Mavi Jake Slim Fit Kot Pantolon | KOT MAVİ | 32/32 | 780 |
| **MZU-GM004** | Zara Dökümlü Keten Karışımlı Pantolon | BEJ | 38 | 690 |
| **MZU-GM005** | Columbia Fermuarlı Kalın Polar Ceket | HAKİ | XL | 1850 |
| **MZU-GM006** | The North Face Su Geçirmez Nefes Alan Yağmurluk | SİYAH | L | 2400 |
| **MZU-GM007** | Nike Dri-Fit Spor Eşofman Altı | LACİVERT | M | 890 |
| **MZU-GM008** | Koton Pamuklu V Yaka Triko Kazak | GRİ | S | 450 |
| **MZU-GM009** | Koton Basic Bisiklet Yaka Pamuklu Tişört | SİYAH | L | 220 |
| **MZU-GM010** | Pamuklu Spor Tenis Çorabı 3'lü Paket | BEYAZ | STD | 120 |
