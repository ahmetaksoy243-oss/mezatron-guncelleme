# 🛒 Mezatron Sektörel Barkod Bankası & Ürün Sözlüğü: Market, Gıda & Şarküteri

Bu dosya, **Marketler, Bakkallar, Şarküteri ve Yöresel Gıda Satıcıları** için hazırlanmıştır.
Beden yerine **Gramaj / Hacim (500g, 1kg, 1lt, 5lt)**, **Yağ Oranı** ve **Ambalaj Türü** içerir.

---

## 1. Popüler Gıda & Temizlik Markaları ve Telaffuz Rehberi

| Doğru Marka Adı | Türkçe Okunuşları ve Ses Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Çaykur** | çaykur, çay kur | Çay & Sıcak İçecek |
| **Sütaş** | sütaş, sutas | Süt & Peynir |
| **Pınar** | pınar, pinar | Et & Süt Ürünleri |
| **Torku** | torku | Şeker, Çikolata, Süt |
| **Marmarabirlik** | marmara birlik, marmarabirlik | Zeytin |
| **Yudum** | yudum, yudum yağ | Sıvı Yağ |
| **Barilla** | barila, barilla | İtalyan Makarna |
| **Tat** | tat, tat salça | Salça & Konserve |
| **Nestle** | nestle, nesle | Çikolata & Kahve |
| **Fairy** | feyri, fayri, feri | Bulaşık Deterjanı |

---

## 2. Hazır Barkod Bankası & Popüler Ürün Listesi

| Barkod | Ürün Adı | Tür / Çeşit | Gramaj / Hacim | Tavsiye Fiyat (TL) |
| :--- | :--- | :--- | :--- | :--- |
| **MZU-MK001** | Torku Doğal Pastörize Süt 1 Lt | TAM YAĞLI | 1LT | 40 |
| **MZU-MK002** | Çaykur Rize Turist Çay 1 Kg | KLASİK | 1KG | 170 |
| **MZU-MK003** | Sütaş Taze Kaşar Peyniri 600 gr | DİLİMLİ / BLOK | 600G | 195 |
| **MZU-MK004** | Marmarabirlik Kuru Sele Doğal Siyah Zeytin 500g | SİYAH | 500G | 115 |
| **MZU-MK005** | Yudum Ayçiçek Yağı 5 Lt Pet | SIZMA / RAFİNE | 5LT | 260 |
| **MZU-MK006** | Pınar Kangal Sucuk 300 gr | ACILI | 300G | 230 |
| **MZU-MK007** | Barilla Spagetti Makarna No 5 500g | DURUM BUĞDAYI | 500G | 45 |
| **MZU-MK008** | Fairy Platinum Bulaşık Makinesi Tableti 60'lı | HİJYEN | 60'LI | 380 |
