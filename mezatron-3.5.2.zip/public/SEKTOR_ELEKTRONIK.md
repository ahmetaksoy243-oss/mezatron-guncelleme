# 📱 Mezatron Sektörel Barkod Bankası & Ürün Sözlüğü: Elektronik, Telefon & Aksesuar

Bu dosya, **Telefon Aksesuar Mağazaları, Teknik Servisler & Elektronik Perakendecileri** için hazırlanmıştır.
Beden yerine **Kapasite (64GB, 128GB, 10000mAh)**, **Güç (20W, 25W, 65W)** ve **Uyumlu Model** içerir.

---

## 1. Popüler Markalar ve Telaffuz Rehberi

| Doğru Marka Adı | Türkçe Okunuşları ve Ses Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Apple** | epıl, apıl, elma | Telefon & Aksesuar |
| **Samsung** | samsung, samsunk | Telefon & Aksesuar |
| **Xiaomi** | şavmi, şaomi, ksiyomi | Telefon & Ekosistem |
| **Anker** | enkır, anker | Şarj & Ses |
| **JBL** | ciy bi el, jbl, ceybiye | Hoparlör & Kulaklık |
| **Baseus** | baseus, baseyus, beysus | Şarj & Araç İçi |
| **Spigen** | spigen, spigın, sipigen | Kılıf & Cam |
| **Ugreen** | yugrin, ugreen, yugreen | Kablo & Dönüştürücü |
| **Philips** | filips, philips | Pil & Aksesuar |
| **Sony** | soni, sony | Kulaklık & Ses |

---

## 2. Hazır Barkod Bankası & Popüler Ürün Listesi

| Barkod | Ürün Adı | Renk / Tür | Kapasite / Model | Tavsiye Fiyat (TL) |
| :--- | :--- | :--- | :--- | :--- |
| **MZU-EL001** | Apple iPhone 15 Uyumlu MagSafe Şeffaf Kılıf | ŞEFFAF | İPHONE 15 | 450 |
| **MZU-EL002** | Samsung 25W Type-C Süper Hızlı Şarj Cihazı | BEYAZ | 25W | 390 |
| **MZU-EL003** | Anker PowerCore 10000mAh Taşınabilir Hızlı Şarj | SİYAH | 10000MAH | 750 |
| **MZU-EL004** | Baseus 3in1 Örgülü Hızlı Şarj Kablosu 1.2m | KIRMIZI | 1.2M | 190 |
| **MZU-EL005** | JBL Wave 100 TWS Bluetooth Kulaklık | SİYAH | STD | 1250 |
| **MZU-EL006** | 9D Tam Kapatan Kırılmaz Hayalet Cam Koruyucu | SİYAH KENAR | İPHONE 15 PRO | 150 |
| **MZU-EL007** | Manyetik Havalandırma Izgarası Araç Telefon Tutacağı | SİYAH | STD | 220 |
| **MZU-EL008** | Xiaomi Mi Band 7 / 8 Silikon Yedek Kordon | LACİVERT | STD | 110 |
