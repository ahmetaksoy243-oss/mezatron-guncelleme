// Ürün girişi (telefon): büyük düğmeye basınca mikrofon açılır, ürün söylenir, susunca kayıt durur ve mikrofon kapanır.
// Söz bilgisayardaki ses motorunda yazıya, sonra tabloya çevrilir. Kişi tabloyu kontrol eder, Kaydet'e basar.
// Düğmeye basılmadıkça mikrofon kapalıdır; ses saklanmaz.
(function () {
  const $ = id => document.getElementById(id);
  // Fabrika barkodu (EAN-8, UPC-12, EAN-13, GTIN-14): hane sayısı ve son rakamdaki kontrol hesabı tutmalı
  function gecerliFabrikaBarkodu(kod) {
    const k = String(kod || '').trim();
    if (!/^(?:\d{8}|\d{12,14})$/.test(k)) return false;
    let toplam = 0;
    for (let i = k.length - 2, kat = 3; i >= 0; i--, kat = kat === 3 ? 1 : 3) toplam += Number(k[i]) * kat;
    return (10 - (toplam % 10)) % 10 === Number(k[k.length - 1]);
  }

  // --- 4 HANELİ YEREL AĞ (WI-FI) GÜVENLİK PIN KORUMASI ---
  const _orijinalFetch = window.fetch ? window.fetch.bind(window) : null;
  function aktifPinAl() {
    try {
      const kayitli = String(localStorage.getItem('mezat_giris_pin') || '').replace(/\D+/g, '').slice(0, 6);
      return kayitli.length >= 4 ? kayitli : '';
    } catch (_) {
      return '';
    }
  }
  window.mezatPinModalAc = function (zorunluMesaj) {
    let modal = document.getElementById('mezat-pin-modal');
    if (modal) modal.remove();
    modal = document.createElement('div');
    modal.id = 'mezat-pin-modal';
    modal.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(2,6,23,0.88);display:flex;align-items:center;justify-content:center;padding:16px;backdrop-filter:blur(6px)';
    modal.innerHTML = `
      <div style="background:#0f172a;border:2px solid #38bdf8;border-radius:16px;padding:18px;max-width:360px;width:100%;color:#f8fafc;box-shadow:0 20px 50px rgba(0,0,0,0.6)">
        <div style="font-size:1.05rem;font-weight:900;color:#7dd3fc;margin-bottom:6px">🔐 Mağaza Güvenlik Şifresi</div>
        <div style="font-size:0.82rem;color:#cbd5e1;margin-bottom:12px;line-height:1.4">${zorunluMesaj || 'Aynı Wi-Fi ağındaki cihazlardan güvenli erişim için 4 haneli PIN kodunuzu girin veya değiştirin.'}</div>
        <label style="font-size:0.78rem;color:#94a3b8;display:block;margin-bottom:4px">Bilgisayar ekranındaki şifre (4-6 rakam):</label>
        <input id="mezat-pin-giris-input" type="tel" inputmode="numeric" maxlength="6" value="${aktifPinAl()}" placeholder="••••" style="width:100%;padding:10px 12px;font-size:1.25rem;font-weight:900;letter-spacing:6px;text-align:center;border-radius:10px;border:2px solid #0284c7;background:#020617;color:#38bdf8;margin-bottom:10px;box-sizing:border-box">
        <details style="margin-bottom:12px;font-size:0.78rem;color:#94a3b8">
          <summary style="cursor:pointer;color:#bae6fd;font-weight:700">🔄 Sunucu PIN Kodunu Değiştir</summary>
          <input id="mezat-pin-yeni-input" type="tel" inputmode="numeric" maxlength="6" placeholder="Yeni şifre (4-6 rakam)" style="width:100%;margin-top:8px;padding:8px 10px;font-size:1.05rem;font-weight:800;letter-spacing:4px;text-align:center;border-radius:8px;border:1.5px solid #475569;background:#020617;color:#fde68a;box-sizing:border-box">
        </details>
        <div id="mezat-pin-durum-mesaj" style="font-size:0.78rem;min-height:18px;margin-bottom:8px;color:#fca5a5;font-weight:700"></div>
        <div style="display:flex;gap:8px">
          <button type="button" id="mezat-pin-kaydet-btn" style="flex:1;padding:10px;border-radius:10px;border:0;background:linear-gradient(135deg,#0284c7,#0369a1);color:#fff;font-weight:900;font-size:0.9rem;cursor:pointer">✅ Doğrula & Kaydet</button>
          <button type="button" id="mezat-pin-kapat-btn" style="padding:10px 14px;border-radius:10px;border:1px solid #475569;background:#1e293b;color:#cbd5e1;font-weight:800;font-size:0.85rem;cursor:pointer">Kapat</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    const girisEl = document.getElementById('mezat-pin-giris-input');
    const yeniEl = document.getElementById('mezat-pin-yeni-input');
    const durumEl = document.getElementById('mezat-pin-durum-mesaj');
    document.getElementById('mezat-pin-kapat-btn').onclick = () => modal.remove();
    document.getElementById('mezat-pin-kaydet-btn').onclick = async () => {
      const girilen = String(girisEl.value || '').replace(/\D+/g, '').slice(0, 6);
      const yeniPin = String(yeniEl.value || '').replace(/\D+/g, '').slice(0, 6);
      if (girilen.length < 4) {
        durumEl.textContent = '⚠️ Şifre 4-6 rakam olmalı.';
        return;
      }
      // Sunucu "success" ve "error" ile cevap verir; doğru şifrede hata gösterilmez
      const basarili = (r, j) => r.ok && Boolean(j && (j.success || j.tamam));
      const hataMetni = (j, yedek) => (j && (j.error || j.hata)) || yedek;
      try {
        if (yeniPin) {
          if (yeniPin.length < 4) {
            durumEl.textContent = '⚠️ Yeni şifre 4-6 rakam olmalı.';
            return;
          }
          const r = await _orijinalFetch('/api/pin-degistir', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Mezat-Pin': girilen },
            body: JSON.stringify({ mevcutPin: girilen, yeniPin })
          });
          const j = await r.json().catch(() => ({}));
          if (!basarili(r, j)) {
            durumEl.textContent = '❌ ' + hataMetni(j, 'Şifre değiştirilemedi.');
            return;
          }
          localStorage.setItem('mezat_giris_pin', yeniPin);
        } else {
          const r = await _orijinalFetch('/api/pin-dogrula', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Mezat-Pin': girilen },
            body: JSON.stringify({ pin: girilen })
          });
          const j = await r.json().catch(() => ({}));
          if (!basarili(r, j)) {
            durumEl.textContent = '❌ ' + hataMetni(j, 'Şifre hatalı.');
            return;
          }
          localStorage.setItem('mezat_giris_pin', girilen);
        }
        modal.remove();
      } catch (_) {
        // Bağlantı yoksa şifre doğrulanmadı: kaydedilmez, pencere açık kalır
        durumEl.textContent = '⚠️ Bilgisayara ulaşılamadı. Wi-Fi bağlantısını kontrol edip tekrar deneyin.';
      }
    };
  };
  function telefonOnayUyarisiGoster(j) {
    if (document.getElementById('mezat-telefon-onay')) return;
    const b = document.createElement('div');
    b.id = 'mezat-telefon-onay';
    b.style.cssText = 'position:fixed;left:10px;right:10px;top:10px;z-index:99999;padding:12px 14px;border:2px solid #fbbf24;border-radius:12px;background:#78350f;color:#fff;font-size:0.95rem;font-weight:800;line-height:1.4';
    const sayi = (j.telefonLimiti ? ` (${j.onayliTelefon || 0}/${j.telefonLimiti} telefon onaylı)` : '');
    b.textContent = '📱 Bu telefon bilgisayarda yönetici onayı bekliyor' + sayi + '. Bilgisayarda Kullanıcı Yönetimi → Telefonlar bölümünden onaylayın. Onaydan sonra Yenile\'ye basın.';
    b.onclick = () => b.remove();
    document.body.appendChild(b);
  }
  if (_orijinalFetch) {
    window.fetch = async function (input, init) {
      const ayar = Object.assign({}, init || {});
      const basliklar = new Headers(ayar.headers || {});
      if (!basliklar.has('X-Mezat-Pin')) {
        basliklar.set('X-Mezat-Pin', aktifPinAl());
      }
      try {
        const kul = (typeof window.mezatOturumAdi === 'function' ? window.mezatOturumAdi() : '') || '';
        if (kul && !basliklar.has('X-Mezat-Kullanici')) basliklar.set('X-Mezat-Kullanici', encodeURIComponent(kul));
        const jt = localStorage.getItem('mezat_oturum_jetonu') || '';
        if (jt && !basliklar.has('X-Mezat-Oturum')) basliklar.set('X-Mezat-Oturum', jt);
      } catch (_) {}
      ayar.headers = basliklar;
      const yanit = await _orijinalFetch(input, ayar);
      // Telefon, lisanstaki telefon sayısı içinde yönetici onayı bekliyor
      if (yanit && yanit.status === 403) {
        yanit.clone().json().then(j => { if (j && j.telefonOnayBekliyor) telefonOnayUyarisiGoster(j); }).catch(() => {});
      }
      if (yanit && yanit.status === 401) {
        const klon = yanit.clone();
        klon.json().then(j => {
          if (j && j.pinGerekli && typeof window.mezatGirisKapisiAc === 'function' && !/^(localhost|127\.0\.0\.1)$/i.test(location.hostname)) {
            try { sessionStorage.removeItem('mezat_oturum_ad'); } catch (_) {}
            window.mezatGirisKapisiAc(false);
          } else if (j && j.pinGerekli && !document.getElementById('mezat-pin-modal')) {
            window.mezatPinModalAc(j.error || j.hata || 'Bu işlem için bilgisayar ekranındaki mağaza şifresini girin.');
          }
        }).catch(() => {});
      }
      return yanit;
    };
  }

  // --- v117: ZORUNLU GİRİŞ KAPISI (Ad + KİŞİSEL 4 haneli şifre) ---
  // Bilgisayarın kendisi (localhost) hariç her telefonda/terminalde program açılışında sorulur.
  // Bir ad ilk kez giriyorsa kendi şifresini belirler; sonra hep o şifreyle girer.
  const yerelBilgisayarMi = /^(localhost|127\.0\.0\.1|\[::1\])$/i.test(location.hostname || '');
  function oturumAdi() { try { return sessionStorage.getItem('mezat_oturum_ad') || ''; } catch (_) { return ''; } }
  function oturumJetonu() { try { return localStorage.getItem('mezat_oturum_jetonu') || ''; } catch (_) { return ''; } }
  function ortakOku(anahtar) { try { return (window.MezatNativeApp && window.MezatNativeApp.ortakOku) ? String(window.MezatNativeApp.ortakOku(anahtar) || '') : ''; } catch (_) { return ''; } }
  function ortakYaz(anahtar, deger) { try { if (window.MezatNativeApp && window.MezatNativeApp.ortakYaz && deger) window.MezatNativeApp.ortakYaz(anahtar, String(deger)); } catch (_) {} }
  // Daha önce giriş yapmış telefonda bilgi ortak hafızaya da alınır; bilgisayar kapalıyken açılan sayfa oradan okur
  try { ortakYaz('giris_ozeti', localStorage.getItem('mezat_yerel_giris_ozeti')); ortakYaz('giris_ad', localStorage.getItem('urun_girisi_ad')); } catch (_) {}
  async function yerelOzet(ad, pin) {
    try {
      const veri = new TextEncoder().encode('mezatron|' + String(ad).toLocaleLowerCase('tr-TR') + '|' + pin);
      const h = await crypto.subtle.digest('SHA-256', veri);
      return Array.from(new Uint8Array(h)).map(b => b.toString(16).padStart(2, '0')).join('');
    } catch (_) { return ''; }
  }
  function girenAlaniniKilitle(ad) {
    const g = $('giren');
    if (!g) return;
    g.value = ad;
    g.readOnly = true;
    g.title = 'Kullanıcıyı değiştirmek için dokunun';
    g.classList.remove('eksik');
    if (!g.dataset.kapiBagli) {
      g.dataset.kapiBagli = '1';
      g.addEventListener('click', () => { if (g.readOnly) window.mezatGirisKapisiAc(true); });
    }
  }
  window.mezatGirisKapisiAc = function (kullaniciDegistir = false) {
    if (yerelBilgisayarMi || document.getElementById('mezat-giris-kapisi')) return;
    const k = document.createElement('div');
    k.id = 'mezat-giris-kapisi';
    k.style.cssText = 'position:fixed;inset:0;z-index:100000;background:#020617;display:flex;align-items:center;justify-content:center;padding:18px;overflow-y:auto';
    const oncekiAd = (localStorage.getItem('urun_girisi_ad') || ortakOku('giris_ad') || '');
    const giris = 'width:100%;box-sizing:border-box;height:56px;font-size:1.6rem;font-weight:900;letter-spacing:12px;text-align:center;border-radius:12px;border:2px solid #0284c7;background:#020617;color:#38bdf8;margin-bottom:10px';
    k.innerHTML = `
      <div style="width:100%;max-width:380px;background:#0f172a;border:2.5px solid #38bdf8;border-radius:18px;padding:20px;color:#f8fafc;box-shadow:0 20px 60px rgba(0,0,0,.7)">
        <div style="font-size:1.35rem;font-weight:900;color:#7dd3fc;text-align:center;margin-bottom:4px">🔐 MEZATRON GİRİŞ</div>
        <div style="font-size:0.92rem;color:#cbd5e1;text-align:center;margin-bottom:16px;line-height:1.4">Kayıtları kimin yaptığı belli olsun diye<br><b style="color:#fde68a">adınız ve kişisel şifreniz zorunludur.</b></div>
        <label style="display:block;font-size:0.9rem;font-weight:800;color:#e2e8f0;margin-bottom:4px">👤 Adınız Soyadınız</label>
        <input id="mgk-ad" autocomplete="name" maxlength="40" value="${oncekiAd.replace(/"/g, '&quot;')}" placeholder="Örn: Ahmet Yılmaz" style="width:100%;box-sizing:border-box;height:52px;padding:8px 12px;font-size:1.15rem;font-weight:800;border-radius:12px;border:2px solid #0284c7;background:#020617;color:#fff;margin-bottom:12px">
        <div id="mgk-bilgi" style="font-size:0.9rem;font-weight:800;color:#e2e8f0;margin-bottom:4px">🔢 4 Haneli Şifreniz</div>
        <input id="mgk-pin" type="password" inputmode="numeric" autocomplete="off" maxlength="4" placeholder="••••" style="${giris}">
        <div id="mgk-tekrar-kutu" style="display:none">
          <div style="font-size:0.9rem;font-weight:800;color:#e2e8f0;margin-bottom:4px">🔁 Şifreyi Tekrar Girin</div>
          <input id="mgk-pin2" type="password" inputmode="numeric" autocomplete="off" maxlength="4" placeholder="••••" style="${giris}">
        </div>
        <div id="mgk-durum" style="min-height:22px;font-size:0.92rem;font-weight:800;color:#fca5a5;text-align:center;margin-bottom:10px"></div>
        <button type="button" id="mgk-gir" style="width:100%;min-height:56px;border-radius:14px;border:2px solid #86efac;background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;font-size:1.15rem;font-weight:900">✓ GİRİŞ YAP</button>
        ${kullaniciDegistir ? '<button type="button" id="mgk-vazgec" style="width:100%;min-height:46px;margin-top:8px;border-radius:12px;border:1.5px solid #475569;background:#1e293b;color:#e2e8f0;font-size:0.95rem;font-weight:800">Vazgeç</button>' : ''}
      </div>`;
    document.body.appendChild(k);
    const adEl = document.getElementById('mgk-ad');
    const pinEl = document.getElementById('mgk-pin');
    const pin2El = document.getElementById('mgk-pin2');
    const durumEl = document.getElementById('mgk-durum');
    const bilgiEl = document.getElementById('mgk-bilgi');
    const tekrarKutu = document.getElementById('mgk-tekrar-kutu');
    const girBtn = document.getElementById('mgk-gir');
    let yeniHesap = false;
    (oncekiAd ? pinEl : adEl).focus();
    if (kullaniciDegistir) document.getElementById('mgk-vazgec').onclick = () => k.remove();

    let sorguZaman = null;
    const hesapSorgula = () => {
      clearTimeout(sorguZaman);
      sorguZaman = setTimeout(async () => {
        const ad = String(adEl.value || '').trim();
        if (ad.length < 3) return;
        try {
          const j = await _orijinalFetch('/api/kullanici/durum?ad=' + encodeURIComponent(ad), { cache: 'no-store' }).then(r => r.json());
          yeniHesap = !j.hesapVar;
        } catch (_) { yeniHesap = false; }
        tekrarKutu.style.display = yeniHesap ? 'block' : 'none';
        bilgiEl.innerHTML = yeniHesap ? '🆕 <span style="color:#86efac">İlk girişiniz:</span> Kendinize 4 haneli şifre belirleyin' : '🔢 4 Haneli Şifreniz';
        girBtn.textContent = yeniHesap ? '✓ ŞİFREMİ OLUŞTUR VE GİR' : '✓ GİRİŞ YAP';
      }, 350);
    };
    adEl.addEventListener('input', hesapSorgula);
    hesapSorgula();

    const gir = async () => {
      const ad = String(adEl.value || '').replace(/\s+/g, ' ').trim();
      const pin = String(pinEl.value || '').replace(/\D+/g, '').slice(0, 4);
      if (ad.length < 3 || !/[a-zA-ZçğıöşüÇĞİÖŞÜ]{2,}/.test(ad)) { durumEl.textContent = '⚠️ Lütfen adınızı yazın (en az 3 harf).'; adEl.focus(); return; }
      if (pin.length !== 4) { durumEl.textContent = '⚠️ Şifre tam 4 rakam olmalı.'; pinEl.focus(); return; }
      if (yeniHesap && String(pin2El.value || '').trim() !== pin) { durumEl.textContent = '⚠️ İki şifre aynı değil.'; pin2El.value = ''; pin2El.focus(); return; }
      durumEl.style.color = '#7dd3fc';
      durumEl.textContent = '⏳ Kontrol ediliyor…';
      let sonuc = null;
      try {
        const r = await _orijinalFetch('/api/kullanici/giris', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ad, pin })
        });
        sonuc = await r.json().catch(() => ({}));
      } catch (_) {
        // Bilgisayara ulaşılamıyorsa: bu telefonda daha önce aynı ad+şifreyle giriş yapılmış olmalı
        const ozet = await yerelOzet(ad, pin);
        if (ozet && (ozet === localStorage.getItem('mezat_yerel_giris_ozeti') || ozet === ortakOku('giris_ozeti'))) sonuc = { success: true, ad, jeton: oturumJetonu(), cevrimdisi: true };
        else sonuc = { success: false, error: 'Bilgisayara ulaşılamadı. İlk giriş için bilgisayar açık olmalı.' };
      }
      if (sonuc && sonuc.onayBekliyor) {
        durumEl.style.color = '#fde68a';
        durumEl.textContent = '⏳ ' + sonuc.error;
        pinEl.value = '';
        if (pin2El) pin2El.value = '';
        tekrarKutu.style.display = 'none';
        yeniHesap = false;
        bilgiEl.textContent = '🔢 4 Haneli Şifreniz';
        girBtn.textContent = '✓ GİRİŞ YAP';
        return;
      }
      if (!sonuc || !sonuc.success) {
        durumEl.style.color = '#fca5a5';
        durumEl.textContent = '❌ ' + ((sonuc && sonuc.error) || 'Giriş başarısız.');
        pinEl.value = '';
        if (pin2El) pin2El.value = '';
        pinEl.focus();
        return;
      }
      const adKesin = sonuc.ad || ad;
      if (sonuc.jeton) localStorage.setItem('mezat_oturum_jetonu', sonuc.jeton);
      if (sonuc.rol) localStorage.setItem('mezat_rol', sonuc.rol);
      if (typeof window.mezatKullaniciYonetimTusunuGuncelle === 'function') window.mezatKullaniciYonetimTusunuGuncelle();
      localStorage.setItem('urun_girisi_ad', adKesin);
      localStorage.setItem('mezat_yerel_giris_ozeti', await yerelOzet(adKesin, pin));
      ortakYaz('giris_ozeti', localStorage.getItem('mezat_yerel_giris_ozeti'));
      ortakYaz('giris_ad', adKesin);
      try { sessionStorage.setItem('mezat_oturum_ad', adKesin); } catch (_) {}
      girenAlaniniKilitle(adKesin);
      k.remove();
      if (sonuc.yeniHesap && typeof durum === 'function') durum(`✓ Hoş geldiniz ${adKesin}! Şifreniz oluşturuldu.`);
    };
    girBtn.onclick = gir;
    [adEl, pinEl, pin2El].forEach(el => el && el.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); gir(); } }));
  };
  window.mezatOturumAdi = () => (yerelBilgisayarMi ? (localStorage.getItem('urun_girisi_ad') || '') : oturumAdi());
  if (!yerelBilgisayarMi) {
    const ad = oturumAdi();
    if (ad && oturumJetonu()) setTimeout(() => girenAlaniniKilitle(ad), 0);
    else window.mezatGirisKapisiAc(false);
  }

  const HEDEF_ORAN = 16000;
  const EN_UZUN_SN = 60;
  const SESSIZLIK_MS = 3800;     // konuşurken nefes alma / etikete bakma payı; tam 3.8 sn susulursa veya düğmeye dokunulursa durur
  const HIC_SES_YOK_MS = 10000;  // düğmeye basıldı ama 10 sn hiç konuşulmadıysa
  const LISTE_YENILEME_MS = 4000; // başka telefonların girdikleri birkaç saniyede görünür
  let kayit = null;              // açık mikrofon
  let duzeltilenId = null;
  let duzeltilenSurum = 0;
  let listeSurumu = 0;
  let irsaliyeModu = false;
  let sayimOnayli = false;
  let irsaliyeKalemler = [];
  let seciliKalemIndeks = 0;
  let kaydedilenKalemler = new Set();
  let sonIrsaliyeGorseli = '';
  let sonSilinenSatir = null;
  let geriAlZamanlayici = null;
  let aktifIstekId = null;
  let sesliTeyitAcik = localStorage.getItem('urun_girisi_tts') !== '0';
  let pcBagli = true;

  function yeniIstekId() {
    return `istek-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function fiyatCozUst(deger) {
    if (deger === '' || deger == null) return null;
    const s = String(deger).trim().replace(/\s+/g, '');
    if (!s) return null;
    if (s.includes(',')) return Number(s.replace(/\./g, '').replace(',', '.'));
    if (/^\d{1,3}(?:\.\d{3})+$/.test(s)) return Number(s.replace(/\./g, ''));
    return Number(s);
  }

  // Gündüz / Gece yüksek kontrast teması ve Sesli Teyit (TTS) durumu
  if (localStorage.getItem('urun_girisi_tema') === 'acik') {
    document.body.classList.add('acik-tema');
  }
  function ustAraclariGuncelle() {
    if ($('sesli-teyit-btn')) {
      $('sesli-teyit-btn').classList.toggle('aktif', sesliTeyitAcik);
      $('sesli-teyit-btn').textContent = sesliTeyitAcik ? '🔊 Sesli Okuma: Açık' : '🔇 Sesli Okuma: Kapalı';
    }
    if ($('tema-degistir')) {
      const acik = document.body.classList.contains('acik-tema');
      $('tema-degistir').textContent = acik ? '🌙 Gece Moduna Geç (Şu An: Gündüz)' : '☀️ Gündüz Moduna Geç (Şu An: Gece)';
      $('tema-degistir').classList.toggle('aktif', acik);
      document.documentElement.classList.toggle('acik-tema', acik);
      const metaTheme = document.querySelector('meta[name="theme-color"]');
      if (metaTheme) metaTheme.setAttribute('content', acik ? '#e2e8f0' : '#080e1e');
      const metaScheme = document.querySelector('meta[name="color-scheme"]');
      if (metaScheme) metaScheme.setAttribute('content', acik ? 'light' : 'dark');
    }
  }
  if ($('sesli-teyit-btn')) {
    $('sesli-teyit-btn').addEventListener('click', () => {
      sesliTeyitAcik = !sesliTeyitAcik;
      localStorage.setItem('urun_girisi_tts', sesliTeyitAcik ? '1' : '0');
      ustAraclariGuncelle();
      if (sesliTeyitAcik) sesliOku('Sesli okuma açık.');
      else { try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (_) {} }
    });
  }
  if ($('tema-degistir')) {
    $('tema-degistir').addEventListener('click', () => {
      const acik = document.body.classList.toggle('acik-tema');
      localStorage.setItem('urun_girisi_tema', acik ? 'acik' : 'koyu');
      ustAraclariGuncelle();
      if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
      if ($('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
    });
  }
  ustAraclariGuncelle();

  // v108: Birinci sayfada sadece Ürün Girişi (mikrofon) + Kaydet görünür; diğer işlemler açılır menüde
  (function digerIslemlerMenusuKur() {
    const mikSatir = document.querySelector('.mikrofon-satir-kapsayici');
    const hizli = document.querySelector('.hizli-kamera-barkod-cubuk');
    const kaydetCubuk = document.querySelector('.kaydet-cubuk');
    if (!mikSatir || document.getElementById('diger-islemler-btn')) return;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'diger-islemler-btn';
    btn.innerHTML = '<span>⋯ Diğer İşlemler</span><span class="di-ok">▾</span>';
    const kutu = document.createElement('div');
    kutu.id = 'diger-islemler-kutu';
    const seviye = document.querySelector('.seviye');
    const sonraki = (seviye && seviye.parentNode === mikSatir.parentNode) ? seviye : mikSatir;
    sonraki.after(btn);
    btn.after(kutu);
    if (hizli) kutu.appendChild(hizli);
    if (kaydetCubuk) kutu.appendChild(kaydetCubuk);
    const satirEkleBtn = document.getElementById('satir-ekle');
    if (satirEkleBtn) kutu.prepend(satirEkleBtn);
    const kapat = () => { kutu.classList.remove('acik'); btn.classList.remove('acik'); };
    btn.addEventListener('click', () => {
      const acik = kutu.classList.toggle('acik');
      btn.classList.toggle('acik', acik);
    });
    // Menüden bir işlem seçilince menü kendiliğinden kapansın
    kutu.addEventListener('click', ev => { if (ev.target.closest('button')) setTimeout(kapat, 0); });
  })();

  function sesliOku(metin) {
    return; // v107: Sesli okuma kullanıcı isteğiyle tamamen kapatıldı
    if (!sesliTeyitAcik || !metin) return;
    try {
      const n = window.MezatNativeApp;
      if (n && typeof n.sesliOku === 'function' && n.sesliOku(String(metin))) return;
    } catch (_) {}
    if (!('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const ileti = new SpeechSynthesisUtterance(metin);
      ileti.lang = 'tr-TR';
      ileti.rate = 1.08;
      window.speechSynthesis.speak(ileti);
    } catch (err) {}
  }

  function tabloyuSesliOzetle() {
    const urun = $('urun').value.trim();
    const fiyat = $('fiyat').value.trim();
    const satirlar = satirlariOku().filter(s => s.adet != null && s.adet >= 0);
    if (!urun && !satirlar.length) return;
    const topAdet = satirlar.reduce((t, s) => t + (Number(s.adet) || 0), 0);
    const parcalar = [
      urun || 'Ürün',
      `${satirlar.length} satır, toplam ${topAdet} adet`,
      fiyat ? `fiyat ${fiyat} lira` : ''
    ].filter(Boolean);
    sesliOku(parcalar.join(', '));
  }

  // Kim giriyor: telefon hatırlar
  $('giren').value = localStorage.getItem('urun_girisi_ad') || '';
  $('giren').addEventListener('input', () => {
    localStorage.setItem('urun_girisi_ad', $('giren').value.trim());
    $('giren').classList.toggle('eksik', !$('giren').value.trim());
  });
  $('giren').classList.toggle('eksik', !$('giren').value.trim());

  const oge = (etiket, ozellik = {}, ...cocuk) => {
    const e = document.createElement(etiket);
    Object.assign(e, ozellik);
    e.append(...cocuk.filter(c => c !== null && c !== undefined));
    return e;
  };
  const post = (yol, govde) => fetch(yol, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(govde) })
    .then(r => r.json());
  let duzeltmePenceresiModu = false;
  let devamEdenUrunGrubu = false;

  function calismaPenceresiniAc(kip = 'giris') {
    if (kip === 'duzelt') duzeltmePenceresiModu = true;
    document.body.classList.add('calisma-penceresi-acik');
    if ($('calisma-pencere-baslik')) {
      $('calisma-pencere-baslik').textContent = duzeltmePenceresiModu
        ? '✎ ÜRÜN DÜZELTME PENCERESİ'
        : '📦 ÜRÜN & BEDEN GİRİŞ PENCERESİ';
    }
  }

  function calismaPenceresiniKapat(temizle = false) {
    if (kayit && kayit.iptalEt) {
      try { kayit.iptalEt(''); } catch (_) {}
    }
    duzeltmePenceresiModu = false;
    devamEdenUrunGrubu = false;
    if ($('calisma-grup-ozet')) {
      $('calisma-grup-ozet').textContent = '';
      $('calisma-grup-ozet').classList.remove('aktif-ozet');
    }
    if (temizle && typeof formuTemizle === 'function') {
      formuTemizle();
    }
    document.body.classList.remove('calisma-penceresi-acik');
  }

  function durum(metin, hata = false) {
    if (window.__ocrIzAktif && metin) ocrIz(`${hata ? '⚠ ' : ''}${metin}`, false, !!hata);
    $('durum').textContent = metin || '';
    $('durum').classList.toggle('hata', hata);
    if (metin && $('calisma-pencere-durum')) {
      $('calisma-pencere-durum').textContent = metin;
      const basarili = /^[✓✅]/.test(String(metin).trim());
      $('calisma-pencere-durum').classList.toggle('durum-hata', Boolean(hata));
      $('calisma-pencere-durum').classList.toggle('durum-basarili', !hata && basarili);
      $('calisma-pencere-durum').style.removeProperty('background');
      $('calisma-pencere-durum').style.removeProperty('color');
      $('calisma-pencere-durum').style.removeProperty('border-color');
    }
    if (metin && $('etiket-panel') && !$('etiket-panel').classList.contains('gizli') && $('etiket-odak-durum')) {
      $('etiket-odak-durum').textContent = metin;
      $('etiket-odak-durum').style.borderColor = hata ? '#ef4444' : '#14b8a6';
      $('etiket-odak-durum').style.color = hata ? '#fecaca' : '#f8fafc';
    }
    if (metin && document.body.classList.contains('dinliyor-aktif') && $('ses-odak-baslik')) {
      $('ses-odak-baslik').textContent = metin;
    }
    if ($('ses-odak-mevcut-urun')) {
      const mUrun = $('urun') ? $('urun').value.trim() : '';
      const mBarkod = $('barkod') ? $('barkod').value.trim() : '';
      $('ses-odak-mevcut-urun').textContent = (mUrun || mBarkod)
        ? `📦 Seçili: ${mUrun || 'Ürün Adı Bekleniyor'}${mBarkod ? ` [${mBarkod}]` : ''}`
        : '';
    }
  }

  // ===== Ses kaydı =====
  function wav(ornekler) {
    const tampon = new ArrayBuffer(44 + ornekler.length * 2);
    const v = new DataView(tampon);
    const yaz = (konum, metin) => [...metin].forEach((c, i) => v.setUint8(konum + i, c.charCodeAt(0)));
    yaz(0, 'RIFF'); v.setUint32(4, 36 + ornekler.length * 2, true); yaz(8, 'WAVEfmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, HEDEF_ORAN, true); v.setUint32(28, HEDEF_ORAN * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    yaz(36, 'data'); v.setUint32(40, ornekler.length * 2, true);
    ornekler.forEach((d, i) => v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, d)) * 32767, true));
    return tampon;
  }

  // Telefon 16 kHz açamazsa ses 16 kHz'e indirilir
  function indir(ornekler, oran) {
    if (oran === HEDEF_ORAN) return ornekler;
    const kat = oran / HEDEF_ORAN;
    const sonuc = new Float32Array(Math.floor(ornekler.length / kat));
    for (let i = 0; i < sonuc.length; i++) {
      const bas = Math.floor(i * kat);
      const son = Math.min(ornekler.length, Math.floor((i + 1) * kat));
      let top = 0;
      for (let j = bas; j < son; j++) top += ornekler[j];
      sonuc[i] = top / Math.max(1, son - bas);
    }
    return sonuc;
  }

  async function httpsAdreseYonlendirUyarisi(ozellikAdi = 'Mikrofon ve Canlı Kamera') {
    try {
      const v = await fetch('/api/mobil-baglanti', { cache: 'no-store' }).then(r => r.json());
      if (v && v.httpsAktif && v.httpsUrl) {
        // iPhone/iPad yalnız Mezatron Yerel Kok ile imzalı iPhone kapısına (3443) güvenir; Android kapısı (3442) iPad'de "güvenli değil" uyarısı verir
        const iosCihaz = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
        const taban = iosCihaz && v.iphoneAktif && v.iphonePort ? `https://${v.yerelIp || window.location.hostname}:${v.iphonePort}` : v.httpsUrl;
        const hedef = `${taban}${window.location.pathname}${window.location.search}`;
        durum(`🔒 Telefonda ${ozellikAdi} için güvenli bağlantı (HTTPS) gerekiyor: ${hedef} adresine geçiliyor…`, true);
        if ($('mobil-baglanti-panel')) {
          $('mobil-baglanti-panel').classList.remove('gizli');
          mobilBaglantiDurumuGuncelle();
        }
        return hedef;
      }
    } catch (_) {}
    durum(`Bu bağlantıda telefon ${ozellikAdi.toLowerCase()} açılmıyor. Sağ üstten "📱 Telefona Bağla" düğmesine basıp HTTPS (3442) adresine dokunun.`, true);
    return '';
  }

  // Bilgisayar kapalıyken ses telefondaki iki motorla çözülür (yalnız bu özelliği olan uygulama sürümünde)
  function telefonMotoruVarMi() {
    try { return Boolean(window.MezatNativeApp && typeof window.MezatNativeApp.telefonMotorVar === 'function' && window.MezatNativeApp.telefonMotorVar()); } catch (_) { return false; }
  }

  function telefonMotoruylaDinle(bekleme = 0) {
    const yerlesik = window.MezatNativeApp;
    const istekNo = ++aktifSesIstekSayaci;
    const oncekiSoz = $('soz') ? $('soz').value.trim() : '';
    const cozuluyorGoster = () => {
      const d = $('mikrofon');
      d.classList.remove('dinliyor');
      d.classList.add('cozuluyor');
      d.disabled = true;
      d.firstChild.textContent = '… YAZIYA ÇEVRİLİYOR';
      $('seviye').style.width = '0%';
    };
    if (!yerlesik.dinlemeBasla()) {
      const engel = typeof yerlesik.sonBaslamaEngeli === 'function' ? yerlesik.sonBaslamaEngeli() : '';
      if (engel === 'mesgul' && bekleme < 20) {
        durum('Önceki ses işi bitiyor, birazdan dinlemeye başlayacak…');
        setTimeout(() => { if (istekNo === aktifSesIstekSayaci && !kayit) telefonMotoruylaDinle(bekleme + 1); }, 400);
        return;
      }
      if (engel === 'izin') durum('Mikrofon izni istendi. İzin verip düğmeye yeniden basın.', true);
      else if (engel === 'mesgul') durum('Önceki ses işi bitmedi. Uygulamayı tamamen kapatıp açın.', true);
      else durum('Mikrofon açılamadı. Mikrofon iznini kontrol edip tekrar deneyin.', true);
      return;
    }
    const oturum = { bitti: false, basladi: Date.now() };
    const kapat = () => { oturum.bitti = true; if (kayit === oturum) kayit = null; };
    oturum.bitir = () => {
      if (oturum.bitti) return;
      kapat();
      cozuluyorGoster();
      yerlesik.dinlemeBitir(false);
    };
    oturum.iptalEt = (mesaj = '↺ Ses girişi iptal edildi.') => {
      if (oturum.bitti) return;
      kapat();
      window.__mezatMotorGeri = null;
      yerlesik.dinlemeBitir(true);
      $('seviye').style.width = '0%';
      dugmeHazir();
      if (mesaj) durum(mesaj);
    };
    kayit = oturum;
    window.__mezatMotorGeri = metin => {
      if (istekNo !== aktifSesIstekSayaci) return;
      const m = JSON.parse(metin);
      if (m.tur === 'seviye') { if (!oturum.bitti) $('seviye').style.width = `${m.deger}%`; return; }
      if (m.tur === 'cozuluyor') { kapat(); cozuluyorGoster(); return; }
      if (m.tur === 'hazirlaniyor') { durum('Ses motorları hazırlanıyor, bu ilk seferde birkaç saniye sürer…'); return; }
      kapat();
      window.__mezatMotorGeri = null;
      $('seviye').style.width = '0%';
      dugmeHazir();
      if (m.tur === 'sessiz') { durum('Ses duyulmadı. Düğmeye basıp tekrar söyleyin.', true); return; }
      if (m.tur === 'hata') { durum('⚠️ ' + m.metin, true); return; }
      const cozum = window.MezatMobilHibrit ? window.MezatMobilHibrit.telefonMotorSonucu(m) : null;
      if (!cozum || !cozum.success) { durum((cozum && cozum.error) || 'Ses anlaşılmadı. Tekrar söyleyin.', true); return; }
      sesSonucunuUygula(cozum, oncekiSoz);
      durum(cozum.motorlarAyrildi ? '⚠️ İki motor ürün adını farklı anladı, adı kontrol edip Kaydet\'e basın.' : '📲 Ses telefonda çözüldü. Kontrol edip Kaydet\'e basın.', Boolean(cozum.motorlarAyrildi));
    };
    const d = $('mikrofon');
    d.classList.add('dinliyor');
    d.firstChild.textContent = '● DİNLİYORUM (Bitirmek için dokunun)';
    d.querySelector('small').textContent = 'Konuştuğunuz sürece kapanmaz. Bitince dokunun ya da 4 saniye susun.';
    if ($('kaydet')) $('kaydet').disabled = true;
    if ($('kaydet-ve-bas')) $('kaydet-ve-bas').disabled = true;
    durum('');
  }

  if (location.protocol === 'file:' && telefonMotoruVarMi()) {
    setTimeout(() => { try { window.MezatNativeApp.motorHazirla(); } catch (_) {} }, 1500);
  }

  // Barkod bankası: bilgisayarla bağlıyken ve giriş yapılmışken telefona alınır
  let barkodBankasiAliniyor = false;
  async function barkodBankasiniTelefonaAl() {
    if (barkodBankasiAliniyor || location.protocol === 'file:' || !telefonMotoruVarMi() || !window.MezatMobilHibrit) return;
    const ad = typeof window.mezatOturumAdi === 'function' ? window.mezatOturumAdi() : '';
    if (!ad || !localStorage.getItem('mezat_oturum_jetonu')) return;
    barkodBankasiAliniyor = true;
    try {
      const r = await fetch(`/api/envanter/barkod-bankasi?q=&_t=${Date.now()}`, { cache: 'no-store', signal: AbortSignal.timeout(8000) });
      if (r.ok) {
        const veri = await r.json();
        if (veri && veri.sifirlamaMs && typeof window.MezatMobilHibrit.bilgisayarTemizliginiUygula === 'function') {
          const t = window.MezatMobilHibrit.bilgisayarTemizliginiUygula(veri.sifirlamaMs);
          if (t && t.temizlendi) {
            durum('🧹 Bilgisayarda liste temizlendi; telefondaki eski kayıtlar da temizlendi.');
            try { listeSurumu = 0; listeyiYenile(); } catch (_) {}
          }
        }
        window.MezatMobilHibrit.barkodBankasiniSakla(veri);
      }
    } catch (_) {
    } finally {
      barkodBankasiAliniyor = false;
    }
  }
  if (telefonMotoruVarMi() && location.protocol !== 'file:') {
    setTimeout(barkodBankasiniTelefonaAl, 4000);
    setInterval(barkodBankasiniTelefonaAl, 300000);
  }

  // Telefondaki bekleyen kayıtlar, bilgisayarla bağlıyken ve giriş yapılmışken kendiliğinden aktarılır
  function bekleyenleriOtomatikAktar() {
    if (location.protocol === 'file:' || !telefonMotoruVarMi() || !window.MezatMobilHibrit) return;
    const ad = typeof window.mezatOturumAdi === 'function' ? window.mezatOturumAdi() : '';
    if (!ad || !localStorage.getItem('mezat_oturum_jetonu')) return;
    if (!window.MezatMobilHibrit.bekleyenKuyruguOku().length) return;
    window.MezatMobilHibrit.bekleyenleriBilgisayaraAktar().then(s => {
      if (s.aktarilan > 0) {
        listeyiYenile();
        durum(`✅ Telefonda bekleyen ${s.aktarilan} kayıt bilgisayara aktarıldı.`);
        barkodBankasiniTelefonaAl();
      }
    }).catch(() => {});
  }
  if (telefonMotoruVarMi() && location.protocol !== 'file:') {
    setTimeout(bekleyenleriOtomatikAktar, 2500);
    setInterval(bekleyenleriOtomatikAktar, 15000);
  }

  // Bilgisayara kendiliğinden bağlanınca kaldığı sayfaya (barkod) döner
  if (location.protocol !== 'file:' && window.MezatNativeApp) {
    setTimeout(() => {
      const donus = ortakOku('donus_sayfasi');
      if (!donus) return;
      try { window.MezatNativeApp.ortakYaz('donus_sayfasi', ''); } catch (_) {}
      if (donus === 'barkod' && typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('barkod');
    }, 1200);
  }

  // Telefon kendi sayfasındayken bilgisayar geri gelirse: boştaysa bağlanır, işlem varsa haber verir
  window.__mezatBilgisayarBulundu = () => {
    if (location.protocol !== 'file:' || !window.MezatNativeApp || !window.MezatNativeApp.bilgisayaraDon) return;
    const sayfa = document.body.dataset.aktifSayfa || 'ses';
    const soz = $('soz') ? $('soz').value.trim() : '';
    // Barkod sayfasında yarım okutma ve açık menü yoksa da bağlanır; bağlanınca barkod sayfasına döner
    const menuEl = $('barkod-diger');
    const menuAcik = Boolean(menuEl && menuEl.classList && menuEl.classList.contains('acik'));
    const barkodBos = sayfa === 'barkod' && !bekleyenBarkodKaydi && !menuAcik;
    if (!kayit && !mevcutTabloDurumuAl() && !soz && (sayfa === 'ses' || barkodBos)) {
      if (barkodBos) { try { window.MezatNativeApp.ortakYaz('donus_sayfasi', 'barkod'); } catch (_) {} }
      window.MezatNativeApp.bilgisayaraDon();
      return;
    }
    if (document.getElementById('mezat-bilgisayar-bulundu')) return;
    const b = document.createElement('button');
    b.id = 'mezat-bilgisayar-bulundu';
    b.type = 'button';
    b.textContent = '💻 Bilgisayar bulundu. Bağlanmak ve kayıtları aktarmak için dokunun.';
    b.style.cssText = 'position:fixed;left:10px;right:10px;top:10px;z-index:99998;min-height:52px;padding:10px 12px;border:2px solid #6ee7b7;border-radius:12px;background:#047857;color:#fff;font-size:1rem;font-weight:900';
    b.onclick = () => window.MezatNativeApp.bilgisayaraDon();
    document.body.appendChild(b);
  };

  // Sayfa bilgisayardan açılmışken bağlantı kesilmiş olabilir; eski bilgiye güvenilmez, o anda bakılır
  function bilgisayaraSimdiUlasilamiyor() {
    try { return typeof window.MezatNativeApp.bilgisayarVarMi === 'function' && !window.MezatNativeApp.bilgisayarVarMi(); } catch (_) { return false; }
  }

  async function dinlemeyiBaslat() {
    if (telefonMotoruVarMi() && (location.protocol === 'file:' || !pcBagli || bilgisayaraSimdiUlasilamiyor())) {
      telefonMotoruylaDinle();
      return;
    }
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      await httpsAdreseYonlendirUyarisi('Canlı Mikrofon');
      return;
    }
    let akis;
    try {
      // Bluetooth kulaklık ve mobil cihazlarda ilk harflerin ("G-ezer", "B-arbara", "S beden") yutulmaması için
      // tarayıcının ikinci kez gürültü/eko kesmesi (echoCancellation/noiseSuppression) kapatılır; saf ses alınır.
      akis = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: true,
          channelCount: 1
        }
      });
    } catch (err) {
      durum('Mikrofon izni verilmedi. Tarayıcı adres çubuğundaki kilit/kamera simgesinden mikrofon izni verin.', true);
      return;
    }

    // Paralel Tarayıcı Ses Tanıma (WebSpeech tr-TR):
    // DİKKAT: Android telefonlarda getUserMedia ile webkitSpeechRecognition aynı anda açıldığında
    // Android ses yönlendiricisi ilk 0.6 saniyelik mikrofon sesini kesip kelimenin başını ("V yaka" / "M beden") bozar!
    // Bu yüzden mobil cihazlarda mikrofon kanalı %100 saf WAV olarak doğrudan yerel GPU Whisper motoruna gider.
    let canliWebSpeechMetin = '';
    let sonSesMs = 0;
    let konustu = false;
    let webSpeechTanima = null;
    const mobilCihazMi = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent || '');
    // PC bağlıyken mobilde ses %100 saf WAV olarak Whisper'a gider; PC kapalıyken (!pcBagli) telefonun kendi ses tanıması devreye girer!
    const SpeechRec = (!mobilCihazMi || !pcBagli) && (window.SpeechRecognition || window.webkitSpeechRecognition);
    if (SpeechRec) {
      try {
        webSpeechTanima = new SpeechRec();
        webSpeechTanima.lang = 'tr-TR';
        webSpeechTanima.continuous = true;
        webSpeechTanima.interimResults = true;
        webSpeechTanima.onresult = ev => {
          const parcalarMetin = [];
          for (let i = 0; i < ev.results.length; i++) {
            const parca = ev.results[i][0] && ev.results[i][0].transcript ? ev.results[i][0].transcript.trim() : '';
            if (parca) parcalarMetin.push(parca);
          }
          const birlesik = parcalarMetin.join(' ').trim();
          if (birlesik) {
            canliWebSpeechMetin = birlesik;
            sonSesMs = Date.now();
            konustu = true;
          }
        };
        webSpeechTanima.onerror = () => {};
        webSpeechTanima.start();
      } catch (_) {
        webSpeechTanima = null;
      }
    }

    let baglam;
    try { baglam = new AudioContext({ sampleRate: HEDEF_ORAN }); } catch (err) { baglam = new AudioContext(); }
    try {
      await baglam.audioWorklet.addModule('mic-worklet.js');
    } catch (err) {
      // Parça bilgisayardan alınamadıysa mikrofon açık bırakılmaz; telefonda motor varsa onunla devam edilir
      try { akis.getTracks().forEach(t => t.stop()); baglam.close(); if (webSpeechTanima) webSpeechTanima.stop(); } catch (_) {}
      if (!telefonMotoruVarMi()) throw err;
      pcBagli = false;
      telefonMotoruylaDinle();
      return;
    }
    const dugum = new AudioWorkletNode(baglam, 'mic-capture');

    // Telefonda çift filtreleme (boğuklaşma) olmaması için yalnızca 75 Hz alt uğultu kesici uygulanır;
    // asıl 75-7600 Hz geniş bant DSP ve otomatik kazanç sunucuda (evrensel_motor.js) yapılır.
    const altKesici = baglam.createBiquadFilter();
    altKesici.type = 'highpass';
    altKesici.frequency.value = 75;
    altKesici.Q.value = 0.707;

    const parcalar = [];
    const basladi = Date.now();
    let konusmaKareSayisi = 0;
    let gurultu = 0.006;
    kayit = { akis, baglam, bitti: false, basladi };
    dugum.port.onmessage = olay => {
      if (!kayit || kayit.bitti) return;
      const p = olay.data;
      parcalar.push(p);
      let top = 0;
      for (let i = 0; i < p.length; i++) top += p[i] * p[i];
      const guc = Math.sqrt(top / p.length);
      const gecen = Date.now() - basladi;
      // Yalnızca gerçekten sessiz çerçevelerde (guc < 0.014) arka plan gürültü tabanını güncelle; konuşma sesini asla gürültü tabanı sanma!
      if (guc < 0.014) {
        gurultu = Math.min(0.014, gurultu * 0.96 + guc * 0.04);
      }
      const baslangicEsik = Math.min(0.024, Math.max(0.009, gurultu * 1.7));
      // Konuşma bir kez başladıktan sonra kısık hecelerde bile kapanmaması için devam eşiğini çok daha hassas tut (histerezis)
      const devamEsik = Math.min(0.015, Math.max(0.0055, gurultu * 1.3));
      if (!konustu) {
        if (guc > baslangicEsik) {
          konusmaKareSayisi += 1;
          if (konusmaKareSayisi >= 2) {
            sonSesMs = Date.now();
            konustu = true;
          }
        } else if (canliWebSpeechMetin.length > 0) {
          sonSesMs = Date.now();
          konustu = true;
        }
      } else if (guc > devamEsik) {
        sonSesMs = Date.now();
      }
      $('seviye').style.width = `${Math.min(100, Math.round(guc / 0.10 * 100))}%`;
      if (konustu && sonSesMs && Date.now() - sonSesMs > SESSIZLIK_MS) bitir();
      else if (!konustu && gecen > HIC_SES_YOK_MS) bitir(true);
      else if (gecen > EN_UZUN_SN * 1000) bitir();
    };
    const kaynak = baglam.createMediaStreamSource(akis);
    kaynak.connect(altKesici);
    altKesici.connect(dugum);
    $('mikrofon').classList.add('dinliyor');
    $('mikrofon').firstChild.textContent = '● DİNLİYORUM (Bitirmek için dokunun)';
    $('mikrofon').querySelector('small').textContent = 'Konuştuğunuz sürece kapanmaz. Bitince dokunun ya da 4 saniye susun.';
    if ($('kaydet')) $('kaydet').disabled = true;
    if ($('kaydet-ve-bas')) $('kaydet-ve-bas').disabled = true;
    durum('');

    function iptalEt(mesaj = '↺ Ses girişi iptal edildi.') {
      if (!kayit || kayit.bitti) return;
      kayit.bitti = true;
      if (webSpeechTanima) {
        try { webSpeechTanima.stop(); } catch (_) {}
      }
      try { akis.getTracks().forEach(t => t.stop()); } catch (_) {}
      try { baglam.close(); } catch (_) {}
      kayit = null;
      $('seviye').style.width = '0%';
      dugmeHazir();
      if (mesaj) durum(mesaj);
    }

    async function bitir(sessiz = false) {
      if (!kayit || kayit.bitti) return;
      kayit.bitti = true;
      if (webSpeechTanima) {
        try { webSpeechTanima.stop(); } catch (_) {}
      }
      akis.getTracks().forEach(t => t.stop());
      const oran = baglam.sampleRate;
      baglam.close();
      kayit = null;
      $('seviye').style.width = '0%';
      if ((sessiz || !konustu) && !canliWebSpeechMetin) {
        dugmeHazir();
        durum('Ses duyulmadı. Düğmeye basıp tekrar söyleyin.', true);
        return;
      }
      const toplam = parcalar.reduce((t, p) => t + p.length, 0);
      const ornekler = new Float32Array(toplam);
      let konum = 0;
      parcalar.forEach(p => { ornekler.set(p, konum); konum += p.length; });
      await sesiGonder(wav(indir(ornekler, oran)), canliWebSpeechMetin);
    }
    kayit.bitir = bitir;
    kayit.iptalEt = iptalEt;
  }

  function dugmeHazir() {
    const d = $('mikrofon');
    if (!d) return;
    d.classList.remove('dinliyor', 'cozuyor');
    d.disabled = false;
    if ($('kaydet')) $('kaydet').disabled = false;
    if ($('kaydet-ve-bas')) $('kaydet-ve-bas').disabled = false;
    const aktifSayfa = document.body.dataset.aktifSayfa || 'ses';
    if (aktifSayfa === 'etiket' || aktifSayfa === 'barkod' || aktifSayfa === 'irsaliye') {
      d.firstChild.textContent = '🎙️ Sesle Tamamla';
    } else {
      d.firstChild.textContent = '🎙️ ÜRÜN GİRİŞİ';
    }
    if (d.querySelector('small')) {
      d.querySelector('small').textContent = 'Basın ve söyleyin. Susunca kendiliğinden durur.';
    }
  }

  function sesAnaliziGoster(cevap) {
    const kutu = $('ses-analiz-cubuk');
    if (!kutu) return;
    const analiz = cevap && cevap.sesAnalizi;
    const iz = (cevap && (cevap.konusmaciIzi || cevap.konusmaci)) || null;
    if (!analiz && !iz) {
      kutu.classList.add('gizli');
      return;
    }
    const parcalar = [];
    if (analiz) {
      const snr = analiz.snrDb ?? 0;
      const gurultuTabani = analiz.noiseFloorDb ?? analiz.gurultuTabaniDb ?? -45;
      const kazanc = analiz.kazancDb ?? analiz.uygulananKazanc ?? 1;
      const sureMs = analiz.motorSureMs ?? (cevap && cevap.motorMs) ?? 0;
      const snrRenk = snr >= 15 ? '🟢' : (snr >= 10 ? '🟡' : '🟠');
      parcalar.push(`${snrRenk} SNR: +${snr} dB`);
      parcalar.push(`Gürültü: ${gurultuTabani} dBFS`);
      parcalar.push(`75-7600Hz DSP (x${kazanc})`);
      if (sureMs) parcalar.push(`⚡ ${sureMs} ms`);
    }
    if (iz && (iz.var || iz.checked)) {
      const yuzde = Math.round(((iz.benzerlik ?? iz.score) || 0) * 100);
      const benim = iz.benim ?? !iz.blocked;
      parcalar.push(benim ? `🗣️ Ses İzi Doğrulandı (%${yuzde})` : `👥 Farklı Konuşmacı (%${yuzde})`);
    }
    if (cevap && cevap.hakemOnayli) {
      parcalar.push(`🤖 DeepSeek Hakem (${cevap.hakemSureMs || 0} ms)`);
    }
    kutu.textContent = parcalar.join(' · ');
    kutu.classList.remove('gizli');
  }

  function mevcutTabloDurumuAl() {
    const urun = $('urun') ? $('urun').value.trim() : '';
    const fiyat = $('fiyat') ? fiyatCozUst($('fiyat').value) : null;
    const satirlar = satirlariOku().filter(s => s.renk || s.beden || (s.adet != null && s.adet > 0));
    if (!urun && !fiyat && satirlar.length === 0) return null;
    return { urun, fiyat, satirlar };
  }

  let aktifSesIstekSayaci = 0;

  async function sesiGonder(veri, yedekWebSpeech = '') {
    const istekNo = ++aktifSesIstekSayaci;
    const d = $('mikrofon');
    d.classList.remove('dinliyor');
    d.classList.add('cozuyor');
    d.disabled = true;
    d.firstChild.textContent = '… YAZIYA ÇEVRİLİYOR';
    try {
      const basliklar = { 'Content-Type': 'audio/wav' };
      if (yedekWebSpeech && String(yedekWebSpeech).trim()) {
        basliklar['X-WebSpeech-Metin'] = encodeURIComponent(String(yedekWebSpeech).trim());
      }
      const mevcutDurum = mevcutTabloDurumuAl();
      if (mevcutDurum) {
        basliklar['X-Mevcut-Durum'] = encodeURIComponent(JSON.stringify(mevcutDurum));
      }
      const cevap = await fetch('/api/envanter/ses', { method: 'POST', headers: basliklar, body: veri }).then(r => r.json());
      if (istekNo !== aktifSesIstekSayaci) return;
      sesAnaliziGoster(cevap);
      const oncekiSoz = $('soz') ? $('soz').value.trim() : '';
      if (!cevap.success) {
        if (cevap.ortamSesiReddedildi) {
          durum(cevap.error || '⚠️ Ortam / TV sesi algılandı, ürün olarak kaydedilmedi.', true);
          return;
        }
        if (yedekWebSpeech && String(yedekWebSpeech).trim()) {
          try {
            const yedekCevap = await post('/api/envanter/coz', { metin: String(yedekWebSpeech).trim(), mevcutDurum });
            if (istekNo !== aktifSesIstekSayaci) return;
            if (yedekCevap && yedekCevap.success) {
              sesSonucunuUygula(yedekCevap, oncekiSoz);
              durum('✓ Ses tabloya aktarıldı. Kontrol edip Kaydet\'e basın.');
              return;
            }
          } catch (_) {}
          if (window.MezatMobilHibrit) {
            const yerelCozum = window.MezatMobilHibrit.envanterCozYerel(String(yedekWebSpeech).trim());
            if (yerelCozum && yerelCozum.success) {
              sesSonucunuUygula(yerelCozum, oncekiSoz);
              durum('📲 Bağımsız Mobil Mod: Ses telefonda çözümlendi. Kontrol edip Kaydet\'e basın.');
              return;
            }
          }
        }
        durum(cevap.error || 'Ses anlaşılmadı.', true);
        return;
      }
      sesSonucunuUygula(cevap, oncekiSoz);
      durum(cevap.hakemOnayli ? '🤖 Hakem doğruladı. Kontrol edip Kaydet\'e basın.' : 'Tabloyu kontrol edin, doğruysa Kaydet\'e basın.');
    } catch (err) {
      if (istekNo !== aktifSesIstekSayaci) return;
      pcBagli = false;
      const oncekiSoz = $('soz') ? $('soz').value.trim() : '';
      if (yedekWebSpeech && String(yedekWebSpeech).trim() && window.MezatMobilHibrit) {
        const yerelCozum = window.MezatMobilHibrit.envanterCozYerel(String(yedekWebSpeech).trim());
        if (yerelCozum && yerelCozum.success) {
          sesSonucunuUygula(yerelCozum, oncekiSoz);
          durum('📲 Bilgisayar kapalı — Ses doğrudan telefonda çözümlendi! Kaydet\'e basabilirsiniz.');
          return;
        }
      }
      durum('📲 Bilgisayar kapalı (Bağımsız Mobil Mod aktif). Tekrar konuşun veya kutuya yazıp Tabloya Aktar\'a basın.');
    } finally {
      dugmeHazir();
    }
  }

  // Fotoğraf, barkod veya önceki ses kaydıyla ürün/beden zaten doldurulduysa ve kişi parça parça konuşmaya devam ettiyse
  // (Örn: 1. cümle "Sarı keten gömlek", 2. cümle "5 adet M beden", 3. cümle "fiyatı 1250 lira") mevcut tabloyu ezmeden akıllıca birleştirir!
  function sesSonucunuUygula(cevap, oncekiSoz = '') {
    aktifIstekId = null;
    const yeniMetin = String(cevap.metin || '').trim();
    const sozKucuk = (yeniMetin || ($('soz') && $('soz').value) || '').toLocaleLowerCase('tr-TR').trim();
    const sadecKaydetKomutu = /^(?:onayla(?:\s+ve)?\s+kaydet|sayımı\s+onayla(?:\s+ve)?\s+kaydet|hepsini\s+kaydet|kaydet|tamam\s+kaydet)[.!?\s]*$/i.test(sozKucuk);
    if (sadecKaydetKomutu && $('urun').value.trim()) {
      durum('Güvenlik için sesle doğrudan kayıt yapılmaz. Tabloyu gözle kontrol edip "✓ KAYDET" düğmesine dokunun.');
      if ($('kaydet')) $('kaydet').scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    if (irsaliyeModu) {
      if (yeniMetin && $('soz')) $('soz').value = yeniMetin;
      if (cevap.fiyat) $('fiyat').value = String(cevap.fiyat);
      if (cevap.urun && !$('urun').value.trim()) $('urun').value = cevap.urun;
      // Sesle spesifik bir bedenin sayım sonucu söylendiyse ("41'den 2 çıktı", "42 numara 3 tane")
      const trListesi = [...$('satirlar').querySelectorAll('tr')];
      let satirGuncellendi = false;
      for (const s of (cevap.satirlar || [])) {
        if (!s.beden && !s.renk) continue;
        if (s.adet == null) continue;
        for (const tr of trListesi) {
          const [rIn, bIn, aIn] = tr.querySelectorAll('input');
          const rEs = !s.renk || rIn.value.trim().toLocaleUpperCase('tr-TR') === String(s.renk).toLocaleUpperCase('tr-TR');
          const bEs = !s.beden || bIn.value.trim().toLocaleUpperCase('tr-TR') === String(s.beden).toLocaleUpperCase('tr-TR');
          if (rEs && bEs) {
            aIn.value = String(s.adet);
            tr.dataset.sayildi = '1';
            satirGuncellendi = true;
          }
        }
      }
      // Yalnız açıkça "hepsini saydım / tüm satırlar sayıldı" dendiyse tüm satırları sayıldı işaretle ("tamam" gibi genel kelimelerle otomatik onaylanmaz)
      if (!satirGuncellendi && /^(?:hepsini\s+sayd[ıi]m|t[üu]m\s+sat[ıi]rlar\s+say[ıi]ld[ıi]|hepsi\s+tam\s+say[ıi]ld[ıi]|say[ıi]m\s+tamamland[ıi])[.!?\s]*$/i.test(sozKucuk)) {
        trListesi.forEach(tr => { tr.dataset.sayildi = '1'; });
        satirGuncellendi = true;
      }
      if (satirGuncellendi || cevap.fiyat) {
        toplamYaz();
        tabloyuSesliOzetle();
        return;
      }
    }

    let mevcutUrun = $('urun').value.trim();
    let mevcutFiyat = fiyatCozUst($('fiyat').value);
    let mevcutSatirlar = satirlariOku().filter(s => s.renk || s.beden || (s.adet != null && s.adet > 0));
    const yeniSatirlar = Array.isArray(cevap.satirlar) ? cevap.satirlar : [];

    // "Aynısından", "bunun", "bir de", "devamı", "yat", "fiyat" gibi ifadeler ürün adına sızdıysa temizle
    if (cevap.urun && /^(?:ayn[ıi]\p{L}*|bunun|bundan|bir\s*de|devam\p{L}*|ilave|ek|ekle|yat|fiyat\p{L}*|seymiştir|seymistir|adet|tane)$/iu.test(cevap.urun.trim())) {
      cevap.urun = '';
    }

    const aynisindanSoruMu = /\b(?:ayn[ıi]s[ıi]\p{L}*|ayn[ıi]\s+(?:[üu]r[üu]n|model)\p{L}*|bunun|bundan|bir\s+de|devam[ıi]|ilave)\b/iu.test(sozKucuk);

    // Eğer ekrandaki kart boşsa (az önce Kaydet'e basıldığı için temizlendiyse) ve kullanıcı yeni ürün adı söylemeden
    // sadece devam bedeni/adedi söylediyse ("beden M adet 10" veya "aynısından XL 3 adet") ya da bugün kaydedilmiş aynı ürün adını söylediyse
    // otomatik olarak o kartı geri açıp bedenleri aynı kartın içine ekle!
    if (!mevcutUrun && Array.isArray(window.__BUGUNKU_KAYITLAR__) && window.__BUGUNKU_KAYITLAR__.length > 0) {
      let hedefKayit = null;
      if (aynisindanSoruMu || (!cevap.urun && yeniSatirlar.length > 0)) {
        hedefKayit = window.__BUGUNKU_KAYITLAR__[window.__BUGUNKU_KAYITLAR__.length - 1];
      } else if (cevap.urun) {
        const arananAnahtar = cevap.urun.toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
        hedefKayit = [...window.__BUGUNKU_KAYITLAR__].reverse().find(k =>
          String(k.urun || '').toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]+/gu, ' ').trim() === arananAnahtar
        );
      }
      if (hedefKayit && yeniSatirlar.length > 0) {
        duzeltilenId = hedefKayit.id;
        duzeltilenSurum = hedefKayit.surum || 1;
        $('duzeltme-notu').classList.remove('gizli');
        mevcutUrun = hedefKayit.urun || '';
        mevcutFiyat = Number(hedefKayit.fiyat) || null;
        mevcutSatirlar = (hedefKayit.satirlar || []).map(s => ({ ...s }));
        if ($('barkod') && hedefKayit.barkod) $('barkod').value = hedefKayit.barkod;
        cevap.urun = '';
      }
    }

    calismaPenceresiniAc(duzeltmePenceresiModu ? 'duzelt' : 'giris');

    // Eğer ekranda açık bir ürün varken kullanıcı FARKLI yeni bir ürün adı söylediyse ("Ürün Keten Gömlek..."), eski ürünü tamamen temizleyip yeni ürüne geç!
    if (cevap.urun && mevcutUrun && cevap.urun.toLocaleLowerCase('tr-TR') !== mevcutUrun.toLocaleLowerCase('tr-TR')) {
      devamEdenUrunGrubu = false;
      duzeltilenId = null;
      duzeltilenSurum = null;
      $('duzeltme-notu').classList.add('gizli');
      if ($('calisma-grup-ozet')) {
        $('calisma-grup-ozet').textContent = '';
        $('calisma-grup-ozet').classList.remove('aktif-ozet');
      }
      mevcutUrun = '';
      mevcutFiyat = null;
      mevcutSatirlar = [];
      oncekiSoz = '';
      if ($('soz')) $('soz').value = yeniMetin;
      if ($('barkod')) $('barkod').value = '';
    }

    // Açık karttaki ürünle AYNI ürün adı tekrar söylendiyse mevcut karta ekle
    if ((mevcutUrun || mevcutSatirlar.length > 0) && cevap.urun && (!mevcutUrun || cevap.urun.toLocaleLowerCase('tr-TR') === mevcutUrun.toLocaleLowerCase('tr-TR'))) {
      if (!mevcutUrun) mevcutUrun = cevap.urun;
      cevap.urun = '';
    }

    // Durum A: Açık kartın üstüne yeni beden/renk/adet/fiyat ekleme ("Aynısından L beden 5 adet", "5 adet M beden" vb.)
    if ((mevcutUrun || mevcutSatirlar.length > 0) && !cevap.urun) {
      cevap.urun = mevcutUrun;
      if (!cevap.fiyat && Number.isFinite(mevcutFiyat) && mevcutFiyat > 0) {
        cevap.fiyat = mevcutFiyat;
      }
      if ($('soz')) {
        $('soz').value = oncekiSoz && yeniMetin && !oncekiSoz.includes(yeniMetin)
          ? `${oncekiSoz.replace(/[.!?\s]+$/, '')}, ${yeniMetin}`
          : (yeniMetin || oncekiSoz);
      }
      const varsayilanRenk = ([...mevcutSatirlar].reverse().find(s => s.renk) || {}).renk || '';
      const varsayilanBeden = ([...mevcutSatirlar].reverse().find(s => s.beden) || {}).beden || '';
      const varsayilanAdet = ([...mevcutSatirlar].reverse().find(s => s.adet != null && s.adet > 0) || {}).adet || 1;

      // Yalnız ilk satır gerçekten yarımsa VE yeni söylenen satır farklı bir beden/renk eklemiyorsa ilk satırı tamamla
      const ilkSatirYarimTamamlamaMi = !yeniSatirSesModu && mevcutSatirlar.length === 1 && yeniSatirlar.length === 1
        && (!mevcutSatirlar[0].beden || !yeniSatirlar[0].beden || mevcutSatirlar[0].beden === yeniSatirlar[0].beden)
        && (!mevcutSatirlar[0].renk || !yeniSatirlar[0].renk || mevcutSatirlar[0].renk === yeniSatirlar[0].renk)
        && (!mevcutSatirlar[0].renk || !mevcutSatirlar[0].beden || mevcutSatirlar[0].adet == null);

      if (ilkSatirYarimTamamlamaMi) {
        const s = yeniSatirlar[0];
        cevap.satirlar = [{
          renk: s.renk || mevcutSatirlar[0].renk || varsayilanRenk,
          beden: s.beden || mevcutSatirlar[0].beden || varsayilanBeden,
          adet: s.adet != null ? s.adet : mevcutSatirlar[0].adet
        }];
      } else if (mevcutSatirlar.length > 0 && yeniSatirlar.length > 0) {
        // Mevcut dolu satırları koru; yarım satır varsa önce onu tamamla, yoksa veya "+ Yeni Renk/Beden Ekle" modundaysa yeni satır ekle!
        const birlesik = mevcutSatirlar.map(s => ({ ...s }));
        for (const ys of yeniSatirlar) {
          // 1) Tabloda bedeni veya adedi eksik (yarım kalmış) bir satır varsa önce onu tamamla!
          const yarimIdx = birlesik.findIndex(m => !m.beden || m.adet == null || Number(m.adet) <= 0);
          if (yarimIdx >= 0) {
            if (ys.renk) birlesik[yarimIdx].renk = ys.renk;
            else if (!birlesik[yarimIdx].renk && varsayilanRenk) birlesik[yarimIdx].renk = varsayilanRenk;
            if (ys.beden) birlesik[yarimIdx].beden = ys.beden;
            else if (!birlesik[yarimIdx].beden && varsayilanBeden && ys.adet != null) birlesik[yarimIdx].beden = varsayilanBeden;
            if (ys.adet != null) birlesik[yarimIdx].adet = ys.adet;
            else if (birlesik[yarimIdx].adet == null && ys.beden) birlesik[yarimIdx].adet = varsayilanAdet;
            continue;
          }

          if (ys.renk && !ys.beden && ys.adet == null) {
            let yazildi = false;
            for (const m of birlesik) {
              if (!m.renk) { m.renk = ys.renk; yazildi = true; }
            }
            if (!yazildi) {
              if (yeniSatirSesModu) {
                birlesik.push({ renk: ys.renk, beden: varsayilanBeden, adet: varsayilanAdet });
              } else if (birlesik.length === 1) {
                birlesik[0].renk = ys.renk;
              }
            }
            continue;
          }
          if (ys.beden && ys.adet == null) {
            const bosBedenIdx = birlesik.findIndex(m => !m.beden);
            if (bosBedenIdx >= 0) {
              birlesik[bosBedenIdx].beden = ys.beden;
              if (ys.renk) birlesik[bosBedenIdx].renk = ys.renk;
            } else {
              birlesik.push({
                renk: ys.renk || varsayilanRenk,
                beden: ys.beden,
                adet: varsayilanAdet
              });
            }
            continue;
          }
          const r = ys.renk || varsayilanRenk;
          const b = ys.beden || varsayilanBeden;
          // Eğer "+ Yeni Renk / Beden Ekle" tuşuna basılarak ses açıldıysa aynı beden/renk olsa bile ikinci satır olarak ekle!
          if (yeniSatirSesModu) {
            birlesik.push({ renk: r, beden: b, adet: ys.adet != null ? ys.adet : varsayilanAdet });
            continue;
          }
          // Normal ses girişinde aynı beden ve uyumlu renk varsa güncelle; farklı bedense YENİ SATIR olarak ekle!
          const idx = birlesik.findIndex(m => {
            const ayniBeden = m.beden === b || (!m.beden && !b);
            const uyumluRenk = m.renk === r || !m.renk || !r;
            return ayniBeden && uyumluRenk;
          });
          if (idx >= 0) {
            if (r) birlesik[idx].renk = r;
            if (b) birlesik[idx].beden = b;
            if (ys.adet != null) birlesik[idx].adet = ys.adet;
          } else {
            birlesik.push({ renk: r, beden: b, adet: ys.adet != null ? ys.adet : varsayilanAdet });
          }
        }
        cevap.satirlar = birlesik;
      } else if (mevcutSatirlar.length > 0 && yeniSatirlar.length === 0) {
        // Yalnız fiyat söylendiyse ("fiyatı 1250 lira") mevcut satırları koru
        cevap.satirlar = mevcutSatirlar;
      }
      cevap.uyarilar = (cevap.uyarilar || []).filter(u => !/Ürün adı|Adedi söylenmeyen/.test(u));
    } else if (mevcutSatirlar.length > 0 && cevap.urun && yeniSatirlar.every(s => !s.beden && s.adet == null)) {
      // Durum B: Önce beden/adet/tür söylendi ("M beden mont 15 adet kahverengi" veya "5 adet M beden"),
      // ardından sadece marka/ürün düzeltmesi söylendi ("Moncler marka", "yakasız gömlek", "Sabri Bey Eşarp")
      const yeniRenk = (yeniSatirlar.find(s => s.renk) || {}).renk || '';
      if (mevcutUrun) {
        const mKucuk = mevcutUrun.toLocaleLowerCase('tr-TR');
        const yKucuk = cevap.urun.toLocaleLowerCase('tr-TR');
        const genelTurMu = /^(?:mont|gömlek|yakasız gömlek|keten gömlek|kazak|v yaka kazak|tişört|v yaka tişört|pantolon|kot pantolon|ayakkabı|spor ayakkabı|terlik|pelüş terlik|eşarp|şal|ceket|elbise|etek|sweatshirt|hırka|yelek|çanta|parfüm)$/iu.test(mKucuk);
        if (genelTurMu && !yKucuk.includes(mKucuk) && !mKucuk.includes(yKucuk)) {
          cevap.urun = `${cevap.urun} ${mevcutUrun}`;
        }
      }
      if (!cevap.fiyat && Number.isFinite(mevcutFiyat) && mevcutFiyat > 0) {
        cevap.fiyat = mevcutFiyat;
      }
      if ($('soz')) {
        $('soz').value = oncekiSoz && yeniMetin && !oncekiSoz.includes(yeniMetin)
          ? `${yeniMetin.replace(/[.!?\s]+$/, '')}, ${oncekiSoz}`
          : (yeniMetin || oncekiSoz);
      }
      cevap.satirlar = mevcutSatirlar.map(s => ({
        renk: yeniRenk || s.renk,
        beden: s.beden,
        adet: s.adet
      }));
      cevap.uyarilar = (cevap.uyarilar || []).filter(u => !/Adedi söylenmeyen/.test(u));
    }

    yeniSatirSesModu = false;
    tabloyuDoldur(cevap);
    tabloyuSesliOzetle();
  }

  // Düğme: kapalıyken büyük çalışma penceresini ve dinlemeyi açar, dinlerken dokunulursa kaydı bitirir.
  $('mikrofon').addEventListener('click', e => {
    if (e.detail === 0) return;
    calismaPenceresiniAc(duzeltmePenceresiModu ? 'duzelt' : 'giris');
    if (kayit) {
      if (kayit.iptalEt && Date.now() - (kayit.basladi || 0) < 850) {
        kayit.iptalEt('↺ Yanlış dokunuş iptal edildi.');
      } else if (kayit.bitir) {
        kayit.bitir();
      }
    } else {
      dinlemeyiBaslat().catch(h => { dugmeHazir(); durum(`Mikrofon açılamadı (${(h && h.name) || 'bilinmeyen hata'}).`, true); });
    }
  });

  if ($('calisma-pencere-kapat-btn')) {
    $('calisma-pencere-kapat-btn').addEventListener('click', () => {
      calismaPenceresiniKapat(true);
      durum('✓ Ürün giriş penceresi kapatıldı. Sıradaki ürüne geçebilirsiniz.');
    });
  }
  if ($('calisma-yeni-urun-btn')) {
    $('calisma-yeni-urun-btn').addEventListener('click', () => {
      duzeltmePenceresiModu = false;
      devamEdenUrunGrubu = false;
      if ($('calisma-grup-ozet')) {
        $('calisma-grup-ozet').textContent = '';
        $('calisma-grup-ozet').classList.remove('aktif-ozet');
      }
      formuTemizle();
      calismaPenceresiniAc('giris');
      durum('🆕 Form temizlendi. Sıradaki yeni ürünün adını, bedenini ve fiyatını söyleyebilir veya girebilirsiniz.');
    });
  }

  // Gerçek Süpermarket / Depo Lazer Barkod Okuyucu Sesi (Zebra / Symbol 2730 Hz Piezo Lazer Bip)
  let barkodSesCtx = null;
  function barkodSesBaglamiHazirla() {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return null;
      if (!barkodSesCtx || barkodSesCtx.state === 'closed') {
        barkodSesCtx = new Ctx();
      }
      if (barkodSesCtx.state === 'suspended') {
        barkodSesCtx.resume().catch(() => {});
      }
      return barkodSesCtx;
    } catch (_) {
      return null;
    }
  }
  document.addEventListener('touchstart', () => barkodSesBaglamiHazirla(), { once: true, passive: true });
  document.addEventListener('click', () => barkodSesBaglamiHazirla(), { once: true, passive: true });

  function bipSesi(hataMi = false) {
    try {
      const ctx = barkodSesBaglamiHazirla();
      if (ctx) {
        const simdi = ctx.currentTime;
        const sikistirici = ctx.createDynamicsCompressor();
        sikistirici.threshold.setValueAtTime(-14, simdi);
        sikistirici.knee.setValueAtTime(6, simdi);
        sikistirici.ratio.setValueAtTime(8, simdi);
        sikistirici.attack.setValueAtTime(0.001, simdi);
        sikistirici.release.setValueAtTime(0.06, simdi);
        sikistirici.connect(ctx.destination);

        if (!hataMi) {
          // Gerçek el tipi lazer barkod okuyucu: 2730 Hz keskin kare (piezo) + üçgen dalga rezonansı (115 ms)
          const filtre = ctx.createBiquadFilter();
          filtre.type = 'peaking';
          filtre.frequency.setValueAtTime(2730, simdi);
          filtre.Q.setValueAtTime(2.2, simdi);
          filtre.gain.setValueAtTime(7, simdi);
          filtre.connect(sikistirici);

          const kazanc = ctx.createGain();
          kazanc.gain.setValueAtTime(0.001, simdi);
          kazanc.gain.linearRampToValueAtTime(0.92, simdi + 0.004);
          kazanc.gain.setValueAtTime(0.92, simdi + 0.095);
          kazanc.gain.exponentialRampToValueAtTime(0.001, simdi + 0.12);
          kazanc.connect(filtre);

          const kareOsc = ctx.createOscillator();
          kareOsc.type = 'square';
          kareOsc.frequency.setValueAtTime(2420, simdi);
          kareOsc.frequency.setValueAtTime(2730, simdi + 0.007);
          kareOsc.connect(kazanc);

          const ucgenOsc = ctx.createOscillator();
          ucgenOsc.type = 'triangle';
          ucgenOsc.frequency.setValueAtTime(2730, simdi);
          ucgenOsc.connect(kazanc);

          kareOsc.start(simdi);
          ucgenOsc.start(simdi);
          kareOsc.stop(simdi + 0.122);
          ucgenOsc.stop(simdi + 0.122);
        } else {
          // Hatalı barkod uyarısı: çift kalın piezo uyarı bipi (340 Hz)
          [[0, 0.14], [0.18, 0.16]].forEach(([bas, sure]) => {
            const o = ctx.createOscillator();
            const g = ctx.createGain();
            o.type = 'sawtooth';
            o.frequency.setValueAtTime(340, simdi + bas);
            g.gain.setValueAtTime(0.85, simdi + bas);
            g.gain.exponentialRampToValueAtTime(0.001, simdi + bas + sure);
            o.connect(g);
            g.connect(sikistirici);
            o.start(simdi + bas);
            o.stop(simdi + bas + sure + 0.01);
          });
        }
      }
    } catch (err) {}
    if (navigator.vibrate) {
      try { navigator.vibrate(hataMi ? [90, 60, 110] : 85); } catch (err) {}
    }
  }

  // ===== Tablo & İrsaliye Sayım Kontrolü =====
  function asciiKod(metin, uzunluk = 6) {
    return String(metin || '')
      .toLocaleLowerCase('tr-TR')
      .replace(/[çğıöşü]/g, h => ({ 'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u' }[h]))
      .replace(/[^a-z0-9]/g, '')
      .toUpperCase()
      .slice(0, uzunluk);
  }

  function otomatikBarkodHesapla(urun, renk = '', beden = '') {
    const ad = String(urun || '').trim();
    if (!ad) return '';
    const norm = ad
      .toLocaleLowerCase('tr-TR')
      .replace(/[çğıöşü]/g, h => ({ 'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u' }[h]))
      .replace(/[^\p{L}\p{N}\s]/gu, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    let hash = 0;
    for (let i = 0; i < norm.length; i++) {
      hash = ((hash * 31) + norm.charCodeAt(i)) % 900;
    }
    const sayisalEk = String(hash + 100);
    const kelimeler = norm.split(' ').filter(Boolean);
    const kok = kelimeler.length >= 2
      ? (asciiKod(kelimeler[0], 3) + asciiKod(kelimeler[1], 3))
      : asciiKod(norm, 6);
    const anaKod = `MZU-${kok || 'URUN'}-${sayisalEk}`;
    const rKod = asciiKod(renk, 3);
    const bKod = asciiKod(beden, 4);
    if (!rKod && !bKod) return anaKod;
    return [anaKod, rKod, bKod].filter(Boolean).join('-');
  }

  function otomatikBarkodGuncelle(bankadaKayitli = null) {
    const urun = $('urun') ? $('urun').value.trim() : '';
    const girilenBarkod = $('barkod') ? $('barkod').value.trim() : '';
    const kutu = $('oto-barkod-kutu');
    if (kutu) {
      if (!urun && !girilenBarkod) {
        kutu.classList.add('gizli');
      } else {
        const anaKod = girilenBarkod || otomatikBarkodHesapla(urun);
        if ($('oto-barkod-deger')) $('oto-barkod-deger').textContent = anaKod;
        if ($('oto-barkod-banka-durum') && bankadaKayitli !== null) {
          $('oto-barkod-banka-durum').textContent = bankadaKayitli
            ? '🏦 Veri Bankasında Kayıtlı'
            : '✨ Yeni Otomatik Barkod';
        }
        kutu.classList.remove('gizli');
      }
    }
    const trListesi = [...$('satirlar').querySelectorAll('tr')];
    trListesi.forEach(tr => {
      const [rIn, bIn] = tr.querySelectorAll('input');
      const etEl = tr.querySelector('.satir-barkod-etiket');
      if (!etEl) return;
      const ozelBarkod = tr.dataset.ozelBarkod || '';
      const rK = asciiKod(rIn ? rIn.value : '', 3);
      const bK = asciiKod(bIn ? bIn.value : '', 4);
      const vKod = ozelBarkod || (urun
        ? otomatikBarkodHesapla(urun, rIn ? rIn.value : '', bIn ? bIn.value : '')
        : (girilenBarkod ? [girilenBarkod, rK, bK].filter(Boolean).join('-') : ''));
      tr.dataset.barkod = vKod;
      etEl.textContent = vKod ? `🏷️ ${vKod}` : '';
    });
  }

  function irsaliyeModunuAyarla(aktif) {
    irsaliyeModu = Boolean(aktif);
    if (!irsaliyeModu) sayimOnayli = false;
    if ($('sayim-banner')) $('sayim-banner').classList.toggle('gizli', !irsaliyeModu);
    if ($('sayim-onay-cubuk')) $('sayim-onay-cubuk').classList.toggle('gizli', !irsaliyeModu);
    if ($('fiyat-etiket')) $('fiyat-etiket').textContent = irsaliyeModu ? 'Satış Fiyatı (TL) *' : 'Fiyat (TL)';
    if ($('fiyat')) $('fiyat').placeholder = irsaliyeModu ? 'Satış Fiyatı (TL) *' : 'Fiyat (TL)';
    if ($('tablo-baslik-kapsayici')) $('tablo-baslik-kapsayici').classList.add('gizli');
    if ($('kaydet')) {
      $('kaydet').textContent = irsaliyeModu ? '✓ SAYIMI ONAYLA & FİYATIYLA STOKA KAYDET' : '✓ KAYDET';
    }
  }

  // ===== 🏢 SEKTÖREL ARAYÜZ, TABLO, FORMLAR & BARKOD BANKASI MOTORU =====
  const SEKTOR_TANIMLARI = {
    giyim: {
      kod: 'giyim',
      ad: 'Tekstil, Giyim & Moda',
      etiket: '👗 Tekstil & Beden Kataloğu Aktif',
      thRenk: 'Renk',
      thBeden: 'Beden',
      renkPlaceholder: 'Renk (Örn: Siyah / Beyaz)',
      bedenPlaceholder: 'Beden (S, M, L, XL, 38...)',
      satirEkleYazi: 'Yeni Renk / Beden Ekle',
      rbPanelBaslik: '➕ RENK, BEDEN & ADET SEÇİMİ',
      rbBedenBaslik: '📏 1. Beden Seçin:',
      rbRenkBaslik: '🎨 2. Renk Seçin:',
      bedenler: ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', 'STD', '36', '38', '40', '42', '44', '46'],
      renkler: ['SİYAH', 'BEYAZ', 'LACİVERT', 'MAVİ', 'KIRMIZI', 'YEŞİL', 'BEJ', 'KREM', 'GRİ', 'KAHVE', 'PEMBE', 'BORDO'],
      yakaBaslik: '👕 İsteğe Bağlı Ürün Cinsi / Yaka Seçimi:',
      yakaCipleri: ['V Yaka Tişört', 'Bisiklet Yaka Tişört', 'Polo Yaka Tişört', 'Gömlek', 'Pantolon', 'Polar Ceket', 'Yağmurluk', 'Mont / Kaban'],
      hizliYaziCipleri: ['Siyah', 'Beyaz', 'Lacivert', 'Bej', 'Kırmızı', 'S', 'M', 'L', 'XL', 'XXL', '1 Adet', '2 Adet', '5 Adet'],
      sesOrnegi: 'Hermes V Yaka Tişört Siyah L 3 Adet 950 TL',
      mdDosya: 'SEKTOR_GIYIM.md',
      etiketRehber: '📷 Kamerayı ürünün yaka etiketine veya kartına tutun. Yalnızca Ürün Adı ve Beden bilgisi alınır.'
    },
    oyuncak: {
      kod: 'oyuncak',
      ad: 'Oyuncakçı & Çocuk Dünyası',
      etiket: '🧸 Oyuncak & Yaş Grubu Kataloğu Aktif',
      thRenk: 'Kategori / Model',
      thBeden: 'Yaş Grubu',
      renkPlaceholder: 'Model / Kategori (Peluş, Figür...)',
      bedenPlaceholder: 'Yaş Grubu (0-3, 3-6, 6-9, 10+...)',
      satirEkleYazi: 'Yeni Model / Yaş Grubu Ekle',
      rbPanelBaslik: '➕ KATEGORİ, YAŞ & ADET SEÇİMİ',
      rbBedenBaslik: '👶 1. Yaş Grubu Seçin:',
      rbRenkBaslik: '🧸 2. Oyuncak Türü / Modeli Seçin:',
      bedenler: ['0-12 AY', '1-3 YAŞ', '3-6 YAŞ', '6-9 YAŞ', '10+ YAŞ', 'TÜM YAŞLAR', '1 PARÇA', 'SET', 'STD'],
      renkler: ['Peluş', 'Kutu Oyunu', 'Lego / Yapı', 'Figür', 'Akülü', 'Model Araç', 'Bebek', 'Eğitici', 'Puzzle', 'Mavi', 'Pembe', 'Renkli'],
      yakaBaslik: '🧸 İsteğe Bağlı Oyuncak Türü Seçimi:',
      yakaCipleri: ['Lego / Yapı', 'Kutu Oyunu', 'Peluş Oyuncak', 'Akülü Araba', 'Model Araç', 'Et Bebek', 'Karakter Figürü', 'Puzzle', 'Eğitici Ahşap', 'Mini Drone'],
      hizliYaziCipleri: ['Lego', 'Peluş', 'Kutu Oyunu', 'Figür', 'Akülü', '0-3 Yaş', '3-6 Yaş', '6+ Yaş', 'Mavi', 'Pembe', '1 Adet', '2 Adet', '5 Adet'],
      sesOrnegi: 'Lego Şehir İtfaiye Seti 6 Yaş 1 Adet 850 TL',
      mdDosya: 'SEKTOR_OYUNCAK.md',
      etiketRehber: '📷 Kamerayı oyuncak kutusuna veya ambalaja tutun. Model adı ve yaş grubu otomatik alınır.'
    },
    ayakkabi: {
      kod: 'ayakkabi',
      ad: 'Ayakkabı, Çanta & Deri',
      etiket: '👟 Ayakkabı & Numara Kataloğu Aktif',
      thRenk: 'Renk / Malzeme',
      thBeden: 'Numara',
      renkPlaceholder: 'Renk / Deri (Siyah, Deri, Süet...)',
      bedenPlaceholder: 'Numara (36, 37, 38... 45)',
      satirEkleYazi: 'Yeni Renk / Numara Ekle',
      rbPanelBaslik: '➕ RENK, NUMARA & ADET SEÇİMİ',
      rbBedenBaslik: '👟 1. Ayakkabı Numarası Seçin:',
      rbRenkBaslik: '🎨 2. Renk veya Malzeme Seçin:',
      bedenler: ['35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', 'STD'],
      renkler: ['SİYAH', 'BEYAZ', 'KAHVE', 'TABA', 'BEJ', 'LACİVERT', 'HAKİKİ DERİ', 'SÜET', 'RUGAN', 'NUBUK', 'KUMAŞ', 'STD'],
      yakaBaslik: '👟 İsteğe Bağlı Ayakkabı / Çanta Türü:',
      yakaCipleri: ['Spor Sneaker', 'Günlük Yürüyüş', 'Klasik Kösele', 'Deri Bot', 'Çizme', 'Sandalet / Terlik', 'Stiletto Topuklu', 'Omuz Çantası', 'Sırt Çantası', 'Cüzdan & Kemer'],
      hizliYaziCipleri: ['Siyah', 'Beyaz', 'Kahve', 'Deri', 'Süet', '38', '39', '40', '41', '42', '43', '1 Adet', '2 Adet'],
      sesOrnegi: 'Nike Air Jordan Siyah 42 Numara 1 Adet 3200 TL',
      mdDosya: 'SEKTOR_AYAKKABI.md',
      etiketRehber: '📷 Kamerayı ayakkabı kutusu etiketine veya tabanına tutun. Numara ve model otomatik alınır.'
    },
    kozmetik: {
      kod: 'kozmetik',
      ad: 'Kozmetik, Parfüm & Bakım',
      etiket: '💄 Kozmetik & Hacim (ML) Kataloğu Aktif',
      thRenk: 'Tür / Koku Tipi',
      thBeden: 'Hacim (ML)',
      renkPlaceholder: 'Koku / Ürün Türü (EDP, EDT, Krem...)',
      bedenPlaceholder: 'Hacim (50ML, 100ML, STD...)',
      satirEkleYazi: 'Yeni Tür / Hacim Ekle',
      rbPanelBaslik: '➕ TÜR, HACİM (ML) & ADET SEÇİMİ',
      rbBedenBaslik: '🧪 1. Hacim veya Boyut Seçin:',
      rbRenkBaslik: '💄 2. Kozmetik / Koku Türü Seçin:',
      bedenler: ['30ML', '50ML', '75ML', '100ML', '125ML', '150ML', '200ML', '250ML', '400ML', '500ML', 'STD'],
      renkler: ['EDP', 'EDT', 'Extrait', 'Parfüm', 'Kolonya', 'Krem', 'Serum', 'Maskara', 'Ruj', 'Şampuan', 'Güneş Kremi', 'STD'],
      yakaBaslik: '💄 İsteğe Bağlı Kozmetik Türü Seçimi:',
      yakaCipleri: ['EDP Parfüm', 'EDT Parfüm', 'Niş Extrait', 'Yüz Serumu', 'Nemlendirici Krem', 'Güneş Kremi', 'Maskara', 'Mat Ruj', 'Onarıcı Şampuan', 'Limon Kolonyası'],
      hizliYaziCipleri: ['EDP', 'EDT', '50 ML', '100 ML', 'Parfüm', 'Serum', 'Krem', 'Ruj', '1 Adet', '2 Adet'],
      sesOrnegi: 'Dior Sauvage Parfüm 100 ML 3850 TL',
      mdDosya: 'SEKTOR_KOZMETIK.md',
      etiketRehber: '📷 Kamerayı parfüm kutusuna veya şişe etiketine tutun. Marka ve ML bilgisi otomatik alınır.'
    },
    kirtasiye: {
      kod: 'kirtasiye',
      ad: 'Kırtasiye, Kitap & Ofis',
      etiket: '📚 Kırtasiye & Ebat Kataloğu Aktif',
      thRenk: 'Tür / Çeşit',
      thBeden: 'Ebat / Birim',
      renkPlaceholder: 'Tür / Çeşit (Mavi, Çizgili, Kareli...)',
      bedenPlaceholder: 'Ebat / Paket (A4, 0.7, 96YP, 12li...)',
      satirEkleYazi: 'Yeni Tür / Ebat Ekle',
      rbPanelBaslik: '➕ TÜR, EBAT & ADET SEÇİMİ',
      rbBedenBaslik: '📐 1. Ebat / Sayfa / Uç Seçin:',
      rbRenkBaslik: '🎨 2. Renk / Sayfa Türü Seçin:',
      bedenler: ['A4', 'A5', '0.5', '0.7', '1.0', "12'Lİ", "24'LÜ", '40YP', '60YP', '80YP', '96YP', 'STD'],
      renkler: ['MAVİ', 'SİYAH', 'KIRMIZI', 'YEŞİL', 'RENKLİ', 'ÇİZGİLİ', 'KARELİ', 'DÜZ', 'SPİRALLİ', 'CİLTLİ', 'PASTEL', 'STD'],
      yakaBaslik: '📚 İsteğe Bağlı Kırtasiye Türü Seçimi:',
      yakaCipleri: ['Metot Defteri', 'Mekanik Kalem', 'Kuru Boya', 'Fotokopi Kağıdı', 'Stick Yapıştırıcı', 'Fosforlu Kalem', 'Versatil Kalem', 'Sınav Silgisi', 'Sırt Çantası'],
      hizliYaziCipleri: ['A4', '0.7', 'Mavi', 'Siyah', 'Kareli', 'Çizgili', '96YP', '12li', '1 Adet', '5 Adet', '10 Adet'],
      sesOrnegi: 'Faber Castell 12li Boya Kalemi 1 Adet 140 TL',
      mdDosya: 'SEKTOR_KIRTASIYE.md',
      etiketRehber: '📷 Kamerayı defter, kitap veya kalem ambalajına tutun. Ürün ve ebat otomatik alınır.'
    },
    elektronik: {
      kod: 'elektronik',
      ad: 'Elektronik, Telefon & Aksesuar',
      etiket: '📱 Elektronik & Model Kataloğu Aktif',
      thRenk: 'Renk / Tür',
      thBeden: 'Kapasite / Model',
      renkPlaceholder: 'Renk / Uyum (Siyah, Şeffaf, Type-C...)',
      bedenPlaceholder: 'Kapasite / Model (128GB, 25W, 10000mAh...)',
      satirEkleYazi: 'Yeni Renk / Kapasite Ekle',
      rbPanelBaslik: '➕ RENK, KAPASİTE & ADET SEÇİMİ',
      rbBedenBaslik: '⚡ 1. Kapasite / Güç Seçin:',
      rbRenkBaslik: '🎨 2. Renk / Kasa Tipi Seçin:',
      bedenler: ['64GB', '128GB', '256GB', '512GB', '1TB', '10000MAH', '20000MAH', '20W', '25W', '65W', 'STD'],
      renkler: ['SİYAH', 'BEYAZ', 'ŞEFFAF', 'LACİVERT', 'TİTANYUM', 'GRİ', 'KIRMIZI', 'MOR', 'YEŞİL', 'ALTIN', 'GÜMÜŞ', 'STD'],
      yakaBaslik: '📱 İsteğe Bağlı Aksesuar Türü:',
      yakaCipleri: ['MagSafe Kılıf', 'Hızlı Şarj Cihazı', 'Şarj Kablosu', 'Powerbank', 'TWS Bluetooth Kulaklık', 'Kırılmaz Cam Koruyucu', 'Araç Telefon Tutacağı', 'Akıllı Saat Kordonu'],
      hizliYaziCipleri: ['Siyah', 'Beyaz', 'Şeffaf', 'Type-C', '25W', '10000mAh', 'iPhone', '1 Adet', '2 Adet'],
      sesOrnegi: 'Samsung 25W Hızlı Şarj Cihazı Beyaz 2 Adet 390 TL',
      mdDosya: 'SEKTOR_ELEKTRONIK.md',
      etiketRehber: '📷 Kamerayı aksesuar kutusu barkoduna veya bilgilerine tutun.'
    },
    market: {
      kod: 'market',
      ad: 'Market, Gıda & Şarküteri',
      etiket: '🛒 Market & Gramaj Kataloğu Aktif',
      thRenk: 'Tür / Çeşit',
      thBeden: 'Gramaj / Hacim',
      renkPlaceholder: 'Çeşit (Tam Yağlı, Acılı, Sızma...)',
      bedenPlaceholder: 'Gramaj / Hacim (500G, 1KG, 1LT, 5LT...)',
      satirEkleYazi: 'Yeni Çeşit / Gramaj Ekle',
      rbPanelBaslik: '➕ ÇEŞİT, GRAMAJ & ADET SEÇİMİ',
      rbBedenBaslik: '⚖️ 1. Gramaj veya Hacim Seçin:',
      rbRenkBaslik: '🧀 2. Çeşit / Yağ Oranı Seçin:',
      bedenler: ['250G', '500G', '600G', '1KG', '2KG', '5KG', '200ML', '500ML', '1LT', '2LT', '5LT', 'STD'],
      renkler: ['TAM YAĞLI', 'YARIM YAĞLI', 'YAĞSIZ', 'ACILI', 'TATLI', 'DOĞAL', 'ORGANİK', 'SIZMA', 'KLASİK', 'DİLİMLİ', 'SİYAH', 'YEŞİL'],
      yakaBaslik: '🛒 İsteğe Bağlı Gıda Türü Seçimi:',
      yakaCipleri: ['Pastörize Süt', 'Rize Çayı', 'Kaşar Peyniri', 'Siyah Zeytin', 'Ayçiçek Yağı', 'Kangal Sucuk', 'Makarna', 'Bulaşık Tableti'],
      hizliYaziCipleri: ['1LT', '1KG', '500G', 'Tam Yağlı', 'Acılı', 'Doğal', '1 Adet', '2 Adet', '6 Adet', '12 Adet'],
      sesOrnegi: 'Torku Doğal Pastörize Süt 1 LT 3 Adet 40 TL',
      mdDosya: 'SEKTOR_MARKET.md',
      etiketRehber: '📷 Kamerayı ürün ambalajına tutun. Gramaj ve ürün adı otomatik alınır.'
    },
    hirdavat: {
      kod: 'hirdavat',
      ad: 'Nalburiye, Hırdavat & Yapı Market',
      etiket: '🔧 Hırdavat & Ölçü Kataloğu Aktif',
      thRenk: 'Tip / Malzeme',
      thBeden: 'Ölçü / Ebat',
      renkPlaceholder: 'Tip / Malzeme (Krom, Çelik, Şeffaf...)',
      bedenPlaceholder: 'Ölçü (1/2", 6x100, 280ml, 8mm...)',
      satirEkleYazi: 'Yeni Tip / Ölçü Ekle',
      rbPanelBaslik: '➕ TİP, ÖLÇÜ & ADET SEÇİMİ',
      rbBedenBaslik: '📐 1. Ölçü veya Boyut Seçin:',
      rbRenkBaslik: '🔩 2. Malzeme / Renk Seçin:',
      bedenler: ['1/2"', '3/4"', '1"', '6MM', '8MM', '10MM', '12MM', '50MM', '100MM', '280ML', '1KG', '5KG', 'STD'],
      renkler: ['ŞEFFAF', 'BEYAZ', 'GRİ', 'SİYAH', 'ÇELİK', 'PİRİNÇ', 'KROM', 'PLASTİK', 'AKRİLİK', 'İZOLASYON', 'MANUEL', 'ŞARJLI'],
      yakaBaslik: '🔧 İsteğe Bağlı Hırdavat Türü:',
      yakaCipleri: ['Akrilik Mastik', 'Şeffaf Silikon', 'Yıldız Tornavida', 'Elektrikçi Pensesi', 'Pirinç Asma Kilit', 'Japon Yapıştırıcı', 'Koli Bandı', 'Tuğla Dübeli'],
      hizliYaziCipleri: ['280ML', 'Şeffaf', 'Beyaz', '8mm', 'Yıldız', 'Pense', '1 Adet', '5 Adet', '10 Adet'],
      sesOrnegi: 'Selsil Şeffaf Silikon 280 ML 5 Adet 85 TL',
      mdDosya: 'SEKTOR_HIRDAVAT.md',
      etiketRehber: '📷 Kamerayı alet veya ambalaj etiketine tutun. Ölçü ve model otomatik alınır.'
    },
    genel: {
      kod: 'genel',
      ad: 'Genel Perakende & Diğer',
      etiket: '🏪 Genel Perakende Kataloğu Aktif',
      thRenk: 'Varyant / Renk',
      thBeden: 'Model / Ölçü',
      renkPlaceholder: 'Varyant / Renk',
      bedenPlaceholder: 'Model / Ölçü / Kod',
      satirEkleYazi: 'Yeni Satır Ekle',
      rbPanelBaslik: '➕ VARYANT & ADET SEÇİMİ',
      rbBedenBaslik: '📐 1. Model / Boyut Seçin:',
      rbRenkBaslik: '🎨 2. Varyant / Renk Seçin:',
      bedenler: ['STD', 'KÜÇÜK', 'ORTA', 'BÜYÜK', '1Lİ', '2Lİ', '3LÜ', '5Lİ', '10LU'],
      renkler: ['BEYAZ', 'SİYAH', 'KIRMIZI', 'MAVİ', 'SARI', 'YEŞİL', 'GRİ', 'STANDART'],
      yakaBaslik: '📦 Genel Ürün Kategorileri:',
      yakaCipleri: ['Standart Ürün', 'Paketli Ürün', 'Set Ürün', 'Aksesuar', 'Hediye'],
      hizliYaziCipleri: ['Standart', '1 Adet', '2 Adet', '5 Adet', '10 Adet'],
      sesOrnegi: 'Genel Barkodlu Ürün A 1 Adet 150 TL',
      mdDosya: 'SEKTOR_GIYIM.md',
      etiketRehber: '📷 Kamerayı barkod veya ambalaja tutun.'
    }
  };

  const SEKTOR_KATALOG_VERILERI = {
    oyuncak: [
      { urun: 'Lego Classic Yaratıcı Yapım Kutusu', fiyat: 750, beden: '4-99 YAŞ', renk: 'LEGO / YAPI', barkod: 'MZU-OY001' },
      { urun: 'Lego City Polis Devriye Arabası', fiyat: 420, beden: '5+ YAŞ', renk: 'LEGO / YAPI', barkod: 'MZU-OY002' },
      { urun: 'Barbie Sonsuz Hareket Sarışın Bebek', fiyat: 680, beden: '3+ YAŞ', renk: 'BEBEK', barkod: 'MZU-OY003' },
      { urun: 'Hot Wheels 5li Araba Seti', fiyat: 450, beden: '3+ YAŞ', renk: 'MODEL ARABA', barkod: 'MZU-OY004' },
      { urun: 'Fisher-Price Eğitici Köpekçik', fiyat: 890, beden: '6-36 AY', renk: 'EĞİTİCİ ELEKTRONİK', barkod: 'MZU-OY005' },
      { urun: 'Play-Doh 4lü Renkli Oyun Hamuru', fiyat: 140, beden: '2+ YAŞ', renk: 'OYUN HAMURU', barkod: 'MZU-OY006' },
      { urun: 'Nerf Elite 2.0 RD-6 Dart Tabancası', fiyat: 620, beden: '8+ YAŞ', renk: 'HEDEF & MACERA', barkod: 'MZU-OY007' },
      { urun: 'Monopoly Türkiye Klasik Kutu Oyunu', fiyat: 590, beden: '8+ YAŞ', renk: 'KUTU OYUNU', barkod: 'MZU-OY008' },
      { urun: 'Jenga Klasik Ahşap Denge Oyunu', fiyat: 380, beden: '6+ YAŞ', renk: 'DENGE OYUNU', barkod: 'MZU-OY009' },
      { urun: 'Uno Klasik Kart Oyunu', fiyat: 120, beden: '7+ YAŞ', renk: 'KART OYUNU', barkod: 'MZU-OY010' },
      { urun: 'Pilsan 12V Uzaktan Kumandalı Akülü Araba', fiyat: 6850, beden: '3-8 YAŞ', renk: 'AKÜLÜ ARAÇ', barkod: 'MZU-OY012' },
      { urun: 'Sevimli Peluş Ayıcık 60 cm', fiyat: 350, beden: '0+ YAŞ', renk: 'PELUŞ OYUNCAK', barkod: 'MZU-OY013' }
    ],
    giyim: [
      { urun: 'Lacoste Klasik Polo Yaka Tişört', fiyat: 950, beden: 'M', renk: 'BEYAZ', barkod: 'MZU-GM001' },
      { urun: 'Tommy Hilfiger Slim Fit Düğmeli Gömlek', fiyat: 1150, beden: 'L', renk: 'AÇIK MAVİ', barkod: 'MZU-GM002' },
      { urun: 'Mavi Jake Slim Fit Kot Pantolon', fiyat: 780, beden: '32/32', renk: 'KOT MAVİ', barkod: 'MZU-GM003' },
      { urun: 'Zara Dökümlü Keten Karışımlı Pantolon', fiyat: 690, beden: '38', renk: 'BEJ', barkod: 'MZU-GM004' },
      { urun: 'Columbia Fermuarlı Kalın Polar Ceket', fiyat: 1850, beden: 'XL', renk: 'HAKİ', barkod: 'MZU-GM005' },
      { urun: 'The North Face Su Geçirmez Yağmurluk', fiyat: 2400, beden: 'L', renk: 'SİYAH', barkod: 'MZU-GM006' }
    ],
    ayakkabi: [
      { urun: 'Erkek Hakiki Deri Klasik Kösele Ayakkabı', fiyat: 1650, beden: '42', renk: 'SİYAH / DERİ', barkod: 'MZU-AY001' },
      { urun: 'Kadın Topuklu Stiletto Abiye Ayakkabı', fiyat: 1250, beden: '38', renk: 'BEJ / RUGAN', barkod: 'MZU-AY002' },
      { urun: 'Günlük Hafif Ortopedik Yürüyüş Sneaker', fiyat: 980, beden: '41', renk: 'BEYAZ', barkod: 'MZU-AY003' },
      { urun: 'Hakiki Deri Erkek Kışlık Su Geçirmez Bot', fiyat: 2400, beden: '43', renk: 'KAHVE / NUBUK', barkod: 'MZU-AY004' },
      { urun: 'Hakiki Deri Çapraz Askılı Omuz Çantası', fiyat: 850, beden: 'STD', renk: 'TABA / DERİ', barkod: 'MZU-AY006' }
    ],
    kozmetik: [
      { urun: 'Dior Sauvage Erkek Parfüm EDP', fiyat: 4250, beden: '100ML', renk: 'EDP PARFÜM', barkod: 'MZU-KZ001' },
      { urun: 'Chanel Bleu De Chanel Erkek Parfüm', fiyat: 4600, beden: '100ML', renk: 'EDP PARFÜM', barkod: 'MZU-KZ002' },
      { urun: 'Nishane Hacivat Extrait De Parfum', fiyat: 4950, beden: '50ML', renk: 'EXTRAIT NİŞ', barkod: 'MZU-KZ003' },
      { urun: 'Loreal Revitalift Hyaluronik Asit Yüz Serumu', fiyat: 340, beden: '30ML', renk: 'CİLT SERUMU', barkod: 'MZU-KZ005' },
      { urun: 'MAC Mat Ruj Velvet Teddy', fiyat: 680, beden: 'STD', renk: 'RUJ', barkod: 'MZU-KZ007' }
    ],
    kirtasiye: [
      { urun: 'Faber-Castell 12li Kuru Boya Kalemi Tüp', fiyat: 145, beden: '12Lİ', renk: 'RENKLİ', barkod: 'MZU-KR001' },
      { urun: 'A4 80 gr Fotokopi Kağıdı 500lü Paket', fiyat: 140, beden: '500LÜ', renk: 'BEYAZ', barkod: 'MZU-KR002' },
      { urun: 'Scrikss 0.7 Mekanik Versatil Kalem', fiyat: 95, beden: '0.7', renk: 'MAVİ GÖVDE', barkod: 'MZU-KR003' },
      { urun: 'Gıpta Spiralli Sert Kapak Kareli Metot Defteri', fiyat: 65, beden: '96YP', renk: 'DESENLİ', barkod: 'MZU-KR004' },
      { urun: 'Pritt Stick Katı Yapıştırıcı 43 gr', fiyat: 70, beden: '43G', renk: 'KIRMIZI', barkod: 'MZU-KR005' }
    ],
    elektronik: [
      { urun: 'Apple iPhone 15 Uyumlu MagSafe Şeffaf Kılıf', fiyat: 450, beden: 'İPHONE 15', renk: 'ŞEFFAF', barkod: 'MZU-EL001' },
      { urun: 'Samsung 25W Type-C Süper Hızlı Şarj Cihazı', fiyat: 390, beden: '25W', renk: 'BEYAZ', barkod: 'MZU-EL002' },
      { urun: 'Anker PowerCore 10000mAh Taşınabilir Hızlı Şarj', fiyat: 750, beden: '10000MAH', renk: 'SİYAH', barkod: 'MZU-EL003' },
      { urun: 'Baseus 3in1 Örgülü Hızlı Şarj Kablosu 1.2m', fiyat: 190, beden: '1.2M', renk: 'KIRMIZI', barkod: 'MZU-EL004' },
      { urun: 'JBL Wave 100 TWS Bluetooth Kulaklık', fiyat: 1250, beden: 'STD', renk: 'SİYAH', barkod: 'MZU-EL005' }
    ],
    market: [
      { urun: 'Torku Doğal Pastörize Süt 1 Lt', fiyat: 40, beden: '1LT', renk: 'TAM YAĞLI', barkod: 'MZU-MK001' },
      { urun: 'Çaykur Rize Turist Çay 1 Kg', fiyat: 170, beden: '1KG', renk: 'KLASİK', barkod: 'MZU-MK002' },
      { urun: 'Sütaş Taze Kaşar Peyniri 600 gr', fiyat: 195, beden: '600G', renk: 'DİLİMLİ', barkod: 'MZU-MK003' },
      { urun: 'Marmarabirlik Doğal Siyah Zeytin 500g', fiyat: 115, beden: '500G', renk: 'SİYAH', barkod: 'MZU-MK004' },
      { urun: 'Yudum Ayçiçek Yağı 5 Lt Pet', fiyat: 260, beden: '5LT', renk: 'SIZMA', barkod: 'MZU-MK005' }
    ],
    hirdavat: [
      { urun: 'Selsil Akrilik Genel Amaçlı Mastik 280ml', fiyat: 55, beden: '280ML', renk: 'BEYAZ', barkod: 'MZU-HD001' },
      { urun: 'Selsil Çok Amaçlı Şeffaf Silikon 280ml', fiyat: 85, beden: '280ML', renk: 'ŞEFFAF', barkod: 'MZU-HD002' },
      { urun: 'İzeltaş Yıldız Uçlu Manyetik Tornavida', fiyat: 125, beden: '6X100', renk: 'KROM VANADYUM', barkod: 'MZU-HD003' },
      { urun: 'İzeltaş İzoleli Elektrikçi Pensesi 180mm', fiyat: 320, beden: '180MM', renk: 'ÇELİK', barkod: 'MZU-HD004' },
      { urun: 'Kale Kilit Sarı Pirinç Asma Kilit 40mm', fiyat: 145, beden: '40MM', renk: 'PİRİNÇ', barkod: 'MZU-HD005' },
      { urun: '404 Hızlı Japon Yapıştırıcı + Aktivatör', fiyat: 80, beden: '200ML', renk: 'HIZLI YAPIŞTIRICI', barkod: 'MZU-HD006' }
    ]
  };

  let g_aktifSektor = 'giyim';
  let g_aktifSektorTanimi = SEKTOR_TANIMLARI.giyim;

  function sektorUygula(sektorKodu, kaydetVeYukle = false) {
    const kod = String(sektorKodu || 'giyim').toLowerCase().trim();
    const def = SEKTOR_TANIMLARI[kod] || SEKTOR_TANIMLARI.giyim;
    g_aktifSektor = def.kod;
    g_aktifSektorTanimi = def;

    try { localStorage.setItem('mezat_aktif_sektor', def.kod); } catch (_) {}

    // 1. Menü Seçimi ve Rozeti Güncelle
    if ($('menu-sektor-secim')) $('menu-sektor-secim').value = def.kod;
    if ($('menu-sektor-bilgi-yazi')) $('menu-sektor-bilgi-yazi').textContent = def.etiket;
    if ($('sektor-md-indir-link')) {
      $('sektor-md-indir-link').href = `/${def.mdDosya}`;
      $('sektor-md-indir-link').download = def.mdDosya;
      $('sektor-md-indir-link').textContent = `⬇ ${def.ad} .md Kataloğu İndir`;
    }

    // 2. Tablo Başlıklarını ve Satır Ekle Butonunu Güncelle
    if ($('th-renk')) $('th-renk').textContent = def.thRenk;
    if ($('th-beden')) $('th-beden').textContent = def.thBeden;
    if ($('satir-ekle-yazi')) $('satir-ekle-yazi').textContent = def.satirEkleYazi;

    // Mevcut satırlardaki input placeholder'larını güncelle
    const satirlarGovde = $('satirlar');
    if (satirlarGovde) {
      satirlarGovde.querySelectorAll('tr').forEach(tr => {
        const renkInp = tr.querySelector('td.renk input');
        const bedenInp = tr.querySelector('td.beden input');
        if (renkInp) renkInp.placeholder = def.renkPlaceholder;
        if (bedenInp) bedenInp.placeholder = def.bedenPlaceholder;
      });
    }

    // 3. Hızlı Renk/Beden Panelini Yenile
    if ($('rb-panel-baslik')) $('rb-panel-baslik').textContent = def.rbPanelBaslik;
    if ($('rb-beden-baslik')) $('rb-beden-baslik').textContent = def.rbBedenBaslik;
    if ($('rb-renk-baslik')) $('rb-renk-baslik').textContent = def.rbRenkBaslik;
    if ($('rb-ozel-beden')) $('rb-ozel-beden').placeholder = `Özel ${def.thBeden}`;
    if ($('rb-ozel-renk')) $('rb-ozel-renk').placeholder = `Özel ${def.thRenk}`;

    // 1. Izgara (Bedenler / Yaş / Hacim / Numara)
    if ($('rb-beden-izgara')) {
      const bIzgara = $('rb-beden-izgara');
      bIzgara.replaceChildren(...def.bedenler.map(b => {
        const btn = oge('button', {
          type: 'button',
          className: 'odak-secim-btn' + (typeof rbSeciliBeden !== 'undefined' && b === rbSeciliBeden ? ' secili' : ''),
          textContent: b
        });
        btn.dataset.beden = b;
        btn.onclick = () => {
          if (typeof rbSeciliBeden !== 'undefined') {
            rbSeciliBeden = rbSeciliBeden === b ? '' : b;
            if ($('rb-ozel-beden')) $('rb-ozel-beden').value = rbSeciliBeden;
            bIzgara.querySelectorAll('.odak-secim-btn').forEach(x => x.classList.toggle('secili', x.dataset.beden === rbSeciliBeden));
            if (typeof rbOzetGuncelle === 'function') rbOzetGuncelle();
          }
        };
        return btn;
      }));
    }

    // 2. Izgara (Renkler / Tür / Model)
    if ($('rb-renk-izgara')) {
      const rIzgara = $('rb-renk-izgara');
      rIzgara.replaceChildren(...def.renkler.map(r => {
        const btn = oge('button', {
          type: 'button',
          className: 'odak-secim-btn' + (typeof rbSeciliRenk !== 'undefined' && r === rbSeciliRenk ? ' secili' : ''),
          textContent: r
        });
        btn.dataset.renk = r;
        btn.onclick = () => {
          if (typeof rbSeciliRenk !== 'undefined') {
            rbSeciliRenk = rbSeciliRenk === r ? '' : r;
            if ($('rb-ozel-renk')) $('rb-ozel-renk').value = rbSeciliRenk;
            rIzgara.querySelectorAll('.odak-secim-btn').forEach(x => x.classList.toggle('secili', x.dataset.renk === rbSeciliRenk));
            if (typeof rbOzetGuncelle === 'function') rbOzetGuncelle();
          }
        };
        return btn;
      }));
    }

    // 4. Ürün Cinsi / Yaka Çiplerini Yenile
    if ($('yaka-cipleri-baslik')) $('yaka-cipleri-baslik').textContent = def.yakaBaslik;
    if ($('yaka-cipleri')) {
      const yKutu = $('yaka-cipleri');
      yKutu.replaceChildren(...def.yakaCipleri.map(m => {
        const cip = oge('button', {
          type: 'button',
          className: 'cip' + (typeof seciliModelCipi !== 'undefined' && m === seciliModelCipi ? ' secili' : ''),
          textContent: m
        });
        cip.dataset.model = m;
        cip.onclick = () => {
          const zaten = cip.classList.contains('secili');
          yKutu.querySelectorAll('.cip').forEach(x => x.classList.remove('secili'));
          if (typeof seciliModelCipi !== 'undefined') {
            seciliModelCipi = zaten ? '' : m;
          }
          if (!zaten) cip.classList.add('secili');
          if (!zaten && $('urun') && !$('urun').value.includes(m)) {
            $('urun').value = ($('urun').value.trim() ? $('urun').value.trim() + ' ' : '') + m;
          }
        };
        return cip;
      }));
    }

    // 5. Hızlı Yazarak Giriş Çiplerini Yenile
    if ($('yazi-hizli-cipler')) {
      const yaziKutu = $('yazi-hizli-cipler');
      yaziKutu.replaceChildren(...def.hizliYaziCipleri.map(kelime => {
        const cip = oge('button', {
          type: 'button',
          className: 'cip yazi-ekle-cip',
          textContent: kelime,
          style: 'padding:6px 2px;font-size:0.78rem;text-align:center'
        });
        cip.dataset.ekle = kelime;
        cip.onclick = () => {
          if (!$('soz')) return;
          const mevcut = $('soz').value.trim();
          $('soz').value = mevcut ? `${mevcut} ${kelime}` : kelime;
        };
        return cip;
      }));
    }

    // 6. Bilgilendirme ve Ses Örnek Metinleri
    if ($('ses-odak-alt-bilgi')) {
      $('ses-odak-alt-bilgi').innerHTML = `Örnek: <b>"${def.sesOrnegi}"</b>`;
    }
    if ($('calisma-pencere-baslik')) {
      $('calisma-pencere-baslik').textContent = `📦 ${def.ad.toLocaleUpperCase('tr-TR')} GİRİŞ PENCERESİ`;
    }
    if ($('calisma-pencere-durum')) {
      $('calisma-pencere-durum').innerHTML = `🎙️ Ürün adını, ${def.thRenk.toLowerCase()}, ${def.thBeden.toLowerCase()} ve fiyatını söyleyin veya girin; ardından alttaki <b>✓ KAYDET</b> tuşuna basın.`;
    }
    if ($('etiket-odak-durum')) {
      $('etiket-odak-durum').textContent = def.etiketRehber;
    }

    // 7. Sektör Kataloğunu Yükleme ve Sunucu Senkronizasyonu
    if (kaydetVeYukle) {
      sektorelKataloguYukleVeSenkronEt(def.kod);
    }
  }

  async function sektorelKataloguYukleVeSenkronEt(sektorKodu) {
    const def = SEKTOR_TANIMLARI[sektorKodu] || SEKTOR_TANIMLARI.giyim;
    durum(`⏳ "${def.ad}" barkod bankası ve marka sözlüğü yükleniyor…`);
    try {
      // 1. Sektörün .md dosyasını çekip yerel sözlüğe işle
      const mdResp = await fetch(`/${def.mdDosya}?t=${Date.now()}`);
      if (mdResp.ok) {
        const mdMetin = await mdResp.text();
        localStorage.setItem('mezat_mobil_marka_sozluk_md_v1', mdMetin);
        try {
          await post('/api/envanter/marka-sozlugu', { icerik: mdMetin, kip: 'birlestir' });
        } catch (_) {}
      }

      // 2. Sunucuya firma profili ve hazır barkod kataloğu isteği at
      const katResp = await fetch('/api/sistem/sektor-katalog-yukle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sektor: def.kod,
          sektorAdi: def.ad,
          urunler: SEKTOR_KATALOG_VERILERI[def.kod] || []
        })
      });
      if (katResp.ok) {
        const res = await katResp.json();
        durum(`✅ ${def.ad} arayüzü ve hazır barkod bankası (${res.toplamBarkodBankasi || 'Hazır'} barkod) aktif!`);
      } else {
        durum(`✅ ${def.ad} arayüzü aktif!`);
      }
    } catch (err) {
      durum(`✅ ${def.ad} yerel arayüzü aktif.`);
    }
  }
  window.sektorUygula = sektorUygula;
  window.sektorelKataloguYukleVeSenkronEt = sektorelKataloguYukleVeSenkronEt;

  function satirEkle(s = { renk: '', beden: '', adet: '', barkod: '' }) {
    const rPlaceholder = (g_aktifSektorTanimi && g_aktifSektorTanimi.renkPlaceholder) || 'Renk (Örn: Siyah / Beyaz)';
    const bPlaceholder = (g_aktifSektorTanimi && g_aktifSektorTanimi.bedenPlaceholder) || 'Beden';
    const renk = oge('input', { value: s.renk || '', placeholder: rPlaceholder, autocomplete: 'off' });
    const renkTemizleBtn = oge('button', {
      type: 'button',
      className: 'girdi-ic-sil-btn renk-temizle-btn',
      textContent: '✕',
      title: 'Yanlış yazılanı sil'
    });
    const renkGirdiKutu = oge('div', { className: 'girdi-temizle-kapsayici renk-girdi-kapsayici' }, renk, renkTemizleBtn);
    const renkTekilCipKutu = oge('div', { className: 'renk-tekil-etiketler gizli' });

    const beden = oge('input', { value: s.beden || '', placeholder: bPlaceholder, autocomplete: 'off' });
    const adet = oge('input', { value: s.adet == null ? '' : String(s.adet), placeholder: 'Adet', inputMode: 'numeric', autocomplete: 'off' });
    const azalt = oge('button', { type: 'button', className: 'adet-dugme', textContent: '−', title: '1 azalt' });
    const artir = oge('button', { type: 'button', className: 'adet-dugme', textContent: '+', title: '1 artır' });
    const sil = oge('button', { type: 'button', textContent: '✕', title: 'Satırı çıkar' });
    const adetKutu = oge('div', { className: 'adet-kutu' }, azalt, adet, artir);

    const irsaliyeAdet = s.irsaliyeAdet != null && s.irsaliyeAdet !== '' ? Number(s.irsaliyeAdet) : null;
    const irsaliyeRozet = oge('span', { className: 'irsaliye-rozet', textContent: irsaliyeAdet != null ? `📄 İrsaliye: ${irsaliyeAdet}` : '📄 İrsaliye: —' });
    const farkRozet = oge('span', { className: 'fark-rozet' });
    const sayimDugme = oge('button', { type: 'button', className: 'sayim-dugme', textContent: s.sayildi ? '☑ Sayıldı' : '☐ Sayıldı' });
    const satirBarkodEtiket = oge('small', { className: 'satir-barkod-etiket', textContent: s.barkod ? `🏷️ ${s.barkod}` : '' });

    function renkTekilCipleriYenile() {
      const parcalar = String(renk.value || '')
        .split(/[\/,;]+/)
        .map(p => p.trim())
        .filter(Boolean);
      if (parcalar.length <= 1) {
        renkTekilCipKutu.classList.add('gizli');
        renkTekilCipKutu.replaceChildren();
        return;
      }
      renkTekilCipKutu.classList.remove('gizli');
      renkTekilCipKutu.replaceChildren(...parcalar.map((parca, idx) => {
        const cipBtn = oge('button', {
          type: 'button',
          className: 'renk-tekil-sil-cip',
          title: `"${parca}" rengini kaldır`,
          textContent: `${parca} ✕`
        });
        cipBtn.onclick = () => {
          const kalanlar = parcalar.filter((_, i) => i !== idx);
          renk.value = kalanlar.join(' / ');
          renkTekilCipleriYenile();
          otomatikBarkodGuncelle();
          toplamYaz();
          durum(`🗑️ "${parca}" rengi silindi.`);
        };
        return cipBtn;
      }));
    }

    renkTemizleBtn.onclick = () => {
      const mevcut = String(renk.value || '').trim();
      if (!mevcut) {
        renk.focus();
        return;
      }
      const parcalar = mevcut.split(/[\/,;]+/).map(p => p.trim()).filter(Boolean);
      if (parcalar.length > 1) {
        const silinen = parcalar.pop();
        renk.value = parcalar.join(' / ');
        renkTekilCipleriYenile();
        otomatikBarkodGuncelle();
        toplamYaz();
        durum(`🗑️ "${silinen}" rengi silindi.`);
      } else {
        renk.value = '';
        renkTekilCipleriYenile();
        otomatikBarkodGuncelle();
        toplamYaz();
        durum('🗑️ Renk temizlendi.');
        renk.focus();
      }
    };

    const hucreler = [
      oge('td', { className: 'renk' }, renkGirdiKutu, renkTekilCipKutu, satirBarkodEtiket),
      oge('td', { className: 'beden' }, beden),
      ...(irsaliyeModu ? [oge('td', { className: 'irsaliye-adet' }, irsaliyeRozet, farkRozet)] : []),
      oge('td', { className: 'adet' }, adetKutu),
      ...(irsaliyeModu ? [oge('td', { className: 'sayim-onay' }, sayimDugme)] : []),
      oge('td', { className: 'sil' }, sil)
    ];
    const tr = oge('tr', { className: irsaliyeModu ? 'irsaliye-satir' : '' }, ...hucreler);
    if (s.barkod) {
      tr.dataset.barkod = s.barkod;
      if (!String(s.barkod).startsWith('MZU-')) tr.dataset.ozelBarkod = s.barkod;
    }
    if (irsaliyeAdet != null && Number.isFinite(irsaliyeAdet)) tr.dataset.irsaliyeAdet = String(irsaliyeAdet);
    tr.dataset.sayildi = s.sayildi ? '1' : '0';

    renkTekilCipleriYenile();
    renk.addEventListener('input', () => {
      renkTekilCipleriYenile();
      otomatikBarkodGuncelle();
    });
    beden.addEventListener('input', () => otomatikBarkodGuncelle());

    const altSinir = irsaliyeModu ? 0 : 1;
    azalt.onclick = () => {
      const n = Number(adet.value) || 0;
      if (n > altSinir) {
        adet.value = String(n - 1);
        if (irsaliyeModu) tr.dataset.sayildi = '1';
        toplamYaz();
      }
    };
    artir.onclick = () => {
      const n = Number(adet.value) || 0;
      adet.value = String(n + 1);
      if (irsaliyeModu) tr.dataset.sayildi = '1';
      toplamYaz();
    };
    sayimDugme.onclick = () => {
      tr.dataset.sayildi = tr.dataset.sayildi === '1' ? '0' : '1';
      toplamYaz();
    };
    sil.onclick = async () => {
      sonSilinenSatir = {
        renk: renk.value.trim(),
        beden: beden.value.trim(),
        adet: adet.value.trim() === '' ? '' : Number(adet.value),
        irsaliyeAdet: tr.dataset.irsaliyeAdet != null && tr.dataset.irsaliyeAdet !== '' ? Number(tr.dataset.irsaliyeAdet) : null,
        sayildi: tr.dataset.sayildi === '1',
        barkod: tr.dataset.barkod || ''
      };
      tr.remove();
      toplamYaz();
      // Eğer kayıtlı bir ürünü düzeltiyorsak (duzeltilenId) ve son satırı da sildiysek, kaydı veritabanından tamamen sil!
      if (duzeltilenId && $('satirlar').children.length === 0) {
        const silinecekId = duzeltilenId;
        const silinecekAd = $('urun') ? $('urun').value.trim() : 'Ürün';
        await kayitSilDogrudan(silinecekId, silinecekAd);
        return;
      }
      if ($('geri-al-cubuk') && (sonSilinenSatir.renk || sonSilinenSatir.beden || sonSilinenSatir.adet !== '')) {
        $('geri-al-metin').textContent = `${[sonSilinenSatir.renk, sonSilinenSatir.beden].filter(Boolean).join(' ') || 'Satır'} (${sonSilinenSatir.adet || 0} adet) silindi.`;
        $('geri-al-cubuk').classList.remove('gizli');
        if (geriAlZamanlayici) clearTimeout(geriAlZamanlayici);
        geriAlZamanlayici = setTimeout(() => {
          if ($('geri-al-cubuk')) $('geri-al-cubuk').classList.add('gizli');
          sonSilinenSatir = null;
        }, 6000);
      }
    };
    adet.addEventListener('input', () => {
      if (irsaliyeModu) tr.dataset.sayildi = '1';
      toplamYaz();
    });
    $('satirlar').append(tr);
    toplamYaz();
  }

  function satirlariOku() {
    return [...$('satirlar').querySelectorAll('tr')].map(tr => {
      const [renk, beden, adet] = tr.querySelectorAll('input');
      const o = { renk: renk.value.trim(), beden: beden.value.trim(), adet: adet.value.trim() === '' ? null : Number(adet.value) };
      if (tr.dataset.barkod) o.barkod = tr.dataset.barkod;
      if (irsaliyeModu) {
        if (tr.dataset.irsaliyeAdet != null && tr.dataset.irsaliyeAdet !== '') o.irsaliyeAdet = Number(tr.dataset.irsaliyeAdet);
        o.sayildi = tr.dataset.sayildi === '1';
      }
      return o;
    });
  }

  function toplamYaz() {
    let toplam = 0;
    let irsaliyeToplam = 0;
    let sayilanSatir = 0;
    const altSinir = irsaliyeModu ? 0 : 1;
    const trListesi = [...$('satirlar').querySelectorAll('tr')];
    trListesi.forEach(tr => {
      const adet = tr.querySelectorAll('input')[2];
      const n = Number(adet.value);
      const gecerli = adet.value.trim() !== '' && Number.isInteger(n) && n >= altSinir;
      adet.classList.toggle('eksik', !gecerli);
      if (gecerli) toplam += n;

      if (irsaliyeModu) {
        const irsAdet = tr.dataset.irsaliyeAdet != null && tr.dataset.irsaliyeAdet !== '' ? Number(tr.dataset.irsaliyeAdet) : null;
        if (irsAdet != null) irsaliyeToplam += irsAdet;
        const farkEl = tr.querySelector('.fark-rozet');
        if (farkEl) {
          farkEl.className = 'fark-rozet';
          if (irsAdet != null && gecerli) {
            const fark = n - irsAdet;
            if (fark === 0) { farkEl.textContent = '✓ Tam'; farkEl.classList.add('tam'); }
            else if (fark < 0) { farkEl.textContent = `⚠ ${fark} Eksik`; farkEl.classList.add('eksik'); }
            else { farkEl.textContent = `+${fark} Fazla`; farkEl.classList.add('fazla'); }
          } else {
            farkEl.textContent = '';
          }
        }
        const sayildi = tr.dataset.sayildi === '1';
        if (sayildi) sayilanSatir++;
        const sayimBtn = tr.querySelector('.sayim-dugme');
        if (sayimBtn) {
          sayimBtn.textContent = sayildi ? '☑ Sayıldı' : '☐ Sayıldı';
          sayimBtn.classList.toggle('onayli', sayildi);
        }
      }
    });
    const satir = trListesi.length;
    $('toplam').textContent = satir
      ? (irsaliyeModu ? `${satir} beden satırı · İrsaliye: ${irsaliyeToplam} adet · Sayılan Net: ${toplam} adet` : `${satir} satır · toplam ${toplam} adet`)
      : 'Henüz satır yok.';

    if (irsaliyeModu) {
      sayimOnayli = satir > 0 && sayilanSatir === satir;
      if ($('sayim-ozet')) {
        const fark = toplam - irsaliyeToplam;
        const farkMetni = fark === 0 ? '✓ İrsaliye ile birebir aynı' : (fark < 0 ? `⚠ İrsaliyeye göre ${Math.abs(fark)} adet eksik` : `ℹ İrsaliyeye göre +${fark} adet fazla`);
        $('sayim-ozet').textContent = `İrsaliye: ${irsaliyeToplam} adet · Sayılan Net: ${toplam} adet (${farkMetni}) · Doğrulanan satır: ${sayilanSatir}/${satir}`;
      }
      if ($('tumunu-saydim')) {
        $('tumunu-saydim').textContent = sayimOnayli
          ? '☑ Tüm Satırlar Sayıldı, Adetler Net (Onaylandı)'
          : '☐ Tüm Satırlar Sayıldı, Adetler Net (Onayla)';
        $('tumunu-saydim').classList.toggle('onayli', sayimOnayli);
      }
      if ($('sayim-onay-cubuk')) $('sayim-onay-cubuk').classList.toggle('tamam', sayimOnayli);
      const fiyatVar = $('fiyat').value.trim() !== '' && Number(String($('fiyat').value).replace(',', '.')) > 0;
      $('fiyat').classList.toggle('fiyat-vurgu', sayimOnayli && !fiyatVar);
    } else {
      $('fiyat').classList.remove('fiyat-vurgu');
    }
    otomatikBarkodGuncelle();
  }

  function tabloyuDoldur(c) {
    if (c.irsaliyeModu !== undefined) irsaliyeModunuAyarla(Boolean(c.irsaliyeModu));
    if (c.urun) $('urun').value = c.urun;
    if (c.fiyat) $('fiyat').value = String(c.fiyat);
    else if (c.onerilenFiyat) $('fiyat').value = String(c.onerilenFiyat);
    else $('fiyat').value = '';
    if (c.barkod && $('barkod')) $('barkod').value = String(c.barkod);
    $('satirlar').replaceChildren();
    (c.satirlar || []).forEach(satirEkle);
    if (!(c.satirlar || []).length) satirEkle();
    $('uyarilar').replaceChildren(...(c.uyarilar || []).map(u => oge('div', { className: 'uyari', textContent: `⚠ ${u}` })));
    toplamYaz();
    otomatikBarkodGuncelle(c.veriBankasindaKayitli != null ? Boolean(c.veriBankasindaKayitli) : null);
  }

  // Etiket/Fotoğraf veya Barkod okutulduğunda tabloya akıllı ekleme (aynı ürünse satır ekler veya adedini +1 artırır)
  function satiraEkleVeyaArtir({ urun, fiyat, barkod, renk = '', beden = '', adet = 1, etiketOkuma = false }) {
    const mevcutUrun = $('urun').value.trim();
    const yeniUrun = String(urun || '').trim();
    let urunDegistiMi = false;
    if (yeniUrun && !mevcutUrun) {
      $('urun').value = yeniUrun;
    } else if (yeniUrun && mevcutUrun && mevcutUrun.toLocaleLowerCase('tr-TR') !== yeniUrun.toLocaleLowerCase('tr-TR')) {
      const mLow = mevcutUrun.toLocaleLowerCase('tr-TR');
      const yLow = yeniUrun.toLocaleLowerCase('tr-TR');
      const cipLow = String(seciliModelCipi || '').toLocaleLowerCase('tr-TR').trim();
      // 1) Biri diğerini kapsıyorsa (örn: "Parfüm Mutfağı" + "Parfüm Mutfağı PM Lab E-182 50 ML") uzun olanı yaz
      if (yLow === mLow) {
        $('urun').value = yeniUrun;
      } else if (yLow.includes(mLow)) {
        $('urun').value = yeniUrun;
      } else if (!mLow.includes(yLow)) {
        // 2) Mevcut kutuda sadece seçili yaka/model çipi varsa birleştir;
        //    farklı bir ürün fotoğrafı çekildiyse (aynı üst markanın farklı serisi "Night" vs "My Voyage" vs "PM Lab E-182" dahil) doğrudan yeni ürünü yaz ve eski satırları sıfırla!
        if (cipLow && mLow === cipLow) {
          $('urun').value = `${yeniUrun} ${mevcutUrun}`.trim();
          urunDegistiMi = true;
        } else {
          $('urun').value = yeniUrun;
          urunDegistiMi = true;
        }
      }
    }
    if (etiketOkuma && urunDegistiMi) {
      duzeltilenId = null;
      duzeltilenSurum = 0;
      if ($('duzeltme-notu')) $('duzeltme-notu').classList.add('gizli');
      $('fiyat').value = fiyat ? String(fiyat) : '';
    } else if (fiyat) {
      $('fiyat').value = String(fiyat);
    }
    if (barkod && $('barkod')) $('barkod').value = String(barkod);
    else if (urunDegistiMi && $('barkod')) $('barkod').value = otomatikBarkodHesapla($('urun').value);

    const rTemiz = String(renk || '').trim().toLocaleUpperCase('tr-TR');
    const bTemiz = String(beden || '').trim().toLocaleUpperCase('tr-TR');
    const trListesi = [...$('satirlar').querySelectorAll('tr')];

    // Fotoğraf/etiket okumasında farklı bir ürüne geçildiyse önceki ürüne ait tüm beden/adet satırlarını temizleyip yalnızca yeni ürünü yaz!
    if (etiketOkuma && urunDegistiMi) {
      $('satirlar').replaceChildren();
      // Ürün kodu (E180) beklerken kamera yalnız adı okuduysa kod beden yerine kalır
      const kodBeden = bTemiz || String(window.__mezatUrunKodu || '').toLocaleUpperCase('tr-TR');
      const koddanMi = Boolean(kodBeden) && !bTemiz;
      satirEkle({ renk: rTemiz, beden: kodBeden, adet: Number(adet) || 1, barkod: koddanMi ? '' : (($('barkod') && $('barkod').value.trim()) || barkod) });
      if (koddanMi) otomatikBarkodGuncelle();
      toplamYaz();
      return;
    }

    // Tabloda aynı renk+beden satırı varsa adedini artır (etiket okumasında aynı kutunun yakın çekimiyse adedi sabit tut);
    // veya tabloda tek bir yarım satır varsa (rengi ya da bedeni boşsa) yeni satır açmak yerine o satırı tamamla!
    for (const tr of trListesi) {
      const [rIn, bIn, aIn] = tr.querySelectorAll('input');
      const mevcutR = rIn.value.trim().toLocaleUpperCase('tr-TR');
      const mevcutB = bIn.value.trim().toLocaleUpperCase('tr-TR');
      if (mevcutR === rTemiz && mevcutB === bTemiz) {
        if (!etiketOkuma) {
          aIn.value = String((Number(aIn.value) || 0) + (Number(adet) || 1));
        } else if (!aIn.value.trim() || Number(aIn.value) <= 0) {
          aIn.value = String(Number(adet) || 1);
        }
        if (barkod) tr.dataset.barkod = barkod;
        toplamYaz();
        return;
      }
      if (trListesi.length === 1 && ((!mevcutR && rTemiz) || (!mevcutB && bTemiz) || (!rTemiz && !bTemiz))) {
        if (rTemiz && !mevcutR) {
          rIn.value = rTemiz;
          rIn.dispatchEvent(new Event('input'));
        }
        if (bTemiz && !mevcutB) bIn.value = bTemiz;
        if (!rTemiz && !bTemiz && !etiketOkuma) {
          aIn.value = String((Number(aIn.value) || 0) + (Number(adet) || 1));
        } else if (!aIn.value.trim()) {
          aIn.value = String(Number(adet) || 1);
        }
        if (barkod) tr.dataset.barkod = barkod;
        toplamYaz();
        return;
      }
    }
    // İlk satır tamamen boşsa onun içine yaz
    if (trListesi.length === 1) {
      const [rIn, bIn, aIn] = trListesi[0].querySelectorAll('input');
      if (!rIn.value.trim() && !bIn.value.trim() && !aIn.value.trim()) {
        rIn.value = rTemiz;
        rIn.dispatchEvent(new Event('input'));
        bIn.value = bTemiz;
        aIn.value = String(Number(adet) || 1);
        if (barkod) trListesi[0].dataset.barkod = barkod;
        toplamYaz();
        return;
      }
    }
    satirEkle({ renk: rTemiz, beden: bTemiz, adet: Number(adet) || 1, barkod });
  }

  function formuTemizle(irsaliyeyiKoru = false) {
    duzeltilenId = null;
    duzeltilenSurum = 0;
    aktifIstekId = null;
    soruyuKapat();
    $('duzeltme-notu').classList.add('gizli');
    $('soz').value = '';
    $('urun').value = '';
    $('fiyat').value = '';
    if ($('barkod')) $('barkod').value = '';
    window.__mezatUrunKodu = '';
    if ($('etiket-metin')) $('etiket-metin').value = '';
    if (!irsaliyeyiKoru) {
      irsaliyeModunuAyarla(false);
      irsaliyeKalemler = [];
      seciliKalemIndeks = 0;
      kaydedilenKalemler = new Set();
      if ($('irsaliye-kalemler')) {
        $('irsaliye-kalemler').replaceChildren();
        $('irsaliye-kalemler').classList.add('gizli');
      }
    }
    $('uyarilar').replaceChildren();
    if ($('ses-analiz-cubuk')) $('ses-analiz-cubuk').classList.add('gizli');
    $('satirlar').replaceChildren();
    satirEkle();
  }

  // ===== 📷 Etiket ve Ürün Fotoğrafı Tanıma =====
  let sonGorselVeri = '';
  let sonTahminRenk = '';
  let seciliModelCipi = '';

  function resimdenRenkTahminEt(canvas) {
    try {
      const ctx = canvas.getContext('2d');
      const d = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      let rTop = 0, gTop = 0, bTop = 0, say = 0;
      let beyazSay = 0, toplamOrnek = 0;
      // Ortadaki parlak beyaz kağıt etiket piksellerini ayıkla ki koyu kumaş gri/bej sanılmasın
      for (let i = 0; i < d.length; i += 16) {
        const pr = d[i], pg = d[i + 1], pb = d[i + 2];
        toplamOrnek++;
        if (pr > 228 && pg > 228 && pb > 228 && Math.max(pr, pg, pb) - Math.min(pr, pg, pb) < 18) {
          beyazSay++;
          continue;
        }
        rTop += pr; gTop += pg; bTop += pb; say++;
      }
      // Görüntünün neredeyse tamamı beyazsa ürün beyazdır
      if (toplamOrnek > 0 && beyazSay / toplamOrnek > 0.72) return 'BEYAZ';
      if (!say) return '';
      const r = rTop / say, g = gTop / say, b = bTop / say;
      const parlaklik = (r + g + b) / 3;
      const fark = Math.max(r, g, b) - Math.min(r, g, b);
      if (parlaklik < 52 && fark < 32) return 'SİYAH';
      if (parlaklik > 205 && fark < 30) return 'BEYAZ';
      if (fark < 22) return 'GRİ';
      if (r > g + 35 && r > b + 35) return r > 160 ? 'KIRMIZI' : 'BORDO';
      if (b > r + 25 && b > g + 15) return parlaklik < 85 ? 'LACİVERT' : 'MAVİ';
      if (g > r + 15 && g > b + 15) return 'YEŞİL';
      if (r > 170 && g > 140 && b < 120) return 'BEJ';
      return '';
    } catch (err) { return ''; }
  }

  let etiketKameraAkis = null;
  let irsaliyeKameraAkis = null;

  function etiketCanliKamerayiKapat() {
    if (etiketKameraAkis) {
      etiketKameraAkis.getTracks().forEach(t => t.stop());
      etiketKameraAkis = null;
    }
  }

  async function etiketCanliKamerayiAc() {
    if ($('etiket-canli-vizor')) $('etiket-canli-vizor').classList.remove('gizli');
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return false;
    }
    if (etiketKameraAkis) return true;
    try {
      try {
        etiketKameraAkis = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: 'environment' },
            width: { ideal: 1920 },
            height: { ideal: 1080 },
            advanced: [{ focusMode: 'continuous' }]
          }
        });
      } catch (_) {
        etiketKameraAkis = await navigator.mediaDevices.getUserMedia({ video: true });
      }
      const v = $('etiket-video');
      if (v) {
        v.srcObject = etiketKameraAkis;
        if ($('etiket-canli-vizor')) $('etiket-canli-vizor').classList.remove('gizli');
        await v.play();
      }
      return true;
    } catch (_) {
      etiketKameraAkis = null;
      return false;
    }
  }

  function irsaliyeCanliKamerayiKapat() {
    if (irsaliyeKameraAkis) {
      irsaliyeKameraAkis.getTracks().forEach(t => t.stop());
      irsaliyeKameraAkis = null;
    }
    if ($('irsaliye-canli-vizor')) $('irsaliye-canli-vizor').classList.add('gizli');
  }

  async function irsaliyeCanliKamerayiAc() {
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return false;
    }
    if (irsaliyeKameraAkis) return true;
    try {
      irsaliyeKameraAkis = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          advanced: [{ focusMode: 'continuous' }]
        }
      });
      const v = $('irsaliye-video');
      if (v) {
        v.srcObject = irsaliyeKameraAkis;
        if ($('irsaliye-canli-vizor')) $('irsaliye-canli-vizor').classList.remove('gizli');
        await v.play();
      }
      return true;
    } catch (_) {
      irsaliyeKameraAkis = null;
      return false;
    }
  }

  let sonGorselBarkodu = '';
  let sonGorselParmakIzi = null;

  // Işık, mesafe ve açı farklarına dayanıklı 9x8 Görsel Parmak İzi (dHash + vHash + Renk İmzası)
  function resimdenParmakIziCikar(kaynakCanvas) {
    try {
      const sw = kaynakCanvas.width || kaynakCanvas.videoWidth || 0;
      const sh = kaynakCanvas.height || kaynakCanvas.videoHeight || 0;
      if (sw < 16 || sh < 16) return null;
      const c = document.createElement('canvas');
      c.width = 9;
      c.height = 8;
      const ctx = c.getContext('2d');
      // Merkezdeki ürün/etiket bölgesini (%12..%88) örnekle
      const sx = Math.round(sw * 0.12);
      const sy = Math.round(sh * 0.12);
      const cw = Math.max(8, Math.round(sw * 0.76));
      const ch = Math.max(8, Math.round(sh * 0.76));
      ctx.drawImage(kaynakCanvas, sx, sy, cw, ch, 0, 0, 9, 8);
      const img = ctx.getImageData(0, 0, 9, 8).data;
      const lum = new Float32Array(72);
      const bantTop = [0, 0, 0, 0, 0, 0, 0, 0, 0];
      for (let y = 0; y < 8; y++) {
        const bant = y < 3 ? 0 : (y < 6 ? 1 : 2);
        for (let x = 0; x < 9; x++) {
          const idx = (y * 9 + x) * 4;
          const r = img[idx];
          const g = img[idx + 1];
          const b = img[idx + 2];
          lum[y * 9 + x] = 0.299 * r + 0.587 * g + 0.114 * b;
          bantTop[bant * 3] += r;
          bantTop[bant * 3 + 1] += g;
          bantTop[bant * 3 + 2] += b;
        }
      }
      let dhash = '';
      for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
          dhash += lum[y * 9 + x] >= lum[y * 9 + x + 1] ? '1' : '0';
        }
      }
      let vhash = '';
      for (let y = 0; y < 7; y++) {
        for (let x = 0; x < 8; x++) {
          vhash += lum[y * 9 + x] >= lum[(y + 1) * 9 + x] ? '1' : '0';
        }
      }
      const renkImza = [];
      for (let b = 0; b < 3; b++) {
        const r = bantTop[b * 3];
        const g = bantTop[b * 3 + 1];
        const bl = bantTop[b * 3 + 2];
        const top = Math.max(1, r + g + bl);
        renkImza.push(
          Math.round((r / top) * 1000) / 1000,
          Math.round((g / top) * 1000) / 1000,
          Math.round((bl / top) * 1000) / 1000
        );
      }
      return { dhash, vhash, renkImza };
    } catch (_) {
      return null;
    }
  }

  // Fotoğraf okuma adımlarını sessizce tutar; yalnız bir sorun olunca hepsini büyük bir kutuda gösterir
  // (hangi adımda kaldığı görünsün). Başarılı okumada kutu çıkmaz.
  let ocrIzZaman = null;
  let ocrIzSatirlar = [];
  function ocrIz(metin, basla = false, hata = false) {
    try {
      const s = new Date();
      const satir = `${String(s.getMinutes()).padStart(2, '0')}:${String(s.getSeconds()).padStart(2, '0')}  ${metin}`;
      if (basla) {
        const kaynak = location.protocol === 'file:' ? 'uygulamanın içindeki sayfa' : `bilgisayardan gelen sayfa (${location.host})`;
        ocrIzSatirlar = [`🔎 Okuma adımları — ${kaynak}, ${typeof ISTEMCI_YAPIM_NO !== 'undefined' ? ISTEMCI_YAPIM_NO : ''} (kapatmak için dokunun)`];
        window.__ocrIzAktif = true;
        const eski = document.getElementById('mezat-ocr-iz');
        if (eski) eski.remove();
      }
      ocrIzSatirlar.push(satir);
      if (ocrIzSatirlar.length > 60) ocrIzSatirlar.splice(1, ocrIzSatirlar.length - 60);
      clearTimeout(ocrIzZaman);
      ocrIzZaman = setTimeout(() => { window.__ocrIzAktif = false; }, 180000);
      let k = document.getElementById('mezat-ocr-iz');
      if (!k && !hata) return;
      if (!k) {
        k = document.createElement('div');
        k.id = 'mezat-ocr-iz';
        k.style.cssText = 'position:fixed;left:8px;right:8px;top:8px;z-index:2147483646;background:#0b1220;border:2px solid #facc15;border-radius:12px;padding:8px 10px;color:#fef9c3;font:700 14px/1.35 system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.7);white-space:pre-wrap;max-height:45vh;overflow:auto';
        k.addEventListener('click', () => k.remove());
        document.body.appendChild(k);
      }
      k.textContent = ocrIzSatirlar.join('\n');
    } catch (_) {}
  }
  window.addEventListener('error', e => { if (window.__ocrIzAktif) ocrIz(`HATA: ${e.message || e}`, false, true); });
  window.addEventListener('unhandledrejection', e => { if (window.__ocrIzAktif) ocrIz(`HATA: ${(e.reason && e.reason.message) || e.reason}`, false, true); });

  // Bilgisayara ulaşılamazsa fotoğraf telefonda okunur (telefon uygulamasında; mobil-hibrit.js)
  async function bilgisayaraYaDaTelefonda(yol, govde, telefonIsi) {
    try {
      ocrIz('bilgisayara gönderiliyor');
      const c = await post(yol, govde);
      ocrIz('bilgisayar cevap verdi');
      return c;
    } catch (agHatasi) {
      ocrIz(`bilgisayara ulaşılamadı (${agHatasi && agHatasi.message ? agHatasi.message : agHatasi})`);
      const H = window.MezatMobilHibrit;
      if (!H || typeof H.telefondaOkumaVarMi !== 'function' || !H.telefondaOkumaVarMi()) {
        ocrIz(`telefonda okuma yok: ${!H ? 'mobil-hibrit yüklenmemiş' : (typeof H.telefondaOkumaVarMi !== 'function' ? 'eski mobil-hibrit' : 'uygulama köprüsü yok')}`, false, true);
        throw agHatasi;
      }
      durum('📷 Bilgisayara ulaşılamadı; yazı telefonda okunuyor (ilk seferde biraz sürer)…');
      try {
        return await telefonIsi(H);
      } catch (e) {
        return { success: false, error: `⚠ Telefonda okunamadı: ${e && e.message ? e.message : e}` };
      }
    }
  }

  async function etiketiSunucuyaSor(gorsel = '') {
    try {
      durum('📷 Ürün bilgisi (Yalnızca Ürün Adı & Beden/ML) ayıklanıyor…');
      const govde = {
        gorsel: gorsel || sonGorselVeri,
        gorselParmakIzi: sonGorselParmakIzi,
        etiketMetni: $('etiket-metin') ? $('etiket-metin').value.trim() : '',
        model: seciliModelCipi,
        mevcutUrun: '',
        renk: '',
        barkod: sonGorselBarkodu || ''
      };
      const cevap = await bilgisayaraYaDaTelefonda('/api/envanter/fotograf', govde, H => H.telefondaEtiketOku({ ...govde, adim: m => durum(`📷 Bilgisayara ulaşılamadı, telefonda okunuyor: ${m}…`) }));
      ocrIz(cevap.success ? `sonuç: ${cevap.urun || '(ürün adı yok)'} / ${(cevap.bedenler || []).join(',') || '(beden yok)'}${cevap.telefondaOkundu ? ' [telefonda okundu]' : ''}` : `sonuç: ${cevap.error}`, false, !cevap.success);
      if (!cevap.success) { durum(cevap.error || 'Ürün bilgisi okunamadı.', true); return; }
      if (cevap.ocrMetin && $('etiket-metin')) {
        $('etiket-metin').value = String(cevap.ocrMetin).replace(/\s+/g, ' ').trim();
      }
      const yeniBarkod = (cevap.barkod && (/^MZU?-/i.test(String(cevap.barkod)) || gecerliFabrikaBarkodu(String(cevap.barkod))))
        ? String(cevap.barkod)
        : (cevap.urun ? otomatikBarkodHesapla(cevap.urun) : '');
      if (yeniBarkod && $('barkod')) {
        $('barkod').value = yeniBarkod;
      }
      const anlamliOkumaVar = Boolean(
        cevap.urun ||
        (Array.isArray(cevap.bedenler) && cevap.bedenler.length > 0) ||
        seciliModelCipi
      );
      if (anlamliOkumaVar && cevap.satirlar && cevap.satirlar.length) {
        bipSesi();
        cevap.satirlar.forEach(s => satiraEkleVeyaArtir({
          urun: cevap.urun,
          fiyat: cevap.fiyat || cevap.onerilenFiyat || null,
          barkod: yeniBarkod || cevap.barkod,
          renk: s.renk,
          beden: s.beden,
          adet: s.adet || 1,
          etiketOkuma: true
        }));
      } else if (cevap.urun) {
        bipSesi();
        satiraEkleVeyaArtir({
          urun: cevap.urun,
          fiyat: cevap.fiyat || cevap.onerilenFiyat || null,
          barkod: yeniBarkod || cevap.barkod,
          renk: '',
          beden: (cevap.bedenler && cevap.bedenler[0]) || '',
          adet: 1,
          etiketOkuma: true
        });
      }
      $('uyarilar').replaceChildren(...(cevap.uyarilar || []).map(u => oge('div', { className: 'uyari', textContent: `⚠ ${u}` })));
      if (!anlamliOkumaVar) {
        durum('⚠ Ürün adı veya beden bilgisi seçilemedi (diğer yazılar atlandı). Kamerayı ürün adına/bedene yaklaştırıp tekrar çekin.', true);
        return;
      }
      etiketCanliKamerayiKapat();
      if ($('etiket-panel')) $('etiket-panel').classList.add('gizli');
      const satirOzet = (cevap.satirlar || []).map(s => [s.renk, s.beden ? `${s.beden}` : ''].filter(Boolean).join(' ')).filter(Boolean).join(', ');
      const hafizaBilgi = cevap.hafizadanDogrulandi ? ' (🧠 Kayıtlı ürün fotoğrafıyla eşleştirilerek doğrulandı)' : '';
      durum(`✓ Ürün bilgisi alındı: ${$('urun').value || cevap.urun || 'Ürün'}${satirOzet ? ` (${satirOzet})` : ''}${hafizaBilgi}. Şimdi 🎙️ ÜRÜN GİRİŞİ ile fiyatını/adedini söyleyebilir veya Kaydet'e basabilirsiniz.`);
    } catch (err) {
      durum('Fotoğraf bilgisayara gönderilemedi.', true);
    }
  }

  async function etiketCanvasIsle(canvas) {
    ocrIz(`fotoğraf alındı (${canvas.width}x${canvas.height})`, true);
    sonTahminRenk = resimdenRenkTahminEt(canvas);
    sonGorselParmakIzi = resimdenParmakIziCikar(canvas);
    sonGorselVeri = canvas.toDataURL('image/jpeg', 0.92);
    sonGorselBarkodu = '';
    if ($('etiket-resim')) {
      $('etiket-resim').src = sonGorselVeri;
      $('etiket-resim').classList.remove('gizli');
    }
    if ($('etiket-metin')) $('etiket-metin').value = '';
    if ('BarcodeDetector' in window) {
      try {
        const det = new window.BarcodeDetector({ formats: ['ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'qr_code'] });
        const bulunanlar = await det.detect(canvas);
        const secilen = window.MezatBarkod && typeof window.MezatBarkod.barkodSec === 'function'
          ? window.MezatBarkod.barkodSec(bulunanlar)
          : (bulunanlar && bulunanlar[0] && bulunanlar[0].rawValue ? bulunanlar[0].rawValue : '');
        if (secilen && (/^MZU?-/i.test(secilen) || gecerliFabrikaBarkodu(secilen))) {
          sonGorselBarkodu = secilen;
        }
      } catch (_) {}
    }
    if (!sonGorselBarkodu && window.MezatBarkod && typeof window.MezatBarkod.goruntudenOku === 'function') {
      const b1d = window.MezatBarkod.goruntudenOku(canvas);
      if (b1d && (/^MZU?-/i.test(b1d) || gecerliFabrikaBarkodu(b1d))) sonGorselBarkodu = b1d;
    }
    ocrIz(`barkod araması bitti${sonGorselBarkodu ? `: ${sonGorselBarkodu}` : ''}; okumaya geçiliyor`);
    await etiketiSunucuyaSor(sonGorselVeri);
    ocrIz('iş bitti');
  }

  async function kutuOkumaKamerasiniAcKapat() {
    const acik = !$('etiket-panel').classList.contains('gizli');
    if (acik) {
      etiketCanliKamerayiKapat();
      $('etiket-panel').classList.add('gizli');
      return;
    }
    digerAltPanelleriKapat('etiket-panel');
    $('etiket-panel').classList.remove('gizli');
    const canliAcildi = await etiketCanliKamerayiAc();
    if (!canliAcildi) {
      durum('📷 Ürün fotoğrafını çekmek veya galeriden seçmek için aşağıdaki yeşil düğmeye dokunun.');
    } else {
      durum('📷 Kamerayı ürün etiketine, bilgi kartına veya kutusuna tutup "📸 ÜRÜNÜ ÇEK (İsim & Beden Al)" tuşuna basın.');
    }
  }

  if ($('kutu-isim-oku-btn')) {
    $('kutu-isim-oku-btn').addEventListener('click', () => kutuOkumaKamerasiniAcKapat());
  }

  if ($('etiket-cek')) {
    $('etiket-cek').addEventListener('click', async e => {
      if (e.detail === 0) return;
      await kutuOkumaKamerasiniAcKapat();
    });
    if ($('etiket-kapat')) {
      $('etiket-kapat').addEventListener('click', () => {
        etiketCanliKamerayiKapat();
        $('etiket-panel').classList.add('gizli');
        durum('');
        if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
      });
    }
    if ($('etiket-canli-cek-btn')) {
      $('etiket-canli-cek-btn').addEventListener('click', async () => {
        const v = $('etiket-video');
        if (!etiketKameraAkis) {
          await etiketCanliKamerayiAc();
          for (let i = 0; i < 8 && v && (v.readyState < 2 || v.videoWidth === 0); i++) {
            await new Promise(r => setTimeout(r, 100));
          }
        }
        if (etiketKameraAkis && v && v.readyState >= 2 && v.videoWidth > 0) {
          const enBoy = 1440;
          const oran = Math.min(1, enBoy / Math.max(v.videoWidth, v.videoHeight));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(v.videoWidth * oran));
          canvas.height = Math.max(1, Math.round(v.videoHeight * oran));
          canvas.getContext('2d').drawImage(v, 0, 0, canvas.width, canvas.height);
          await etiketCanvasIsle(canvas);
        } else {
          ocrIz(`canlı kamera açılamadı (güvenli sayfa: ${window.isSecureContext ? 'evet' : 'hayır'}, kamera izni/aygıtı: ${navigator.mediaDevices ? 'var' : 'yok'}); galeri açılıyor`, true);
          if (typeof window.mezatGaleriMerkeziAc === 'function') window.mezatGaleriMerkeziAc('etiket');
          else $('kamera-dosya').click();
        }
      });
    }
    if ($('etiket-tekrar')) {
      $('etiket-tekrar').addEventListener('click', () => {
        const eskiApk = Boolean(window.MezatNativeApp && typeof window.MezatNativeApp.dosyaSeciciDestekli !== 'function');
        if (!eskiApk && $('kamera-dosya')) {
          try { $('kamera-dosya').click(); } catch (_) {}
        }
        if (typeof window.mezatGaleriMerkeziAc === 'function') {
          window.mezatGaleriMerkeziAc('etiket');
        }
      });
    }
    $('etiket-uygula').addEventListener('click', () => etiketiSunucuyaSor());
    $('yaka-cipleri').querySelectorAll('.cip').forEach(d => {
      d.addEventListener('click', () => {
        const zaten = d.classList.contains('secili');
        $('yaka-cipleri').querySelectorAll('.cip').forEach(x => x.classList.remove('secili'));
        seciliModelCipi = zaten ? '' : d.dataset.model;
        if (!zaten) d.classList.add('secili');
        if (seciliModelCipi && $('urun')) {
          const mevcut = $('urun').value.trim();
          if (!mevcut) {
            $('urun').value = seciliModelCipi;
          } else {
            const birlesik = [];
            for (const k of `${mevcut} ${seciliModelCipi}`.split(/\s+/).filter(Boolean)) {
              if (!birlesik.some(x => x.toLocaleLowerCase('tr-TR') === k.toLocaleLowerCase('tr-TR'))) {
                birlesik.push(k);
              }
            }
            $('urun').value = birlesik.join(' ');
          }
          otomatikBarkodGuncelle();
          durum(`✓ Model seçildi: ${$('urun').value}. Şimdi yeşil tuşa basarak yaka etiketini çekebilirsiniz.`);
        }
        if (($('etiket-metin') && $('etiket-metin').value.trim()) || sonGorselVeri) etiketiSunucuyaSor();
      });
    });
    $('kamera-dosya').addEventListener('change', async () => {
      const dosya = $('kamera-dosya').files && $('kamera-dosya').files[0];
      if (!dosya) return;
      if ($('mezat-galeri-merkezi-modal')) $('mezat-galeri-merkezi-modal').remove();
      const urlNesne = URL.createObjectURL(dosya);
      const img = new Image();
      img.onload = async () => {
        const enBoy = 1600;
        const oran = Math.min(1, enBoy / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * oran));
        canvas.height = Math.max(1, Math.round(img.height * oran));
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(urlNesne);
        await etiketCanvasIsle(canvas);
      };
      img.src = urlNesne;
      $('kamera-dosya').value = '';
    });
  }

  // ===== ▮▯ Telefon Barkod Okuyucu (BarcodeDetector + Saf JS Code-128 + Sunucu OCR) =====
  let barkodAkis = null;
  let barkodZamanlayici = null;
  let barkodOcrZamanlayici = null;
  let barkodOcrMesgul = false;
  let barkodIsleniyor = false;
  let sonOkunanBarkod = '';
  let sonOkunanZaman = 0;
  const BARKOD_GENEL_BEKLEME_MS = 3500; // Bir barkod okunduktan sonra el çekilirken yanlışlıkla tekrar okumasını önlemek için 3.5 sn genel bekleme
  const BARKOD_AYNI_KOD_BEKLEME_MS = 5000; // Aynı barkodun kamera önünde kalması durumunda 5 sn koruma

  function otomatikBarkodBeklemedeMi(adayKod) {
    if (barkodIsleniyor) return true;
    const simdi = Date.now();
    const gecen = simdi - sonOkunanZaman;
    if (gecen < BARKOD_GENEL_BEKLEME_MS) return true;
    const temiz = String(adayKod || '').trim().toUpperCase();
    if (temiz && temiz === sonOkunanBarkod && gecen < BARKOD_AYNI_KOD_BEKLEME_MS) return true;
    return false;
  }

  let barkodIslemKipi = 'giris'; // 'giris' (+) veya 'satis' (-1)
  let sonSatisDusulenBarkod = '';
  const KASA_SEPET_ANAHTAR = 'mezat_kasa_sepeti_v1';
  let kasaSepeti = [];
  try {
    const kayitliSepet = JSON.parse(localStorage.getItem(KASA_SEPET_ANAHTAR) || '[]');
    if (Array.isArray(kayitliSepet)) kasaSepeti = kayitliSepet;
  } catch (_) {
    kasaSepeti = [];
  }

  function kasaSepetiKaydet() {
    try {
      localStorage.setItem(KASA_SEPET_ANAHTAR, JSON.stringify(kasaSepeti || []));
    } catch (_) {}
  }

  function kasaCanliSonucYaz(htmlMetin, renk = '#10b981') {
    const kutu = $('kasa-canli-sonuc');
    if (!kutu) return;
    kutu.style.borderColor = renk;
    kutu.innerHTML = htmlMetin;
  }

  function kasaSepetiCiz() {
    const listeEl = $('kasa-sepet-liste');
    const tutarEl = $('kasa-toplam-tutar');
    const adetEl = $('kasa-toplam-adet-yazi');
    const sonIptalBtn = $('kasa-son-iptal-btn');
    if (!listeEl) return;

    const toplamAdet = kasaSepeti.reduce((t, u) => t + (Number(u.adet) || 0), 0);
    const toplamTutar = kasaSepeti.reduce((t, u) => t + ((Number(u.adet) || 0) * (Number(u.birimFiyat) || 0)), 0);

    if (tutarEl) {
      tutarEl.textContent = `${toplamTutar.toLocaleString('tr-TR')} TL`;
    }
    if (adetEl) {
      adetEl.textContent = toplamAdet > 0
        ? `${kasaSepeti.length} Çeşit · Toplam ${toplamAdet} Ürün`
        : '0 Ürün · Kasada Barkod Okutun';
    }
    if (sonIptalBtn) {
      sonIptalBtn.classList.toggle('gizli', kasaSepeti.length === 0);
    }

    if (kasaSepeti.length === 0) {
      listeEl.innerHTML = `
        <div style="padding:18px 10px;text-align:center;color:#94a3b8;font-weight:800;font-size:0.9rem">
          Henüz ürün okutulmadı.<br>Barkod okuttuğunuzda 1. ürün, 2. ürün, 3. ürün alt alta eklenecek ve müşterinin ödeyeceği toplam tutar yukarıda görünecektir.
        </div>
      `;
      return;
    }

    listeEl.replaceChildren(...kasaSepeti.slice().reverse().map((kalem, tersIdx) => {
      const siraNo = kasaSepeti.length - tersIdx;
      const birimFiyat = Number(kalem.birimFiyat) || 0;
      const adet = Number(kalem.adet) || 1;
      const araToplam = birimFiyat * adet;
      const varyantYazi = [kalem.renk, kalem.beden].filter(Boolean).join(' ') || 'STD';
      const kalanBilgi = kalem.kalanAdet != null ? ` · Depoda Kalan: ${kalem.kalanAdet}` : '';

      const eksiBtn = oge('button', {
        type: 'button',
        className: 'adet-dugme',
        style: 'min-width:36px;height:36px;font-size:1.1rem;padding:2px 8px',
        textContent: '−',
        title: '1 adet azalt (stoğa +1 geri ekler)'
      });
      eksiBtn.onclick = () => kasaSatirAzaltVeyaIptal(kalem.barkod, 1);

      const adetSpan = oge('span', {
        style: 'font-size:1.05rem;font-weight:900;color:#fde68a;min-width:26px;text-align:center',
        textContent: `${adet}x`
      });

      const artiBtn = oge('button', {
        type: 'button',
        className: 'adet-dugme',
        style: 'min-width:36px;height:36px;font-size:1.1rem;padding:2px 8px',
        textContent: '+',
        title: 'Aynı üründen 1 adet daha ekle (stoktan -1 düşer)'
      });
      artiBtn.onclick = () => barkoduIsle(kalem.barkod, true);

      const silBtn = oge('button', {
        type: 'button',
        style: 'background:#dc2626;border:1.5px solid #fca5a5;color:#fff;border-radius:8px;padding:6px 10px;height:36px;font-size:0.82rem;font-weight:900;cursor:pointer',
        textContent: '🗑️',
        title: 'Bu satırı fişten çıkar ve stoğa geri ekle'
      });
      silBtn.onclick = () => kasaSatirAzaltVeyaIptal(kalem.barkod, adet);

      return oge('div', { className: 'kasa-satir' },
        oge('div', { className: 'kasa-satir-bilgi' },
          oge('div', { className: 'kasa-satir-ad', textContent: `${siraNo}. ${kalem.urun} (${varyantYazi})` }),
          oge('div', { className: 'kasa-satir-detay', textContent: `🏷️ ${kalem.barkod} · Birim: ${birimFiyat.toLocaleString('tr-TR')} TL${kalanBilgi}` })
        ),
        oge('div', { className: 'kasa-satir-sag' },
          eksiBtn,
          adetSpan,
          artiBtn,
          oge('div', { className: 'kasa-satir-tutar', textContent: `${araToplam.toLocaleString('tr-TR')} TL` }),
          silBtn
        )
      );
    }));
  }

  async function kasaSatirAzaltVeyaIptal(barkod, miktar = 1) {
    const kod = String(barkod || '').trim().toUpperCase();
    if (!kod) return;
    const idx = kasaSepeti.findIndex(u => u.barkod === kod);
    if (idx < 0) return;
    const kalem = kasaSepeti[idx];
    const iadeAdet = Math.min(kalem.adet, Math.max(1, Number(miktar) || 1));

    let sonuc = null;
    try {
      sonuc = await post('/api/envanter/barkod', {
        islem: 'satis-dus',
        barkod: kod,
        adet: iadeAdet,
        geriAl: true,
        giren: ($('giren') && $('giren').value.trim()) || 'Kasa'
      });
      if (sonuc && sonuc.success && sonuc.kayit && window.MezatMobilHibrit) {
        window.MezatMobilHibrit.yerelEnvantereYansit(sonuc.kayit);
      }
    } catch (_) {
      if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelBarkodSatisDus === 'function') {
        sonuc = window.MezatMobilHibrit.yerelBarkodSatisDus({ barkod: kod, adet: iadeAdet, geriAl: true, cevrimdisiKuyrugaEkle: true });
      }
    }

    if (kalem.adet <= iadeAdet) {
      kasaSepeti.splice(idx, 1);
    } else {
      kalem.adet -= iadeAdet;
      if (sonuc && sonuc.kalanAdet != null) kalem.kalanAdet = sonuc.kalanAdet;
    }
    kasaSepetiKaydet();
    kasaSepetiCiz();
    bipSesi(false);
    listeSurumu = 0;
    await listeyiYenile(sonuc && sonuc.kayitId ? sonuc.kayitId : undefined);
    const toplamTutar = kasaSepeti.reduce((t, u) => t + ((Number(u.adet) || 0) * (Number(u.birimFiyat) || 0)), 0);
    kasaCanliSonucYaz(
      `↶ <b>İPTAL EDİLDİ (+${iadeAdet} Stoğa Geri Eklendi):</b> ${kalem.urun} · <b>Güncel Kasa Toplamı: ${toplamTutar.toLocaleString('tr-TR')} TL</b>`,
      '#f59e0b'
    );
  }

  function kasaYeniMusteriSifirla() {
    const toplamAdet = kasaSepeti.reduce((t, u) => t + (Number(u.adet) || 0), 0);
    const toplamTutar = kasaSepeti.reduce((t, u) => t + ((Number(u.adet) || 0) * (Number(u.birimFiyat) || 0)), 0);
    kasaSepeti = [];
    sonSatisDusulenBarkod = '';
    kasaSepetiKaydet();
    kasaSepetiCiz();
    if ($('kasa-barkod-girdi')) $('kasa-barkod-girdi').value = '';
    bipSesi(false);
    if (toplamAdet > 0) {
      kasaCanliSonucYaz(
        `✅ <b>SATIŞ TAMAMLANDI (${toplamAdet} Ürün · ${toplamTutar.toLocaleString('tr-TR')} TL):</b> Kasa yeni müşteri için sıfırlandı.`,
        '#10b981'
      );
      sesliOku(`Satış tamamlandı, toplam ${toplamTutar} lira. Yeni müşteri için kasa hazır.`);
    } else {
      kasaCanliSonucYaz(
        `🛒 <b>KASA SIFIRLANDI:</b> Yeni müşterinin ürün barkodlarını okutabilirsiniz.`,
        '#10b981'
      );
    }
  }

  function barkodCanliSonucYaz(htmlMetin, renk = '#10b981') {
    const kutu = $('barkod-canli-sonuc');
    if (!kutu) return;
    kutu.style.borderColor = renk;
    kutu.innerHTML = htmlMetin;
  }

  function barkodIslemKipiniAyarla(kip = 'giris') {
    barkodIslemKipi = kip === 'satis' ? 'satis' : 'giris';
  }

  async function barkodSatisGeriAl() {
    if (!sonSatisDusulenBarkod) return;
    const kod = sonSatisDusulenBarkod;
    sonSatisDusulenBarkod = '';
    await kasaSatirAzaltVeyaIptal(kod, 1);
  }

  // v111: Barkod sayfası – Okut → Bilgilendir → (−/+ adet) → ✓ KAYDET
  let bekleyenBarkodKaydi = null;
  function barkodAdetOku() {
    const n = parseInt(($('barkod-adet') && $('barkod-adet').value) || '1', 10);
    return Number.isFinite(n) && n > 0 ? n : 1;
  }
  // Barkod sayfası: GİRİŞ stoğa ekler, ÇIKIŞ stoktan düşer. Sayfa her açıldığında GİRİŞ'e döner.
  let barkodSayfaKipi = 'giris';
  function barkodKaydetYazisi() { return barkodSayfaKipi === 'cikis' ? '✓ ÇIKIŞ YAP' : '✓ GİRİŞ KAYDET'; }
  function barkodSayfaKipiniAyarla(kip) {
    barkodSayfaKipi = kip === 'cikis' ? 'cikis' : 'giris';
    const g = $('barkod-kip-giris'), c = $('barkod-kip-cikis'), k = $('barkod-kaydet-btn');
    // Seçili düğme dolu renkli ve ✔ işaretli; seçili olmayan düz düğme gibi durur
    const boya = (d, aktif, renk, kenar, etiket) => {
      if (!d) return;
      d.textContent = (aktif ? '✔ ' : '') + etiket;
      d.style.background = aktif ? renk : '#334155';
      d.style.borderColor = aktif ? '#ffffff' : kenar;
      d.style.borderWidth = aktif ? '3px' : '2px';
      d.style.opacity = '1';
    };
    boya(g, barkodSayfaKipi === 'giris', '#16a34a', '#86efac', '➕ GİRİŞ');
    boya(c, barkodSayfaKipi === 'cikis', '#dc2626', '#fca5a5', '➖ ÇIKIŞ');
    const y = $('barkod-kip-yazi');
    if (y) {
      y.textContent = barkodSayfaKipi === 'cikis' ? 'Şu an: ÇIKIŞ — okutulan ürün stoktan düşülür' : 'Şu an: GİRİŞ — okutulan ürün stoğa eklenir';
      y.style.color = barkodSayfaKipi === 'cikis' ? '#fca5a5' : '#86efac';
    }
    if (k) {
      k.textContent = barkodKaydetYazisi();
      k.style.background = barkodSayfaKipi === 'cikis' ? 'linear-gradient(135deg,#dc2626,#b91c1c)' : 'linear-gradient(135deg,#16a34a,#15803d)';
      k.style.borderColor = barkodSayfaKipi === 'cikis' ? '#fca5a5' : '#86efac';
    }
  }
  // Fiyat kutusu: okutulan ürünün fiyatıyla dolar; değiştirilirse Kaydet'te ürünün fiyatı da güncellenir
  function barkodFiyatOku() {
    // "1.250,50" ve "199,90" Türkçe yazımı; "199.90" telefon klavyesi yazımı olarak okunur
    let ham = String(($('barkod-fiyat') && $('barkod-fiyat').value) || '').trim().replace(/\s|TL/gi, '');
    if (!ham) return null;
    if (ham.includes(',')) ham = ham.replace(/\./g, '').replace(',', '.');
    else if (!/^\d+\.\d{1,2}$/.test(ham)) ham = ham.replace(/\./g, '');
    const n = Math.round(Number(ham) * 100) / 100;
    return Number.isFinite(n) && n > 0 ? n : NaN;
  }
  async function barkodFiyatiUygula(b, kod, giren) {
    const yeni = barkodFiyatOku();
    if (yeni === null) return '';
    if (Number.isNaN(yeni)) return '<br>⚠️ Fiyat anlaşılamadı, değiştirilmedi.';
    const eski = Number(b && b.ilkFiyat);
    if (Number.isFinite(eski) && eski === yeni) return '';
    const cevap = (b && b.cevap) || {};
    let f = null;
    try {
      f = await post('/api/envanter/barkod', { islem: 'fiyat', istekId: `fiyat-${Date.now()}-${Math.floor(Math.random() * 90000 + 10000)}`, barkod: kod, fiyat: yeni, urun: cevap.urun, giren });
      if (f && f.success && f.kayit && window.MezatMobilHibrit) window.MezatMobilHibrit.yerelEnvantereYansit(f.kayit);
    } catch (_) {
      if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.telefondaFiyatDegistir === 'function') {
        f = window.MezatMobilHibrit.telefondaFiyatDegistir({ barkod: kod, fiyat: yeni, urun: cevap.urun, renk: cevap.renk, beden: cevap.beden });
      }
    }
    if (!f || !f.success) return `<br>⚠️ Fiyat değiştirilemedi: ${(f && f.error) || 'bilinmeyen hata'}`;
    if (b) b.ilkFiyat = yeni;
    return f.sadeceKuyruk ? `<br>💰 Fiyat ${yeni} TL yapıldı, bilgisayar açılınca uygulanacak.` : `<br>💰 Fiyat ${yeni} TL olarak güncellendi.`;
  }
  function barkodKaydetHazirla(hazir) {
    if (!hazir) bekleyenBarkodKaydi = null;
    if ($('barkod-kaydet-btn')) {
      $('barkod-kaydet-btn').disabled = !hazir;
      $('barkod-kaydet-btn').style.opacity = hazir ? '1' : '0.45';
    }
    if ($('barkod-adet')) $('barkod-adet').value = '1';
    if (!hazir && $('barkod-fiyat')) $('barkod-fiyat').value = '';
    if (!hazir && $('barkod-girdi')) $('barkod-girdi').value = '';
  }
  // Giriş Kaydet: belindeki yazıcıdan adet kadar etiket basar; yazıcı yoksa kayıt yine yapılır
  async function barkodGirisEtiketiBas(e) {
    const h = window.MezatMobilHibrit;
    // Telefon uygulamasında yazıcıya gönderme yolu yoksa basılmış gibi gösterilmez
    if (window.MezatNativeApp && typeof window.MezatNativeApp.yaziciGonder !== 'function') return '<br>🖨️ Yazıcı bağlı değil, etiket basılmadı.';
    if (!h || typeof h.bluetoothTermalEtiketBas !== 'function') return '<br>🖨️ Yazıcı ayarlı değil, etiket basılmadı.';
    const y = typeof h.yaziciDurumu === 'function' ? h.yaziciDurumu() : { bagli: false, kip: 'otomatik' };
    if (!y.bagli && y.kip === 'otomatik') return '<br>🖨️ Yazıcı ayarlı değil, etiket basılmadı.';
    try {
      const s = await h.bluetoothTermalEtiketBas({
        urun: e.urun || 'Ürün', fiyat: e.fiyat, barkod: e.barkod,
        satirlar: [{ renk: e.renk || '', beden: e.beden || '', adet: e.adet, barkod: e.barkod }]
      }, 'tum-adetler');
      return s && s.success ? `<br>🖨️ ${s.adet} etiket yazıcıya gönderildi.` : '<br>⚠️ Etiket basılamadı.';
    } catch (err) {
      return `<br>⚠️ Etiket basılamadı: ${(err && err.message) || 'yazıcı hatası'}`;
    }
  }
  // Sonuç kutusu gizli olabilir: notlar üstteki durum satırına da düz yazı olarak eklenir
  function barkodNotuDuzYazi(not) {
    return String(not || '').replace(/<br\s*\/?>/gi, ' · ').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
  }
  // Bilgisayar ekranındaki "Telefon uygulamasını bağla" kare kodu: adres ve bilgisayarın kimliği
  function eslesmeKodu(metin, elle = false) {
    // Kamerada yalnız Mezatron kare kodu sayılır; kutuya elle yazılan düz bilgisayar adresi de kabul edilir
    const m = String(metin || '').trim().match(/^https?:\/\/([0-9.]{7,15}):(\d{2,5})\/?(\?mezatron-baglan=?([0-9a-f:]*))?$/i);
    if (!m || (!m[3] && !elle)) return null;
    return [m[0], m[1], m[2], m[4] || ''];
  }
  function bilgisayarEslestir(m) {
    const adres = `https://${m[1]}:${m[2]}`;
    const parmak = String(m[3] || '').toUpperCase();
    const k = window.MezatNativeApp;
    if (!k || typeof k.sunucuEslestir !== 'function') {
      durum('Bu kare kod telefon uygulamasıyla okutulur. Uygulamayı güncelleyin.', true);
      return;
    }
    let tamam = false;
    try { tamam = Boolean(k.sunucuEslestir(adres, parmak)); } catch (_) {}
    if (!tamam) { durum('⚠️ Kare kod okunamadı, tekrar deneyin.', true); return; }
    if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.hedefPcUrlKaydet === 'function') window.MezatMobilHibrit.hedefPcUrlKaydet('');
    durum(`💻 Bilgisayar eşlendi (${m[1]}). Bağlanılıyor…`);
    barkodVizorNotu('💻 Bilgisayar eşlendi, bağlanılıyor…');
    try { k.ortakYaz('donus_sayfasi', 'barkod'); } catch (_) {}
    setTimeout(() => { try { k.bilgisayaraDon(); } catch (_) {} }, 900);
  }
  // Uyarıyı kamera görüntüsünün en altındaki sarı şeride yazar; boş verilirse şerit kapanır
  function barkodVizorNotu(not) {
    const el = $('barkod-vizor-not');
    if (el) el.textContent = barkodNotuDuzYazi(not).replace(/^·\s*/, '');
  }
  async function barkodKaydiniUygula() {
    const b = bekleyenBarkodKaydi;
    if (!b) { durum('Önce kameradan bir barkod okutun.', true); return; }
    if (b.tur === 'yeni') {
      barkodKaydetHazirla(false);
      barkodElleUygulaIstegi = true;
      await barkoduIsle(b.kod, true); // tanınmayan barkodu forma aktarır
      return;
    }
    const adet = barkodAdetOku();
    const { kod, cevap, kendiAnaBarkodumuz } = b;
    const kaydetDugme = $('barkod-kaydet-btn');
    if (kaydetDugme) { kaydetDugme.disabled = true; kaydetDugme.textContent = '⏳ KAYDEDİLİYOR…'; }
    const giren = ($('giren') && $('giren').value.trim()) || 'Depo';
    if (barkodSayfaKipi === 'cikis') {
      let s = null;
      let cevrimdisi = false;
      try {
        s = await post('/api/envanter/barkod', { islem: 'satis-dus', istekId: `cikis-${Date.now()}-${Math.floor(Math.random() * 90000 + 10000)}`, barkod: kod, adet, giren });
        if (s && s.success && s.kayit && window.MezatMobilHibrit) window.MezatMobilHibrit.yerelEnvantereYansit(s.kayit);
      } catch (_) {
        // Bilgisayara ulaşılamadı: telefondaki listeden düşülür, bilgisayar açılınca yalnız bu çıkış aktarılır
        cevrimdisi = true;
        if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelBarkodSatisDus === 'function') {
          s = window.MezatMobilHibrit.yerelBarkodSatisDus({ barkod: kod, adet, cevrimdisiKuyrugaEkle: true, urun: cevap.urun, renk: cevap.renk, beden: cevap.beden });
        }
      }
      if (!s || !s.success) {
        bipSesi(true);
        if (kaydetDugme) { kaydetDugme.disabled = false; kaydetDugme.textContent = barkodKaydetYazisi(); }
        const h = (s && s.error) || 'Çıkış yapılamadı.';
        barkodCanliSonucYaz(`⚠️ <b>${h}</b>`, '#ef4444');
        durum(h, true);
        return;
      }
      const fiyatNotuC = await barkodFiyatiUygula(b, kod, giren);
      barkodKaydetHazirla(false);
      bipSesi(false);
      const vb = [s.renk || cevap.renk, s.beden || cevap.beden].filter(Boolean).join(' ') || 'STD';
      const once = Number(s.oncekiAdet);
      const eksik = Number.isFinite(once) && adet > once ? `<br>⚠️ Stokta yalnız ${once} adet vardı, stok 0'a indi.` : '';
      const kalanYazi = s.kalanAdet != null ? ` · Kalan Stok: ${s.kalanAdet} Adet` : '';
      const telNot = !cevrimdisi ? '' : (s.sadeceKuyruk ? '<br>📲 Çıkış kaydedildi, bilgisayar açılınca stoktan düşülecek.' : '<br>📲 Telefonda düşüldü, bilgisayar açılınca aktarılacak.');
      barkodCanliSonucYaz(`✅ <b>ÇIKIŞ YAPILDI (−${adet} Adet):</b> ${s.urun || cevap.urun} (${vb})${kalanYazi}${eksik}${telNot}${fiyatNotuC}`, '#f59e0b');
      durum(`✓ Çıkış yapıldı (−${adet} adet): ${s.urun || cevap.urun} ${vb}${kalanYazi}`);
      barkodVizorNotu(eksik + telNot + fiyatNotuC);
      if (kaydetDugme) {
        kaydetDugme.textContent = '✅ ÇIKIŞ YAPILDI';
        setTimeout(() => { if (kaydetDugme.textContent === '✅ ÇIKIŞ YAPILDI') kaydetDugme.textContent = barkodKaydetYazisi(); }, 2500);
      }
      listeSurumu = 0;
      try { await listeyiYenile(s.kayitId); } catch (_) {}
      return;
    }
    let sonuc = null;
    try {
      sonuc = await post('/api/envanter/barkod', { islem: 'satis-dus', barkod: kod, adet, geriAl: true, giren });
      if (sonuc && sonuc.success && sonuc.kayit && window.MezatMobilHibrit) {
        window.MezatMobilHibrit.yerelEnvantereYansit(sonuc.kayit);
      }
    } catch (_) {
      if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelBarkodSatisDus === 'function') {
        sonuc = window.MezatMobilHibrit.telefondaStokEkle({ urun: cevap.urun, fiyat: cevap.fiyat, anaBarkod: cevap.anaBarkod, barkod: kod, renk: cevap.renk, beden: cevap.beden, adet, giren });
      }
    }
    if ((!sonuc || !sonuc.success) && cevap.bankadan && window.MezatMobilHibrit) {
      sonuc = window.MezatMobilHibrit.telefondaStokEkle({ urun: cevap.urun, fiyat: cevap.fiyat, anaBarkod: cevap.anaBarkod, barkod: kod, renk: cevap.renk, beden: cevap.beden, adet, giren });
    }
    if (!sonuc || !sonuc.success) {
      bipSesi(true);
      if (kaydetDugme) { kaydetDugme.disabled = false; kaydetDugme.textContent = barkodKaydetYazisi(); }
      const h = (sonuc && sonuc.error) || 'Stok kaydedilemedi.';
      barkodCanliSonucYaz(`⚠️ <b>${h}</b>`, '#ef4444');
      durum(h, true);
      return;
    }
    const girilenFiyat = barkodFiyatOku();
    const etiketFiyat = girilenFiyat && !Number.isNaN(girilenFiyat) ? girilenFiyat : cevap.fiyat;
    const fiyatNotu = await barkodFiyatiUygula(b, kod, giren);
    barkodKaydetHazirla(false);
    bipSesi(false);
    const etiketNotu = await barkodGirisEtiketiBas({ urun: cevap.urun, fiyat: etiketFiyat, barkod: kod, renk: cevap.renk, beden: cevap.beden, adet });
    const varyantBilgi = [cevap.renk, cevap.beden].filter(Boolean).join(' ') || 'STD';
    const stokYazi = sonuc.kalanAdet != null ? ` · Güncel Stok: ${sonuc.kalanAdet} Adet` : '';
    const telefonaNot = sonuc.mobilCevrimdisi ? '<br>📲 Telefona kaydedildi, bilgisayar açılınca aktarılacak.' : '';
    barkodCanliSonucYaz(`✅ <b>KAYDEDİLDİ (+${adet} Adet):</b> ${cevap.urun} (${varyantBilgi}) [${kendiAnaBarkodumuz}]${stokYazi}${telefonaNot}${fiyatNotu}${etiketNotu}`, '#10b981');
    durum(`✓ Kaydedildi (+${adet} adet): ${cevap.urun} ${varyantBilgi}${stokYazi}`);
    barkodVizorNotu(fiyatNotu + etiketNotu);
    if (kaydetDugme) {
      kaydetDugme.textContent = '✅ KAYDEDİLDİ';
      setTimeout(() => { if (kaydetDugme.textContent === '✅ KAYDEDİLDİ') kaydetDugme.textContent = barkodKaydetYazisi(); }, 2500);
    }
    listeSurumu = 0;
    try { await listeyiYenile(sonuc.kayitId); } catch (_) {}
  }
  if ($('barkod-kaydet-btn')) {
    barkodKaydetHazirla(false);
    $('barkod-kaydet-btn').addEventListener('click', barkodKaydiniUygula);
    if ($('barkod-kip-giris')) $('barkod-kip-giris').addEventListener('click', () => barkodSayfaKipiniAyarla('giris'));
    if ($('barkod-kip-cikis')) $('barkod-kip-cikis').addEventListener('click', () => barkodSayfaKipiniAyarla('cikis'));
    barkodSayfaKipiniAyarla('giris');
    $('barkod-adet-arti').addEventListener('click', () => { $('barkod-adet').value = String(barkodAdetOku() + 1); });
    $('barkod-adet-eksi').addEventListener('click', () => { $('barkod-adet').value = String(Math.max(1, barkodAdetOku() - 1)); });
  }
  // "Diğer İşlemler": birinci sayfadaki gibi düğmenin altında açılıp kapanır; bir işlem seçilince kapanır
  if ($('barkod-diger-btn') && $('barkod-diger')) {
    const menu = $('barkod-diger'), dugme = $('barkod-diger-btn');
    const kapat = () => { menu.classList.remove('acik'); dugme.classList.remove('acik'); };
    window.barkodDigerKapat = kapat;
    dugme.addEventListener('click', () => {
      const acik = menu.classList.toggle('acik');
      dugme.classList.toggle('acik', acik);
    });
    menu.addEventListener('click', ev => { if (ev.target.closest('button')) setTimeout(kapat, 0); });
  }
  if ($('barkodsuz-barkod-uret-btn')) {
    $('barkodsuz-barkod-uret-btn').addEventListener('click', () => {
      // Kutudaki kod (E180 gibi) silinmez; barkod onunla üretilir
      const kutu = $('barkod-girdi') ? $('barkod-girdi').value : '';
      barkodKaydetHazirla(false);
      if ($('barkod-girdi')) $('barkod-girdi').value = kutu;
    });
  }

  let barkodElleUygulaIstegi = false;
  async function barkoduIsle(hamKod, manuelTetik = false) {
    const elleUygula = barkodElleUygulaIstegi; barkodElleUygulaIstegi = false;
    const kod = String(hamKod || '').trim().toUpperCase();
    if (!kod) { durum('Barkod numarası girin veya kameraya tutun.', true); return; }
    barkodVizorNotu('');
    const eslesme = eslesmeKodu(hamKod, manuelTetik);
    if (eslesme) { bilgisayarEslestir(eslesme); return; }
    if (!manuelTetik && otomatikBarkodBeklemedeMi(kod)) return;
    barkodIsleniyor = true;
    sonOkunanBarkod = kod;
    sonOkunanZaman = Date.now();
    const aktifSayfa = document.body.dataset.aktifSayfa || 'ses';
    const satisModuAktif = aktifSayfa === 'satis' || barkodIslemKipi === 'satis';
    try {
      // ===== MOD 2: 🛒 MARKET KASASI SATIŞ & STOKTAN DÜŞÜMÜ (-1 ADET + FİŞ TOPLAMI) =====
      if (satisModuAktif) {
        let satisSonuc = null;
        try {
          satisSonuc = await post('/api/envanter/barkod', {
            islem: 'satis-dus',
            istekId: `kasa-${Date.now()}-${Math.floor(Math.random() * 90000 + 10000)}`,
            barkod: kod,
            adet: 1,
            giren: ($('giren') && $('giren').value.trim()) || 'Kasa'
          });
          // Bilgisayar cevap verdiyse (stok yok vb.) telefonda ayrıca düşülmez; yalnız ulaşılamazsa telefonda düşülür
          if (satisSonuc && satisSonuc.success && satisSonuc.kayit && window.MezatMobilHibrit) {
            window.MezatMobilHibrit.yerelEnvantereYansit(satisSonuc.kayit);
          }
        } catch (_) {
          // Bilgisayar olmadan (Sadece Cep Telefonu Modu) yerel envanterden düş
          if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelBarkodSatisDus === 'function') {
            satisSonuc = window.MezatMobilHibrit.yerelBarkodSatisDus({ barkod: kod, adet: 1, cevrimdisiKuyrugaEkle: true });
          }
        }

        if (!satisSonuc || !satisSonuc.success) {
          bipSesi(true);
          const hataYazi = (satisSonuc && satisSonuc.error) || `Barkod (${kod}) envanterde bulunamadı.`;
          kasaCanliSonucYaz(`⚠️ <b>${hataYazi}</b>`, '#ef4444');
          durum(hataYazi, true);
          return;
        }

        bipSesi(false);
        if ($('kasa-barkod-vizor')) {
          $('kasa-barkod-vizor').style.outline = '3px solid #10b981';
          setTimeout(() => { if ($('kasa-barkod-vizor')) $('kasa-barkod-vizor').style.outline = ''; }, BARKOD_GENEL_BEKLEME_MS);
        }
        if ($('kasa-barkod-girdi')) $('kasa-barkod-girdi').value = kod;
        sonSatisDusulenBarkod = satisSonuc.barkod || kod;

        const birimFiyat = Number(satisSonuc.fiyat ?? (satisSonuc.kayit && satisSonuc.kayit.fiyat) ?? 0) || 0;
        const hedefBarkod = String(satisSonuc.barkod || kod).toUpperCase();
        const mevcutKalem = kasaSepeti.find(u => u.barkod === hedefBarkod);
        if (mevcutKalem) {
          mevcutKalem.adet += 1;
          if (birimFiyat > 0) mevcutKalem.birimFiyat = birimFiyat;
          mevcutKalem.kalanAdet = satisSonuc.kalanAdet;
        } else {
          kasaSepeti.push({
            barkod: hedefBarkod,
            urun: satisSonuc.urun || 'Ürün',
            renk: satisSonuc.renk || '',
            beden: satisSonuc.beden || '',
            birimFiyat,
            adet: 1,
            kalanAdet: satisSonuc.kalanAdet
          });
        }
        kasaSepetiKaydet();
        kasaSepetiCiz();

        listeSurumu = 0;
        await listeyiYenile(satisSonuc.kayitId);
        const varyantEtiket = [satisSonuc.renk, satisSonuc.beden].filter(Boolean).join(' ') || 'STD';
        const kasaToplamTutar = kasaSepeti.reduce((t, u) => t + ((Number(u.adet) || 0) * (Number(u.birimFiyat) || 0)), 0);
        const kasaToplamAdet = kasaSepeti.reduce((t, u) => t + (Number(u.adet) || 0), 0);
        kasaCanliSonucYaz(
          `✅ <b>KASAYA EKLENDİ (+${birimFiyat.toLocaleString('tr-TR')} TL):</b> ${satisSonuc.urun} (${varyantEtiket}) · <b>Ödenecek Toplam: ${kasaToplamTutar.toLocaleString('tr-TR')} TL (${kasaToplamAdet} Ürün)</b> · Depoda Kalan: ${satisSonuc.kalanAdet}`,
          '#10b981'
        );
        sesliOku(`${satisSonuc.urun}, ${birimFiyat} lira. Toplam ${kasaToplamTutar} lira.`);
        return;
      }

      // ===== MOD 1: 📥 STOK GİRİŞİ (+1 EKLE VEYA KENDİ BARKODUMUZU ÜRET) =====
      let cevap = null;
      try {
        cevap = await post('/api/envanter/barkod', { barkod: kod });
      } catch (_) {}

      // Eğer sunucu bulamadıysa veya çevrimdışıysa telefondaki yerel envanterden de kontrol et
      if ((!cevap || !cevap.bulundu) && window.MezatMobilHibrit) {
        const yerelListe = window.MezatMobilHibrit.yerelEnvanteriOku();
        const bulunanKayit = yerelListe.find(k =>
          String(k.barkod || '').toUpperCase() === kod ||
          (k.satirlar || []).some(s => String(s.barkod || '').toUpperCase() === kod)
        );
        if (bulunanKayit) {
          const sEs = (bulunanKayit.satirlar || []).find(s => String(s.barkod || '').toUpperCase() === kod) || bulunanKayit.satirlar[0] || {};
          cevap = {
            success: true,
            bulundu: true,
            barkod: bulunanKayit.barkod || kod,
            anaBarkod: bulunanKayit.barkod || kod,
            urun: bulunanKayit.urun,
            fiyat: bulunanKayit.fiyat,
            renk: sEs.renk || '',
            beden: sEs.beden || ''
          };
        } else if (!cevap) {
          cevap = window.MezatMobilHibrit.bankadaBarkodBul(kod) || { success: true, bulundu: false, barkod: kod };
        }
      }
      if (!cevap || !cevap.success) {
        bipSesi(true);
        const h = (cevap && cevap.error) || 'Barkod geçersiz.';
        barkodCanliSonucYaz(`⚠️ <b>${h}</b>`, '#ef4444');
        durum(h, true);
        return;
      }
      bipSesi(false);
      if ($('barkod-vizor')) {
        $('barkod-vizor').style.outline = '3px solid #10b981';
        setTimeout(() => { if ($('barkod-vizor')) $('barkod-vizor').style.outline = ''; }, BARKOD_GENEL_BEKLEME_MS);
      }
      if (cevap.bulundu) {
        // Kayıtlı ürün barkodu (veya fabrika EAN-13 barkodu) okutulduğunda hem ana envanterde stoğu +1 artır hem de formu doldur!
        const kendiAnaBarkodumuz = /^\d{8,14}$/.test(kod)
          ? kod
          : ((cevap.anaBarkod && /^MZU-/i.test(cevap.anaBarkod))
            ? cevap.anaBarkod
            : (otomatikBarkodHesapla(cevap.urun) || cevap.barkod));
        // Barkod sayfasında okutulan ürün ilk sayfadaki ürün formuna yazılmaz
        if ($('barkod') && aktifSayfa !== 'barkod') $('barkod').value = kendiAnaBarkodumuz;
        if ($('barkod-girdi')) $('barkod-girdi').value = kendiAnaBarkodumuz;

        // v111: Okutunca SADECE bilgilendir; stok, "✓ KAYDET" tuşuna basılınca seçilen adet kadar artırılır
        const varyantBilgi = [cevap.renk, cevap.beden].filter(Boolean).join(' · ') || 'STD';
        const mevcutStok = cevap.kalanAdet ?? cevap.adet ?? cevap.stok;
        bekleyenBarkodKaydi = { tur: 'kayitli', kod, cevap, kendiAnaBarkodumuz, ilkFiyat: cevap.fiyat != null && cevap.fiyat !== '' ? Number(cevap.fiyat) : null };
        barkodKaydetHazirla(true);
        if ($('barkod-fiyat')) $('barkod-fiyat').value = cevap.fiyat != null && cevap.fiyat !== '' ? String(cevap.fiyat) : '';
        barkodCanliSonucYaz(
          `🔎 <b>KAYITLI ÜRÜN OKUNDU</b><br>` +
          `<b>Ürün:</b> ${cevap.urun || '-'}<br>` +
          `<b>Renk / Beden:</b> ${varyantBilgi}<br>` +
          (cevap.fiyat != null && cevap.fiyat !== '' ? `<b>Fiyat:</b> ${cevap.fiyat} TL<br>` : '') +
          `<b>Barkod:</b> ${kendiAnaBarkodumuz}` +
          (mevcutStok != null ? `<br><b>Mevcut Stok:</b> ${mevcutStok} Adet` : '') +
          `<br><span style="color:#fde68a">Adedi ve gerekirse fiyatı girip Kaydet'e basın.</span>`,
          '#38bdf8'
        );
        durum(`🔎 ${cevap.urun} (${varyantBilgi}) okundu. Kaydetmek için ✓ KAYDET'e basın.`);
        return;
      } else if (!elleUygula) {
        // v111: Kamerayla okunan TANINMAYAN barkod: önce bilgilendir, Kaydet'e basılınca forma aktar
        bekleyenBarkodKaydi = { tur: 'yeni', kod, cevap };
        if ($('barkod-girdi')) $('barkod-girdi').value = kod;
        barkodKaydetHazirla(true);
        barkodCanliSonucYaz(
          `🆕 <b>KAYITLI OLMAYAN BARKOD: [${kod}]</b><br>` +
          `Bu barkodla yeni ürün girmek için <b>✓ KAYDET</b>'e basın (ürün formuna aktarılır).<br>` +
          `Ürünün barkodu yoksa birinci sayfadaki <b>🏷️ BARKOD ÜRET</b> ile yeni barkod verilir.`,
          '#f59e0b'
        );
        durum(`🆕 Kayıtlı olmayan barkod okundu: ${kod}`);
        return;
      } else {
        barkodKaydetHazirla(false);
        // Elle yazılan E180 gibi ürün kodu: barkod sayılmaz, beden yerine yazılır
        if (!gecerliFabrikaBarkodu(kod) && !/^MZU-/i.test(kod) && typeof window.kendiBarkodNumaramiziOlustur === 'function') {
          if ($('barkod-girdi')) $('barkod-girdi').value = kod;
          window.kendiBarkodNumaramiziOlustur();
          return;
        }
        // Tanınmayan barkod okutulduğunda: Eğer 8-14 haneli fabrika barkodu (868..., 869...) ise doğrudan kendi numarasını koru ki kaydedilince market kasası gibi eşleşsin!
        const mevcutUrunAdi = $('urun') ? $('urun').value.trim() : '';
        const sonEk = kod.replace(/[^A-Z0-9]/gi, '').slice(-6).toUpperCase() || String(Date.now()).slice(-6);
        const kendiBarkodumuz = (gecerliFabrikaBarkodu(kod) || /^MZU-/i.test(kod))
          ? kod
          : (/^MZU-/i.test(cevap.barkod)
            ? cevap.barkod
            : (mevcutUrunAdi ? otomatikBarkodHesapla(mevcutUrunAdi) : `MZU-${sonEk}`));
        if ($('barkod')) $('barkod').value = kendiBarkodumuz;
        if ($('barkod-girdi')) $('barkod-girdi').value = kendiBarkodumuz;
        if (!$('satirlar').children.length) {
          satirEkle({ renk: '', beden: '', adet: 1 });
        }
        otomatikBarkodGuncelle();
        barkodCanliSonucYaz(
          `🏷️ <b>BARKOD OLUŞTURULDU: [${kendiBarkodumuz}]</b><br>Barkod kutusuna yazıldı, ürün formuna dönülüyor…`,
          '#10b981'
        );
        durum(`🏷️ Kendi barkodumuz [${kendiBarkodumuz}] Barkod kutusuna yazıldı. Şimdi ürün adını, rengini, bedenini/ML'ini ve fiyatını girip kaydedin.`);
        sesliOku(`Barkod numarası oluşturuldu. Ürün adını ve fiyatı girip kaydedin.`);
        setTimeout(() => {
          if (document.body.dataset.aktifSayfa === 'barkod' && typeof window.aktifSayfayiSec === 'function') {
            window.aktifSayfayiSec('ses');
          }
        }, 550);
      }
    } catch (err) {
      durum('Barkod sorgulanamadı.', true);
    } finally {
      barkodIsleniyor = false;
    }
  }

  function barkodKamerayiKapat() {
    if (barkodZamanlayici) { clearInterval(barkodZamanlayici); barkodZamanlayici = null; }
    if (barkodOcrZamanlayici) { clearInterval(barkodOcrZamanlayici); barkodOcrZamanlayici = null; }
    if (barkodAkis) { barkodAkis.getTracks().forEach(t => t.stop()); barkodAkis = null; }
    if ($('barkod-vizor')) $('barkod-vizor').classList.add('gizli');
    if ($('kasa-barkod-vizor')) $('kasa-barkod-vizor').classList.add('gizli');
  }

  // v112: Sahte barkod koruması – checksum doğrulaması + otomatik okumada çoklu kare teyidi
  function barkodGecerliMi(kod) {
    const k = String(kod || '').trim().toUpperCase();
    if (!k) return false;
    if (/^MZU-[A-Z0-9]{4,}$/.test(k)) return true;
    if (/^\d+$/.test(k)) {
      if (![8, 12, 13, 14].includes(k.length)) return false;
      if (/^(\d)\1+$/.test(k)) return false; // 00000000 gibi yansıma okumaları
      const d = k.split('').map(Number);
      const kontrol = d.pop();
      let t = 0;
      for (let i = d.length - 1, j = 0; i >= 0; i--, j++) t += d[i] * (j % 2 === 0 ? 3 : 1);
      return (10 - (t % 10)) % 10 === kontrol;
    }
    // Code-128/39 alfanümerik: en az 6 karakter, harf+rakam karışık, tekrar eden çöp değil
    return /^[A-Z0-9\-\.\/]{6,32}$/.test(k) && /\d/.test(k) && !/^(.)\1+$/.test(k);
  }
  const barkodTeyitGecmisi = new Map();
  function otomatikBarkodTeyitli(kod, gerekenSayi = 2) {
    const k = String(kod || '').trim().toUpperCase();
    if (!barkodGecerliMi(k)) return false;
    const simdi = Date.now();
    for (const [x, v] of barkodTeyitGecmisi) if (simdi - v.son > 2000) barkodTeyitGecmisi.delete(x);
    const v = barkodTeyitGecmisi.get(k) || { sayi: 0, son: 0 };
    v.sayi += 1; v.son = simdi;
    barkodTeyitGecmisi.set(k, v);
    if (v.sayi >= gerekenSayi) { barkodTeyitGecmisi.clear(); return true; }
    return false;
  }

  async function kameradanBarkodKaresiTara(videoVeyaCanvas, manuelTetik = false) {
    if (!videoVeyaCanvas) return false;
    if (!manuelTetik && (barkodIsleniyor || Date.now() - sonOkunanZaman < BARKOD_GENEL_BEKLEME_MS)) return false;
    try {
      // 0) Bilgisayarın eşleme kare kodu
      if ('BarcodeDetector' in window) {
        try {
          const qd = new window.BarcodeDetector({ formats: ['qr_code'] });
          const q = await qd.detect(videoVeyaCanvas);
          const e = (q || []).map(x => eslesmeKodu(x && x.rawValue)).find(Boolean);
          if (e) { sonOkunanZaman = Date.now(); bilgisayarEslestir(e); return true; }
        } catch (_) {}
      }
      // 1) Saf JS Code-128 1D tarayıcı
      if (window.MezatBarkod && typeof window.MezatBarkod.goruntudenOku === 'function') {
        const jsKod = window.MezatBarkod.goruntudenOku(videoVeyaCanvas);
        if (jsKod && (manuelTetik ? barkodGecerliMi(jsKod) : otomatikBarkodTeyitli(jsKod, 3))) {
          if (manuelTetik || !otomatikBarkodBeklemedeMi(jsKod)) {
            await barkoduIsle(jsKod, manuelTetik);
            return true;
          }
        }
      }
      // 2) Sunucu OCR & Barkod çözücü (/api/kamera/barkod-ocr)
      if (barkodOcrMesgul && !manuelTetik) return false;
      barkodOcrMesgul = true;
      const w = videoVeyaCanvas.videoWidth || videoVeyaCanvas.width || 640;
      const h = videoVeyaCanvas.videoHeight || videoVeyaCanvas.height || 480;
      if (!w || !h) { barkodOcrMesgul = false; return false; }
      const oran = Math.min(1, 960 / Math.max(w, h));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(w * oran));
      c.height = Math.max(1, Math.round(h * oran));
      c.getContext('2d').drawImage(videoVeyaCanvas, 0, 0, c.width, c.height);
      const anlikParmakIzi = resimdenParmakIziCikar(c);
      if (manuelTetik && anlikParmakIzi) sonGorselParmakIzi = anlikParmakIzi;
      const gorsel = c.toDataURL('image/jpeg', 0.82);
      const r = await post('/api/kamera/barkod-ocr', { gorsel, gorselParmakIzi: anlikParmakIzi, otomatikOkut: false, manuelTetik: Boolean(manuelTetik) });
      barkodOcrMesgul = false;
      // Görüntü daha önce görülen bir ürüne benzetildiyse bu yalnız tahmindir: stok hareketi yapılmaz, form doldurulup sorulur
      const tahminMi = Boolean(r && r.etiketCozum && r.etiketCozum.hafizadanDogrulandi);
      if (r && r.bulunanKod && !tahminMi && (manuelTetik ? barkodGecerliMi(r.bulunanKod) : otomatikBarkodTeyitli(r.bulunanKod, 2))) {
        if (manuelTetik || !otomatikBarkodBeklemedeMi(r.bulunanKod)) {
          await barkoduIsle(r.bulunanKod, manuelTetik);
          return true;
        }
      } else if (manuelTetik && r && r.etiketCozum && r.etiketCozum.urun) {
        // Yalnızca kullanıcı manuel "Kameradan Barkodu Yakala" düğmesine bastığında ve barkod çizgisi yoksa kutu üzerindeki ürün yazısını forma aktar!
        const ec = r.etiketCozum;
        bipSesi(false);
        const hedefBarkod = ec.barkod || ec.otomatikBarkod || otomatikBarkodHesapla(ec.urun);
        if ($('barkod')) $('barkod').value = hedefBarkod;
        if ($('barkod-girdi')) $('barkod-girdi').value = hedefBarkod;
        (ec.satirlar && ec.satirlar.length ? ec.satirlar : [{ renk: '', beden: (ec.bedenler && ec.bedenler[0]) || '', adet: 1 }]).forEach(s => {
          satiraEkleVeyaArtir({
            urun: ec.urun,
            fiyat: ec.fiyat || ec.onerilenFiyat || null,
            barkod: hedefBarkod,
            renk: s.renk || '',
            beden: s.beden || '',
            adet: s.adet || 1,
            etiketOkuma: true
          });
        });
        barkodKamerayiKapat();
        if ($('barkod-panel')) $('barkod-panel').classList.add('gizli');
        if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
        durum(`✓ Kutudan ürün bilgisi alındı: ${ec.urun}${ec.bedenler && ec.bedenler[0] ? ` (${ec.bedenler[0]})` : ''}`);
        return true;
      } else if (manuelTetik) {
        durum('Kameradaki görüntüde barkod seçilemedi. Etiketi yaklaştırıp tekrar deneyin.', true);
      }
    } catch (_) {
      barkodOcrMesgul = false;
    }
    return false;
  }

  async function barkodKamerayiAc(hedefVideoId = 'barkod-video', hedefVizorId = 'barkod-vizor') {
    barkodKamerayiKapat();
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      durum('📷 Fotoğraftan barkod okumak için "🖼️ Fotoğraftan Oku" düğmesine dokunun veya HTTPS (3442) adresine geçin.');
      return;
    }
    try {
      try {
        barkodAkis = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: 'environment' },
            width: { ideal: 1920 },
            height: { ideal: 1080 },
            advanced: [{ focusMode: 'continuous' }]
          }
        });
      } catch (_) {
        barkodAkis = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }
        });
      }
      const video = $(hedefVideoId) || $('barkod-video');
      const vizor = $(hedefVizorId) || $('barkod-vizor');
      if (!video) return;
      video.srcObject = barkodAkis;
      if (vizor) vizor.classList.remove('gizli');
      await video.play();
      let det = null;
      if ('BarcodeDetector' in window) {
        try { det = new window.BarcodeDetector({ formats: ['ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'qr_code'] }); } catch (_) {}
      }
      barkodZamanlayici = setInterval(async () => {
        if (!barkodAkis || video.readyState < 2) return;
        if (barkodIsleniyor || Date.now() - sonOkunanZaman < BARKOD_GENEL_BEKLEME_MS) return;
        try {
          if (det) {
            const kodlar = await det.detect(video);
            const deger = window.MezatBarkod && typeof window.MezatBarkod.barkodSec === 'function'
              ? window.MezatBarkod.barkodSec(kodlar)
              : (kodlar && kodlar.length && kodlar[0].rawValue ? kodlar[0].rawValue : '');
            // Barkod süzgeci adresleri atar: eşleme kare kodu süzgeçten önce ham okunan kodlarda aranır
            const eslesme = (kodlar || []).map(x => eslesmeKodu(x && x.rawValue)).find(Boolean);
            if (eslesme) { sonOkunanZaman = Date.now(); bilgisayarEslestir(eslesme); return; }
            if (deger && !/^HTTPS?:/i.test(deger) && otomatikBarkodTeyitli(deger, 2)) {
              if (otomatikBarkodBeklemedeMi(deger)) return;
              await barkoduIsle(deger, false);
              return;
            }
          }
          if (window.MezatBarkod && typeof window.MezatBarkod.goruntudenOku === 'function') {
            const jsDeger = window.MezatBarkod.goruntudenOku(video);
            if (jsDeger && otomatikBarkodTeyitli(jsDeger, 3)) {
              if (otomatikBarkodBeklemedeMi(jsDeger)) return;
              await barkoduIsle(jsDeger, false);
            }
          }
        } catch (err) {}
      }, 250);
      // BarcodeDetector olmayan telefonlar için her 1.2 saniyede sunucu OCR + barkod taraması
      barkodOcrZamanlayici = setInterval(() => {
        if (!barkodAkis || video.readyState < 2) return;
        if (barkodIsleniyor || Date.now() - sonOkunanZaman < BARKOD_GENEL_BEKLEME_MS) return;
        kameradanBarkodKaresiTara(video, false);
      }, 1200);
    } catch (err) {
      // Kamera izni yoksa yazılı/el okuyucu kutusu açık kalır
    }
  }

  if ($('barkod-ac')) {
    $('barkod-ac').addEventListener('click', e => {
      if (e.detail === 0) return;
      const acik = !$('barkod-panel').classList.contains('gizli');
      if (acik) {
        barkodKamerayiKapat();
        $('barkod-panel').classList.add('gizli');
      } else {
        barkodIslemKipi = 'giris';
        digerAltPanelleriKapat('barkod-panel');
        $('barkod-panel').classList.remove('gizli');
        $('barkod-vizor').classList.remove('gizli');
        barkodKamerayiAc('barkod-video', 'barkod-vizor');
        if (document.activeElement && document.activeElement.tagName === 'INPUT') {
          try { document.activeElement.blur(); } catch (_) {}
        }
      }
    });
    function kendiBarkodNumaramiziOlustur() {
      const mevcutUrun = $('urun') ? $('urun').value.trim() : '';
      // Kutudaki fabrika barkodu aynen kullanılır; E180 gibi ürün kodu beden yerine yazılır, barkod ürün adından üretilir
      const kutudakiKod = $('barkod-girdi') ? $('barkod-girdi').value.trim().toUpperCase().replace(/\s+/g, '') : '';
      const fabrikaMi = Boolean(kutudakiKod) && (gecerliFabrikaBarkodu(kutudakiKod) || /^MZU-/i.test(kutudakiKod));
      const urunKodu = kutudakiKod && !fabrikaMi ? kutudakiKod : '';
      window.__mezatUrunKodu = urunKodu;
      const yeniBarkod = fabrikaMi
        ? kutudakiKod
        : (mevcutUrun ? otomatikBarkodHesapla(mevcutUrun) : (urunKodu ? '' : `MZU-${String(Date.now()).slice(-6)}`));
      if ($('barkod')) $('barkod').value = yeniBarkod;
      if ($('barkod-girdi')) $('barkod-girdi').value = yeniBarkod || urunKodu;
      if (!$('satirlar').children.length) {
        satirEkle({ renk: '', beden: urunKodu, adet: 1 });
      } else if (urunKodu) {
        const ilkSatir = $('satirlar').querySelector('tr');
        const bedenGirdi = ilkSatir ? ilkSatir.querySelectorAll('input')[1] : null;
        if (bedenGirdi) bedenGirdi.value = urunKodu;
      }
      otomatikBarkodGuncelle();
      bipSesi();
      if (urunKodu) {
        barkodCanliSonucYaz(
          `🏷️ <b>ÜRÜN KODU: ${urunKodu}</b><br>Beden yerine yazıldı, ana forma dönülüyor…`,
          '#10b981'
        );
        durum(`🏷️ Ürün kodu ${urunKodu} beden yerine yazıldı. Ürün adını yazın ya da 📷 kameradan okutun, adedi girip kaydedin. Barkod ürün adından üretilir.`);
      } else {
        barkodCanliSonucYaz(
          `🏷️ <b>BARKOD NUMARASI OLUŞTURULDU: [${yeniBarkod}]</b><br>Barkod kutusuna yazıldı, ana forma dönülüyor…`,
          '#10b981'
        );
        durum(`🏷️ Kendi barkod numaramız oluşturuldu: [${yeniBarkod}]. Ürün adını, rengini, bedenini/ML'ini ve fiyatını girip kaydedebilirsiniz.`);
      }
      if (document.body.dataset.aktifSayfa === 'barkod' && typeof window.aktifSayfayiSec === 'function') {
        setTimeout(() => window.aktifSayfayiSec('ses'), 450);
      }
    }
    window.kendiBarkodNumaramiziOlustur = kendiBarkodNumaramiziOlustur;
    if ($('barkodsuz-barkod-uret-btn')) {
      $('barkodsuz-barkod-uret-btn').addEventListener('click', () => kendiBarkodNumaramiziOlustur());
    }
    if ($('form-barkod-uret-btn')) {
      $('form-barkod-uret-btn').addEventListener('click', () => kendiBarkodNumaramiziOlustur());
    }
    if ($('etiket-barkod-uret-btn')) {
      $('etiket-barkod-uret-btn').addEventListener('click', () => {
        kendiBarkodNumaramiziOlustur();
      });
    }
    if ($('barkod-panel-etiket-ac-btn')) {
      $('barkod-panel-etiket-ac-btn').addEventListener('click', async () => {
        barkodKamerayiKapat();
        if ($('barkod-panel')) $('barkod-panel').classList.add('gizli');
        if (typeof window.aktifSayfayiSec === 'function') await window.aktifSayfayiSec('ses');
        await kutuOkumaKamerasiniAcKapat();
      });
    }
    $('barkod-kapat').addEventListener('click', () => {
      barkodKamerayiKapat();
      $('barkod-panel').classList.add('gizli');
      if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
    });
    if ($('barkod-anlik-tara-btn')) {
      $('barkod-anlik-tara-btn').addEventListener('click', async () => {
        barkodIslemKipi = 'giris';
        const v = $('barkod-video');
        if (barkodAkis && v && v.readyState >= 2) {
          durum('▮▯ Kameradaki barkod/etiket çözümleniyor…');
          await kameradanBarkodKaresiTara(v, true);
        } else if (typeof window.mezatGaleriMerkeziAc === 'function') {
          window.mezatGaleriMerkeziAc('barkod');
        } else if ($('barkod-dosya')) {
          $('barkod-dosya').click();
        }
      });
    }
    if ($('barkod-foto-sec-btn') && $('barkod-dosya')) {
      $('barkod-foto-sec-btn').addEventListener('click', () => {
        barkodIslemKipi = 'giris';
        const eskiApk = Boolean(window.MezatNativeApp && typeof window.MezatNativeApp.dosyaSeciciDestekli !== 'function');
        if (!eskiApk && $('barkod-dosya')) {
          try { $('barkod-dosya').click(); } catch (_) {}
        }
        if (typeof window.mezatGaleriMerkeziAc === 'function') {
          window.mezatGaleriMerkeziAc('barkod');
        }
      });
      $('barkod-dosya').addEventListener('change', () => {
        const dosya = $('barkod-dosya').files && $('barkod-dosya').files[0];
        if (!dosya) return;
        if ($('mezat-galeri-merkezi-modal')) $('mezat-galeri-merkezi-modal').remove();
        const urlNesne = URL.createObjectURL(dosya);
        const img = new Image();
        img.onload = async () => {
          URL.revokeObjectURL(urlNesne);
          durum('▮▯ Fotoğraftaki barkod okunuyor…');
          await kameradanBarkodKaresiTara(img, true);
        };
        img.src = urlNesne;
        $('barkod-dosya').value = '';
      });
    }
    $('barkod-sorgula').addEventListener('click', () => {
      barkodIslemKipi = 'giris';
      barkodElleUygulaIstegi = true; barkoduIsle($('barkod-girdi').value, true);
    });
    $('barkod-girdi').addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        barkodIslemKipi = 'giris';
        barkodElleUygulaIstegi = true; barkoduIsle($('barkod-girdi').value, true);
      }
    });
  }

  // ===== 🛒 KASA SATIŞ SAYFASI (3. SATIŞ SEKMESİ) OLAY DİNLEYİCİLERİ =====
  kasaSepetiCiz();
  if ($('kasa-barkod-ekle-btn') && $('kasa-barkod-girdi')) {
    $('kasa-barkod-ekle-btn').addEventListener('click', async () => {
      barkodIslemKipi = 'satis';
      const val = $('kasa-barkod-girdi').value.trim();
      if (!val) {
        $('kasa-barkod-girdi').focus();
        return;
      }
      await barkoduIsle(val, true);
      $('kasa-barkod-girdi').value = '';
    });
    $('kasa-barkod-girdi').addEventListener('keydown', async e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        barkodIslemKipi = 'satis';
        const val = $('kasa-barkod-girdi').value.trim();
        if (!val) return;
        await barkoduIsle(val, true);
        $('kasa-barkod-girdi').value = '';
      }
    });
  }
  if ($('kasa-anlik-tara-btn')) {
    $('kasa-anlik-tara-btn').addEventListener('click', async () => {
      barkodIslemKipi = 'satis';
      const v = $('kasa-barkod-video');
      if (barkodAkis && v && v.readyState >= 2) {
        kasaCanliSonucYaz('📸 Kameradaki barkod çözümleniyor…', '#38bdf8');
        await kameradanBarkodKaresiTara(v, true);
      } else {
        await barkodKamerayiAc('kasa-barkod-video', 'kasa-barkod-vizor');
        if (!barkodAkis && typeof window.mezatGaleriMerkeziAc === 'function') {
          window.mezatGaleriMerkeziAc('barkod');
        }
      }
    });
  }
  if ($('kasa-son-iptal-btn')) {
    $('kasa-son-iptal-btn').addEventListener('click', async () => {
      if (kasaSepeti.length > 0) {
        await kasaSatirAzaltVeyaIptal(kasaSepeti.length - 1, false);
      } else {
        await barkodSatisGeriAl();
      }
    });
  }
  if ($('kasa-yeni-musteri-btn')) {
    $('kasa-yeni-musteri-btn').addEventListener('click', () => {
      kasaYeniMusteriSifirla();
    });
  }

  // ===== 📄 İrsaliye Okutma & Depo Teslim Sayım Kontrolü =====
  function irsaliyeKalemCipleriniCiz() {
    const kutu = $('irsaliye-kalemler');
    if (!kutu) return;
    if (!irsaliyeKalemler || irsaliyeKalemler.length <= 1) {
      kutu.replaceChildren();
      kutu.classList.add('gizli');
      return;
    }
    kutu.classList.remove('gizli');
    kutu.replaceChildren(...irsaliyeKalemler.map((k, idx) => {
      const kaydedildi = kaydedilenKalemler.has(idx);
      const topAdet = (k.satirlar || []).reduce((t, s) => t + (s.irsaliyeAdet || s.adet || 0), 0);
      const dugme = oge('button', {
        type: 'button',
        className: `cip${idx === seciliKalemIndeks ? ' secili' : ''}`,
        textContent: `${kaydedildi ? '✓ ' : ''}${idx + 1}. ${k.urun || 'Ürün'} (${topAdet} adet)`
      });
      dugme.addEventListener('click', () => irsaliyeKaleminiYukle(idx));
      return dugme;
    }));
  }

  function irsaliyeKaleminiYukle(indeks, uyarilar = []) {
    const kalem = irsaliyeKalemler[indeks];
    if (!kalem) return;
    seciliKalemIndeks = indeks;
    irsaliyeModunuAyarla(true);
    $('urun').value = kalem.urun || '';
    $('fiyat').value = kalem.fiyat ? String(kalem.fiyat) : '';
    $('satirlar').replaceChildren();
    const liste = Array.isArray(kalem.satirlar) && kalem.satirlar.length > 0
      ? kalem.satirlar
      : [{ renk: '', beden: '', irsaliyeAdet: 1, adet: 1, sayildi: false }];
    liste.forEach(s => satirEkle({
      renk: s.renk,
      beden: s.beden,
      irsaliyeAdet: s.irsaliyeAdet != null ? s.irsaliyeAdet : s.adet,
      adet: s.adet != null ? s.adet : s.irsaliyeAdet,
      sayildi: Boolean(s.sayildi),
      barkod: s.barkod || ''
    }));
    $('uyarilar').replaceChildren(...(uyarilar || []).map(u => oge('div', { className: 'uyari', textContent: `⚠ ${u}` })));
    irsaliyeKalemCipleriniCiz();
    toplamYaz();
  }

  async function irsaliyeyiSunucuyaSor(gorsel = '') {
    const metin = $('irsaliye-metin') ? $('irsaliye-metin').value.trim() : '';
    const gorselVeri = gorsel || sonIrsaliyeGorseli;
    if (!metin && !gorselVeri) {
      durum('Önce irsaliye fotoğrafı çekin ya da irsaliye satırlarını kutuya yazın.', true);
      return;
    }
    try {
      durum('📄 İrsaliye OCR ile okunuyor ve sayım tablosu hazırlanıyor…');
      const govde = {
        gorsel: gorselVeri,
        irsaliyeNo: $('irsaliye-no') ? $('irsaliye-no').value.trim() : '',
        irsaliyeMetni: metin,
        soz: $('soz') ? $('soz').value.trim() : ''
      };
      const cevap = await bilgisayaraYaDaTelefonda('/api/envanter/irsaliye', govde, H => H.telefondaIrsaliyeOku({ ...govde, adim: m => durum(`📄 Bilgisayara ulaşılamadı, telefonda okunuyor: ${m}…`) }));
      if (!cevap.success) { durum(cevap.error || 'İrsaliye okunamadı.', true); return; }
      if (cevap.ocrMetin && $('irsaliye-metin') && !$('irsaliye-metin').value.trim()) {
        $('irsaliye-metin').value = cevap.ocrMetin;
      }
      if (cevap.irsaliyeNo && $('irsaliye-no') && !$('irsaliye-no').value.trim()) {
        $('irsaliye-no').value = cevap.irsaliyeNo;
      }
      const gecerliKalemler = Array.isArray(cevap.kalemler)
        ? cevap.kalemler.filter(k => k && Array.isArray(k.satirlar) && k.satirlar.length > 0)
        : [];
      const gecerliSatirlar = Array.isArray(cevap.satirlar) ? cevap.satirlar : [];
      if (gecerliKalemler.length === 0 && gecerliSatirlar.length === 0) {
        if ($('satirlar') && $('satirlar').children.length === 0) satirEkle();
        $('uyarilar').replaceChildren(...(cevap.uyarilar || ['İrsaliyeden beden/adet satırı okunamadı.']).map(u => oge('div', { className: 'uyari', textContent: `⚠ ${u}` })));
        durum('⚠ Görüntüden irsaliye satırı (ürün, beden ve adet) okunamadı. Kamerayı irsaliye listesine yaklaştırıp tekrar çekin veya satırları kutuya yazıp Aktar deyin.', true);
        return;
      }
      bipSesi();
      irsaliyeKalemler = gecerliKalemler.length > 0
        ? gecerliKalemler
        : [{ urun: cevap.urun || '', fiyat: cevap.fiyat || null, satirlar: gecerliSatirlar }];
      kaydedilenKalemler = new Set();
      irsaliyeKaleminiYukle(0, cevap.uyarilar || []);
      if ($('irsaliye-kamera-govde')) {
        $('irsaliye-kamera-govde').classList.add('gizli');
        irsaliyeCanliKamerayiKapat();
        if ($('irsaliye-daralt-btn')) $('irsaliye-daralt-btn').textContent = '🔽 Kamerayı / Metni Aç';
      }
      const topAdet = gecerliSatirlar.reduce((t, s) => t + (s.irsaliyeAdet || s.adet || 0), 0);
      durum(`📋 İrsaliye tabloya aktarıldı: ${cevap.urun || 'Ürün'} (${topAdet} adet). Depo tesliminde ürünleri sayıp "Tüm Satırlar Sayıldı" onayını verin ve satış fiyatını girip kaydedin.`);
      tabloyuSesliOzetle();
    } catch (err) {
      durum('İrsaliye bilgisayara gönderilemedi.', true);
    }
  }

  function farkTutanagiMetniOlustur(ozelKayit = null) {
    const urun = ozelKayit ? ozelKayit.urun : $('urun').value.trim();
    const fiyat = ozelKayit ? ozelKayit.fiyat : $('fiyat').value.trim();
    const irsNo = ozelKayit ? (ozelKayit.irsaliyeNo || '') : ($('irsaliye-no') ? $('irsaliye-no').value.trim() : '');
    const giren = ozelKayit ? (ozelKayit.giren || '') : ($('giren').value.trim() || 'Depo');
    const satirlar = ozelKayit
      ? [...(ozelKayit.satirlar || []), ...(ozelKayit.eksikSatirlar || [])]
      : satirlariOku();
    const irsTop = satirlar.reduce((t, s) => t + (s.irsaliyeAdet != null ? Number(s.irsaliyeAdet) : Number(s.adet) || 0), 0);
    const sayTop = satirlar.reduce((t, s) => t + (Number(s.adet) || 0), 0);
    const farkTop = sayTop - irsTop;
    const farklilar = satirlar.filter(s => s.irsaliyeAdet != null && Number(s.adet) !== Number(s.irsaliyeAdet));
    const satirDetay = farklilar.length
      ? ['Farklı Çıkan Bedenler:', ...farklilar.map(s => {
          const f = (Number(s.adet) || 0) - Number(s.irsaliyeAdet);
          return `• ${[s.renk, s.beden].filter(Boolean).join(' ') || 'Standart'}: İrsaliye ${s.irsaliyeAdet} -> Çıkan ${s.adet || 0} (${f > 0 ? `+${f} Fazla` : `${f} Eksik`})`;
        })].join('\n')
      : 'Tüm bedenler irsaliye ile birebir mutabıktır.';
    return [
      '📋 MAL KABUL & DEPO SAYIM MUTABAKAT TUTANAĞI',
      irsNo ? `İrsaliye No: ${irsNo}` : 'İrsaliye: Belirtilmedi',
      `Ürün: ${urun || '—'}${fiyat ? ` (${fiyat} TL)` : ''}`,
      `Sayımı Yapan: ${giren} · Saat: ${new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}`,
      `İrsaliye Toplamı: ${irsTop} Adet | Sayılan Net: ${sayTop} Adet | Fark: ${farkTop === 0 ? '0 (Tam Mutabakat ✓)' : (farkTop > 0 ? `+${farkTop} Fazla` : `${farkTop} Eksik ⚠`)}`,
      satirDetay
    ].join('\n');
  }

  async function farkTutanaginiPaylas(ozelKayit = null) {
    const metin = farkTutanagiMetniOlustur(ozelKayit);
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(metin);
      }
    } catch (err) {}
    durum('📤 Sayım / Fark tutanağı panoya kopyalandı ve WhatsApp paylaşımı açılıyor…');
    try {
      window.open(`https://wa.me/?text=${encodeURIComponent(metin)}`, '_blank', 'noopener');
    } catch (err) {}
  }

  if ($('fark-tutanagi-btn')) {
    $('fark-tutanagi-btn').addEventListener('click', () => farkTutanaginiPaylas());
  }

  if ($('geri-al-btn')) {
    $('geri-al-btn').addEventListener('click', () => {
      if (!sonSilinenSatir) return;
      satirEkle(sonSilinenSatir);
      sonSilinenSatir = null;
      if (geriAlZamanlayici) clearTimeout(geriAlZamanlayici);
      $('geri-al-cubuk').classList.add('gizli');
      durum('✓ Silinen satır geri alındı.');
    });
  }

  if ($('irsaliye-ac')) {
    $('irsaliye-ac').addEventListener('click', async e => {
      if (e.detail === 0) return;
      const acik = !$('irsaliye-panel').classList.contains('gizli');
      if (acik) {
        irsaliyeCanliKamerayiKapat();
        $('irsaliye-panel').classList.add('gizli');
        return;
      }
      digerAltPanelleriKapat('irsaliye-panel');
      $('irsaliye-panel').classList.remove('gizli');
      if ($('irsaliye-kamera-govde')) $('irsaliye-kamera-govde').classList.remove('gizli');
      if ($('irsaliye-daralt-btn')) $('irsaliye-daralt-btn').textContent = '🔼 Kamerayı Daralt';
      try { $('irsaliye-panel').scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (_) {}
      await irsaliyeCanliKamerayiAc();
    });
    $('irsaliye-kapat').addEventListener('click', () => {
      irsaliyeCanliKamerayiKapat();
      irsaliyeModunuAyarla(false);
      if ($('uyarilar')) $('uyarilar').replaceChildren();
      if ($('satirlar') && $('satirlar').children.length === 0) satirEkle();
      toplamYaz();
      $('irsaliye-panel').classList.add('gizli');
      if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
    });
    if ($('irsaliye-canli-cek-btn')) {
      $('irsaliye-canli-cek-btn').addEventListener('click', async () => {
        const v = $('irsaliye-video');
        if (!irsaliyeKameraAkis) {
          await irsaliyeCanliKamerayiAc();
          for (let i = 0; i < 8 && v && (v.readyState < 2 || v.videoWidth === 0); i++) {
            await new Promise(r => setTimeout(r, 100));
          }
        }
        if (irsaliyeKameraAkis && v && v.readyState >= 2 && v.videoWidth > 0) {
          const enBoy = 1440;
          const oran = Math.min(1, enBoy / Math.max(v.videoWidth, v.videoHeight));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(v.videoWidth * oran));
          canvas.height = Math.max(1, Math.round(v.videoHeight * oran));
          canvas.getContext('2d').drawImage(v, 0, 0, canvas.width, canvas.height);
          sonIrsaliyeGorseli = canvas.toDataURL('image/jpeg', 0.92);
          if ($('irsaliye-resim')) {
            $('irsaliye-resim').src = sonIrsaliyeGorseli;
            $('irsaliye-resim').classList.remove('gizli');
          }
          if ($('irsaliye-metin')) $('irsaliye-metin').value = '';
          await irsaliyeyiSunucuyaSor(sonIrsaliyeGorseli);
        } else {
          if (typeof window.mezatGaleriMerkeziAc === 'function') window.mezatGaleriMerkeziAc('irsaliye');
          else $('irsaliye-dosya').click();
        }
      });
    }
    $('irsaliye-foto-cek').addEventListener('click', () => {
      const eskiApk = Boolean(window.MezatNativeApp && typeof window.MezatNativeApp.dosyaSeciciDestekli !== 'function');
      if (!eskiApk && $('irsaliye-dosya')) {
        try { $('irsaliye-dosya').click(); } catch (_) {}
      }
      if (typeof window.mezatGaleriMerkeziAc === 'function') {
        window.mezatGaleriMerkeziAc('irsaliye');
      }
    });
    if ($('irsaliye-xml-sec') && $('irsaliye-xml-dosya')) {
      $('irsaliye-xml-sec').addEventListener('click', () => {
        const eskiApk = Boolean(window.MezatNativeApp && typeof window.MezatNativeApp.dosyaSeciciDestekli !== 'function');
        if (!eskiApk && $('irsaliye-xml-dosya')) {
          try { $('irsaliye-xml-dosya').click(); } catch (_) {}
        }
        if (typeof window.mezatGaleriMerkeziAc === 'function') {
          window.mezatGaleriMerkeziAc('irsaliye-xml');
        }
      });
      $('irsaliye-xml-dosya').addEventListener('change', async () => {
        const dosya = $('irsaliye-xml-dosya').files && $('irsaliye-xml-dosya').files[0];
        if (!dosya) return;
        if ($('mezat-galeri-merkezi-modal')) $('mezat-galeri-merkezi-modal').remove();
        try {
          const xmlMetin = await dosya.text();
          if ($('irsaliye-metin')) $('irsaliye-metin').value = xmlMetin;
          sonIrsaliyeGorseli = '';
          await irsaliyeyiSunucuyaSor('');
        } catch (err) {
          durum('XML irsaliye dosyası okunamadı.', true);
        }
        $('irsaliye-xml-dosya').value = '';
      });
    }
    $('irsaliye-aktar').addEventListener('click', () => irsaliyeyiSunucuyaSor());
    $('irsaliye-dosya').addEventListener('change', async () => {
      const dosya = $('irsaliye-dosya').files && $('irsaliye-dosya').files[0];
      if (!dosya) return;
      if ($('mezat-galeri-merkezi-modal')) $('mezat-galeri-merkezi-modal').remove();
      const urlNesne = URL.createObjectURL(dosya);
      const img = new Image();
      img.onload = async () => {
        const enBoy = 1280;
        const oran = Math.min(1, enBoy / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * oran));
        canvas.height = Math.max(1, Math.round(img.height * oran));
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        sonIrsaliyeGorseli = canvas.toDataURL('image/jpeg', 0.86);
        if ($('irsaliye-resim')) {
          $('irsaliye-resim').src = sonIrsaliyeGorseli;
          $('irsaliye-resim').classList.remove('gizli');
        }
        if ($('irsaliye-metin')) $('irsaliye-metin').value = '';
        URL.revokeObjectURL(urlNesne);
        await irsaliyeyiSunucuyaSor(sonIrsaliyeGorseli);
      };
      img.src = urlNesne;
      $('irsaliye-dosya').value = '';
    });
  }

  // 🔫 El Terminali / Lazer Barkod Okuyucu (HID Klavye Modu) Otomatik Yakalayıcı
  let lazerTampon = '';
  let lazerSonTusMs = 0;
  document.addEventListener('keydown', e => {
    const aktif = document.activeElement;
    const yaziAlaninda = aktif && (aktif.tagName === 'INPUT' || aktif.tagName === 'TEXTAREA');
    if (yaziAlaninda && aktif.id !== 'barkod-girdi' && aktif.id !== 'kasa-barkod-girdi') return;
    const simdi = Date.now();
    if (simdi - lazerSonTusMs > 80) lazerTampon = '';
    lazerSonTusMs = simdi;
    if (e.key === 'Enter' && lazerTampon.length >= 6) {
      e.preventDefault();
      const okunan = lazerTampon;
      lazerTampon = '';
      barkoduIsle(okunan);
    } else if (e.key.length === 1 && /[\dA-Za-z\-]/.test(e.key)) {
      lazerTampon += e.key;
    }
  });

  if ($('tumunu-saydim')) {
    $('tumunu-saydim').addEventListener('click', () => {
      const trListesi = [...$('satirlar').querySelectorAll('tr')];
      const hepsiSayildi = trListesi.length > 0 && trListesi.every(tr => tr.dataset.sayildi === '1');
      const yeniDurum = hepsiSayildi ? '0' : '1';
      trListesi.forEach(tr => { tr.dataset.sayildi = yeniDurum; });
      toplamYaz();
      if (yeniDurum === '1') {
        bipSesi();
        if (!$('fiyat').value.trim()) {
          durum('✓ Depo sayımı onaylandı! Şimdi satış fiyatını (TL) girip Kaydet\'e basın.');
          $('fiyat').focus();
        } else {
          durum('✓ Depo sayımı ve satış fiyatı hazır. Stoka kaydetmek için yeşil düğmeye basın.');
        }
      }
    });
  }
  $('fiyat').addEventListener('input', () => { if (irsaliyeModu) toplamYaz(); });

  $('cevir').addEventListener('click', async e => {
    if (e.detail === 0) return;
    const metin = $('soz').value.trim();
    if (!metin) { durum('Önce ürünü kutuya yazın.', true); return; }
    try {
      const cevap = await post('/api/envanter/coz', { metin });
      if (!cevap.success) { durum(cevap.error, true); return; }
      sesSonucunuUygula(cevap);
      $('soz').value = '';
      if ($('yazi-giris-kutu')) $('yazi-giris-kutu').classList.add('gizli');
      if ($('yazi-kutu-ac-btn')) $('yazi-kutu-ac-btn').classList.remove('aktif');
      durum('✓ Yazılan ürün tabloya aktarıldı, doğruysa Kaydet\'e basın.');
    } catch (err) {
      pcBagli = false;
      if (window.MezatMobilHibrit) {
        const yerel = window.MezatMobilHibrit.envanterCozYerel(metin, { yazili: true });
        if (yerel && yerel.success) {
          sesSonucunuUygula(yerel);
          $('soz').value = '';
          if ($('yazi-giris-kutu')) $('yazi-giris-kutu').classList.add('gizli');
          if ($('yazi-kutu-ac-btn')) $('yazi-kutu-ac-btn').classList.remove('aktif');
          durum('📲 Bağımsız Mobil Mod: Ürün telefonda tabloya aktarıldı, Kaydet\'e basın.');
          return;
        }
      }
      durum('Bilgisayara ulaşılamadı.', true);
    }
  });
  let yeniSatirSesModu = false;

  // ===== 🎙️ SES ODAK PENCERESİ VE ✍️ YAZARAK GİRİŞ PENCERESİ KONTROLLERİ =====
  if ($('ses-odak-bitir-btn')) {
    $('ses-odak-bitir-btn').addEventListener('click', () => {
      if ($('mikrofon')) $('mikrofon').click();
    });
  }
  if ($('ses-odak-iptal-btn')) {
    $('ses-odak-iptal-btn').addEventListener('click', () => {
      aktifSesIstekSayaci++;
      if (kayit && kayit.iptalEt) {
        try { kayit.iptalEt('🎙️ Sesli giriş iptal edildi.'); } catch (_) {}
      }
      dugmeHazir();
      durum('🎙️ Sesli giriş iptal edildi.');
    });
  }
  if ($('yazi-kutu-kapat-btn')) {
    $('yazi-kutu-kapat-btn').addEventListener('click', () => {
      if ($('yazi-giris-kutu')) $('yazi-giris-kutu').classList.add('gizli');
      if ($('yazi-kutu-ac-btn')) $('yazi-kutu-ac-btn').classList.remove('aktif');
    });
  }
  if ($('soz-temizle-ic-btn')) {
    $('soz-temizle-ic-btn').addEventListener('click', () => {
      if ($('soz')) {
        $('soz').value = '';
        $('soz').focus();
      }
    });
  }
  if ($('yazi-hizli-cipler')) {
    $('yazi-hizli-cipler').querySelectorAll('.yazi-ekle-cip').forEach(btn => {
      btn.addEventListener('click', () => {
        const kelime = btn.dataset.ekle || '';
        if (!kelime || !$('soz')) return;
        const mevcut = $('soz').value.trim();
        $('soz').value = mevcut ? `${mevcut} ${kelime}` : kelime;
      });
    });
  }

  // ===== ➕ ODAKLI RENK / BEDEN / ADET SEÇİM PENCERESİ =====
  let rbSeciliBeden = '';
  let rbSeciliRenk = '';
  function rbOzetGuncelle() {
    const b = ($('rb-ozel-beden') && $('rb-ozel-beden').value.trim().toLocaleUpperCase('tr-TR')) || rbSeciliBeden;
    const r = ($('rb-ozel-renk') && $('rb-ozel-renk').value.trim().toLocaleUpperCase('tr-TR')) || rbSeciliRenk;
    const a = Math.max(1, Number($('rb-adet-girdi') && $('rb-adet-girdi').value) || 1);
    const bBaslik = (g_aktifSektorTanimi && g_aktifSektorTanimi.thBeden) || 'Beden';
    const rBaslik = (g_aktifSektorTanimi && g_aktifSektorTanimi.thRenk) || 'Renk';
    if ($('rb-odak-ozet')) {
      $('rb-odak-ozet').textContent = `Seçilen: ${b || bBaslik + ' Yok'} · ${r || rBaslik + ' Yok'} · ${a} Adet`;
    }
  }
  function rbPenceresiniAc() {
    const trListesi = [...$('satirlar').querySelectorAll('tr')];
    const sonTr = trListesi[trListesi.length - 1];
    const mevcutRenk = sonTr && sonTr.querySelectorAll('input')[0]
      ? sonTr.querySelectorAll('input')[0].value.trim().toLocaleUpperCase('tr-TR')
      : '';
    rbSeciliBeden = '';
    rbSeciliRenk = mevcutRenk || '';
    if ($('rb-ozel-beden')) $('rb-ozel-beden').value = '';
    if ($('rb-ozel-renk')) $('rb-ozel-renk').value = rbSeciliRenk;
    if ($('rb-adet-girdi')) $('rb-adet-girdi').value = '1';
    if ($('rb-beden-izgara')) {
      $('rb-beden-izgara').querySelectorAll('.odak-secim-btn').forEach(b => b.classList.remove('secili'));
    }
    if ($('rb-renk-izgara')) {
      $('rb-renk-izgara').querySelectorAll('.odak-secim-btn').forEach(b => {
        b.classList.toggle('secili', b.dataset.renk === rbSeciliRenk);
      });
    }
    rbOzetGuncelle();
    if ($('renk-beden-odak-panel')) $('renk-beden-odak-panel').classList.remove('gizli');
  }
  function rbSecimiTabloyaUygula(pencereyiKapat = true) {
    const b = (($('rb-ozel-beden') && $('rb-ozel-beden').value.trim()) || rbSeciliBeden).toLocaleUpperCase('tr-TR');
    const r = (($('rb-ozel-renk') && $('rb-ozel-renk').value.trim()) || rbSeciliRenk).toLocaleUpperCase('tr-TR');
    const a = Math.max(1, Number($('rb-adet-girdi') && $('rb-adet-girdi').value) || 1);
    satiraEkleVeyaArtir({
      urun: $('urun') ? $('urun').value.trim() : '',
      fiyat: $('fiyat') ? $('fiyat').value.trim() : null,
      barkod: $('barkod') ? $('barkod').value.trim() : '',
      renk: r,
      beden: b,
      adet: a
    });
    bipSesi();
    durum(`✓ Satıra eklendi: ${[r, b, `${a} Adet`].filter(Boolean).join(' · ')}`);
    if (pencereyiKapat) {
      if ($('renk-beden-odak-panel')) $('renk-beden-odak-panel').classList.add('gizli');
    } else {
      rbSeciliBeden = '';
      if ($('rb-ozel-beden')) $('rb-ozel-beden').value = '';
      if ($('rb-adet-girdi')) $('rb-adet-girdi').value = '1';
      if ($('rb-beden-izgara')) {
        $('rb-beden-izgara').querySelectorAll('.odak-secim-btn').forEach(btn => btn.classList.remove('secili'));
      }
      rbOzetGuncelle();
    }
  }
  if ($('rb-beden-izgara')) {
    $('rb-beden-izgara').querySelectorAll('.odak-secim-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const val = btn.dataset.beden || '';
        rbSeciliBeden = rbSeciliBeden === val ? '' : val;
        if ($('rb-ozel-beden')) $('rb-ozel-beden').value = rbSeciliBeden;
        $('rb-beden-izgara').querySelectorAll('.odak-secim-btn').forEach(b => b.classList.toggle('secili', b.dataset.beden === rbSeciliBeden));
        rbOzetGuncelle();
      });
    });
  }
  if ($('rb-renk-izgara')) {
    $('rb-renk-izgara').querySelectorAll('.odak-secim-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const val = btn.dataset.renk || '';
        rbSeciliRenk = rbSeciliRenk === val ? '' : val;
        if ($('rb-ozel-renk')) $('rb-ozel-renk').value = rbSeciliRenk;
        $('rb-renk-izgara').querySelectorAll('.odak-secim-btn').forEach(b => b.classList.toggle('secili', b.dataset.renk === rbSeciliRenk));
        rbOzetGuncelle();
      });
    });
  }
  if ($('rb-ozel-beden')) $('rb-ozel-beden').addEventListener('input', rbOzetGuncelle);
  if ($('rb-ozel-renk')) $('rb-ozel-renk').addEventListener('input', rbOzetGuncelle);
  if ($('rb-ozel-renk-temizle-btn')) {
    $('rb-ozel-renk-temizle-btn').addEventListener('click', () => {
      rbSeciliRenk = '';
      if ($('rb-ozel-renk')) {
        $('rb-ozel-renk').value = '';
        $('rb-ozel-renk').focus();
      }
      if ($('rb-renk-izgara')) {
        $('rb-renk-izgara').querySelectorAll('.odak-secim-btn').forEach(b => b.classList.remove('secili'));
      }
      rbOzetGuncelle();
    });
  }
  if ($('rb-ozel-beden-temizle-btn')) {
    $('rb-ozel-beden-temizle-btn').addEventListener('click', () => {
      rbSeciliBeden = '';
      if ($('rb-ozel-beden')) {
        $('rb-ozel-beden').value = '';
        $('rb-ozel-beden').focus();
      }
      if ($('rb-beden-izgara')) {
        $('rb-beden-izgara').querySelectorAll('.odak-secim-btn').forEach(b => b.classList.remove('secili'));
      }
      rbOzetGuncelle();
    });
  }
  if ($('rb-adet-azalt')) {
    $('rb-adet-azalt').addEventListener('click', () => {
      if ($('rb-adet-girdi')) $('rb-adet-girdi').value = String(Math.max(1, (Number($('rb-adet-girdi').value) || 1) - 1));
      rbOzetGuncelle();
    });
  }
  if ($('rb-adet-artir')) {
    $('rb-adet-artir').addEventListener('click', () => {
      if ($('rb-adet-girdi')) $('rb-adet-girdi').value = String((Number($('rb-adet-girdi').value) || 1) + 1);
      rbOzetGuncelle();
    });
  }
  if ($('rb-onayla-kapat-btn')) {
    $('rb-onayla-kapat-btn').addEventListener('click', () => rbSecimiTabloyaUygula(true));
  }
  if ($('rb-ekle-devam-btn')) {
    $('rb-ekle-devam-btn').addEventListener('click', () => rbSecimiTabloyaUygula(false));
  }
  if ($('rb-odak-kapat-btn')) {
    $('rb-odak-kapat-btn').addEventListener('click', () => {
      if ($('renk-beden-odak-panel')) $('renk-beden-odak-panel').classList.add('gizli');
    });
  }

  $('satir-ekle').addEventListener('click', () => {
    rbPenceresiniAc();
  });
  if ($('urun-temizle-btn')) {
    $('urun-temizle-btn').addEventListener('click', () => {
      if ($('urun')) {
        $('urun').value = '';
        otomatikBarkodGuncelle();
      }
      durum('🗑️ Ürün adı temizlendi.');
    });
  }
  if ($('fiyat-temizle-btn')) {
    $('fiyat-temizle-btn').addEventListener('click', () => {
      if ($('fiyat')) $('fiyat').value = '';
      durum('🗑️ Fiyat temizlendi.');
    });
  }
  if ($('barkod-temizle-btn')) {
    $('barkod-temizle-btn').addEventListener('click', () => {
      if ($('barkod')) {
        $('barkod').value = '';
        otomatikBarkodGuncelle();
      }
      durum('🗑️ Barkod temizlendi.');
    });
  }
  $('temizle').addEventListener('click', () => {
    aktifSesIstekSayaci++;
    if (kayit && kayit.iptalEt) {
      kayit.iptalEt('');
    }
    formuTemizle();
    dugmeHazir();
    durum('🗑️ Yanlış giriş temizlendi, tablo sıfırlandı.');
    setTimeout(() => {
      if ($('durum') && $('durum').textContent === '🗑️ Yanlış giriş temizlendi, tablo sıfırlandı.') durum('');
    }, 1500);
  });

  // ===== Soru kutusu: aynı ürün başkası tarafından girilmiş ya da düzeltilirken değişmiş =====
  function soruyuKapat() { $('soru').classList.add('gizli'); $('soru-dugmeleri').replaceChildren(); }
  function soruSor(metin, detay, secenekler) {
    $('soru-metni').textContent = metin;
    $('soru-detay').textContent = detay || '';
    $('soru-dugmeleri').replaceChildren(...secenekler.map(([yazi, sinif, is]) => {
      const d = oge('button', { type: 'button', className: sinif, textContent: yazi });
      d.addEventListener('click', ev => { if (ev.detail > 0) { soruyuKapat(); is(); } });
      return d;
    }));
    $('soru').classList.remove('gizli');
    $('soru').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  async function kaydet(ek = {}) {
    const dugme = $('kaydet');
    const giren = $('giren').value.trim();
    if (!giren) {
      if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.remove('gizli');
      durum('Önce menüden (👤 Kullanıcı) adınızı yazın.', true);
      $('giren').focus();
      return;
    }

    // 🛡️ BOŞ ÜRÜN & BOŞ SATIR KAYIT ENGELİ:
    const urunAdi = String(($('urun') && $('urun').value) || '').trim();
    if (!urunAdi || urunAdi.length < 2 || urunAdi.toLocaleLowerCase('tr-TR') === 'isimsiz ürün') {
      durum('⚠️ Ürün adı boş bırakılamaz! Lütfen ürün adı girin veya sesle söyleyin.', true);
      if ($('urun')) $('urun').focus();
      return;
    }

    const girilenSatirlarKontrol = satirlariOku();
    if (!girilenSatirlarKontrol || !girilenSatirlarKontrol.length) {
      durum('⚠️ Boş kayıt yapılamaz! Lütfen en az 1 adet ürün girin.', true);
      return;
    }
    const toplamGecerliAdet = girilenSatirlarKontrol.reduce((t, s) => t + (Number(s.adet) || 0), 0);
    if (!irsaliyeModu && toplamGecerliAdet <= 0) {
      durum('⚠️ Adet sıfır veya boş olamaz! Lütfen geçerli bir adet girin.', true);
      return;
    }
    const fiyatDeger = fiyatCozUst($('fiyat').value);
    if (irsaliyeModu) {
      if (!sayimOnayli) {
        durum('İrsaliye girişinde ürünler sayılıp "Tüm Satırlar Sayıldı, Adetler Net" onayı verilmeden stoka kayıt yapılamaz.', true);
        if ($('sayim-onay-cubuk')) $('sayim-onay-cubuk').scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      if (!$('fiyat').value.trim() || !Number.isFinite(fiyatDeger) || fiyatDeger <= 0) {
        durum('Sayım onaylandı! Kaydetmeden önce ürünün satış fiyatını (TL) girin.', true);
        $('fiyat').classList.add('fiyat-vurgu');
        $('fiyat').focus();
        return;
      }
    }
    if (!ek.yuksekFiyatOnayli && Number.isFinite(fiyatDeger) && fiyatDeger >= 25000) {
      soruSor(`Girilen fiyat çok yüksek görünüyor: ${fiyatDeger.toLocaleString('tr-TR')} TL`, 'Kuruş noktası veya fazladan sıfır yazılmış olabilir. Bu fiyatla kaydetmek istediğinize emin misiniz?', [
        [`✓ Evet, ${fiyatDeger.toLocaleString('tr-TR')} TL doğru`, 'evet', () => kaydet({ ...ek, yuksekFiyatOnayli: true })],
        ['✎ Fiyatı düzelt', '', () => { $('fiyat').focus(); durum('Fiyatı kontrol edip tekrar kaydedin.'); }]
      ]);
      durum('Yüksek fiyat uyarısı: aşağıdan onaylayın veya fiyatı düzeltin.', true);
      return;
    }
    if (!aktifIstekId) aktifIstekId = yeniIstekId();
    const istekId = ek.istekId || aktifIstekId;
    const girilenSatirlar = satirlariOku();
    // Grup devam modunda ("devamEdenUrunGrubu") yeni bir beden girilmeden tekrar Kaydet'e basıldıysa fazladan bedensiz (STD: 1) satır ekleme, pencereyi kapat!
    if (devamEdenUrunGrubu && !duzeltmePenceresiModu && !girilenSatirlar.some(s => s.beden && String(s.beden).trim())) {
      calismaPenceresiniKapat(true);
      durum('✓ Kayıt tamamlandı · Sıradaki ürüne geçebilirsiniz.');
      return;
    }
    const bedenGirildiMi = girilenSatirlar.some(s => s.beden && !/^(TEK|STANDART|STD)$/i.test(String(s.beden).trim()));
    const sonGirilenRenk = (girilenSatirlar.find(s => s.renk) || {}).renk || '';
    const girilenBedenMetni = girilenSatirlar
      .filter(s => s.beden && !/^(TEK|STANDART|STD)$/i.test(String(s.beden).trim()))
      .map(s => `${s.renk ? s.renk + ' ' : ''}${s.beden} bedeni (${s.adet} adet)`)
      .join(', ');
    const buIslemAdet = girilenSatirlar.reduce((t, s) => t + (Number(s.adet) || 0), 0);
    dugme.disabled = true;
    try {
      const cevap = await post('/api/envanter/kaydet', {
        istekId,
        id: duzeltilenId, surum: duzeltilenSurum, giren,
        urun: $('urun').value, fiyat: $('fiyat').value, barkod: $('barkod') ? $('barkod').value.trim() : '',
        irsaliyeModu, sayimOnayli,
        irsaliyeNo: $('irsaliye-no') ? $('irsaliye-no').value.trim() : '',
        satirlar: girilenSatirlar, soz: $('soz').value,
        gorselParmakIzi: sonGorselParmakIzi,
        ocrMetin: $('etiket-metin') ? $('etiket-metin').value.trim() : '',
        ...ek
      });
      if (cevap.cift) {
        const m = cevap.mevcut;
        const secimIstekId = yeniIstekId();
        if (m.devir) {
          // Dünden kalan mal yeniden sayıldıysa sayım dünkü kalanın yerine geçer
          soruSor(`${m.urun} dünden kalan olarak listede.`, `Dünden kalan: ${ozet(m)}. Rafı yeniden saydıysanız sayımınız onun yerine geçsin.`, [
            ['✓ Sayımımla değiştir', 'evet', () => kaydet({ id: m.id, surum: m.surum, istekId: secimIstekId, yuksekFiyatOnayli: true })],
            ['➕ Dünden kalanın üstüne ekle', '', () => kaydet({ birlestir: m.id, istekId: secimIstekId, yuksekFiyatOnayli: true })],
            ['Vazgeç', '', () => durum('Kaydedilmedi.')]
          ]);
          durum('Bu ürün dünden kalmış. Aşağıdan seçin.', true);
          return;
        }
        // Bugün aynı ürün girilmişse sormadan toplanmaz: iki kişi aynı rafı saymış olabilir
        soruSor(`${m.urun} bugün ${m.giren || 'biri'} tarafından ${m.saat}'de girildi.`, `Listede: ${ozet(m)}. Aynı malı ikinci kez saymış olabilirsiniz.`, [
          ['➕ Üstüne ekle', 'evet', () => kaydet({ birlestir: m.id, istekId: secimIstekId, yuksekFiyatOnayli: true })],
          ['Sayımımla değiştir', '', () => kaydet({ id: m.id, surum: m.surum, istekId: secimIstekId, yuksekFiyatOnayli: true })],
          ['Vazgeç', '', () => durum('Kaydedilmedi.')]
        ]);
        durum('Bu ürün bugün girilmiş. Aşağıdan seçin.', true);
        return;
      }
      if (cevap.cakisma) {
        const m = cevap.mevcut;
        const zorlaIstekId = yeniIstekId();
        soruSor(cevap.error, `Şimdiki hâli: ${ozet(m)}.`, [
          ['Yeni hâlini aç', 'evet', () => duzeltmeyeAc(m)],
          ['Benimkini yine de kaydet', '', () => kaydet({ zorla: true, istekId: zorlaIstekId, yuksekFiyatOnayli: true })]
        ]);
        durum('Bu ürün siz düzeltirken değişti. Aşağıdan seçin.', true);
        return;
      }
      if (!cevap.success) { durum(cevap.error || 'Kaydedilemedi.', true); return; }
      aktifIstekId = null;
      const k = cevap.kayit;
      if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelEnvantereYansit === 'function') {
        window.MezatMobilHibrit.yerelEnvantereYansit(k);
      }
      const kaydedilenAdet = k.satirlar.reduce((t, s) => t + s.adet, 0);
      await listeyiYenile(k.id);

      // İrsaliyede birden fazla ürün kalemi varsa sıradaki sayılmamış ürüne otomatik geç
      if (irsaliyeModu && irsaliyeKalemler.length > 1) {
        kaydedilenKalemler.add(seciliKalemIndeks);
        const siradakiIndeks = irsaliyeKalemler.findIndex((_, idx) => !kaydedilenKalemler.has(idx));
        if (siradakiIndeks >= 0) {
          irsaliyeKaleminiYukle(siradakiIndeks);
          durum(`✓ ${k.urun} · Barkod kaydedildi · ${kaydedilenAdet} adet kaydedildi${k.fiyat ? ` · ${k.fiyat} TL` : ''} · Sıradaki irsaliye kalemi (${irsaliyeKalemler[siradakiIndeks].urun}) yüklendi.`);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
      }

      const etiketMesaji = cevap.etiketBasim && cevap.etiketBasim.success
        ? ` · 🖨️ ${cevap.etiketBasim.eklenenSayisi} etiket kuyruğa gönderildi`
        : '';
      if (ek.etiketBas && window.MezatMobilHibrit && (window.MezatMobilHibrit.yaziciDurumu().bagli || window.MezatMobilHibrit.yaziciDurumu().kip !== 'otomatik')) {
        window.MezatMobilHibrit.bluetoothTermalEtiketBas(k, ek.etiketKip || 'varyant');
      }
      await barkodBankasiniYenile($('banka-arama') ? $('banka-arama').value : '');

      const fiyatBilgi = k.fiyat ? ` · ${k.fiyat} TL` : '';
      const islemDurumMetni = (cevap.duzeltme || duzeltmePenceresiModu)
        ? 'Kayıt yenilendi'
        : (cevap.birlesti ? 'Aynı ürün grubuna eklendi, kayıt yenilendi' : 'Yeni kayıt açıldı, yeni olarak kaydedildi');

      // Kaydet tuşuna basıldığında formu tamamen temizle ve çalışma penceresini kapat (eski ürün ekranda asılı kalmasın, boş satır oluşmasın)
      calismaPenceresiniKapat(true);
      durum(`✓ ${k.urun}: ${girilenBedenMetni || `${buIslemAdet || kaydedilenAdet} adet`} kaydedildi · Barkod kaydedildi${fiyatBilgi} · ${islemDurumMetni}${etiketMesaji} · Sıradaki ürüne geçebilirsiniz.`);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      pcBagli = false;
      if (window.MezatMobilHibrit) {
        const yerel = window.MezatMobilHibrit.ceptenCevrimdisiKaydet({
          id: duzeltilenId,
          giren,
          urun: $('urun').value,
          fiyat: $('fiyat').value,
          barkod: $('barkod') ? $('barkod').value.trim() : '',
          irsaliyeModu,
          sayimOnayli,
          irsaliyeNo: $('irsaliye-no') ? $('irsaliye-no').value.trim() : '',
          satirlar: girilenSatirlar,
          soz: $('soz').value
        });
        if (!yerel.success) {
          durum(yerel.error || 'Telefona kaydedilemedi.', true);
          return;
        }
        aktifIstekId = null;
        const k = yerel.kayit;
        const kaydedilenAdet = k.satirlar.reduce((t, s) => t + s.adet, 0);
        if (ek.etiketBas) {
          await window.MezatMobilHibrit.bluetoothTermalEtiketBas(k, ek.etiketKip || 'varyant');
        }
        await listeyiYenile(k.id);
        const fiyatBilgi = k.fiyat ? ` · ${k.fiyat} TL` : '';
        const islemDurumMetni = duzeltmePenceresiModu ? 'Kayıt yenilendi' : 'Yeni kayıt açıldı, yeni olarak kaydedildi';
        calismaPenceresiniKapat(true);
        durum(`✓ ${k.urun}: ${girilenBedenMetni || `${buIslemAdet || kaydedilenAdet} adet`} kaydedildi · Barkod kaydedildi${fiyatBilgi} · ${islemDurumMetni} · Sıradaki ürüne geçebilirsiniz.`);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      durum('Bilgisayara ulaşılamadı, kaydedilmedi. Tekrar deneyin.', true);
    } finally {
      dugme.disabled = false;
      if ($('kaydet-ve-bas')) $('kaydet-ve-bas').disabled = false;
    }
  }

  async function kayitSilDogrudan(id, urunAdi = 'Ürün') {
    if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelEnvanterdenSil === 'function') {
      window.MezatMobilHibrit.yerelEnvanterdenSil(id, urunAdi);
    }
    try {
      const cevap = await post('/api/envanter/sil', { id, silen: ($('giren') && $('giren').value.trim()) || 'Depo' });
      if (!cevap.success) {
        durum(cevap.error || 'Kayıt silinemedi.', true);
      }
    } catch (_) {}
    if (duzeltilenId === id) formuTemizle();
    const domOge = $('liste') ? $('liste').querySelector(`[data-id="${id}"]`) : null;
    if (domOge) domOge.remove();
    listeSurumu = 0;
    await listeyiYenile(null, false);
    await barkodBankasiniYenile($('banka-arama') ? $('banka-arama').value : '');
    bipSesi();
    durum(`🗑️ "${urunAdi}" kaydı envanterden ve barkod bankasından kalıcı olarak silindi.`);
  }

  async function kayitSil(k) {
    if (!window.confirm(`"${k.urun}" kaydı silinsin mi? Bu işlem barkod bankasından da siler.`)) return;
    await kayitSilDogrudan(k.id, k.urun);
  }

  // Kaydet yalnız dokunarak ya da tıklayarak çalışır
  $('kaydet').addEventListener('click', e => { if (e.detail > 0) kaydet(); });
  if ($('kaydet-ve-bas')) {
    $('kaydet-ve-bas').addEventListener('click', e => {
      if (e.detail > 0) {
        $('kaydet-ve-bas').disabled = true;
        kaydet({ etiketBas: true, etiketKip: 'varyant' });
      }
    });
  }
  if ($('urun')) $('urun').addEventListener('input', () => otomatikBarkodGuncelle(null));
  if ($('barkod')) $('barkod').addEventListener('input', () => otomatikBarkodGuncelle(null));

  async function barkodEtiketBas(istek) {
    const kip = istek.kip || 'varyant';
    const yerelKayit = istek.kayit || (window.MezatMobilHibrit ? window.MezatMobilHibrit.yerelEnvanteriOku().find(x => x.id === istek.id) : null);
    let sunucuBilgi = null;
    try {
      sunucuBilgi = await post('/api/envanter/barkod-etiket-bas', istek);
    } catch (_) {}

    if (window.MezatMobilHibrit && yerelKayit) {
      const bSonuc = await window.MezatMobilHibrit.bluetoothTermalEtiketBas(yerelKayit, kip);
      if (bSonuc && bSonuc.success) {
        bipSesi();
        const kipAciklama = kip === 'tum-adetler'
          ? `HER ÜRÜN İÇİN TEK TEK (${bSonuc.adet} adet etiket)`
          : `SERİ / POŞET ÖZETİ (${bSonuc.adet} çeşit etiketi)`;
        durum(`🖨️ ${yerelKayit.urun} [${yerelKayit.barkod || (sunucuBilgi && sunucuBilgi.anaBarkod) || 'MZU'}]: ${kipAciklama} yazdırılıyor!`);
        return;
      }
    }
    if (sunucuBilgi && sunucuBilgi.success) {
      bipSesi();
      const kipAciklama = kip === 'tum-adetler'
        ? `HER ÜRÜN İÇİN TEK TEK (${sunucuBilgi.eklenenSayisi} adet etiket)`
        : `SERİ / POŞET ÖZETİ (${sunucuBilgi.eklenenSayisi} çeşit etiketi)`;
      durum(`🖨️ ${sunucuBilgi.urun} (${sunucuBilgi.anaBarkod}): ${kipAciklama} termal yazıcıya gönderildi!`);
      return;
    }
    durum((sunucuBilgi && sunucuBilgi.error) || 'Barkod etiketi yazdırılamadı.', true);
  }

  async function canliYayinaAc(barkod) {
    try {
      const cevap = await post('/api/active-product/barkod', { barkod });
      if (!cevap.success) { durum(cevap.error || 'Ürün canlı yayına açılamadı.', true); return; }
      bipSesi();
      durum(cevap.message || `📺 ${barkod} canlı yayına açıldı!`);
    } catch (err) {
      durum('Canlı yayın masasına ulaşılamadı.', true);
    }
  }

  function duzeltmeyeAc(k, zorla = false) {
    const mevcutUrun = $('urun') ? $('urun').value.trim() : '';
    const mevcutSatirVar = satirlariOku().some(s => s.renk || s.beden || (s.adet != null && s.adet > 0));
    if (!zorla && (mevcutUrun || mevcutSatirVar) && duzeltilenId !== k.id) {
      soruSor(
        `Tabloda henüz kaydedilmemiş "${mevcutUrun || 'Yeni Ürün'}" var.`,
        `Silip "${k.urun}" kaydını düzeltmeye açmak istiyor musunuz?`,
        [
          [`✎ Evet, "${k.urun}" Kaydını Aç`, 'evet', () => duzeltmeyeAc(k, true)],
          ['Vazgeç (Mevcut Tabloyu Koru)', '', () => {}]
        ]
      );
      return;
    }
    duzeltilenId = k.id;
    duzeltilenSurum = k.surum || 1;
    soruyuKapat();
    $('duzeltme-notu').classList.remove('gizli');
    $('soz').value = k.soz || '';
    tabloyuDoldur({ irsaliyeModu: false, urun: k.urun, fiyat: k.fiyat, barkod: k.barkod || '', satirlar: k.satirlar, uyarilar: [] });
    if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
    calismaPenceresiniAc('duzelt');
    durum(`✎ "${k.urun}" düzeltme penceresinde açıldı. Değişikliği yapıp ✓ KAYDET tuşuna basın.`);
  }
  document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.tagName === 'INPUT') e.preventDefault(); });

  // ===== Bugün girilenler =====
  // Yayında satılanlar da görünür: "SİYAH 40:2 (1 satıldı)"
  function ozet(k) {
    const satilan = new Map();
    Object.values(k.satislar || {}).forEach(s => satilan.set(`${s.renk}|${s.beden}`, (satilan.get(`${s.renk}|${s.beden}`) || 0) + s.adet));
    const renkler = new Map();
    k.satirlar.forEach(s => {
      const r = s.renk || 'Renksiz';
      const n = satilan.get(`${s.renk}|${s.beden}`) || 0;
      renkler.set(r, [...(renkler.get(r) || []), `${s.beden ? `${s.beden}:${s.adet}` : `${s.adet} adet`}${n ? ` (${n} satıldı)` : ''}`]);
    });
    return [...renkler].map(([r, b]) => `${r} ${b.join(' ')}`).join(' · ');
  }

  let envanterGosterimLimiti = 100;

  function aramaMetniNormalize(metin) {
    return String(metin || '')
      .toLocaleLowerCase('tr-TR')
      .replace(/ı/g, 'i')
      .replace(/ğ/g, 'g')
      .replace(/ü/g, 'u')
      .replace(/ş/g, 's')
      .replace(/ö/g, 'o')
      .replace(/ç/g, 'c')
      .trim();
  }

  function kayitAramayaUyuyorMu(k, sorguNorm) {
    if (!sorguNorm) return true;
    const kelimeler = sorguNorm.split(/\s+/).filter(Boolean);
    if (!kelimeler.length) return true;
    const barkodKodu = k.barkod || otomatikBarkodHesapla(k.urun);
    const satirBilgisi = (k.satirlar || [])
      .map(s => `${s.renk || ''} ${s.beden || ''} ${s.barkod || ''} ${s.adet || ''}`)
      .join(' ');
    const samanlik = aramaMetniNormalize(
      `${k.urun || ''} ${barkodKodu || ''} ${k.fiyat || ''} ${satirBilgisi} ${k.giren || ''} ${k.irsaliyeNo || ''}`
    );
    return kelimeler.every(kelime => samanlik.includes(kelime));
  }

  function kayitListesiniCiz(kayitlar, yeniId, ilk) {
    window.__BUGUNKU_KAYITLAR__ = Array.isArray(kayitlar) ? kayitlar : [];
    const oncekiIdler = new Set([...$('liste').querySelectorAll('[data-id]')].map(e => e.dataset.id));
    const toplam = kayitlar.reduce((t, k) => t + (k.satirlar || []).reduce((a, s) => a + (Number(s.adet) || 0), 0), 0);
    $('sayac').textContent = kayitlar.length ? `(${kayitlar.length} ürün, ${toplam} adet)` : '';

    const hamArama = $('envanter-arama') ? $('envanter-arama').value.trim() : '';
    const sorguNorm = aramaMetniNormalize(hamArama);
    if ($('envanter-ara-temizle-btn')) {
      $('envanter-ara-temizle-btn').classList.toggle('gizli', !hamArama);
    }

    const tersSirali = kayitlar.slice().reverse();
    const eslesenKayitlar = sorguNorm
      ? tersSirali.filter(k => kayitAramayaUyuyorMu(k, sorguNorm))
      : tersSirali;

    if ($('envanter-arama-sonuc-bilgi')) {
      if (hamArama) {
        const eslesenAdet = eslesenKayitlar.reduce((t, k) => t + (k.satirlar || []).reduce((a, s) => a + (Number(s.adet) || 0), 0), 0);
        $('envanter-arama-sonuc-bilgi').classList.remove('gizli');
        $('envanter-arama-sonuc-bilgi').textContent = eslesenKayitlar.length
          ? `🔍 "${hamArama}" araması: ${kayitlar.length} kayıt içinden ${eslesenKayitlar.length} ürün (${eslesenAdet} adet) bulundu.`
          : `⚠️ "${hamArama}" aramasına uygun kayıt bulunamadı (${kayitlar.length} kayıt tarandı).`;
      } else {
        $('envanter-arama-sonuc-bilgi').classList.add('gizli');
        $('envanter-arama-sonuc-bilgi').textContent = '';
      }
    }

    const aktifLimit = sorguNorm ? Math.max(250, envanterGosterimLimiti) : envanterGosterimLimiti;
    const gosterilecekKayitlar = eslesenKayitlar.slice(0, aktifLimit);

    const kartOgeleri = gosterilecekKayitlar.map(k => {
      const duzelt = oge('button', { type: 'button', textContent: '✎ Düzelt' });
      duzelt.onclick = () => duzeltmeyeAc(k);
      const silBtn = oge('button', { type: 'button', textContent: '🗑️ Sil', style: 'border-color:#f87171;color:#fca5a5' });
      silBtn.onclick = () => kayitSil(k);
      const varyantSayisi = Math.max(1, (k.satirlar || []).length);
      const urunToplamAdet = Math.max(1, (k.satirlar || []).reduce((a, s) => a + (Number(s.adet) || 0), 0));
      const varyantBasBtn = oge('button', {
        type: 'button',
        textContent: urunToplamAdet > varyantSayisi
          ? `🖨️ Seri Özeti Bas (${varyantSayisi} Etiket)`
          : `🖨️ Barkod Bas (${varyantSayisi} Etiket)`,
        style: 'border-color:#818cf8;color:#c7d2fe'
      });
      varyantBasBtn.onclick = () => barkodEtiketBas({ id: k.id, kip: 'varyant', kayit: k });
      const tumAdetBasBtn = urunToplamAdet > varyantSayisi
        ? oge('button', {
            type: 'button',
            textContent: `🖨️ Tek Tek Bas (${urunToplamAdet} Etiket)`,
            style: 'border-color:#34d399;color:#6ee7b7'
          })
        : null;
      if (tumAdetBasBtn) tumAdetBasBtn.onclick = () => barkodEtiketBas({ id: k.id, kip: 'tum-adetler', kayit: k });
      const tutanakBtn = k.irsaliyeOnayli
        ? oge('button', { type: 'button', textContent: '📤 Fark Tutanağı', style: 'border-color:#60a5fa;color:#93c5fd' })
        : null;
      if (tutanakBtn) tutanakBtn.onclick = () => farkTutanaginiPaylas(k);
      const saat = new Date(k.duzeltildiMs || k.zamanMs || Date.now()).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
      const yeni = k.id === yeniId || (!ilk && !oncekiIdler.has(k.id));
      const barkodKodu = k.barkod || otomatikBarkodHesapla(k.urun);
      const mobilEtiket = k.cevrimdisiMobil ? '📲 [Mobil Bekleyen] · ' : '';
      const aksiyonSatiri = oge(
        'div',
        { className: 'liste-aksiyon-sag' },
        silBtn,
        duzelt,
        tutanakBtn,
        tumAdetBasBtn,
        varyantBasBtn
      );
      const kutu = oge('div', { className: `liste-oge${yeni ? ' yeni' : ''}` },
        oge('b', { textContent: `${k.urun}${k.fiyat ? ` · ${Number(k.fiyat).toLocaleString('tr-TR')} TL` : ''}` }),
        oge('div', { className: 'kimden', textContent: `${mobilEtiket}🏷️ ${barkodKodu} · ${k.devir ? `📦 Dünden kalan (${k.devir.gun.split('-').reverse().join('.')}) · ` : ''}${k.irsaliyeOnayli ? `📋 İrsaliye & Sayım Onaylı${k.irsaliyeNo ? ` (${k.irsaliyeNo})` : ''} · ` : ''}👤 ${k.giren || '—'}${k.duzelten && k.duzelten !== k.giren ? ` · düzelten ${k.duzelten}` : ''} · ${saat}` }),
        oge('div', { className: 'detay', textContent: ozet(k) }),
        aksiyonSatiri);
      kutu.dataset.id = k.id;
      return kutu;
    });

    if (eslesenKayitlar.length > gosterilecekKayitlar.length) {
      const kalanSayi = eslesenKayitlar.length - gosterilecekKayitlar.length;
      const dahaFazlaBtn = oge('button', {
        type: 'button',
        textContent: `⬇️ Diğer ${kalanSayi} Kaydı Daha Göster (Toplam ${eslesenKayitlar.length})`,
        style: 'width:100%;margin-top:8px;padding:12px;border-radius:12px;background:rgba(30,41,59,0.95);border:1.5px solid #38bdf8;color:#bae6fd;font-weight:900;font-size:0.9rem;cursor:pointer'
      });
      dahaFazlaBtn.onclick = () => {
        envanterGosterimLimiti += 250;
        kayitListesiniCiz(window.__BUGUNKU_KAYITLAR__ || [], null, true);
      };
      kartOgeleri.push(dahaFazlaBtn);
    }

    $('liste').replaceChildren(...kartOgeleri);
    if (!kayitlar.length) {
      $('liste').append(oge('p', { className: 'not', textContent: 'Bugün henüz ürün girilmedi.' }));
    } else if (!eslesenKayitlar.length && hamArama) {
      $('liste').append(oge('p', { className: 'not', textContent: `"${hamArama}" aramasına uygun kayıt bulunamadı.` }));
    }

    // Ana ekrandaki "Bugün Son Girilenler" alt özet kartını da doldur (alttaki alanı verimli değerlendirir)
    const anaSonListe = $('ana-son-liste');
    const anaSonSayac = $('ana-son-sayac');
    if (anaSonSayac) {
      anaSonSayac.textContent = kayitlar.length ? `${kayitlar.length} ürün · ${toplam} adet` : '0 ürün';
    }
    if (anaSonListe) {
      if (!kayitlar.length) {
        anaSonListe.innerHTML = '<div style="font-size:0.9rem;font-weight:800;padding:6px 4px;">Henüz ürün girilmedi. Mikrofona basıp ilk ürünü söyleyin.</div>';
      } else {
        anaSonListe.replaceChildren(...kayitlar.slice(-8).reverse().map(k => {
          const kalemToplam = (k.satirlar || []).reduce((a, s) => a + (Number(s.adet) || 0), 0);
          const fiyatYazi = k.fiyat ? ` · ${Number(k.fiyat).toLocaleString('tr-TR')} TL` : '';
          const duzBtn = oge('button', {
            type: 'button',
            className: 'ana-son-duzelt-btn',
            textContent: '✎ Düzelt',
            title: 'Bu ürünü düzenlemek için aç'
          });
          duzBtn.onclick = e => {
            e.stopPropagation();
            duzeltmeyeAc(k);
          };
          const satirOge = oge('div', {
            className: 'ana-son-satir'
          },
            oge('div', { className: 'ana-son-metin-kutu' },
              oge('div', { className: 'ana-son-urun-ad', textContent: `${k.urun}${fiyatYazi}` }),
              oge('div', { className: 'ana-son-urun-detay', textContent: `Toplam ${kalemToplam} Adet · ${ozet(k)}` })
            ),
            duzBtn
          );
          return satirOge;
        }));
      }
    }
  }

  function envanterAramasiniCalistir(klavyeKapat = false) {
    envanterGosterimLimiti = 100;
    kayitListesiniCiz(window.__BUGUNKU_KAYITLAR__ || [], null, true);
    if (klavyeKapat && $('envanter-arama')) {
      $('envanter-arama').blur();
      const aranan = $('envanter-arama').value.trim();
      if (aranan) {
        bipSesi();
        durum(`🔍 Envanter & Excel listesinde "${aranan}" arandı.`);
      }
    }
  }

  if ($('envanter-arama')) {
    $('envanter-arama').addEventListener('input', () => envanterAramasiniCalistir(false));
    $('envanter-arama').addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        envanterAramasiniCalistir(true);
      }
    });
  }
  if ($('envanter-ara-btn')) {
    $('envanter-ara-btn').addEventListener('click', () => envanterAramasiniCalistir(true));
  }
  if ($('envanter-ara-temizle-btn')) {
    $('envanter-ara-temizle-btn').addEventListener('click', () => {
      if ($('envanter-arama')) $('envanter-arama').value = '';
      envanterAramasiniCalistir(false);
      durum('✓ Envanter arama filtresi temizlendi, tüm kayıtlar gösteriliyor.');
    });
  }

  // Liste yalnızca açılışta, kayıt işleminde veya kullanıcı yenilediğinde sorulur (arka planda sürekli bilgisayarı arama sinyali göndermez).
  async function listeyiYenile(yeniId, sadeceDegistiyse = false) {
    try {
      const veri = await fetch(`/api/envanter${sadeceDegistiyse && listeSurumu ? `?surum=${listeSurumu}` : ''}`, {
        signal: AbortSignal.timeout(2500)
      }).then(r => r.json());
      pcBagli = true;
      $('baglanti').textContent = '🟢 Bağlı';
      if (veri.degismedi) return;
      const ilk = !listeSurumu;
      listeSurumu = veri.surum;
      if ($('excel')) $('excel').href = `/api/envanter/excel?gun=${encodeURIComponent(veri.gun)}`;
      kayitListesiniCiz(veri.kayitlar || [], yeniId, ilk);
    } catch (err) {
      pcBagli = false;
      const bekleyenSayi = window.MezatMobilHibrit ? window.MezatMobilHibrit.bekleyenKuyruguOku().length : 0;
      $('baglanti').textContent = bekleyenSayi > 0
        ? `📲 Mobil (${bekleyenSayi})`
        : '📲 Mobil';
      if (window.MezatMobilHibrit && !sadeceDegistiyse) {
        const yerelKayitlar = window.MezatMobilHibrit.yerelEnvanteriOku();
        kayitListesiniCiz(yerelKayitlar, yeniId, false);
      }
    }
  }

  // ===== 🏦 Kalıcı Ürün Barkod Veri Bankası =====
  let bankaGosterimLimiti = 60;

  function yerelBarkodBankasiVerisiOlustur(arama = '') {
    const kaynakKayitlar = (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelEnvanteriOku === 'function')
      ? window.MezatMobilHibrit.yerelEnvanteriOku()
      : (window.__BUGUNKU_KAYITLAR__ || []);
    const sorguNorm = aramaMetniNormalize(arama);
    const kelimeler = sorguNorm.split(/\s+/).filter(Boolean);
    const urunHaritasi = new Map();
    const inenBanka = (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.barkodBankasiOku === 'function') ? window.MezatMobilHibrit.barkodBankasiOku().urunler : [];
    inenBanka.forEach(u => urunHaritasi.set(u.urun, { ...u, bugunStokta: false, bugunToplamAdet: 0, varyantlar: u.varyantlar || [] }));
    kaynakKayitlar.forEach(k => {
      if (!k || !k.urun) return;
      const anaBarkod = k.barkod || otomatikBarkodHesapla(k.urun);
      const varyantlar = (k.satirlar || []).map(s => ({
        renk: s.renk || '',
        beden: s.beden || '',
        sonAdet: s.adet || 1,
        barkod: s.barkod || anaBarkod
      }));
      const bankadaki = urunHaritasi.get(k.urun);
      if (bankadaki) (bankadaki.varyantlar || []).forEach(v => { if (!varyantlar.some(x => x.barkod === v.barkod)) varyantlar.push(v); });
      urunHaritasi.set(k.urun, {
        urun: k.urun,
        fiyat: k.fiyat,
        anaBarkod,
        bugunStokta: true,
        bugunToplamAdet: (k.satirlar || []).reduce((t, s) => t + (Number(s.adet) || 0), 0),
        varyantlar
      });
    });
    const tumUrunler = [...urunHaritasi.values()];
    const filtreli = kelimeler.length
      ? tumUrunler.filter(u => {
          const varyantMetin = (u.varyantlar || []).map(v => `${v.renk} ${v.beden} ${v.barkod}`).join(' ');
          const samanlik = aramaMetniNormalize(`${u.urun} ${u.anaBarkod} ${u.fiyat || ''} ${varyantMetin}`);
          return kelimeler.every(kelime => samanlik.includes(kelime));
        })
      : tumUrunler;
    return {
      success: true,
      toplamUrun: tumUrunler.length,
      toplamBarkod: tumUrunler.reduce((t, u) => t + Math.max(1, (u.varyantlar || []).length), 0),
      urunler: filtreli
    };
  }

  async function barkodBankasiniYenile(arama = '', manuelTiklama = false) {
    const kutu = $('banka-liste');
    const yenileBtn = $('banka-yenile');
    if (!kutu) return;
    const temizArama = String(arama || '').trim();
    if ($('banka-ara-temizle-btn')) {
      $('banka-ara-temizle-btn').classList.toggle('gizli', !temizArama);
    }
    if (manuelTiklama && yenileBtn) {
      yenileBtn.disabled = true;
      yenileBtn.textContent = '⏳ Yenileniyor…';
    }
    let veri = null;
    try {
      const sorgu = encodeURIComponent(temizArama);
      const r = await fetch(`/api/envanter/barkod-bankasi?q=${sorgu}&_t=${Date.now()}`, { cache: 'no-store' });
      veri = await r.json();
      if (!temizArama && manuelTiklama && location.protocol !== 'file:' && telefonMotoruVarMi() && window.MezatMobilHibrit) {
        const alinan = window.MezatMobilHibrit.barkodBankasiniSakla(veri);
        if (alinan && alinan.toplamBarkod) durum(`📲 Telefonda ${alinan.toplamBarkod} barkod hazır, bilgisayar kapalıyken de kullanılır.`);
      }
    } catch (err) {
      veri = yerelBarkodBankasiVerisiOlustur(temizArama);
    }
    try {
      if (!veri || !veri.success) {
        veri = yerelBarkodBankasiVerisiOlustur(temizArama);
      }
      if ($('banka-sayac')) {
        $('banka-sayac').textContent = veri.toplamUrun ? `(${veri.toplamUrun} ürün · ${veri.toplamBarkod} barkod)` : '(Henüz kayıt yok)';
      }
      const urunListesi = Array.isArray(veri.urunler) ? veri.urunler : [];
      if ($('banka-arama-sonuc-bilgi')) {
        if (temizArama) {
          $('banka-arama-sonuc-bilgi').classList.remove('gizli');
          $('banka-arama-sonuc-bilgi').textContent = urunListesi.length
            ? `🔍 "${temizArama}" araması: Barkod bankasında ${urunListesi.length} eşleşen ürün bulundu.`
            : `⚠️ "${temizArama}" aramasına uygun barkodlu ürün bulunamadı (${veri.toplamUrun || 0} ürün tarandı).`;
        } else {
          $('banka-arama-sonuc-bilgi').classList.add('gizli');
          $('banka-arama-sonuc-bilgi').textContent = '';
        }
      }
      if (!urunListesi.length) {
        kutu.replaceChildren(oge('p', { className: 'not', textContent: temizArama ? `"${temizArama}" aramasına uygun barkodlu ürün bulunamadı.` : 'Henüz veri bankasında kayıtlı ürün yok. İlk ürünü kaydettiğinizde otomatik barkoduyla burada oluşur.' }));
      } else {
        const aktifLimit = temizArama ? Math.max(120, bankaGosterimLimiti) : bankaGosterimLimiti;
        const gosterilecekUrunler = urunListesi.slice(0, aktifLimit);
        const bankaOgeleri = gosterilecekUrunler.map(u => {
          const varyantCipListesi = (u.varyantlar || []).map(v => {
            const cip = oge('span', {
              className: 'banka-varyant-cip',
              title: `Varyant Barkodu: ${v.barkod} — Tıklayınca tabloya +1 ekler`,
              style: 'cursor:pointer',
              textContent: `${[v.renk, v.beden].filter(Boolean).join(' ') || 'Standart'} (${v.barkod})`
            });
            cip.onclick = () => {
              bipSesi();
              satiraEkleVeyaArtir({
                urun: u.urun,
                fiyat: u.fiyat,
                barkod: v.barkod,
                renk: v.renk,
                beden: v.beden,
                adet: 1
              });
              durum(`✓ Veri bankasından eklendi: ${u.urun} ${[v.renk, v.beden].filter(Boolean).join(' ')} (+1 adet).`);
              if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
            };
            return cip;
          });

          const stogaAktarBtn = oge('button', { type: 'button', textContent: '➕ Tabloya Aktar', style: 'padding:8px 12px;font-size:0.86rem;font-weight:900;border-color:#10b981;color:#6ee7b7' });
          stogaAktarBtn.onclick = () => {
            bipSesi();
            tabloyuDoldur({
              irsaliyeModu: false,
              urun: u.urun,
              fiyat: u.fiyat || '',
              barkod: u.anaBarkod,
              veriBankasindaKayitli: true,
              satirlar: (u.varyantlar && u.varyantlar.length)
                ? u.varyantlar.map(v => ({ renk: v.renk || '', beden: v.beden || '', adet: v.sonAdet || 1, barkod: v.barkod }))
                : [{ renk: '', beden: '', adet: 1, barkod: u.anaBarkod }],
              uyarilar: []
            });
            if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
            calismaPenceresiniAc('giris');
            durum(`🏦 ${u.urun} tabloya aktarıldı. Kaydet tuşuna basın.`);
          };

          const barkodBasBtn = oge('button', { type: 'button', textContent: '🖨️ Barkod Bas', style: 'padding:8px 12px;font-size:0.86rem;font-weight:900;border-color:#818cf8;color:#c7d2fe' });
          barkodBasBtn.onclick = () => barkodEtiketBas({ barkod: u.anaBarkod, kip: 'varyant' });

          return oge('div', { className: 'banka-oge' },
            oge('div', { style: 'display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap' },
              oge('b', { textContent: `${u.urun}${u.fiyat ? ` · ${Number(u.fiyat).toLocaleString('tr-TR')} TL` : ''}` }),
              oge('code', { textContent: `🏷️ ${u.anaBarkod}` })
            ),
            oge('div', { className: 'not', style: 'margin-top:3px', textContent: `${u.bugunStokta ? `🟢 Bugün stokta (${u.bugunToplamAdet} adet)` : '⚪ Bugün henüz girilmedi'} · ${(u.varyantlar || []).length} varyant barkodu` }),
            varyantCipListesi.length ? oge('div', { className: 'banka-varyantlar' }, ...varyantCipListesi) : null,
            oge('div', { className: 'banka-aksiyon-sag' }, stogaAktarBtn, barkodBasBtn)
          );
        });

        if (urunListesi.length > gosterilecekUrunler.length) {
          const kalanSayi = urunListesi.length - gosterilecekUrunler.length;
          const dahaFazlaBtn = oge('button', {
            type: 'button',
            textContent: `⬇️ Diğer ${kalanSayi} Ürünü Daha Göster (Toplam ${urunListesi.length})`,
            style: 'width:100%;margin-top:8px;padding:12px;border-radius:12px;background:rgba(30,41,59,0.95);border:1.5px solid #38bdf8;color:#bae6fd;font-weight:900;font-size:0.9rem;cursor:pointer'
          });
          dahaFazlaBtn.onclick = () => {
            bankaGosterimLimiti += 120;
            barkodBankasiniYenile($('banka-arama') ? $('banka-arama').value : '', false);
          };
          bankaOgeleri.push(dahaFazlaBtn);
        }

        kutu.replaceChildren(...bankaOgeleri);
      }
      if (manuelTiklama) {
        bipSesi();
        await listeyiYenile(null, false);
        durum(veri.toplamUrun
          ? `🏦 Barkod veri bankası yenilendi (${veri.toplamUrun} ürün · ${veri.toplamBarkod} barkod).`
          : '🏦 Barkod veri bankası yenilendi (Henüz kayıtlı barkod yok — ilk ürün kaydında otomatik oluşur).');
        if (yenileBtn) {
          yenileBtn.textContent = '✓ Yenilendi';
          setTimeout(() => {
            yenileBtn.disabled = false;
            yenileBtn.textContent = '↻ Yenile';
          }, 1200);
        }
      }
    } finally {
      if (yenileBtn && yenileBtn.textContent !== '✓ Yenilendi') {
        yenileBtn.disabled = false;
        yenileBtn.textContent = '↻ Yenile';
      }
    }
  }

  if ($('banka-arama')) {
    $('banka-arama').addEventListener('input', () => {
      bankaGosterimLimiti = 60;
      barkodBankasiniYenile($('banka-arama').value, false);
    });
    $('banka-arama').addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        $('banka-arama').blur();
        bankaGosterimLimiti = 60;
        barkodBankasiniYenile($('banka-arama').value, false);
      }
    });
  }
  if ($('banka-ara-btn')) {
    $('banka-ara-btn').addEventListener('click', () => {
      const aranan = $('banka-arama') ? $('banka-arama').value.trim() : '';
      if ($('banka-arama')) $('banka-arama').blur();
      bankaGosterimLimiti = 60;
      barkodBankasiniYenile(aranan, false);
      if (aranan) {
        bipSesi();
        durum(`🔍 Kalıcı barkod bankasında "${aranan}" arandı.`);
      }
    });
  }
  if ($('banka-ara-temizle-btn')) {
    $('banka-ara-temizle-btn').addEventListener('click', () => {
      if ($('banka-arama')) $('banka-arama').value = '';
      bankaGosterimLimiti = 60;
      barkodBankasiniYenile('', false);
      durum('✓ Barkod bankası arama filtresi temizlendi, tüm kayıtlar gösteriliyor.');
    });
  }
  if ($('banka-yenile')) {
    $('banka-yenile').addEventListener('click', () => barkodBankasiniYenile($('banka-arama') ? $('banka-arama').value : '', true));
  }
  if ($('bugun-liste-yenile-btn')) {
    $('bugun-liste-yenile-btn').addEventListener('click', async () => {
      listeSurumu = 0;
      await listeyiYenile(null, false);
      await barkodBankasiniYenile($('banka-arama') ? $('banka-arama').value : '', true);
      durum('↻ Envanter listesi ve barkod bankası yenilendi.');
    });
  }

  async function motorDurumu() {
    try {
      const m = await fetch('/api/envanter/motor').then(r => r.json());
      if (!m.hazir || m.kip === 'tiklama') {
        durum('Ses motoru şu an açık değil. Ürünü yazarak girebilirsiniz.', true);
      } else {
        $('baglanti').textContent = '🟢 Bağlı';
      }
    } catch (err) {}
  }

  // ===== 🔗 Mezatron Canlı Entegrasyon Köprüsü =====
  async function kopruDurumuGuncelle() {
    const kutu = $('kopru-hedefler');
    if (!kutu) return;
    try {
      const veri = await fetch('/api/mezatron-koprusu/durum').then(r => r.json());
      if (!veri || !veri.success) return;
      const satirlar = (veri.hedefler || []).map(h =>
        `${h.acik ? '🟢 Bağlı' : '⚪ Kapalı'} — ${h.url}${h.surumBilgisi && h.surumBilgisi.surum ? ` (${h.surumBilgisi.surum})` : ''}`
      );
      kutu.textContent = satirlar.join('  |  ') || 'Hedef tanımlı değil.';
    } catch (err) {
      kutu.textContent = 'Köprü durumu alınamadı.';
    }
  }

  // Tek seferde yalnız bir alt panel açık kalsın (üst üste binen / çift panel önleyici + Geri/Esc tuşu desteği)
  const ALT_PANELLER = ['ust-araclar-cekmece', 'bt-mobil-panel', 'mobil-baglanti-panel', 'mezatron-kopru-panel', 'doktor-panel', 'irsaliye-panel', 'etiket-panel', 'barkod-panel'];
  function digerAltPanelleriKapat(haricId = '') {
    ALT_PANELLER.forEach(id => {
      if (id === haricId) return;
      const el = $(id);
      if (el && !el.classList.contains('gizli')) {
        el.classList.add('gizli');
        if (id === 'barkod-panel') barkodKamerayiKapat();
        if (id === 'etiket-panel') etiketCanliKamerayiKapat();
        if (id === 'irsaliye-panel') irsaliyeCanliKamerayiKapat();
        if (id === 'ust-araclar-cekmece' && $('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
        if (id === 'mobil-baglanti-panel' && $('mobil-ac-btn')) $('mobil-ac-btn').classList.remove('aktif');
        if (id === 'mezatron-kopru-panel' && $('kopru-ac-btn')) $('kopru-ac-btn').classList.remove('aktif');
    if ( id === 'doktor-panel' && $('doktor-ac-btn')) $('doktor-ac-btn').classList.remove('aktif');
      }
    });
  }

  function acikAltPanelVeyaSoruyuKapat() {
    if ($('soru') && !$('soru').classList.contains('gizli')) {
      soruyuKapat();
      return true;
    }
    for (const id of ALT_PANELLER) {
      const el = $(id);
      if (el && !el.classList.contains('gizli')) {
        el.classList.add('gizli');
        if (id === 'barkod-panel') barkodKamerayiKapat();
        if (id === 'etiket-panel') etiketCanliKamerayiKapat();
        if (id === 'irsaliye-panel') irsaliyeCanliKamerayiKapat();
        if (id === 'ust-araclar-cekmece' && $('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
        if (id === 'mobil-baglanti-panel' && $('mobil-ac-btn')) $('mobil-ac-btn').classList.remove('aktif');
        if (id === 'mezatron-kopru-panel' && $('mezatron-kopru-panel')) $('kopru-ac-btn').classList.remove('aktif');
        if (id === 'doktor-panel' && $('doktor-ac-btn')) $('doktor-ac-btn').classList.remove('aktif');
        if (id === 'etiket-panel' || id === 'barkod-panel' || id === 'irsaliye-panel') {
          durum('');
          if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
        }
        return true;
      }
    }
    return false;
  }

  async function mobilBaglantiDurumuGuncelle() {
    const kutu = $('mobil-baglanti-icerik');
    if (!kutu) return;
    try {
      const v = await fetch('/api/mobil-baglanti', { cache: 'no-store' }).then(r => r.json());
      if (!v || !v.success) return;
      const anaUrl = v.httpsAktif ? v.httpsUrl : v.httpUrl;
      const apkDirectUrl = `${v.httpUrl}/Mezatron-Envanter.apk?v=3.4.9`;
      const okutUrl = v.httpsAktif ? v.okutHttpsUrl : v.okutHttpUrl;
      // v113: QR kodları internetsiz, yerelde (qrcode.min.js) üretilir
      const yerelQr = (metin) => {
        try {
          if (typeof window.qrcode !== 'function') return '';
          const q = window.qrcode(0, 'M');
          q.addData(String(metin));
          q.make();
          return q.createDataURL(8, 4);
        } catch (_) { return ''; }
      };
      const qrKutu = (metin, renk) => {
        const src = yerelQr(metin);
        return src
          ? `<img src="${src}" alt="QR" class="mb-qr" style="border-color:${renk}">`
          : `<div class="mb-qr mb-qr-yok" style="border-color:${renk}">QR oluşturulamadı</div>`;
      };
      kutu.innerHTML = `
        <div class="mb-kart" style="border-color:#10b981">
          <div class="mb-baslik" style="color:#6ee7b7">📲 1. APK İNDİR (Uygulama Kur)</div>
          ${qrKutu(apkDirectUrl, '#10b981')}
          <div class="mb-aciklama">Diğer telefonun kamerasını bu QR koda tutun. <b>Mezatron uygulaması</b> indirilir; kurunca o telefon da bu bilgisayara bağlı çalışır.</div>
          <a class="mb-dugme mb-dugme-yesil" href="${apkDirectUrl}" download="Mezatron-Envanter.apk">⬇️ Yeni Telefona Kurulum Dosyasını (APK) İndir</a>
          <div class="mb-adres">${apkDirectUrl}</div>
        </div>
        <div class="mb-kart" style="border-color:#38bdf8">
          <div class="mb-baslik" style="color:#7dd3fc">🌐 2. TARAYICIDAN BAĞLAN (Kurulumsuz)</div>
          ${qrKutu(anaUrl, '#38bdf8')}
          <div class="mb-aciklama">Uygulama kurmadan, telefonun tarayıcısında <b>bu programı açar</b>. Kayıtlar aynı bilgisayara gider.</div>
          ${v.httpsAktif ? `<div class="mb-not">İlk girişte “Gelişmiş → ${v.yerelIp} sitesine ilerle” deyin (mikrofon ve kamera için).</div>` : ''}
          <a class="mb-dugme mb-dugme-mavi" href="${anaUrl}" target="_blank">🔗 Tarayıcıda Aç</a>
          <details class="mb-detay">
            <summary>📋 Diğer Adresler ▾</summary>
            <a class="mb-adres-link" href="${v.httpsUrl}" target="_blank"><b>🔒 HTTPS</b> · mikrofon + kamera<span>${v.httpsUrl}</span></a>
            <a class="mb-adres-link" href="${v.httpUrl}" target="_blank"><b>🌐 HTTP</b> · fotoğraf + tablo<span>${v.httpUrl}</span></a>
            <a class="mb-adres-link" href="${okutUrl}" target="_blank"><b>📦 Barkod Okutma İstasyonu</b><span>${okutUrl}</span></a>
          </details>
        </div>
      `;
    } catch (err) {
      kutu.textContent = 'Mobil bağlantı bilgisi alınamadı.';
    }
  }

  // ===== v118: 👥 LİSANS SAHİBİ – KULLANICI ONAY & YÖNETİM PENCERESİ =====
  function lisansSahibiMi() {
    if (/^(localhost|127\.0\.0\.1|\[::1\])$/i.test(location.hostname || '')) return true;
    return localStorage.getItem('mezat_rol') === 'sahip';
  }
  async function bekleyenSayisiniGuncelle() {
    const rozet = $('kullanici-bekleyen-rozet');
    if (!rozet || !lisansSahibiMi()) return;
    try {
      const j = await fetch('/api/kullanici/liste', { cache: 'no-store' }).then(r => r.json());
      const n = (j.kullanicilar || []).filter(k => !k.onayli).length;
      rozet.textContent = n ? String(n) : '';
      rozet.style.display = n ? 'inline-block' : 'none';
    } catch (_) {}
  }
  window.mezatKullaniciYonetimTusunuGuncelle = function () {
    const b = $('kullanici-yonetim-btn');
    if (b) b.classList.toggle('gizli', !lisansSahibiMi());
    bekleyenSayisiniGuncelle();
  };
  window.mezatKullaniciYonetimTusunuGuncelle();
  setInterval(bekleyenSayisiniGuncelle, 30000);

  async function kullaniciYonetimiAc() {
    if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
    if ($('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
    let m = document.getElementById('mezat-kullanici-modal');
    if (m) m.remove();
    m = document.createElement('div');
    m.id = 'mezat-kullanici-modal';
    m.style.cssText = 'position:fixed;inset:0;z-index:99998;background:rgba(2,6,23,.92);display:flex;align-items:center;justify-content:center;padding:10px';
    m.innerHTML = `
      <div style="width:100%;max-width:560px;max-height:92vh;display:flex;flex-direction:column;background:#0f172a;border:2px solid #a78bfa;border-radius:16px;color:#f8fafc;overflow:hidden">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:12px 14px;background:#1e1b4b;border-bottom:2px solid #4c1d95">
          <div><div style="font-size:1.1rem;font-weight:900">👥 Kullanıcılar & Onaylar</div>
          <div style="font-size:.82rem;color:#c4b5fd;font-weight:700">Yalnız lisans sahibi görebilir</div></div>
          <button type="button" id="mku-kapat" style="padding:9px 14px;border-radius:10px;border:2px solid #fca5a5;background:#dc2626;color:#fff;font-weight:900">✕ Kapat</button>
        </div>
        <div id="mku-liste" style="padding:12px;overflow-y:auto;display:flex;flex-direction:column;gap:10px">⏳ Yükleniyor…</div>
      </div>`;
    document.body.appendChild(m);
    $('mku-kapat').onclick = () => m.remove();
    m.addEventListener('click', e => { if (e.target === m) m.remove(); });

    const islem = async (yol, ad, onayMetni) => {
      if (onayMetni && !confirm(onayMetni)) return;
      const r = await fetch(yol, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ad }) });
      const j = await r.json().catch(() => ({}));
      if (!j.success) alert(j.error || 'İşlem yapılamadı.');
      ciz();
    };
    const tus = (renk, metin) => `style="flex:1;min-height:46px;border-radius:10px;border:0;background:${renk};color:#fff;font-weight:900;font-size:.92rem">${metin}`;
    async function ciz() {
      const kutu = $('mku-liste');
      let j;
      try { j = await fetch('/api/kullanici/liste', { cache: 'no-store' }).then(r => r.json()); } catch (_) { kutu.textContent = 'Bilgisayara ulaşılamadı.'; return; }
      if (!j.success) { kutu.textContent = j.error || 'Liste alınamadı.'; return; }
      const liste = (j.kullanicilar || []).sort((a, b) => (a.onayli - b.onayli) || a.ad.localeCompare(b.ad, 'tr'));
      if (!liste.length) { kutu.innerHTML = '<div style="padding:16px;text-align:center;color:#cbd5e1">Henüz kayıtlı kullanıcı yok.</div>'; return; }
      kutu.innerHTML = '';
      if (j.lisans) {
        const dolu = j.lisans.onayliSayisi >= j.lisans.kullaniciLimiti;
        const lb = document.createElement('div');
        lb.style.cssText = 'border-radius:12px;padding:12px;font-weight:800;font-size:.95rem;text-align:center;border:2px solid ' + (dolu ? '#f87171;background:#450a0a;color:#fecaca' : '#86efac;background:#052e16;color:#bbf7d0');
        const musteriEtiket = j.lisans.musteri ? ` · <span style="font-weight:900;color:#fde047">${j.lisans.musteri}</span>` : '';
        lb.innerHTML = `
          <div style="font-size:1.05rem;font-weight:900">🎫 Lisans: ${j.lisans.onayliSayisi} / ${j.lisans.kullaniciLimiti} Kullanıcı${musteriEtiket}</div>
          ${dolu ? '<div style="font-size:.85rem;font-weight:700;margin-top:4px;color:#fca5a5">Kapasite dolu! Ek kullanıcı için lisans satın alıp lisans kodunu girin.</div>' : ''}
          <div style="margin-top:8px;display:flex;gap:6px">
            <input id="mku-lisans-input" placeholder="MZL-... Lisans Kodunu Yapıştırın" style="flex:1;padding:8px 10px;border-radius:8px;border:1.5px solid #64748b;background:#020617;color:#fff;font-size:.84rem">
            <button type="button" id="mku-lisans-yukle-btn" style="padding:8px 12px;border-radius:8px;border:0;background:#0284c7;color:#fff;font-weight:900;font-size:.84rem;cursor:pointer">Yükle</button>
          </div>
        `;
        kutu.appendChild(lb);
        setTimeout(() => {
          const lBtn = $('mku-lisans-yukle-btn');
          const lInp = $('mku-lisans-input');
          if (lBtn && lInp) {
            lBtn.onclick = async () => {
              const kod = (lInp.value || '').trim();
              if (!kod) { alert('Lütfen lisans kodunu yapıştırın.'); return; }
              const r = await fetch('/api/kullanici/lisans-yukle', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ lisansKodu: kod })
              });
              const res = await r.json().catch(() => ({}));
              if (!res.success) {
                alert('❌ ' + (res.error || 'Lisans doğrulanamadı.'));
              } else {
                alert('✅ Lisans aktifleştirildi! Yeni kullanıcı limiti: ' + res.lisans.kullaniciLimiti);
                ciz();
              }
            };
          }
        }, 0);
      }
      liste.forEach(k => {
        const kart = document.createElement('div');
        kart.style.cssText = `border:2px solid ${k.onayli ? '#334155' : '#facc15'};border-radius:14px;padding:12px;background:${k.onayli ? '#111827' : '#422006'}`;
        const durumYazi = k.rol === 'sahip' ? '👑 Lisans Sahibi' : (k.onayli ? '✅ Onaylı' : '⏳ Onay Bekliyor');
        const tarih = t => t ? new Date(t).toLocaleString('tr-TR') : '—';
        kart.innerHTML = `
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;margin-bottom:6px">
            <b style="font-size:1.08rem">${k.ad.replace(/</g, '&lt;')}</b>
            <span style="font-weight:900;font-size:.86rem;color:${k.onayli ? '#86efac' : '#fde047'}">${durumYazi}</span>
          </div>
          <div style="font-size:.82rem;color:#cbd5e1;margin-bottom:10px">Kayıt: ${tarih(k.olusturma)} · Son giriş: ${tarih(k.sonGiris)}</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap" class="mku-tuslar"></div>`;
        const tuslar = kart.querySelector('.mku-tuslar');
        const ekle = (html, fn) => { tuslar.insertAdjacentHTML('beforeend', `<button type="button" ${html}</button>`); tuslar.lastElementChild.onclick = fn; };
        if (!k.onayli) ekle(tus('#16a34a', '✓ Onayla'), () => islem('/api/kullanici/onayla', k.ad));
        ekle(tus('#0369a1', '🔑 Şifre Sıfırla'), () => islem('/api/kullanici/sifre-sifirla', k.ad, `${k.ad} kişisinin şifresi sıfırlansın mı? Bir sonraki girişte yeni şifresini kendisi belirleyecek.`));
        if (k.rol !== 'sahip') ekle(tus('#b91c1c', k.onayli ? '⛔ Erişimi Kaldır' : '✕ Reddet'), () => islem('/api/kullanici/reddet', k.ad, `${k.ad} kişisinin hesabı silinsin mi? (Yaptığı kayıtlar silinmez.)`));
        kutu.appendChild(kart);
      });
      bekleyenSayisiniGuncelle();
    }
    ciz();
  }
  if ($('kullanici-yonetim-btn')) $('kullanici-yonetim-btn').addEventListener('click', kullaniciYonetimiAc);

  if ($('mobil-ac-btn')) {
    $('mobil-ac-btn').addEventListener('click', () => {
      const p = $('mobil-baglanti-panel');
      if (!p) return;
      const acik = !p.classList.contains('gizli');
      if (!acik) digerAltPanelleriKapat('mobil-baglanti-panel');
      const gizli = p.classList.toggle('gizli');
      $('mobil-ac-btn').classList.toggle('aktif', !gizli);
      if (!gizli) mobilBaglantiDurumuGuncelle();
    });
  }
  if ($('mobil-kapat-btn')) {
    $('mobil-kapat-btn').addEventListener('click', () => {
      $('mobil-baglanti-panel').classList.add('gizli');
      if ($('mobil-ac-btn')) $('mobil-ac-btn').classList.remove('aktif');
    });
  }

  // ===== ⏻ TAM AÇILIŞ ANİMASYONU, TAM KAPANIŞ VE GERİ TUŞU YÖNETİCİSİ =====
  let programKapaliModda = false;
  let kapanisSayaciCalisiyor = false;
  let sonKapanisBitisMs = 0;
  let kapanisGeriGecisi = false;
  let acilisAnimasyonCalisiyor = false;

  function sistemGecisSesi(acilisMi = true) {
    // Mobil cihazlarda Bluetooth kulaklık takılıyken açılış/kapanışta AudioContext açılması
    // Android'in "Mobil cihazınızda bir aramadasınız" (Call Casting) uyarısını tetiklememesi için mobilde devre dışı bırakılır.
    if (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent || '')) return;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      const simdi = ctx.currentTime;
      const notalar = acilisMi ? [523.25, 659.25, 783.99] : [659.25, 440.0];
      notalar.forEach((frekans, i) => {
        const osc = ctx.createOscillator();
        const kazanc = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(frekans, simdi + i * 0.09);
        kazanc.gain.setValueAtTime(0.001, simdi + i * 0.09);
        kazanc.gain.exponentialRampToValueAtTime(0.18, simdi + i * 0.09 + 0.02);
        kazanc.gain.exponentialRampToValueAtTime(0.001, simdi + i * 0.09 + 0.14);
        osc.connect(kazanc);
        kazanc.connect(ctx.destination);
        osc.start(simdi + i * 0.09);
        osc.stop(simdi + i * 0.09 + 0.15);
      });
      setTimeout(() => { try { ctx.close(); } catch (_) {} }, 550);
    } catch (_) {}
  }

  let acilisKapanisSayacTimer = null;

  function acilisKapanisSayacTemizle() {
    if (acilisKapanisSayacTimer) {
      clearInterval(acilisKapanisSayacTimer);
      acilisKapanisSayacTimer = null;
    }
  }

  function acilisEkraniniSifirlaHazirla(baslangicMetni = '🚀 Sistem ve ses motoru başlatılıyor… (6 sn)') {
    acilisKapanisSayacTemizle();
    const eskiKilit = document.getElementById('mezat-guvenli-kapanis-ekrani');
    if (eskiKilit) eskiKilit.remove();
    const ekran = $('mezat-acilis-ekrani');
    if (!ekran) return null;
    ekran.style.display = 'flex';
    ekran.style.background = '';
    ekran.classList.remove('acilis-bitti', 'ekran-kapali-siyah');
    const dalga = $('mezat-acilis-dalga');
    if (dalga) dalga.style.display = 'flex';
    const barKutu = $('mezat-acilis-bar-kutu');
    if (barKutu) barKutu.style.display = 'block';
    const cubuk = $('mezat-acilis-cubuk');
    if (cubuk) {
      cubuk.style.background = 'linear-gradient(90deg, #38bdf8, #e879f9, #ffe08a, #10b981)';
      cubuk.style.width = '10%';
    }
    const durumEl = $('mezat-acilis-durum');
    if (durumEl) durumEl.innerHTML = baslangicMetni;
    return ekran;
  }

  window.programAcilisAnimasyonuBaslat = function (baslangicMetni = '🚀 Envanter ve ses motoru başlatılıyor…', sesCal = false) {
    if (acilisAnimasyonCalisiyor || kapanisSayaciCalisiyor) return;
    acilisAnimasyonCalisiyor = true;
    programKapaliModda = false;

    const ekran = acilisEkraniniSifirlaHazirla(baslangicMetni);
    if (sesCal) sistemGecisSesi(true);

    try {
      digerAltPanelleriKapat('');
      if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
      window.scrollTo({ top: 0, behavior: 'instant' });
    } catch (_) {}

    try { listeyiYenile(); } catch (_) {}
    try { motorDurumu(); } catch (_) {}

    const cubuk = $('mezat-acilis-cubuk');
    const durumEl = $('mezat-acilis-durum');
    const TOPLAM_SANIYE = 2;
    let kalan = TOPLAM_SANIYE;

    const acilisAsamalari = {
      6: '🚀 Envanter ve ses motoru başlatılıyor…',
      5: '🛡️ Güvenlik zırhı ve yerel yedekler doğrulanıyor…',
      4: '🎙️ Türkçe ses ve etiket OCR motoru hazırlanıyor…',
      3: '📚 Marka ve renk telaffuz sözlükleri yükleniyor…',
      2: '🖨️ Barkod ve termal yazıcı modülleri kontrol ediliyor…',
      1: '✅ Sistem hazır! Envanter ekranı açılıyor…'
    };

    acilisKapanisSayacTimer = setInterval(() => {
      kalan -= 1;
      if (kalan > 0) {
        const yuzde = Math.min(98, Math.round(((TOPLAM_SANIYE - kalan) / TOPLAM_SANIYE) * 100) + 10);
        if (cubuk) cubuk.style.width = `${yuzde}%`;
        const metin = acilisAsamalari[kalan] || baslangicMetni;
        if (durumEl) durumEl.textContent = `${metin} (${kalan} sn)`;
      } else {
        acilisKapanisSayacTemizle();
        if (cubuk) cubuk.style.width = '100%';
        if (durumEl) durumEl.textContent = '✅ Sistem hazır!';
        if (ekran) ekran.classList.add('acilis-bitti');
        durum('✓ Mezatron Sesli Envanter hazır.');
        setTimeout(() => {
          if (ekran && !programKapaliModda && !kapanisSayaciCalisiyor) ekran.style.display = 'none';
          acilisAnimasyonCalisiyor = false;
        }, 450);
      }
    }, 1000);
  };

  // İlk açılışta 6 saniyelik reklam + açılış animasyonunu çalıştır (🔄 Yenile ile gelindiyse 6 sn beklemeden doğrudan aç)
  const hizliYenile = (() => {
    let aktif = /[?&]hizli_yenile=1\b/.test(window.location.search || '');
    try {
      if (sessionStorage.getItem('mezat_hizli_yenile_v1') === '1') {
        sessionStorage.removeItem('mezat_hizli_yenile_v1');
        aktif = true;
      }
    } catch (_) {}
    if (aktif) {
      try {
        const temizUrl = window.location.pathname + window.location.search.replace(/([?&])hizli_yenile=1(&?)/, (_, p1, p2) => (p1 === '?' && p2 ? '?' : (p1 === '&' && p2 ? '&' : ''))).replace(/[?&]v=\d+/, '');
        window.history.replaceState(null, '', temizUrl || '/urun-girisi.html');
      } catch (_) {}
    }
    return aktif;
  })();

  if (hizliYenile) {
    const ekran = $('mezat-acilis-ekrani');
    if (ekran) {
      ekran.classList.add('acilis-bitti');
      ekran.style.display = 'none';
    }
    acilisAnimasyonCalisiyor = false;
    programKapaliModda = false;
    setTimeout(() => {
      try {
        const taslakHam = sessionStorage.getItem('mezat_taslak_form_v1');
        if (taslakHam) {
          sessionStorage.removeItem('mezat_taslak_form_v1');
          const taslak = JSON.parse(taslakHam);
          if (taslak.aktifSayfa && typeof window.aktifSayfayiSec === 'function') {
            window.aktifSayfayiSec(taslak.aktifSayfa);
          }
          if (taslak.urun && $('urun')) $('urun').value = taslak.urun;
          if (taslak.fiyat && $('fiyat')) $('fiyat').value = taslak.fiyat;
          if (taslak.barkod && $('barkod')) $('barkod').value = taslak.barkod;
          if (Array.isArray(taslak.satirlar) && taslak.satirlar.some(s => s.renk || s.beden || Number(s.adet) > 0)) {
            $('satirlar').replaceChildren(...taslak.satirlar.map(s => satirOgesi(s)));
            toplamGuncelle();
          }
          if (typeof temizleTuslariniGuncelle === 'function') temizleTuslariniGuncelle();
        }
      } catch (_) {}
      try { listeyiYenile(); } catch (_) {}
      try { barkodBankasiniYenile('', false); } catch (_) {}
      try { motorDurumu(); } catch (_) {}
      durum('✓ Program, arayüz ve yapılan tüm değişiklikler anında yenilendi.');
    }, 40);
  } else {
    setTimeout(() => {
      window.programAcilisAnimasyonuBaslat('🚀 Envanter ve ses motoru başlatılıyor…', false);
    }, 40);
  }

  // Ekran tamamen karardığında (kapalıyken) ekrana dokunulursa tekrar 6 sn açılış animasyonuyla başlat
  if ($('mezat-acilis-ekrani')) {
    $('mezat-acilis-ekrani').addEventListener('click', e => {
      if (e.target && e.target.closest && e.target.closest('a,button')) return;
      if (programKapaliModda && !kapanisSayaciCalisiyor && Date.now() - sonKapanisBitisMs > 1200) {
        window.programAcilisAnimasyonuBaslat('🚀 Program yeniden başlatılıyor…', true);
      }
    });
  }

  window.guvenliProgramiKapat = async function (zorlaKapat = false) {
    if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
    if ($('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
    if (kayit && kayit.iptalEt) {
      try { kayit.iptalEt(''); } catch (_) {}
    }
    try { barkodKamerayiKapat(); } catch (_) {}
    try { etiketCanliKamerayiKapat(); } catch (_) {}
    try { irsaliyeCanliKamerayiKapat(); } catch (_) {}

    if ($('giren') && $('giren').value.trim()) {
      try { localStorage.setItem('giren', $('giren').value.trim()); } catch (_) {}
    }

    const doluSatirlar = satirlariOku().filter(s => s.renk || s.beden || (s.adet != null && s.adet > 0));
    if (!zorlaKapat && doluSatirlar.length > 0) {
      try {
        if ($('urun') && !$('urun').value.trim()) $('urun').value = 'Genel Ürün';
        await kaydet();
      } catch (_) {}
    }

    kapanisSayaciCalisiyor = true;
    programKapaliModda = false;
    acilisAnimasyonCalisiyor = false;
    sistemGecisSesi(false);

    function tamEkranKipindenCik() {
      document.body.classList.remove('tam-ekran-kipi');
      if ($('tam-ekran-btn')) $('tam-ekran-btn').textContent = '⛶ Ekran';
      try {
        if (window.MezatNativeApp && typeof window.MezatNativeApp.tamEkranMi === 'function' && window.MezatNativeApp.tamEkranMi()) {
          window.MezatNativeApp.tamEkranDegistir();
        }
      } catch (_) {}
      try {
        if (document.fullscreenElement && document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.webkitFullscreenElement && document.webkitExitFullscreen) {
          document.webkitExitFullscreen();
        }
      } catch (_) {}
    }

    function telefonAnaMenusuneCik() {
      acilisKapanisSayacTemizle();
      kapanisSayaciCalisiyor = false;
      programKapaliModda = true;
      sonKapanisBitisMs = Date.now();
      tamEkranKipindenCik();

      // 1. Güncel Android APK (v2.8+ / v3.0+): Doğrudan Android Ana Ekran (Home Launcher) + finishAndRemoveTask()
      if (window.MezatNativeApp && typeof window.MezatNativeApp.uygulamayiKapat === 'function') {
        try {
          window.MezatNativeApp.uygulamayiKapat();
          return;
        } catch (_) {}
      }

      // 2. Android Chrome / PWA: Doğrudan telefonun ana ekranına (Home Launcher) çık
      const homeIntentUri = 'intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.HOME;launchFlags=0x10000000;end';
      if (!window.MezatNativeApp && /Android/i.test(navigator.userAgent || '')) {
        try {
          window.location.href = homeIntentUri;
        } catch (_) {}
      }

      // 3. Masaüstü / WebChromeClient pencere kapatma
      try { window.close(); } catch (_) {}

      // 4. Eğer telefonda ilk kurulan eski APK (kapatVar: false) çalışıyorsa (uygulamayiKapat metodu olmayan ilk kurulum):
      if (window.MezatNativeApp && typeof window.MezatNativeApp.uygulamayiKapat !== 'function') {
        const dEl = $('mezat-acilis-durum');
        if (dEl) {
          dEl.innerHTML = '⚠️ Telefon uygulamanız eski.<br>Yenisi için: Bilgisayar ekranındaki <b>📱 Mobil</b> tuşuna basıp <b>Yeşil QR Kodu</b> telefon kamerasıyla okutun (Google arama kutusuna yazmayın).';
        }
      }
    }

    tamEkranKipindenCik();

    try {
      digerAltPanelleriKapat('');
      if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('ses');
    } catch (_) {}

    // Kapanışta 6 saniye boyunca reklam ve giriş/kapanış sayfasını göster, ardından OTOMATİK kapat!
    acilisEkraniniSifirlaHazirla('✅ Veriler kaydedildi · 6 saniye içinde otomatik kapanıyor…');
    const cubuk = $('mezat-acilis-cubuk');
    const durumEl = $('mezat-acilis-durum');
    if (cubuk) {
      cubuk.style.background = 'linear-gradient(90deg, #f59e0b, #10b981)';
      cubuk.style.width = '100%';
    }

    try {
      if (window.MezatMobilHibrit && window.MezatMobilHibrit.bekleyenKuyruguOku().length > 0) {
        window.MezatMobilHibrit.bekleyenleriBilgisayaraAktar(true).catch(() => {});
      }
    } catch (_) {}

    const KAPANIS_SANIYE = 6;
    let kalanSn = KAPANIS_SANIYE;

    acilisKapanisSayacTimer = setInterval(() => {
      kalanSn -= 1;
      if (kalanSn > 0) {
        const yuzde = Math.max(0, Math.round((kalanSn / KAPANIS_SANIYE) * 100));
        if (cubuk) cubuk.style.width = `${yuzde}%`;
        if (durumEl) durumEl.textContent = `✅ Veriler kaydedildi · ${kalanSn} saniye içinde otomatik kapanıyor…`;
      } else {
        if (cubuk) cubuk.style.width = '0%';
        if (durumEl) durumEl.textContent = '⏻ Telefon ana menüsüne dönülüyor…';
        telefonAnaMenusuneCik();
      }
    }, 1000);
  };

  // Uygulama kapalı moddayken arka plana atılıp (telefon ana menüsü) tekrar açıldığında
  // eski kapanış yazısını ASLA gösterme; doğrudan tam açılış animasyonuyla sıfırdan başlat!
  let kapaliIkendenArkaplanaGecti = false;
  function kapaliArkaPlanaHazirla() {
    if (programKapaliModda && !kapanisSayaciCalisiyor) {
      kapaliIkendenArkaplanaGecti = true;
      acilisEkraniniSifirlaHazirla('🚀 Program yeniden başlatılıyor…');
    }
  }
  function kapaliOnPlandaAcilisiBaslat() {
    if (kapanisSayaciCalisiyor) return;
    if (programKapaliModda && kapaliIkendenArkaplanaGecti && Date.now() - sonKapanisBitisMs > 1200) {
      kapaliIkendenArkaplanaGecti = false;
      window.programAcilisAnimasyonuBaslat('🚀 Program yeniden başlatılıyor…', true);
    }
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') kapaliArkaPlanaHazirla();
    else if (document.visibilityState === 'visible') kapaliOnPlandaAcilisiBaslat();
  });
  window.addEventListener('pagehide', kapaliArkaPlanaHazirla);
  window.addEventListener('pageshow', e => {
    if (e.persisted && !kapanisSayaciCalisiyor) {
      kapaliIkendenArkaplanaGecti = true;
      kapaliOnPlandaAcilisiBaslat();
    }
  });

  if ($('programi-guvenli-kapat-btn')) {
    $('programi-guvenli-kapat-btn').addEventListener('click', () => {
      window.guvenliProgramiKapat(false);
    });
  }

  window.__mezatGeriTusuBasildi = function () {
    if (programKapaliModda || kapanisSayaciCalisiyor) return false;
    if (acikAltPanelVeyaSoruyuKapat()) return true;
    const aktifSayfa = document.body.dataset.aktifSayfa || 'ses';
    if (aktifSayfa !== 'ses' && typeof window.aktifSayfayiSec === 'function') {
      window.aktifSayfayiSec('ses');
      return true;
    }
    soruSor(
      'Programdan çıkmak istiyor musunuz?',
      'Kayıtlarınız ve yedekleriniz güvenli şekilde korunacaktır.',
      [
        ['⏻ Güvenli Kaydet ve Kapat', 'evet', () => window.guvenliProgramiKapat(false)],
        ['İptal (Programda Kal)', '', () => {}]
      ]
    );
    return true;
  };

  window.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if (acikAltPanelVeyaSoruyuKapat()) e.preventDefault();
    }
  });
  window.addEventListener('popstate', () => {
    if (kapanisGeriGecisi || programKapaliModda) {
      kapanisGeriGecisi = false;
      return;
    }
    acikAltPanelVeyaSoruyuKapat();
  });

  if ($('kopru-ac-btn')) {
    $('kopru-ac-btn').addEventListener('click', () => {
      const p = $('mezatron-kopru-panel');
      if (!p) return;
      const acik = !p.classList.contains('gizli');
      if (!acik) digerAltPanelleriKapat('mezatron-kopru-panel');
      const gizli = p.classList.toggle('gizli');
      $('kopru-ac-btn').classList.toggle('aktif', !gizli);
      if (!gizli) kopruDurumuGuncelle();
    });
  }
  if ($('kopru-kapat-btn')) {
    $('kopru-kapat-btn').addEventListener('click', () => {
      $('mezatron-kopru-panel').classList.add('gizli');
      if ($('kopru-ac-btn')) $('kopru-ac-btn').classList.remove('aktif');
    });
  }
  if ($('kopru-kontrol-btn')) {
    $('kopru-kontrol-btn').addEventListener('click', () => kopruDurumuGuncelle());
  }
  if ($('kopru-senkron-btn')) {
    $('kopru-senkron-btn').addEventListener('click', async () => {
      $('kopru-senkron-btn').disabled = true;
      try {
        const c = await post('/api/mezatron-koprusu/senkronize-et', {});
        const basariliHedefler = (c.sonuclar || []).filter(s => s.success).map(s => `${s.url} (${s.aktarilanUrun} ürün)`);
        if (basariliHedefler.length) {
          bipSesi();
          durum(`🔗 Mezatron senkronizasyonu tamamlandı: ${basariliHedefler.join(', ')}`);
        } else {
          durum('Açık Mezatron sunucusu bulunamadı (Port 3000 veya 3001 açık olmalı).', true);
        }
        await kopruDurumuGuncelle();
      } catch (err) {
        durum('Senkronizasyon sırasında hata oluştu.', true);
      } finally {
        $('kopru-senkron-btn').disabled = false;
      }
    });
  }

  // ===== 🩺 Envanter Ses Doktoru & 🗣️ Depo Görevlisi Ses İzi =====
  async function doktorDurumuGuncelle() {
    try {
      const [izVeri, dokVeri] = await Promise.all([
        fetch('/api/ses-izi/durum').then(r => r.json()),
        fetch('/api/envanter/doktor').then(r => r.json())
      ]);
      if ($('ses-izi-durum') && izVeri) {
        $('ses-izi-durum').textContent = izVeri.kayitli
          ? `🟢 Konuşmacı Ses İzi Kayıtlı (${izVeri.ornekSayisi} ses örneği ile eğitildi — gürültülü ortamda sizin sesinizi önceliklendirir)`
          : '🟡 Henüz ses izi tanıtılmadı. Gürültülü depoda başkalarının sesini filtrelemek için 5 sn konuşarak ses izinizi tanıtın.';
      }
      if ($('doktor-ozet-kutu') && dokVeri && dokVeri.teshis) {
        const t = dokVeri.teshis;
        const o = t.ozet || {};
        const puan = t.saglikPuani ?? o.saglikPuani ?? 100;
        const bulguMetni = (t.bulgular || []).length
          ? t.bulgular.map(b => `• [${b.seviye}] ${b.baslik}: ${b.aciklama || b.cozum || ''}`).join('\n')
          : '✓ Tüm ses kayıtları, ürün fiyatları ve irsaliye sayımları kusursuz görünüyor.';
        $('doktor-ozet-kutu').innerHTML = `
          <div style="font-weight:800;color:${puan >= 85 ? '#34d399' : '#fbbf24'};margin-bottom:4px">
            🩺 Depo & Ses Sağlığı Puanı: ${puan}/100 · Ort. SNR: ${o.ortalamaSnrDb != null ? `+${o.ortalamaSnrDb} dB` : '—'} · Ses Kaydı: ${o.toplamSesKaydi || 0}
          </div>
          <div style="white-space:pre-line;font-size:0.82rem;color:#cbd5e1">${bulguMetni}</div>
        `;
      }
    } catch (err) {}
  }

  if ($('doktor-ac-btn')) {
    $('doktor-ac-btn').addEventListener('click', () => {
      const p = $('doktor-panel');
      if (!p) return;
      const acik = !p.classList.contains('gizli');
      if (!acik) digerAltPanelleriKapat('doktor-panel');
      const gizli = p.classList.toggle('gizli');
      $('doktor-ac-btn').classList.toggle('aktif', !gizli);
      if (!gizli) doktorDurumuGuncelle();
    });
  }
  if ($('doktor-kapat-btn')) {
    $('doktor-kapat-btn').addEventListener('click', () => {
      $('doktor-panel').classList.add('gizli');
      if ($('doktor-ac-btn')) $('doktor-ac-btn').classList.remove('aktif');
    });
  }
  if ($('doktor-yenile-btn')) {
    $('doktor-yenile-btn').addEventListener('click', () => doktorDurumuGuncelle());
  }
  if ($('doktor-rapor-btn')) {
    $('doktor-rapor-btn').addEventListener('click', async () => {
      try {
        const c = await post('/api/envanter/doktor/rapor', {});
        if (c.success) {
          bipSesi();
          durum(`📄 Envanter Ses Doktoru raporu kaydedildi: ${c.dosya || c.dosyaYolu}`);
        }
      } catch (err) {
        durum('Rapor kaydedilemedi.', true);
      }
    });
  }
  if ($('ses-izi-sil-btn')) {
    $('ses-izi-sil-btn').addEventListener('click', async () => {
      await post('/api/ses-izi/sil', {});
      await doktorDurumuGuncelle();
      await motorDurumu();
      durum('Konuşmacı ses izi sıfırlandı.');
    });
  }
  if ($('ses-izi-kaydet-btn')) {
    $('ses-izi-kaydet-btn').addEventListener('click', async () => {
      const btn = $('ses-izi-kaydet-btn');
      btn.disabled = true;
      durum('🗣️ Örnek metni okuyun: "Siyah spor ayakkabı kırk numara iki adet bin beş yüz lira"');
      try {
        const akis = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
        let baglam;
        try { baglam = new AudioContext({ sampleRate: HEDEF_ORAN }); } catch (err) { baglam = new AudioContext(); }
        await baglam.audioWorklet.addModule('mic-worklet.js');
        const dugum = new AudioWorkletNode(baglam, 'mic-capture');
        const parcalar = [];
        dugum.port.onmessage = e => parcalar.push(e.data);
        baglam.createMediaStreamSource(akis).connect(dugum);
        for (let sn = 5; sn >= 1; sn--) {
          btn.textContent = `🎙️ Konuşun (${sn} sn kaldı)…`;
          await new Promise(r => setTimeout(r, 1000));
        }
        akis.getTracks().forEach(t => t.stop());
        const oran = baglam.sampleRate;
        await baglam.close();
        const toplam = parcalar.reduce((t, p) => t + p.length, 0);
        const ornekler = new Float32Array(toplam);
        let konum = 0;
        parcalar.forEach(p => { ornekler.set(p, konum); konum += p.length; });
        const wavVeri = wav(indir(ornekler, oran));
        const c = await fetch('/api/ses-izi/kaydet', { method: 'POST', headers: { 'Content-Type': 'audio/wav' }, body: wavVeri }).then(r => r.json());
        if (c.success) {
          bipSesi();
          durum('🗣️ Ses iziniz başarıyla kaydedildi! Artık gürültülü ortamda sizin sesiniz tanınacak.');
        } else {
          durum(c.error || c.message || 'Ses izi çıkarılamadı. Lütfen 5 saniye boyunca kesintisiz konuşun.', true);
        }
        await doktorDurumuGuncelle();
        await motorDurumu();
      } catch (err) {
        durum('Ses izi kaydı için mikrofon açılamadı.', true);
      } finally {
        btn.disabled = false;
        btn.textContent = '🗣️ Ses İzimi Tanıt (5 sn Konuş)';
      }
    });
  }

  // ===== 📱 TEK EL 3 SAYFALI ERGONOMİK SAHNE YÖNETİCİSİ + PARMAKLA KAYDIRMA (SWIPE) =====
  // Not: 'satis' bölümü silinmedi; 2. Proje (Barkodlu Satış & Müşteri Kaydı) için korundu.
  const SAYFA_SIRASI = ['ses', 'barkod', 'kayitlar'];

  window.aktifSayfayiSec = async function (sayfaKodu = 'ses', kaymaYonu = '') {
    const gecerli = SAYFA_SIRASI.includes(sayfaKodu) ? sayfaKodu : 'ses';
    const onceki = document.body.dataset.aktifSayfa || 'ses';
    if (!kaymaYonu && onceki !== gecerli) {
      const eskiIdx = SAYFA_SIRASI.indexOf(onceki);
      const yeniIdx = SAYFA_SIRASI.indexOf(gecerli);
      if (eskiIdx >= 0 && yeniIdx >= 0) {
        kaymaYonu = yeniIdx > eskiIdx ? 'sola' : 'saga';
      }
    }
    document.body.dataset.aktifSayfa = gecerli;
    const sahne = document.querySelector('.sahne-govde');
    if (sahne) {
      sahne.style.transition = '';
      sahne.style.transform = '';
      sahne.classList.remove('sayfa-gecis-sola', 'sayfa-gecis-saga');
      if (kaymaYonu === 'sola' || kaymaYonu === 'saga') {
        void sahne.offsetWidth;
        sahne.classList.add(kaymaYonu === 'sola' ? 'sayfa-gecis-sola' : 'sayfa-gecis-saga');
      }
    }
    if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
    if ($('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
    if (typeof window.barkodDigerKapat === 'function') window.barkodDigerKapat();
    durum('');
    // v110: Sayfa değişince Ürün & Beden Giriş penceresi ve ses uyarıları diğer sayfalara taşınmasın
    if ($('calisma-pencere-durum')) {
      $('calisma-pencere-durum').textContent = '';
      $('calisma-pencere-durum').classList.remove('durum-hata', 'durum-basarili');
    }
    if (gecerli !== 'ses' && document.body.classList.contains('calisma-penceresi-acik')) {
      calismaPenceresiniKapat(false);
    }

    document.querySelectorAll('#alt-sayfa-cubuk .alt-sayfa-btn').forEach(btn => {
      btn.classList.toggle('aktif', btn.dataset.sayfa === gecerli);
    });

    if (gecerli === 'ses') {
      barkodIslemKipi = 'giris';
      digerAltPanelleriKapat('');
      dugmeHazir();
    } else if (gecerli === 'barkod') {
      barkodIslemKipi = 'giris';
      barkodSayfaKipiniAyarla('giris');
      digerAltPanelleriKapat('barkod-panel');
      if ($('barkod-panel')) $('barkod-panel').classList.remove('gizli');
      dugmeHazir();
      await barkodKamerayiAc('barkod-video', 'barkod-vizor');
    } else if (gecerli === 'satis') {
      barkodIslemKipi = 'satis';
      digerAltPanelleriKapat('');
      kasaSepetiCiz();
      await barkodKamerayiAc('kasa-barkod-video', 'kasa-barkod-vizor');
    } else if (gecerli === 'kayitlar') {
      barkodIslemKipi = 'giris';
      digerAltPanelleriKapat('');
      listeyiYenile();
      barkodBankasiniYenile($('banka-arama') ? $('banka-arama').value : '');
    }
  };

  document.querySelectorAll('#alt-sayfa-cubuk .alt-sayfa-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      window.aktifSayfayiSec(btn.dataset.sayfa || 'ses');
    });
  });

  // Parmakla sağa/sola kaydırarak (Swipe) 5 sayfa arasında doğal telefon geçişi
  (function sayfaKaydirmaKur() {
    const sahne = document.querySelector('.sahne-govde');
    if (!sahne) return;
    let basX = 0;
    let basY = 0;
    let sonX = 0;
    let sonY = 0;
    let basZaman = 0;
    let takipAktif = false;
    let yatayKilidi = null; // true: yatay sayfa kaydırma, false: dikey liste kaydırma

    function kaydirmaEngelliMi(hedef) {
      if (kayit && !kayit.bitti) return true;
      if ($('soru') && !$('soru').classList.contains('gizli')) return true;
      const acilirPaneller = ['ust-araclar-cekmece', 'bt-mobil-panel', 'mobil-baglanti-panel', 'mezatron-kopru-panel', 'doktor-panel'];
      for (const pid of acilirPaneller) {
        const el = $(pid);
        if (el && !el.classList.contains('gizli')) return true;
      }
      if (hedef && hedef.closest && hedef.closest('input[type="range"], select')) return true;
      return false;
    }

    document.addEventListener('touchstart', e => {
      if (!e.touches || e.touches.length !== 1) { takipAktif = false; return; }
      if (kaydirmaEngelliMi(e.target)) { takipAktif = false; return; }
      basX = e.touches[0].clientX;
      basY = e.touches[0].clientY;
      sonX = basX;
      sonY = basY;
      basZaman = Date.now();
      takipAktif = true;
      yatayKilidi = null;
      sahne.style.transition = 'none';
    }, { passive: true });

    document.addEventListener('touchmove', e => {
      if (!takipAktif || !e.touches || e.touches.length !== 1) return;
      sonX = e.touches[0].clientX;
      sonY = e.touches[0].clientY;
      const dx = sonX - basX;
      const dy = sonY - basY;
      if (yatayKilidi === null) {
        if (Math.abs(dx) > 14 || Math.abs(dy) > 14) {
          yatayKilidi = Math.abs(dx) > Math.abs(dy) * 1.35;
        }
      }
      if (yatayKilidi) {
        const mevcut = document.body.dataset.aktifSayfa || 'ses';
        const idx = SAYFA_SIRASI.indexOf(mevcut);
        const sinirCizgisi = (idx === 0 && dx > 0) || (idx === SAYFA_SIRASI.length - 1 && dx < 0);
        const kaymaPx = Math.max(-68, Math.min(68, dx * (sinirCizgisi ? 0.12 : 0.32)));
        sahne.style.transform = `translateX(${Math.round(kaymaPx)}px)`;
      }
    }, { passive: true });

    function dokunmaBitir() {
      if (!takipAktif) return;
      takipAktif = false;
      const dx = sonX - basX;
      const dy = sonY - basY;
      const sure = Date.now() - basZaman;
      sahne.style.transition = 'transform 0.16s ease-out';
      sahne.style.transform = '';

      if (yatayKilidi && Math.abs(dx) >= 52 && Math.abs(dx) > Math.abs(dy) * 1.3 && sure < 750) {
        const mevcut = document.body.dataset.aktifSayfa || 'ses';
        const idx = SAYFA_SIRASI.indexOf(mevcut);
        if (dx < 0 && idx < SAYFA_SIRASI.length - 1) {
          window.aktifSayfayiSec(SAYFA_SIRASI[idx + 1], 'sola');
        } else if (dx > 0 && idx > 0) {
          window.aktifSayfayiSec(SAYFA_SIRASI[idx - 1], 'saga');
        }
      }
      yatayKilidi = null;
    }

    document.addEventListener('touchend', dokunmaBitir, { passive: true });
    document.addEventListener('touchcancel', () => {
      takipAktif = false;
      yatayKilidi = null;
      sahne.style.transition = '';
      sahne.style.transform = '';
    }, { passive: true });
  })();

  // Kayıtlar sayfası içindeki 3 alt sekme (Envanter Listesi / Barkod Bankası / Kalıcı Excel & Basım)
  document.querySelectorAll('.kayitlar-alt-sekmeler .kayit-alt-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const hedef = btn.dataset.altSekme || 'bugun';
      document.querySelectorAll('.kayitlar-alt-sekmeler .kayit-alt-btn').forEach(b => {
        b.classList.toggle('aktif', b.dataset.altSekme === hedef);
      });
      if ($('alt-sekme-bugun')) $('alt-sekme-bugun').classList.toggle('gizli', hedef !== 'bugun');
      if ($('alt-sekme-banka')) $('alt-sekme-banka').classList.toggle('gizli', hedef !== 'banka');
      if ($('alt-sekme-istasyonlar')) $('alt-sekme-istasyonlar').classList.toggle('gizli', hedef !== 'istasyonlar');
      if (hedef === 'istasyonlar' && $('sekme-telefon-dosya-ozet') && window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelExcelSatirlariniCikar === 'function') {
        const y = window.MezatMobilHibrit.yerelExcelSatirlariniCikar();
        const topAdet = y.satirlar.reduce((t, s) => t + (Number(s.kalan) || 0), 0);
        $('sekme-telefon-dosya-ozet').textContent = `Telefondaki Kalıcı Dosya: ${y.kayitlar.length} Barkodlu Ürün · ${y.satirlar.length} Varyant Satırı · Toplam ${topAdet} Adet`;
      }
    });
  });

  if ($('menu-barkod-bankasi-ac-btn')) {
    $('menu-barkod-bankasi-ac-btn').addEventListener('click', () => {
      if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
      if ($('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
      if (typeof window.aktifSayfayiSec === 'function') window.aktifSayfayiSec('liste');
      const bankaBtn = document.querySelector('.kayitlar-alt-sekmeler .kayit-alt-btn[data-alt-sekme="banka"]');
      if (bankaBtn) bankaBtn.click();
    });
  }
  if ($('sekme-kalici-excel-aktar-btn')) {
    $('sekme-kalici-excel-aktar-btn').addEventListener('click', () => window.mezatExcelPdfMerkeziAc('gonder'));
  }
  if ($('sekme-telefon-excel-indir-btn')) {
    $('sekme-telefon-excel-indir-btn').addEventListener('click', () => {
      if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelExcelIndir === 'function') {
        window.MezatMobilHibrit.yerelExcelIndir('xls');
        durum('📲 Telefondaki kalıcı barkodlu envanter dosyası Excel (.XLS) olarak indirildi.');
      } else {
        window.mezatExcelPdfMerkeziAc('gonder');
      }
    });
  }
  if ($('sekme-excelden-yukle-btn')) {
    $('sekme-excelden-yukle-btn').addEventListener('click', () => window.mezatExcelPdfMerkeziAc('yukle'));
  }
  if ($('sekme-bt-yazici-ayar-btn')) {
    $('sekme-bt-yazici-ayar-btn').addEventListener('click', () => {
      if ($('bt-yazici-ac-btn')) $('bt-yazici-ac-btn').click();
    });
  }

  // Telefonda bilgisayara ulaşılamıyorsa yenileme telefondaki sayfayı açar; boş hata sayfası çıkmaz
  function yenilemeAdresi() {
    const ek = `uygulama=apk&hizli_yenile=1&v=${Date.now()}`;
    const kopru = window.MezatNativeApp;
    if (kopru && typeof kopru.bilgisayarVarMi === 'function') {
      let ulasiyor = false;
      try { ulasiyor = Boolean(kopru.bilgisayarVarMi()); } catch (_) {}
      if (!ulasiyor) return `file:///android_asset/public/urun-girisi.html?${ek}`;
    }
    if (window.location.protocol === 'file:') {
      let pc = '';
      try { if (kopru && typeof kopru.sunucuUrlOku === 'function') pc = String(kopru.sunucuUrlOku() || '').trim().replace(/\/+$/, ''); } catch (_) {}
      return `${pc || 'https://192.168.8.3:3442'}/urun-girisi.html?${ek}`;
    }
    return `/urun-girisi.html?${ek}`;
  }
  window.yenilemeAdresi = yenilemeAdresi;

  if ($('ust-yenile-btn')) {
    $('ust-yenile-btn').addEventListener('click', async () => {
      const btn = $('ust-yenile-btn');
      btn.textContent = '⏳ Yenileniyor…';
      durum('🔄 Önbellek temizleniyor ve en güncel program değişiklikleri yükleniyor…');
      try {
        const mevcutTaslak = {
          aktifSayfa: document.body.dataset.aktifSayfa || 'ses',
          urun: $('urun') ? $('urun').value : '',
          fiyat: $('fiyat') ? $('fiyat').value : '',
          barkod: $('barkod') ? $('barkod').value : '',
          satirlar: satirlariOku()
        };
        sessionStorage.setItem('mezat_taslak_form_v1', JSON.stringify(mevcutTaslak));
        sessionStorage.setItem('mezat_hizli_yenile_v1', '1');
      } catch (_) {}

      try {
        if (window.MezatMobilHibrit && window.MezatMobilHibrit.bekleyenKuyruguOku().length > 0) {
          await window.MezatMobilHibrit.bekleyenleriBilgisayaraAktar(true);
        }
      } catch (_) {}

      try {
        const [mRes, rRes] = await Promise.all([
          fetch(`/MARKA_TELAFFUZ_SOZLUGU.md?t=${Date.now()}`, { cache: 'no-store' }),
          fetch(`/RENK_TELAFFUZ_SOZLUGU.md?t=${Date.now()}`, { cache: 'no-store' })
        ]);
        if (mRes.ok) localStorage.setItem('mezatron_mobil_marka_sozluk_md_v1', await mRes.text());
        if (rRes.ok) localStorage.setItem('mezatron_mobil_renk_sozluk_md_v1', await rRes.text());
      } catch (_) {}

      try {
        if ('serviceWorker' in navigator) {
          const regs = await navigator.serviceWorker.getRegistrations();
          for (const reg of regs) {
            try { await reg.unregister(); } catch (_) {}
          }
        }
        if ('caches' in window) {
          const keys = await caches.keys();
          await Promise.all(keys.map(k => caches.delete(k)));
        }
      } catch (_) {}

      window.location.replace(yenilemeAdresi());
    });
  }

  if ($('araclar-menu-btn') && $('ust-araclar-cekmece')) {
    $('araclar-menu-btn').addEventListener('click', () => {
      const gizli = $('ust-araclar-cekmece').classList.toggle('gizli');
      $('araclar-menu-btn').classList.toggle('aktif', !gizli);
    });
  }

  if ($('yazi-kutu-ac-btn') && $('yazi-giris-kutu')) {
    $('yazi-kutu-ac-btn').addEventListener('click', () => {
      const gizli = $('yazi-giris-kutu').classList.toggle('gizli');
      $('yazi-kutu-ac-btn').classList.toggle('aktif', !gizli);
      if (!gizli && $('soz')) $('soz').focus();
    });
  }

  if ($('irsaliye-daralt-btn') && $('irsaliye-kamera-govde')) {
    $('irsaliye-daralt-btn').addEventListener('click', async () => {
      const gizli = $('irsaliye-kamera-govde').classList.toggle('gizli');
      if (gizli) {
        irsaliyeCanliKamerayiKapat();
        $('irsaliye-daralt-btn').textContent = '🔽 Kamerayı / Metni Aç';
      } else {
        $('irsaliye-daralt-btn').textContent = '🔼 Kamerayı Daralt';
        await irsaliyeCanliKamerayiAc();
      }
    });
  }

  formuTemizle();
  listeyiYenile();
  barkodBankasiniYenile();
  motorDurumu();

  // Tarayıcı eklenti kalkanı ve agresif ardışık tıklama (rage-click) koruması
  function envanterGirdiZirhla() {
    document.querySelectorAll('input, textarea, select').forEach(el => {
      if (el.dataset.zirhli === '1') return;
      el.setAttribute('data-gramm', 'false');
      el.setAttribute('data-gramm_editor', 'false');
      el.setAttribute('data-enable-grammarly', 'false');
      el.setAttribute('spellcheck', 'false');
      el.setAttribute('translate', 'no');
      el.classList.add('notranslate');
      el.dataset.zirhli = '1';
    });
    ['grammarly-extension', 'grammarly-popups', 'deepl-inline-translate', '#goog-gt-tt', '.goog-te-banner-frame'].forEach(sel => {
      document.querySelectorAll(sel).forEach(n => { try { n.remove(); } catch (_) {} });
    });
  }
  envanterGirdiZirhla();
  try {
    new MutationObserver(() => envanterGirdiZirhla()).observe(document.body, { childList: true, subtree: true });
  } catch (_) {}
  document.addEventListener('click', e => {
    const btn = e.target && e.target.closest ? e.target.closest('button') : null;
    if (!btn) return;
    if (btn.id === 'kaydet' || btn.id === 'kaydet-ve-bas' || btn.id === 'irsaliye-uygula' || btn.id === 'etiket-uygula' || btn.id === 'barkod-oku-btn') {
      const simdi = Date.now();
      if (simdi - Number(btn.dataset.sonTik || 0) < 350) {
        e.stopImmediatePropagation();
        e.preventDefault();
        return;
      }
      btn.dataset.sonTik = String(simdi);
    }
  }, true);

  // ===== 📦 İLK KURULUM, SES DOSYALARI VE EKLENTİ İNDİRME SİHİRBAZI =====
  let envanterKurulumCalisiyor = false;
  let envanterKurulumTimer = null;

  function envanterKurulumEscape(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  async function envanterKurulumSihirbaziGuncelle() {
    const govde = document.getElementById('envanter-kurulum-govde');
    if (!govde) return;
    try {
      const r = await fetch('/api/sistem/kurulum', { cache: 'no-store' });
      const rapor = await r.json();
      const d = rapor.donanim || {};
      const o = rapor.ozet || {};
      const tavsiyeler = rapor.tavsiyeler || [];
      const bilesenler = rapor.bilesenler || [];

      const donanimHtml = `
        <div style="background:rgba(15,23,42,0.75);border:1px solid rgba(56,189,248,0.3);border-radius:10px;padding:10px 12px;margin-bottom:10px">
          <div style="font-size:0.86rem;font-weight:700;color:#7dd3fc">💻 Algılanan Bilgisayar Donanımı</div>
          <div style="font-size:0.8rem;color:#cbd5e1;margin-top:3px">
            İşlemci: <b>${envanterKurulumEscape(d.cpuModel || 'Bilinmiyor')}</b> (${d.cpuCekirdek || '?'} Çekirdek) ·
            RAM: <b>${d.toplamRamGb || '?'} GB</b> ·
            Ekran Kartı: <b>${envanterKurulumEscape((d.ekranKartlari && d.ekranKartlari[0]) || 'Dahili GPU')}</b>
          </div>
          <div style="font-size:0.8rem;color:#34d399;margin-top:4px;font-weight:600">
            🎯 Tavsiye Edilen Kurulum Profili: ${envanterKurulumEscape(d.tavsiyeProfil || 'Evrensel Hibrit')}
          </div>
        </div>
      `;

      const tavsiyeHtml = tavsiyeler.map(t => {
        const renk = t.seviye === 'tamam' ? '#10b981' : (t.seviye === 'kritik' ? '#ef4444' : '#f59e0b');
        const bg = t.seviye === 'tamam' ? 'rgba(16,185,129,0.12)' : (t.seviye === 'kritik' ? 'rgba(239,68,68,0.14)' : 'rgba(245,158,11,0.12)');
        return `
          <div style="background:${bg};border:1px solid ${renk};border-radius:10px;padding:9px 11px;margin-bottom:8px">
            <div style="font-size:0.85rem;font-weight:700;color:#f8fafc">${envanterKurulumEscape(t.baslik)}</div>
            <div style="font-size:0.78rem;color:#e2e8f0;margin-top:3px;line-height:1.4">${envanterKurulumEscape(t.mesaj)}</div>
          </div>
        `;
      }).join('');

      const bilesenlerHtml = bilesenler.map(b => {
        const kurulu = b.kurulu;
        const aktif = b.aktifIslem && (b.aktifIslem.durum === 'indiriliyor' || b.aktifIslem.durum === 'kopyalaniyor' || b.aktifIslem.durum === 'cikariliyor' || b.aktifIslem.durum === 'kuruluyor' || b.aktifIslem.durum === 'baslatildi');
        const yuzde = b.aktifIslem ? (b.aktifIslem.yuzde || 0) : (kurulu ? 100 : 0);
        const rozetRenk = kurulu ? '#10b981' : (b.zorunlu ? '#f59e0b' : '#94a3b8');
        const rozetYazi = kurulu
          ? `✅ Kurulu (${b.boyutMb || b.tahminiBoyutMb} MB)`
          : (b.yerelOnbellekteVar ? `⚡ Yerel Önbellekte Hazır (${b.tahminiBoyutMb} MB)` : `⬇️ İndirilebilir (~${b.tahminiBoyutMb} MB)`);
        return `
          <div style="background:rgba(15,23,42,0.85);border:1px solid ${kurulu ? 'rgba(16,185,129,0.35)' : 'rgba(148,163,184,0.28)'};border-radius:10px;padding:10px 12px;margin-bottom:8px">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;flex-wrap:wrap">
              <div style="flex:1;min-width:200px">
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                  <span style="font-size:0.88rem;font-weight:700;color:#f8fafc">${envanterKurulumEscape(b.ad)}</span>
                  <span style="font-size:0.72rem;padding:2px 7px;border-radius:999px;background:rgba(255,255,255,0.07);color:${rozetRenk};font-weight:700">${rozetYazi}</span>
                </div>
                <div style="font-size:0.77rem;color:#cbd5e1;margin-top:4px;line-height:1.35">${envanterKurulumEscape(b.aciklama)}</div>
                <div style="font-size:0.74rem;color:#38bdf8;margin-top:3px">💡 <b>Tavsiye:</b> ${envanterKurulumEscape(b.tavsiye)}</div>
              </div>
              <div style="display:flex;flex-direction:column;gap:5px;align-items:flex-end;min-width:170px">
                ${!kurulu ? `
                  <button type="button" onclick="window.envanterBilesenIzinliKur('${b.id}', '${envanterKurulumEscape(b.ad)}', ${b.tahminiBoyutMb || 0}, ${Boolean(b.yerelOnbellekteVar)})" ${aktif ? 'disabled' : ''} style="width:100%;padding:7px 10px;border-radius:8px;border:1px solid rgba(16,185,129,0.65);background:rgba(16,185,129,0.22);color:#ecfdf5;font-weight:700;font-size:0.78rem;cursor:pointer">
                    ${aktif ? '⏳ Kuruluyor...' : (b.yerelOnbellekteVar ? '⚡ İzin Ver & 1 Sn\'de Kur' : '⬇️ İzin Ver & Otomatik İndir/Kur')}
                  </button>
                ` : `
                  <span style="font-size:0.76rem;color:#34d399;font-weight:700;padding:4px 8px">✓ Bu Bilgisayarda Hazır</span>
                `}
                <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end">
                  <a href="${envanterKurulumEscape(b.indirmeUrl)}" target="_blank" rel="noopener noreferrer" style="font-size:0.72rem;color:#93c5fd;text-decoration:underline;padding:2px 4px">🔗 Doğrudan İndir</a>
                  <a href="${envanterKurulumEscape(b.resmiSayfaUrl)}" target="_blank" rel="noopener noreferrer" style="font-size:0.72rem;color:#cbd5e1;text-decoration:underline;padding:2px 4px">🌐 Resmi Sayfa</a>
                </div>
              </div>
            </div>
            ${(aktif || (b.aktifIslem && b.aktifIslem.mesaj)) ? `
              <div style="margin-top:8px">
                <div style="height:6px;background:rgba(255,255,255,0.1);border-radius:999px;overflow:hidden">
                  <div style="height:100%;width:${Math.min(100, Math.max(5, yuzde))}%;background:#10b981;transition:width 0.3s"></div>
                </div>
                <div style="font-size:0.73rem;color:#a7f3d0;margin-top:3px">${envanterKurulumEscape(b.aktifIslem.mesaj || '')} (${yuzde}%)</div>
              </div>
            ` : ''}
          </div>
        `;
      }).join('');

      govde.innerHTML = `
        <div style="background:rgba(15,23,42,0.85);border:1px solid rgba(16,185,129,0.4);border-radius:10px;padding:10px 12px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
          <div>
            <div style="font-size:0.85rem;font-weight:700;color:#6ee7b7">🔄 Yazılım Güncelleme &amp; GitHub Sürüm Kontrolü</div>
            <div id="envanter-guncelleme-durum" style="font-size:0.78rem;color:#cbd5e1;margin-top:2px">Mevcut Sürüm: v2.4.0 (Kararlı Sürüm)</div>
          </div>
          <button type="button" onclick="window.envanterGuncellemeKontrolEt()" style="padding:7px 12px;border-radius:8px;border:1px solid #38bdf8;background:#0284c7;color:#fff;font-weight:700;font-size:0.78rem;cursor:pointer">
            🔍 Güncellemeleri Kontrol Et
          </button>
        </div>
        ${donanimHtml}
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
          <div style="font-size:0.82rem;color:#cbd5e1">
            Durum: <b>${o.kuruluSayisi || 0} / ${o.toplamBilesen || 0}</b> bileşen kurulu
            ${o.eksikSayisi > 0 ? `<span style="color:#fbbf24;margin-left:6px">(${o.eksikSayisi} eksik/isteğe bağlı paket mevcut)</span>` : '<span style="color:#34d399;margin-left:6px">(Tümü eksiksiz kurulu!)</span>'}
          </div>
          ${o.eksikSayisi > 0 ? `
            <button type="button" onclick="window.envanterTumEksikleriIzinliKur()" ${envanterKurulumCalisiyor ? 'disabled' : ''} style="padding:8px 13px;border-radius:8px;border:1px solid #10b981;background:linear-gradient(135deg,#059669,#047857);color:#fff;font-weight:700;font-size:0.8rem;cursor:pointer">
              ⚡ Tüm Eksikleri Tek Tıkla İndir ve Kur (${o.eksikSayisi} Paket)
            </button>
          ` : ''}
        </div>
        ${tavsiyeHtml}
        <div style="margin-top:8px">${bilesenlerHtml}</div>
      `;
    } catch (e) {
      govde.innerHTML = `<div style="color:#fca5a5;padding:12px">Kurulum durumu alınamadı: ${envanterKurulumEscape(e.message)}</div>`;
    }
  }

  window.envanterKurulumSihirbaziAc = function () {
    let modal = document.getElementById('envanter-kurulum-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'envanter-kurulum-modal';
      modal.style.cssText = 'position:fixed;inset:0;z-index:99998;background:rgba(2,6,23,0.84);backdrop-filter:blur(5px);display:flex;align-items:center;justify-content:center;padding:14px';
      modal.innerHTML = `
        <div style="background:#0f172a;border:1px solid rgba(56,189,248,0.4);border-radius:14px;max-width:780px;width:100%;max-height:88vh;display:flex;flex-direction:column;box-shadow:0 20px 50px rgba(0,0,0,0.65);color:#f8fafc;font-family:system-ui,-apple-system,sans-serif">
          <div style="display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:1px solid rgba(148,163,184,0.2)">
            <div>
              <div style="font-size:1rem;font-weight:800;color:#38bdf8">📦 İlk Kurulum, Ses Modelleri ve Eklenti İndirme Sihirbazı</div>
              <div style="font-size:0.76rem;color:#94a3b8;margin-top:2px">Yeni kurulan bilgisayarlarda eksik ses motorlarını, yapay zeka modellerini ve eklentileri izin vererek tek tıkla kurun veya resmi bağlantılardan indirin.</div>
            </div>
            <button type="button" onclick="window.envanterKurulumSihirbaziKapat()" style="padding:6px 11px;border-radius:8px;border:1px solid rgba(148,163,184,0.35);background:rgba(30,41,59,0.9);color:#e2e8f0;font-weight:700;cursor:pointer">✕ Kapat</button>
          </div>
          <div id="envanter-kurulum-govde" style="padding:14px 16px;overflow-y:auto;flex:1">
            <div style="color:#94a3b8;font-size:0.85rem">Sistem bileşenleri ve ses modelleri taranıyor...</div>
          </div>
        </div>
      `;
      modal.addEventListener('click', ev => { if (ev.target === modal) window.envanterKurulumSihirbaziKapat(); });
      document.body.appendChild(modal);
    } else {
      modal.style.display = 'flex';
    }
    envanterKurulumSihirbaziGuncelle();
    if (envanterKurulumTimer) clearInterval(envanterKurulumTimer);
    envanterKurulumTimer = setInterval(envanterKurulumSihirbaziGuncelle, 1500);
  };

  window.envanterKurulumSihirbaziKapat = function () {
    const modal = document.getElementById('envanter-kurulum-modal');
    if (modal) modal.style.display = 'none';
    if (envanterKurulumTimer) {
      clearInterval(envanterKurulumTimer);
      envanterKurulumTimer = null;
    }
  };

  window.envanterBilesenIzinliKur = async function (bilesenId, ad, boyutMb, yerelVar) {
    const kaynakMetni = yerelVar
      ? 'Bilgisayardaki yerel Mezatron önbelleğinden 1 saniyede kopyalanarak'
      : `Resmi kaynaktan (~${boyutMb} MB) indirilerek`;
    const onay = window.confirm(
      `[KURULUM İZNİ]\n\n"${ad}" bileşenini bu bilgisayara ${kaynakMetni} kurmak istiyor musunuz?\n\nOnayladığınızda kurulum otomatik tamamlanacaktır.`
    );
    if (!onay) return;
    envanterKurulumCalisiyor = true;
    envanterKurulumSihirbaziGuncelle();
    try {
      await fetch('/api/sistem/kurulum/indir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bilesenId })
      });
    } catch (_) {}
    envanterKurulumCalisiyor = false;
    await envanterKurulumSihirbaziGuncelle();
    await motorDurumu();
  };

  window.envanterTumEksikleriIzinliKur = async function () {
    const onay = window.confirm(
      '[TOPLU KURULUM İZNİ]\n\nBu bilgisayarda eksik olan tüm ses modellerini ve eklentileri otomatik indirip kurmak için izin veriyor musunuz?'
    );
    if (!onay) return;
    envanterKurulumCalisiyor = true;
    envanterKurulumSihirbaziGuncelle();
    try {
      await fetch('/api/sistem/kurulum/indir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tumu: true })
      });
    } catch (_) {}
    envanterKurulumCalisiyor = false;
    await envanterKurulumSihirbaziGuncelle();
    await motorDurumu();
  };

  if ($('kurulum-ac-btn')) {
    $('kurulum-ac-btn').addEventListener('click', () => window.envanterKurulumSihirbaziAc());
  }

  if ($('zirh-ac-btn')) {
    $('zirh-ac-btn').addEventListener('click', async () => {
      try {
        const r = await fetch('/api/sistem/zirh', { cache: 'no-store' }).then(x => x.json());
        const testOnay = window.confirm(
          `🛡️ ÇİFT ÇEKİRDEKLİ GÜVENLİK & ENJEKSİYON ZIRHI\n\n` +
          `• Durum: ${r.durumAciklamasi}\n` +
          `• Cihaz Kontrolü (yalnız uyarı verir): ${r.donanim?.cihazKimligi} (${r.donanim?.donanimEslesiyor ? 'Aynı cihaz' : '⚠️ Farklı cihaz'})\n` +
          `• Mühürlü Dosya Sayısı: ${r.butunluk?.korunanDosyaSayisi} (HMAC-SHA256: ${r.butunluk?.imzaGecerli ? 'Geçerli' : 'Uyarı'})\n` +
          `• Engellenen Saldırı/Enjeksiyon: ${r.kalkanIstatistik?.engellenenSaldiriSayisi || 0}\n\n` +
          `Barkod, Excel ve Prompt Enjeksiyon Kalkanını şimdi canlı test etmek ister misiniz?`
        );
        if (testOnay) {
          const t = await fetch('/api/sistem/zirh/test', { method: 'POST' }).then(x => x.json());
          const ozet = (t.testler || []).map((k, idx) => `${idx + 1}. ${k.testAdi}: ${k.engellendi ? '✅ Engellendi' : '❌ Engellenmedi'}`).join('\n');
          window.alert(`🧪 Örnek saldırı denemesi (${t.engellenenSayisi || 0}/${t.testSayisi || 0} engellendi):\n\n${ozet}\n\nBu deneme yalnız 4 örnek metni sınar, programın tamamen güvenli olduğunu göstermez.`);
          durum(t.tumSaldirilarEngellendi ? '🛡️ Örnek saldırıların hepsi engellendi.' : '⚠️ Bazı örnek saldırılar engellenmedi.', !t.tumSaldirilarEngellendi);
        }
      } catch (e) {
        durum('Güvenlik zırhı bilgisi alınamadı.', true);
      }
    });
  }

  window.envanterGuncellemeKontrolEt = async function () {
    const kutu = document.getElementById('envanter-guncelleme-durum');
    if (kutu) kutu.textContent = '⏳ GitHub ve yerel sürüm kontrol ediliyor...';
    try {
      const r = await fetch('/api/sistem/guncelleme-kontrol', { cache: 'no-store' }).then(x => x.json());
      if (kutu) kutu.textContent = r.durumMesaji || `✅ Sürüm v${r.mevcutSurum} güncel.`;
      durum(r.durumMesaji || `✅ Programınız güncel (v${r.mevcutSurum}).`, Boolean(r.guncellemeVar));
    } catch (e) {
      if (kutu) kutu.textContent = '⚠️ Güncelleme kontrolü yapılamadı.';
    }
  };

  // 🔐 GİZLİ KURUCU / AR-GE GÖZETİM TETİKLEYİCİSİ (Son kullanıcıda güvenlik ve kurulum araçları gizlidir)
  // Başlığa 5 kez hızlı tıklama veya Ctrl + Shift + Y ile açılır/kapanır
  let __envKurucuTik = 0;
  let __envKurucuSonMs = 0;
  let __envKurucuAcik = false;

  function envanterKurucuModuDegistir(zorlaAcik) {
    const kayitliSifre = localStorage.getItem('mezatron_kurucu_paket_sifresi') || '';
    if (!__envKurucuAcik && kayitliSifre && !window.__ENV_KURUCU_DOGRULANDI__) {
      const girilen = window.prompt('🔐 Mezatron Kurucu & Ar-Ge Konsolu Şifresi:');
      if (girilen !== kayitliSifre) {
        if (girilen !== null) durum('❌ Kurucu şifresi hatalı.', true);
        return;
      }
      window.__ENV_KURUCU_DOGRULANDI__ = true;
    }
    __envKurucuAcik = typeof zorlaAcik === 'boolean' ? zorlaAcik : !__envKurucuAcik;
    ['kurulum-ac-btn', 'zirh-ac-btn', 'doktor-ac-btn'].forEach(id => {
      const el = $(id);
      if (el) el.classList.toggle('gizli', !__envKurucuAcik);
    });
    if (__envKurucuAcik) {
      durum('🛡️ Kurucu & Ar-Ge Modu Açıldı: Güvenlik Zırhı, Kurulum Sihirbazı ve Ses Doktoru düğmeleri aktif edildi.');
    } else {
      durum('🔒 Son Kullanıcı Görünümüne Dönüldü: Ar-Ge ve güvenlik araçları gizlendi.');
    }
  }

  // v116: Herhangi bir sayfayı telefonun tarayıcısında (APK dışında) aç
  window.mezatTarayicidaAc = function (yol) {
    const tamUrl = new URL(yol, location.href).href;
    const n = window.MezatNativeApp;
    if (n && typeof n.tarayicidaAc === 'function' && /^https?:/i.test(tamUrl)) { n.tarayicidaAc(tamUrl); return; }
    const w = window.open(tamUrl, '_blank', 'noopener');
    if (!w) location.href = tamUrl;
  };

  // v116: Logo 5 dokunuş → Yönetici şifresi → Yönetici Konsolu (tarayıcıda)
  function yoneticiGirisiAc() {
    if (document.getElementById('mezat-yonetici-kapisi')) return;
    const k = document.createElement('div');
    k.id = 'mezat-yonetici-kapisi';
    k.style.cssText = 'position:fixed;inset:0;z-index:100001;background:rgba(2,6,23,.92);display:flex;align-items:center;justify-content:center;padding:18px';
    k.innerHTML = `
      <div style="width:100%;max-width:360px;background:#0f172a;border:2px solid #64748b;border-radius:16px;padding:18px;color:#f8fafc">
        <div style="font-size:1.1rem;font-weight:900;margin-bottom:10px">🔑 Yetkili Girişi</div>
        <input id="myk-sifre" type="password" autocomplete="off" placeholder="Şifre" style="width:100%;box-sizing:border-box;height:50px;padding:8px 12px;font-size:1.1rem;border-radius:12px;border:2px solid #475569;background:#020617;color:#fff;margin-bottom:8px">
        <div id="myk-durum" style="min-height:20px;color:#fca5a5;font-weight:800;font-size:.9rem;margin-bottom:8px"></div>
        <div style="display:flex;gap:8px">
          <button type="button" id="myk-gir" style="flex:1;min-height:48px;border-radius:12px;border:0;background:#0369a1;color:#fff;font-weight:900">Giriş</button>
          <button type="button" id="myk-kapat" style="min-height:48px;padding:0 16px;border-radius:12px;border:1px solid #475569;background:#1e293b;color:#e2e8f0;font-weight:800">Kapat</button>
        </div>
      </div>`;
    document.body.appendChild(k);
    const sEl = document.getElementById('myk-sifre');
    const dEl = document.getElementById('myk-durum');
    sEl.focus();
    document.getElementById('myk-kapat').onclick = () => k.remove();
    const gir = async () => {
      dEl.textContent = '';
      try {
        const r = await fetch('/api/yonetici/giris', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sifre: sEl.value }) });
        const j = await r.json().catch(() => ({}));
        if (!j.success) { dEl.textContent = j.error || 'Giriş başarısız.'; sEl.value = ''; return; }
        k.remove();
        window.__ENV_KURUCU_DOGRULANDI__ = true;
        envanterKurucuModuDegistir(true);
        window.mezatTarayicidaAc('yonetici.html#' + encodeURIComponent(j.jeton));
      } catch (_) {
        dEl.textContent = 'Bilgisayara ulaşılamadı.';
      }
    };
    document.getElementById('myk-gir').onclick = gir;
    sEl.addEventListener('keydown', e => { if (e.key === 'Enter') gir(); });
  }

  const anaBaslik = $('envanter-ana-baslik') || $('baglanti');
  if (anaBaslik) {
    anaBaslik.addEventListener('click', () => {
      const simdi = Date.now();
      if (simdi - __envKurucuSonMs > 2200) __envKurucuTik = 0;
      __envKurucuSonMs = simdi;
      __envKurucuTik += 1;
      if (__envKurucuTik >= 5) {
        __envKurucuTik = 0;
        yoneticiGirisiAc();
      }
    });
  }

  window.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      barkodKamerayiKapat();
      digerAltPanelleriKapat('');
    }
    if (e.ctrlKey && e.shiftKey && (e.key === 'Y' || e.key === 'y' || e.key === 'Z' || e.key === 'z')) {
      e.preventDefault();
      yoneticiGirisiAc();
    }
  });

  // ===== 📲 BAĞIMSIZ CEP MODU + BLUETOOTH TERMAL YAZICI + OTO WI-FI SENKRON MERKEZİ =====
  function btYaziciDurumYenile() {
    if (!window.MezatMobilHibrit) return;
    const y = window.MezatMobilHibrit.yaziciDurumu();
    const ayar = window.MezatMobilHibrit.etiketAyarOku ? window.MezatMobilHibrit.etiketAyarOku() : { boyut: 'kucuk' };
    const buyukMu = ayar.boyut === 'buyuk';

    if ($('bt-secili-boyut-etiket')) {
      $('bt-secili-boyut-etiket').textContent = buyukMu ? '80x50 mm (Geniş) Seçili' : '50x30 mm (Mini) Seçili';
    }
    if ($('bt-boyut-kucuk-btn')) {
      $('bt-boyut-kucuk-btn').style.background = !buyukMu ? '#059669' : '#1e293b';
      $('bt-boyut-kucuk-btn').style.borderColor = !buyukMu ? '#34d399' : '#475569';
      $('bt-boyut-kucuk-btn').style.color = !buyukMu ? '#fff' : '#cbd5e1';
    }
    if ($('bt-boyut-buyuk-btn')) {
      $('bt-boyut-buyuk-btn').style.background = buyukMu ? '#7c3aed' : '#1e293b';
      $('bt-boyut-buyuk-btn').style.borderColor = buyukMu ? '#c084fc' : '#475569';
      $('bt-boyut-buyuk-btn').style.color = buyukMu ? '#fff' : '#cbd5e1';
    }
    if ($('bt-test-etiket-btn')) {
      $('bt-test-etiket-btn').textContent = buyukMu ? '📦 Test Etiketi (80x50)' : '🏷️ Test Etiketi (50x30)';
    }
    if ($('bt-ayar-magaza-adi') && document.activeElement !== $('bt-ayar-magaza-adi')) {
      $('bt-ayar-magaza-adi').value = ayar.magazaAdi || '';
    }
    if ($('bt-ayar-fiyat')) $('bt-ayar-fiyat').checked = ayar.fiyatGoster !== false;
    if ($('bt-ayar-beden')) $('bt-ayar-beden').checked = ayar.bedenGoster !== false;
    if ($('bt-ayar-renk')) $('bt-ayar-renk').checked = ayar.renkGoster !== false;
    if ($('bt-ayar-tarih')) $('bt-ayar-tarih').checked = Boolean(ayar.tarihGoster);

    if ($('bt-yazici-kip')) $('bt-yazici-kip').value = y.kip || 'otomatik';
    if ($('mobil-hedef-pc')) $('mobil-hedef-pc').value = window.MezatMobilHibrit.hedefPcUrlOku() || '';
    if ($('bt-yazici-durum')) {
      const bekleyen = window.MezatMobilHibrit.bekleyenKuyruguOku().length;
      const yerelToplam = window.MezatMobilHibrit.yerelEnvanteriOku().length;
      const etiketBoyAd = buyukMu ? 'Büyük Etiket (80x50mm)' : 'Küçük Etiket (50x30mm)';
      $('bt-yazici-durum').textContent = `🖨️ ${etiketBoyAd} · ${y.bagli ? `🟢 ${y.ad} (seçili)` : 'Yazıcı seçilmedi'} · 📲 Kayıt: ${yerelToplam} (Bekleyen: ${bekleyen})`;
    }
    btYerelYaziciDoldur(false);
    window.MezatMobilHibrit.rozetGuncelle();
  }

  // Telefon uygulamasının kendi Bluetooth yazıcı seçimi: eşleşmiş cihazlar listelenir, yazıcı dili seçilir
  const htmlTemiz = s => String(s == null ? '' : s).replace(/[<>&"]/g, '');
  function btYerelYaziciDoldur(listele) {
    const h = window.MezatMobilHibrit;
    const kutu = $('bt-yerel-kutu'), sec = $('bt-yerel-yazici'), dil = $('bt-yerel-dil');
    if (!h || !kutu || !sec || typeof h.yerelYaziciVarMi !== 'function' || !h.yerelYaziciVarMi()) return;
    kutu.classList.remove('gizli');
    const secili = h.yerelYaziciOku() || {};
    if (dil) dil.value = secili.dil || 'tspl';
    if (!listele && sec.options.length > 1) return;
    const r = h.yerelYaziciListesi();
    const liste = Array.isArray(r.liste) ? r.liste : [];
    sec.innerHTML = '<option value="">Yazıcı seçin</option>' + liste.map(y => `<option value="${htmlTemiz(y.adres)}">${htmlTemiz(y.ad || y.adres)}</option>`).join('');
    if (secili.adres) {
      if (![...sec.options].some(o => o.value === secili.adres)) sec.insertAdjacentHTML('beforeend', `<option value="${htmlTemiz(secili.adres)}">${htmlTemiz(secili.ad || secili.adres)}</option>`);
      sec.value = secili.adres;
    }
    if (!listele) return;
    if (r.hata) durum('🖨️ ' + r.hata, true);
    else if (!liste.length) durum('🖨️ Eşleşmiş Bluetooth cihazı yok. Yazıcıyı önce telefonun Bluetooth ayarlarından eşleştirin.', true);
    else durum(`🖨️ ${liste.length} Bluetooth cihazı bulundu. Yazıcınızı seçin.`);
  }
  if ($('bt-yerel-yenile-btn')) $('bt-yerel-yenile-btn').addEventListener('click', () => btYerelYaziciDoldur(true));
  ['bt-yerel-yazici', 'bt-yerel-dil'].forEach(id => {
    if (!$(id)) return;
    $(id).addEventListener('change', () => {
      const h = window.MezatMobilHibrit, sec = $('bt-yerel-yazici');
      if (!h || !sec || typeof h.yerelYaziciKaydet !== 'function') return;
      const o = sec.options[sec.selectedIndex];
      h.yerelYaziciKaydet(sec.value ? { adres: sec.value, ad: o ? o.textContent : '', dil: $('bt-yerel-dil') ? $('bt-yerel-dil').value : 'tspl' } : null);
      btYaziciDurumYenile();
      durum(sec.value ? `🖨️ Yazıcı seçildi: ${o.textContent}. Test etiketi basabilirsiniz.` : '🖨️ Yazıcı seçimi kaldırıldı.');
    });
  });

  if ($('bt-boyut-kucuk-btn')) {
    $('bt-boyut-kucuk-btn').addEventListener('click', () => {
      if (window.MezatMobilHibrit && window.MezatMobilHibrit.etiketBoyutuAyarla) {
        window.MezatMobilHibrit.etiketBoyutuAyarla('kucuk');
        btYaziciDurumYenile();
        durum('🏷️ Taşınabilir yazıcı: Küçük Sticker (50x30 mm) seçildi.');
      }
    });
  }
  if ($('bt-boyut-buyuk-btn')) {
    $('bt-boyut-buyuk-btn').addEventListener('click', () => {
      if (window.MezatMobilHibrit && window.MezatMobilHibrit.etiketBoyutuAyarla) {
        window.MezatMobilHibrit.etiketBoyutuAyarla('buyuk');
        btYaziciDurumYenile();
        durum('📦 Taşınabilir yazıcı: Büyük Sticker (80x50 mm) seçildi.');
      }
    });
  }

  function btEtiketDetayAyarGuncelle() {
    if (!window.MezatMobilHibrit || !window.MezatMobilHibrit.etiketAyarKaydet) return;
    window.MezatMobilHibrit.etiketAyarKaydet({
      magazaAdi: $('bt-ayar-magaza-adi') ? $('bt-ayar-magaza-adi').value.trim() : '',
      fiyatGoster: $('bt-ayar-fiyat') ? $('bt-ayar-fiyat').checked : true,
      bedenGoster: $('bt-ayar-beden') ? $('bt-ayar-beden').checked : true,
      renkGoster: $('bt-ayar-renk') ? $('bt-ayar-renk').checked : true,
      tarihGoster: $('bt-ayar-tarih') ? $('bt-ayar-tarih').checked : false
    });
  }

  ['bt-ayar-magaza-adi', 'bt-ayar-fiyat', 'bt-ayar-beden', 'bt-ayar-renk', 'bt-ayar-tarih'].forEach(id => {
    if ($(id)) {
      $(id).addEventListener('change', btEtiketDetayAyarGuncelle);
      if ($(id).tagName === 'INPUT' && $(id).type === 'text') {
        $(id).addEventListener('input', btEtiketDetayAyarGuncelle);
      }
    }
  });

  if ($('bt-yazici-ac-btn')) {
    $('bt-yazici-ac-btn').addEventListener('click', () => {
      const panel = $('bt-mobil-panel');
      if (!panel) return;
      const acilacak = panel.classList.contains('gizli');
      digerAltPanelleriKapat('bt-mobil-panel');
      panel.classList.toggle('gizli', !acilacak);
      if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
      if (acilacak) btYaziciDurumYenile();
    });
  }
  if ($('bt-mobil-kapat-btn')) {
    $('bt-mobil-kapat-btn').addEventListener('click', () => {
      if ($('bt-mobil-panel')) $('bt-mobil-panel').classList.add('gizli');
    });
  }
  if ($('bt-eslestir-btn')) {
    $('bt-eslestir-btn').addEventListener('click', async () => {
      if (!window.MezatMobilHibrit) return;
      const s = await window.MezatMobilHibrit.bluetoothYaziciBagla();
      btYaziciDurumYenile();
      if (s.success) durum(`🖨️ Bluetooth Termal Yazıcı bağlandı: ${s.ad}`);
      else durum(s.error || 'Bluetooth yazıcı bağlanamadı.', true);
    });
  }
  if ($('bt-test-etiket-btn')) {
    $('bt-test-etiket-btn').addEventListener('click', async () => {
      if (!window.MezatMobilHibrit) return;
      const testKayit = {
        urun: $('urun')?.value?.trim() || 'BIGAZZI TRIKO KAZAK',
        fiyat: $('fiyat')?.value?.trim() || '750',
        barkod: $('barkod')?.value?.trim() || 'MZU10001',
        satirlar: satirlariOku().length ? satirlariOku() : [{ renk: 'SİYAH', beden: 'L', adet: 1 }]
      };
      let s = null;
      try {
        s = await window.MezatMobilHibrit.bluetoothTermalEtiketBas(testKayit, 'varyant');
      } catch (err) {
        durum('⚠️ ' + ((err && err.message) || 'Etiket basılamadı.'), true);
        return;
      }
      btYaziciDurumYenile();
      if (s && s.success) durum(`🏷️ Test etiketi yazıcıya gönderildi (${s.yontem || s.kip}).`);
    });
  }
  if ($('bt-yazici-kip')) {
    $('bt-yazici-kip').addEventListener('change', e => {
      if (window.MezatMobilHibrit) {
        window.MezatMobilHibrit.yaziciKipAyarla(e.target.value);
        btYaziciDurumYenile();
      }
    });
  }
  if ($('mobil-hedef-kaydet-btn')) {
    $('mobil-hedef-kaydet-btn').addEventListener('click', () => {
      if (!window.MezatMobilHibrit) return;
      const url = window.MezatMobilHibrit.hedefPcUrlKaydet($('mobil-hedef-pc') ? $('mobil-hedef-pc').value : '');
      durum(url ? `💻 Hedef bilgisayar adresi kaydedildi: ${url}` : '💻 Varsayılan yerel sunucu adresi kullanılacak.');
    });
  }
  if ($('mobil-bilgisayar-ara-btn')) {
    $('mobil-bilgisayar-ara-btn').addEventListener('click', () => {
      const k = window.MezatNativeApp;
      if (!k || typeof k.bilgisayarAra !== 'function') { durum('Bu özellik telefon uygulamasında çalışır.', true); return; }
      k.bilgisayarAra();
      durum('🔎 Aynı Wi-Fi ağında bilgisayar aranıyor. Bulununca kendiliğinden bağlanır.');
    });
  }
  if ($('mobil-simdi-aktar-btn')) {
    $('mobil-simdi-aktar-btn').addEventListener('click', async () => {
      if (!window.MezatMobilHibrit) return;
      if (location.protocol === 'file:' && window.MezatNativeApp && window.MezatNativeApp.bilgisayaraDon) {
        const bekleyen = window.MezatMobilHibrit.bekleyenKuyruguOku().length;
        if (window.MezatNativeApp.bilgisayarVarMi()) {
          durum('💻 Bilgisayara bağlanılıyor, kayıtlar aktarılacak…');
          window.MezatNativeApp.bilgisayaraDon();
        } else {
          durum(`⚠️ Bilgisayara ulaşılamadı (${bekleyen} kayıt telefonda güvende bekliyor).`, true);
        }
        return;
      }
      const s = await window.MezatMobilHibrit.bekleyenleriBilgisayaraAktar();
      btYaziciDurumYenile();
      if (s.aktarilan > 0) {
        await listeyiYenile();
        durum(`✅ Telefonda bekleyen ${s.aktarilan} ürün bilgisayara başarıyla aktarıldı!`);
      } else if (s.kalan > 0) {
        durum(`⚠️ Bilgisayara henüz ulaşılamadı (${s.kalan} ürün telefonda güvende bekliyor).`, true);
      } else {
        durum('✓ Telefonda aktarılmayı bekleyen çevrimdışı kayıt yok.');
      }
    });
  }
  if ($('mobil-senkron-rozet')) {
    $('mobil-senkron-rozet').addEventListener('click', async () => {
      if ($('mobil-simdi-aktar-btn')) $('mobil-simdi-aktar-btn').click();
    });
  }
  if ($('mobil-yerel-excel-btn')) {
    $('mobil-yerel-excel-btn').addEventListener('click', () => {
      if (window.MezatMobilHibrit) {
        window.MezatMobilHibrit.yerelExcelIndir();
        durum('⬇ Telefondaki yerel envanter Excel (CSV) olarak indirildi.');
      }
    });
  }
  if ($('sektor-md-input')) {
    $('sektor-md-input').addEventListener('change', async e => {
      const dosya = e.target.files && e.target.files[0];
      if (!dosya) return;
      try {
        const icerik = await dosya.text();
        localStorage.setItem('mezatron_mobil_marka_sozluk_md_v1', icerik);
        try {
          const r = await post('/api/envanter/marka-sozlugu', { icerik, kip: 'birlestir' });
          if (r && r.success) {
            durum(`✅ "${dosya.name}" sözlüğü sisteme eklendi! Toplam ${r.toplamMarka} marka/ürün telaffuzu aktif.`);
            return;
          }
        } catch (_) {}
        durum(`📲 "${dosya.name}" sözlüğü telefonun çevrimdışı hafızasına yüklendi!`);
      } catch (_) {
        durum('Sözlük dosyası okunamadı.', true);
      } finally {
        e.target.value = '';
      }
    });
  }

  // --- 🏢 Sektör Seçim Olayı & Otomatik Yükleyici ---
  if ($('menu-sektor-secim')) {
    $('menu-sektor-secim').addEventListener('change', e => {
      const secilen = e.target.value;
      sektorUygula(secilen, true);
    });
  }
  if ($('menu-sektor-katalog-yukle-btn')) {
    $('menu-sektor-katalog-yukle-btn').addEventListener('click', () => {
      sektorelKataloguYukleVeSenkronEt(g_aktifSektor);
    });
  }

  // İlk açılışta hafızadaki sektörü hemen uygula
  setTimeout(async () => {
    let baslangicSektor = 'giyim';
    try {
      const yerel = localStorage.getItem('mezat_aktif_sektor');
      if (yerel && SEKTOR_TANIMLARI[yerel]) baslangicSektor = yerel;
      else {
        const resp = await fetch('/api/sistem/firma-profili');
        if (resp.ok) {
          const d = await resp.json();
          if (d && d.profil && d.profil.sektor && SEKTOR_TANIMLARI[d.profil.sektor]) {
            baslangicSektor = d.profil.sektor;
          }
        }
      }
    } catch (_) {}
    sektorUygula(baslangicSektor, false);
  }, 100);

  // ===== 📦 APK İNDİR -> 🔄 PROGRAMI GÜNCELLE VE OTOMATİK SÜRÜM KONTROL MERKEZİ =====
  const GUNCEL_APK_SURUMU = '3.4.9';
  const ISTEMCI_YAPIM_NO = 'v156';
  const ISTEMCI_SURUM_NO = '3.4.9';
  let sonGuncellemeRaporu = null;

  function guncellemeMenuButonunuYenile(rapor) {
    const btn = $('pwa-uygulama-kur-btn');
    if (!btn) return;
    let baslikEl = $('pwa-uygulama-kur-baslik');
    let altEl = $('menu-guncelleme-alt-durum');
    if (!baslikEl || !altEl) {
      btn.innerHTML = `
        <span id="pwa-uygulama-kur-baslik">🔄 Programı Güncelle (Yeni Sürümü Yükle)</span>
        <small id="menu-guncelleme-alt-durum" style="display:block;font-size:0.72rem;font-weight:700;opacity:0.92;margin-top:2px">🔍 Otomatik sürüm kontrolü aktif</small>
      `;
      baslikEl = $('pwa-uygulama-kur-baslik');
      altEl = $('menu-guncelleme-alt-durum');
    }
    btn.removeAttribute('download');
    btn.setAttribute('href', '#guncelle-merkezi');

    if (!rapor) {
      baslikEl.textContent = '🔄 Programı Güncelle & Sürüm Kontrolü';
      altEl.textContent = `📌 Kurulu Sürüm: v${ISTEMCI_SURUM_NO} (${ISTEMCI_YAPIM_NO}) · Kontrol için dokunun`;
      return;
    }

    const saatStr = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    if (rapor.guncellemeVar) {
      const kaynakAd = rapor.pcGuncellemeVar && rapor.githubGuncellemeVar
        ? 'Bilgisayar + GitHub'
        : (rapor.pcGuncellemeVar ? 'Bilgisayar Sunucusu' : 'GitHub');
      baslikEl.textContent = `🔔 YENİ GÜNCELLEME VAR! (${rapor.sunucuYapimNo || rapor.uzakSurum || 'Yeni'})`;
      altEl.textContent = `⚡ Kaynak: ${kaynakAd} · Yüklemek için dokunun (${saatStr})`;
      btn.style.background = 'linear-gradient(135deg, #d97706, #b45309)';
      btn.style.borderColor = '#fcd34d';
    } else {
      baslikEl.textContent = '🔄 Programı Güncelle & Sürüm Kontrolü';
      altEl.textContent = `✅ Güncelleme Yok · Sürüm Güncel (v${rapor.mevcutSurum || ISTEMCI_SURUM_NO} · ${rapor.sunucuYapimNo || ISTEMCI_YAPIM_NO}) · ${saatStr}`;
      btn.style.background = '';
      btn.style.borderColor = '';
    }
  }

  // Cihazın yapım numarası, gerçekten kurulu olan önbellekten okunur. Önbellek yoksa karşılaştırma yapılmaz.
  async function kurulumYapimNoAl() {
    try {
      if (!('caches' in window)) return '';
      const nolar = (await caches.keys()).map(k => Number((String(k).match(/^mezatron-mobil-.*_v(\d+)$/) || [])[1] || 0)).filter(Boolean);
      return nolar.length ? `v${Math.max(...nolar)}` : '';
    } catch (_) { return ''; }
  }

  async function otomatikSurumKontrolEt(sessizMi = true) {
    const kayitliRepo = (localStorage.getItem('mezatron_github_repo') || '').trim();
    try {
      const qs = new URLSearchParams({ t: String(Date.now()) });
      const kurulumNo = await kurulumYapimNoAl();
      if (kurulumNo) qs.set('istemciSurum', kurulumNo);
      if (kayitliRepo) qs.set('githubRepo', kayitliRepo);
      const r = await fetch(`/api/sistem/guncelleme-kontrol?${qs.toString()}`, { cache: 'no-store' });
      const d = await r.json();
      if (d && d.ok) {
        sonGuncellemeRaporu = d;
        guncellemeMenuButonunuYenile(d);
        if (!sessizMi) {
          durum(d.durumMesaji || (d.guncellemeVar ? '🔔 Yeni güncelleme bulundu!' : '✅ Güncelleme yok, sürümünüz güncel.'));
        } else if (d.guncellemeVar) {
          durum(d.durumMesaji || '🔔 Yeni program güncellemesi mevcut! ☰ Menü -> Programı Güncelle bölümünden yükleyebilirsiniz.');
        }
        return d;
      }
    } catch (_) {
      // PC sunucusuna ulaşılamıyorsa ve GitHub reposu tanımlıysa doğrudan GitHub üzerinden kontrol et
      if (kayitliRepo) {
        try {
          const ghRes = await fetch(`https://raw.githubusercontent.com/${kayitliRepo}/main/sesli-envanter-asistani/surum.json?t=${Date.now()}`, { cache: 'no-store' });
          if (ghRes.ok) {
            const ghData = await ghRes.json();
            const ghYapim = String(ghData.yapimNo || '');
            const farkVar = Boolean(ghYapim && ghYapim !== ISTEMCI_YAPIM_NO);
            const yedekRapor = {
              ok: true,
              mevcutSurum: ISTEMCI_SURUM_NO,
              istemciYapimNo: ISTEMCI_YAPIM_NO,
              sunucuYapimNo: ghYapim || ISTEMCI_YAPIM_NO,
              uzakSurum: ghData.surum || ISTEMCI_SURUM_NO,
              guncellemeVar: farkVar,
              pcGuncellemeVar: false,
              githubGuncellemeVar: farkVar,
              kaynak: `GitHub (${kayitliRepo})`,
              durumMesaji: farkVar
                ? `🔔 GitHub üzerinde yeni sürüm var: ${ghData.surum || ''} (${ghYapim})`
                : `✅ Güncelleme Yok — GitHub ile sürümünüz güncel (${ISTEMCI_SURUM_NO} · ${ISTEMCI_YAPIM_NO})`,
              kontrolZamani: new Date().toISOString()
            };
            sonGuncellemeRaporu = yedekRapor;
            guncellemeMenuButonunuYenile(yedekRapor);
            return yedekRapor;
          }
        } catch (_e) {}
      }
    }
    const yerelRapor = {
      ok: true,
      mevcutSurum: ISTEMCI_SURUM_NO,
      istemciYapimNo: ISTEMCI_YAPIM_NO,
      sunucuYapimNo: ISTEMCI_YAPIM_NO,
      guncellemeVar: false,
      pcGuncellemeVar: false,
      githubGuncellemeVar: false,
      kaynak: 'Yerel Cihaz (Çevrimdışı)',
      durumMesaji: `ℹ️ Bilgisayar sunucusuna şu an ulaşılamıyor. Cihazdaki kurulu sürüm: v${ISTEMCI_SURUM_NO} (${ISTEMCI_YAPIM_NO}).`,
      kontrolZamani: new Date().toISOString()
    };
    sonGuncellemeRaporu = yerelRapor;
    guncellemeMenuButonunuYenile(yerelRapor);
    return yerelRapor;
  }
  window.otomatikSurumKontrolEt = otomatikSurumKontrolEt;

  async function istemciProgramiSimdiYenileVeGuncelle(githubdanCek = false) {
    durum('🔄 Yeni sürüm, ses/OCR modelleri ve marka/renk sözlükleri güncelleniyor…');
    if (githubdanCek) {
      try {
        const ghR = await fetch('/api/sistem/github-guncelle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({})
        });
        const ghD = await ghR.json();
        if (ghD && ghD.mesaj) durum(ghD.mesaj);
      } catch (_) {}
    }

    try {
      if (window.MezatMobilHibrit && window.MezatMobilHibrit.bekleyenKuyruguOku().length > 0) {
        await window.MezatMobilHibrit.bekleyenleriBilgisayaraAktar(true);
      }
    } catch (_) {}

    try {
      const [mRes, rRes] = await Promise.all([
        fetch(`/MARKA_TELAFFUZ_SOZLUGU.md?t=${Date.now()}`, { cache: 'no-store' }),
        fetch(`/RENK_TELAFFUZ_SOZLUGU.md?t=${Date.now()}`, { cache: 'no-store' })
      ]);
      if (mRes.ok) localStorage.setItem('mezatron_mobil_marka_sozluk_md_v1', await mRes.text());
      if (rRes.ok) localStorage.setItem('mezatron_mobil_renk_sozluk_md_v1', await rRes.text());
    } catch (_) {}

    try {
      if ('serviceWorker' in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (const reg of regs) {
          try { await reg.unregister(); } catch (_) {}
        }
      }
      if ('caches' in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map(k => caches.delete(k)));
      }
    } catch (_) {}

    durum('✅ Program en güncel sürüme yükseltildi, ekran yenileniyor…');
    setTimeout(() => {
      window.location.replace(typeof window.yenilemeAdresi === 'function' ? window.yenilemeAdresi() : `/urun-girisi.html?uygulama=apk&hizli_yenile=1&v=${Date.now()}`);
    }, 350);
  }

  async function mezatGuncellemeMerkeziAc() {
    let modal = document.getElementById('mezat-guncelleme-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mezat-guncelleme-modal';
      modal.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(2,6,23,0.88);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:12px;box-sizing:border-box;';
      document.body.appendChild(modal);
    }
    modal.style.display = 'flex';
    modal.innerHTML = `
      <div style="width:100%;max-width:460px;max-height:92dvh;overflow-y:auto;background:#0f172a;color:#f8fafc;border:2px solid #38bdf8;border-radius:18px;padding:14px;box-sizing:border-box;box-shadow:0 20px 50px rgba(0,0,0,0.75);font-family:system-ui,sans-serif">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;border-bottom:1px solid rgba(148,163,184,0.25);padding-bottom:10px;margin-bottom:10px">
          <strong style="font-size:1rem;color:#38bdf8">🔄 Sürüm Kontrolü & Güncelleme Merkezi</strong>
          <button type="button" id="guncelle-modal-kapat" style="background:#dc2626;color:#fff;border:none;border-radius:10px;padding:6px 12px;font-weight:900;cursor:pointer">✕ Kapat</button>
        </div>
        <div id="guncelle-modal-icerik" style="font-size:0.86rem;line-height:1.45">
          ⏳ Bilgisayar sunucusu ve GitHub üzerinden yeni sürüm kontrol ediliyor...
        </div>
      </div>
    `;
    const kapatBtn = document.getElementById('guncelle-modal-kapat');
    if (kapatBtn) kapatBtn.onclick = () => { modal.style.display = 'none'; };

    const rapor = await otomatikSurumKontrolEt(false);
    const icerik = document.getElementById('guncelle-modal-icerik');
    if (!icerik) return;

    const guncelRenk = rapor.guncellemeVar ? '#f59e0b' : '#10b981';
    const guncelArka = rapor.guncellemeVar ? 'rgba(245,158,11,0.16)' : 'rgba(16,185,129,0.15)';
    const guncelBaslik = rapor.guncellemeVar
      ? '🔔 YENİ GÜNCELLEME VAR!'
      : '✅ GÜNCELLEME YOK — SÜRÜMÜNÜZ GÜNCEL';
    const saat = new Date(rapor.kontrolZamani || Date.now()).toLocaleTimeString('tr-TR');
    const kayitliRepo = (localStorage.getItem('mezatron_github_repo') || rapor.githubRepo || '').trim();
    const degisiklikListesi = Array.isArray(rapor.degisiklikler) && rapor.degisiklikler.length
      ? rapor.degisiklikler.slice(0, 4).map(m => `<li style="margin-bottom:3px">${m}</li>`).join('')
      : '';

    icerik.innerHTML = `
      <div style="padding:12px;border-radius:12px;background:${guncelArka};border:2px solid ${guncelRenk};margin-bottom:10px">
        <div style="font-size:0.98rem;font-weight:900;color:${guncelRenk};margin-bottom:4px">${guncelBaslik}</div>
        <div style="font-size:0.83rem;font-weight:700">${rapor.durumMesaji || ''}</div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:10px;font-size:0.78rem">
        <div style="padding:8px;border-radius:10px;background:rgba(30,41,59,0.75);border:1px solid rgba(148,163,184,0.25)">
          <div style="opacity:0.75">📱 Bu Cihazdaki Sürüm</div>
          <strong style="font-size:0.9rem">v${ISTEMCI_SURUM_NO} (${ISTEMCI_YAPIM_NO})</strong>
        </div>
        <div style="padding:8px;border-radius:10px;background:rgba(30,41,59,0.75);border:1px solid rgba(148,163,184,0.25)">
          <div style="opacity:0.75">🖥️ Sunucu / Uzak Sürüm</div>
          <strong style="font-size:0.9rem">v${rapor.uzakSurum || rapor.mevcutSurum || ISTEMCI_SURUM_NO} (${rapor.sunucuYapimNo || ISTEMCI_YAPIM_NO})</strong>
        </div>
        <div style="padding:8px;border-radius:10px;background:rgba(30,41,59,0.75);border:1px solid rgba(148,163,184,0.25)">
          <div style="opacity:0.75">🌐 Kontrol Kaynağı</div>
          <strong>${rapor.kaynak || 'Bilgisayar Sunucusu'}</strong>
        </div>
        <div style="padding:8px;border-radius:10px;background:rgba(30,41,59,0.75);border:1px solid rgba(148,163,184,0.25)">
          <div style="opacity:0.75">🕒 Son Kontrol (Otomatik: 5 dk)</div>
          <strong>${saat}</strong>
        </div>
      </div>

      ${degisiklikListesi ? `
        <div style="padding:8px 10px;border-radius:10px;background:rgba(30,41,59,0.55);border:1px solid rgba(148,163,184,0.2);margin-bottom:10px;font-size:0.76rem">
          <strong style="display:block;margin-bottom:4px;color:#38bdf8">📋 Son Sürüm Notları:</strong>
          <ul style="margin:0;padding-left:16px">${degisiklikListesi}</ul>
        </div>
      ` : ''}

      <div style="margin-bottom:10px">
        <label style="display:block;font-size:0.74rem;font-weight:800;margin-bottom:4px;opacity:0.85">🐙 GitHub Depo Adresi (İsteğe bağlı — örn: kullanici/mezatron-ai):</label>
        <div style="display:flex;gap:6px">
          <input id="guncelle-github-repo-inp" type="text" value="${kayitliRepo}" placeholder="kullanici/depo-adi" style="flex:1;min-width:0;padding:8px 10px;border-radius:8px;border:1px solid #475569;background:#1e293b;color:#fff;font-size:0.8rem" />
          <button type="button" id="guncelle-github-kaydet-btn" style="padding:8px 10px;border-radius:8px;border:1px solid #38bdf8;background:#0284c7;color:#fff;font-weight:800;font-size:0.78rem;cursor:pointer">Kaydet</button>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr;gap:8px">
        <button type="button" id="guncelle-simdi-yukle-btn" style="width:100%;padding:12px;border-radius:12px;border:2px solid #6ee7b7;background:linear-gradient(135deg,#059669,#10b981);color:#fff;font-weight:900;font-size:0.9rem;cursor:pointer">
          ⚡ ${rapor.guncellemeVar ? 'Yeni Sürümü Şimdi Yükle & Yenile' : 'Sözlükleri ve Programı Şimdi Yenile (Temiz Kurulum)'}
        </button>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <button type="button" id="guncelle-tekrar-kontrol-btn" style="padding:10px;border-radius:10px;border:1px solid #38bdf8;background:#0369a1;color:#fff;font-weight:800;font-size:0.8rem;cursor:pointer">
            🔍 Şimdi Tekrar Kontrol Et
          </button>
          <a href="/Mezatron-Envanter.apk?v=${GUNCEL_APK_SURUMU}_${Date.now()}" download="Mezatron-Envanter.apk" style="display:flex;align-items:center;justify-content:center;padding:10px;border-radius:10px;border:1px solid #a78bfa;background:#4f46e5;color:#fff;font-weight:800;font-size:0.8rem;text-decoration:none;text-align:center">
            📦 Android .APK İndir
          </a>
        </div>
      </div>
    `;

    const repoKaydetBtn = document.getElementById('guncelle-github-kaydet-btn');
    if (repoKaydetBtn) {
      repoKaydetBtn.onclick = () => {
        const val = (document.getElementById('guncelle-github-repo-inp')?.value || '').trim();
        localStorage.setItem('mezatron_github_repo', val);
        durum(val ? `✅ GitHub güncelleme deposu kaydedildi: ${val}` : 'ℹ️ GitHub depo ayarı temizlendi (Bilgisayar sunucusu kullanılacak).');
        mezatGuncellemeMerkeziAc();
      };
    }

    const tekrarBtn = document.getElementById('guncelle-tekrar-kontrol-btn');
    if (tekrarBtn) {
      tekrarBtn.onclick = () => mezatGuncellemeMerkeziAc();
    }

    const simdiYukleBtn = document.getElementById('guncelle-simdi-yukle-btn');
    if (simdiYukleBtn) {
      simdiYukleBtn.onclick = () => {
        modal.style.display = 'none';
        istemciProgramiSimdiYenileVeGuncelle(Boolean(rapor.githubGuncellemeVar));
      };
    }
  }
  window.mezatGuncellemeMerkeziAc = mezatGuncellemeMerkeziAc;

  function apkKurulumDurumuKontrolEt() {
    guncellemeMenuButonunuYenile(sonGuncellemeRaporu);
    const gercekApkIcinde = Boolean(window.MezatNativeApp);
    const androidCihaz = /Android/i.test(navigator.userAgent || '');

    // Eğer Android Chrome tarayıcısında açıldıysa (APK içinde değilse), en üste 1 dokunuşla APK indirme şeridi koy
    if (!gercekApkIcinde && androidCihaz) {
      let ustIndirBar = document.getElementById('chrome-apk-hemen-indir-bar');
      if (!ustIndirBar) {
        ustIndirBar = document.createElement('a');
        ustIndirBar.id = 'chrome-apk-hemen-indir-bar';
        ustIndirBar.href = `/Mezatron-Envanter.apk?v=${GUNCEL_APK_SURUMU}_${Date.now()}`;
        ustIndirBar.setAttribute('download', 'Mezatron-Envanter.apk');
        ustIndirBar.style.cssText = 'display:block;margin:6px 0;padding:11px 12px;border-radius:12px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;font-weight:900;font-size:0.9rem;text-align:center;text-decoration:none;box-shadow:0 6px 18px rgba(16,185,129,0.4);border:1.5px solid #6ee7b7';
        ustIndirBar.textContent = '⬇️ TELEFON UYGULAMASINI İNDİR (3.4)';
        const ustEl = document.querySelector('.ust');
        if (ustEl && ustEl.parentNode) {
          ustEl.parentNode.insertBefore(ustIndirBar, ustEl.nextSibling);
        }
      }
    }
  }
  apkKurulumDurumuKontrolEt();
  // Telefon uygulamasının yeni sürümü bilgisayarda varsa sorar (yalnız bilgisayardan açılan sayfada).
  // Yeni uygulama kendini kurar (indirir, parmak izini denetler, Android'in kurulum penceresini açar);
  // eski uygulamada yalnız indirme bağlantısı gösterilir.
  (async function telefonUygulamasiGuncellemeDenetle() {
    const k = window.MezatNativeApp;
    if (!k || location.protocol === 'file:') return;
    let bilgi = null;
    try { bilgi = await (await fetch('/api/mobil/apk-bilgi', { cache: 'no-store' })).json(); } catch (_) { return; }
    if (!bilgi || !bilgi.var || !bilgi.surumKodu) return;
    const karsilastir = (a, b) => {
      const x = String(a || '0').split('.').map(Number), y = String(b || '0').split('.').map(Number);
      for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0) ? 1 : -1;
      return 0;
    };
    const destekli = typeof k.apkGuncelleDestekli === 'function' && k.apkGuncelleDestekli();
    const kendiAd = typeof k.apkSurumu === 'function' ? String(k.apkSurumu()) : 'eski';
    if (destekli) { if (Number(k.apkSurumKodu()) >= bilgi.surumKodu) return; }
    else if (karsilastir(kendiAd, bilgi.surumAdi) >= 0) return;
    const ertele = 'mezat_apk_sonra_' + bilgi.surumKodu;
    try { if (Date.now() - Number(localStorage.getItem(ertele) || 0) < 24 * 3600 * 1000) return; } catch (_) {}

    const kutu = document.createElement('div');
    kutu.id = 'mezat-apk-guncelleme';
    kutu.style.cssText = 'position:fixed;inset:0;z-index:99998;background:rgba(2,6,23,0.88);display:flex;align-items:center;justify-content:center;padding:18px';
    const mb = Math.round((bilgi.boyut || 0) / 1048576);
    kutu.innerHTML = `<div style="max-width:380px;width:100%;background:#0f172a;border:2px solid #10b981;border-radius:16px;padding:20px;color:#f8fafc;font-family:'Segoe UI',system-ui,sans-serif;line-height:1.45">
      <div style="font-size:1.1rem;font-weight:600;color:#6ee7b7;margin-bottom:8px">📲 Telefon uygulamasının yeni sürümü var</div>
      <div style="font-size:0.95rem;margin-bottom:6px">Bilgisayarda <b>${bilgi.surumAdi}</b> var, bu telefonda <b>${kendiAd}</b>.</div>
      <div style="font-size:0.85rem;color:#94a3b8;margin-bottom:14px">Dosya yaklaşık ${mb} MB, bilgisayardan (Wi-Fi) iner. Kayıtlarınız silinmez.</div>
      <div id="mezat-apk-cubuk" style="display:none;height:8px;border-radius:6px;background:#1e293b;overflow:hidden;margin-bottom:10px"><div style="height:100%;width:0;background:#10b981"></div></div>
      <div id="mezat-apk-durum" style="font-size:0.9rem;min-height:1.2em;margin-bottom:12px;color:#e2e8f0"></div>
      <div style="display:flex;gap:10px">
        ${destekli
          ? '<button type="button" id="mezat-apk-kur" style="flex:1;padding:13px;border:0;border-radius:12px;background:#059669;color:#fff;font-size:1rem;font-weight:600">Şimdi kur</button>'
          : '<a href="/Mezatron-Envanter.apk?v=' + Date.now() + '" style="flex:1;padding:13px;border-radius:12px;background:#059669;color:#fff;font-size:1rem;font-weight:600;text-align:center;text-decoration:none">İndir</a>'}
        <button type="button" id="mezat-apk-sonra" style="flex:1;padding:13px;border:1px solid #475569;border-radius:12px;background:none;color:#e2e8f0;font-size:1rem">Sonra</button>
      </div>
      ${destekli ? '' : '<div style="font-size:0.8rem;color:#94a3b8;margin-top:10px">İndirince bildirimden dosyayı açıp "Güncelle"ye dokunun. Bu sürümden sonra güncelleme kendiliğinden kurulur.</div>'}
    </div>`;
    document.body.appendChild(kutu);
    const durumEl = kutu.querySelector('#mezat-apk-durum');
    const cubuk = kutu.querySelector('#mezat-apk-cubuk');
    const kurBtn = kutu.querySelector('#mezat-apk-kur');
    kutu.querySelector('#mezat-apk-sonra').addEventListener('click', () => {
      try { localStorage.setItem(ertele, String(Date.now())); } catch (_) {}
      kutu.remove();
    });
    window.__mezatApkGuncelleme = d => {
      if (!d) return;
      durumEl.textContent = d.metin || '';
      durumEl.style.color = d.durum === 'hata' ? '#fca5a5' : '#e2e8f0';
      if (d.durum === 'indiriliyor') { cubuk.style.display = 'block'; cubuk.firstElementChild.style.width = (d.yuzde || 0) + '%'; }
      if (kurBtn) kurBtn.disabled = d.durum === 'indiriliyor' || d.durum === 'kuruluyor';
      if (kurBtn && (d.durum === 'hata' || d.durum === 'iptal' || d.durum === 'izin')) kurBtn.textContent = 'Tekrar dene';
      if (d.durum === 'tamam' || d.durum === 'guncel') setTimeout(() => kutu.remove(), 2500);
    };
    if (kurBtn) kurBtn.addEventListener('click', () => {
      kurBtn.disabled = true;
      durumEl.textContent = 'Hazırlanıyor…';
      try { k.apkGuncelle(String(bilgi.sha256 || '')); } catch (e) { durumEl.textContent = 'Başlatılamadı: ' + e.message; kurBtn.disabled = false; }
    });
  })();
  // Telefon uygulamasının sürümü alttaki yazıda görünür (eski sürüm kurulu mu anlaşılsın)
  try {
    const k = window.MezatNativeApp;
    const s = document.querySelector('.alt-kimlik-surum');
    if (k && typeof k.apkSurumu === 'function' && s) s.textContent = `v3.4 · uygulama ${k.apkSurumu()}`;
    // Bilgisayardaki ekranda telefonun hangi uygulama sürümünü kullandığı görülsün
    if (location.protocol !== 'file:') {
      const uygulama = k && typeof k.apkSurumu === 'function' ? String(k.apkSurumu()) : (k ? 'eski (3.3 ya da öncesi)' : 'tarayıcı');
      fetch('/api/mobil-telemetri', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uygulamaSurumu: uygulama, eslemeVar: Boolean(k && typeof k.sunucuEslestir === 'function'), derinBaglanti: Boolean(k && typeof k.apkSurumu === 'function' && k.apkSurumu() >= '3.4.2') }) }).catch(() => {});
    }
  } catch (_) {}
  if (/[?&]uygulama-eski=1/.test(location.search) && !window.MezatNativeApp) {
    const u = document.createElement('div');
    u.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(2,6,23,0.94);display:flex;align-items:center;justify-content:center;padding:18px';
    u.innerHTML = `<div style="max-width:380px;width:100%;background:#0f172a;border:2px solid #f59e0b;border-radius:16px;padding:20px;color:#f8fafc;text-align:center;font-family:system-ui,sans-serif;line-height:1.45">
      <div style="font-size:1.1rem;font-weight:900;color:#fde047;margin-bottom:10px">⚠️ Telefondaki uygulama eski</div>
      <div style="font-size:0.95rem;margin-bottom:12px">Bu bağlantı uygulamanın <b>3.4.2</b> sürümüyle çalışır. Aşağıdaki düğmeyle yeni sürümü indirip kurun, sonra bilgisayardaki alttaki kare kodu tekrar okutun.</div>
      <a href="/Mezatron-Envanter.apk?v=${Date.now()}" style="display:block;padding:14px;border-radius:12px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;font-weight:900;text-decoration:none">⬇️ Uygulamanın 3.4.2 sürümünü indir</a>
      <div style="font-size:0.8rem;color:#94a3b8;margin-top:12px">Kurarken "İndirilenler"de birden çok Mezatron dosyası görürseniz en son indirileni seçin.</div>
    </div>`;
    document.body.appendChild(u);
  }
  if (/[?&]eslendi=1/.test(location.search)) {
    durum('💻 Bilgisayar eşlendi. Telefon bu bilgisayara bağlı.');
  }
  // Eşleme kare kodu telefonun kendi kamerasıyla okutulursa tarayıcıda açılır: uygulamayı açıp bağlayan düğme gösterilir
  (function tarayicidaEslemeDugmesi() {
    const m = location.search.match(/[?&]mezatron-baglan=?([0-9A-Fa-f:]*)/);
    if (!m || window.MezatNativeApp) return;
    const adres = `${location.protocol}//${location.host}`;
    const hedef = `intent://baglan?adres=${encodeURIComponent(adres)}&parmak=${encodeURIComponent(m[1].toUpperCase())}#Intent;scheme=mezatron;package=com.mezatron.envanter;S.browser_fallback_url=${encodeURIComponent(`${adres}/urun-girisi.html?uygulama-eski=1`)};end`;
    const kutu = document.createElement('div');
    kutu.id = 'mezat-tarayici-esleme';
    kutu.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(2,6,23,0.94);display:flex;align-items:center;justify-content:center;padding:18px';
    kutu.innerHTML = `<div style="max-width:380px;width:100%;background:#0f172a;border:2px solid #10b981;border-radius:16px;padding:20px;color:#f8fafc;text-align:center;font-family:system-ui,sans-serif">
      <div style="font-size:1.15rem;font-weight:900;color:#6ee7b7;margin-bottom:10px">📲 Telefonu bilgisayara bağla</div>
      <div style="font-size:0.95rem;line-height:1.45;margin-bottom:16px">Mezatron uygulaması telefonunuzda kuruluysa aşağıdaki düğmeye dokunun. Uygulama açılır ve bu bilgisayara bağlanır.</div>
      <a href="${hedef}" style="display:block;padding:16px;border-radius:12px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;font-weight:900;font-size:1.1rem;text-decoration:none">📲 Uygulamada aç ve bağla</a>
      <div style="font-size:0.82rem;color:#94a3b8;margin-top:14px;line-height:1.4">Uygulama kurulu değilse önce bilgisayardaki soldaki yeşil kare kodla indirip kurun, sonra bu kare kodu tekrar okutun.</div>
      <button type="button" style="margin-top:12px;padding:8px 14px;border-radius:10px;border:1px solid #475569;background:#1e293b;color:#cbd5e1;font-weight:800">Kapat</button>
    </div>`;
    kutu.querySelector('button').onclick = () => kutu.remove();
    document.body.appendChild(kutu);
  })();
  if (/[?&]kimlik=degisti/.test(location.search)) {
    durum('⚠️ Bilgisayarın kimliği değişmiş, güvenlik için bağlanılmadı. Bilgisayardaki Mobil Bağlantı ekranının kare kodunu Barkod sayfasında okutun.', true);
  }
  // Arka planda sürekli bilgisayar arama / sürüm sinyali gönderilmez; yalnız kullanıcı butona bastığında kontrol edilir.

  if ($('pwa-uygulama-kur-btn')) {
    $('pwa-uygulama-kur-btn').addEventListener('click', async e => {
      e.preventDefault();
      if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
      if ($('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
      await mezatGuncellemeMerkeziAc();
    });
  }

  // ===== 📖 BENİ OKU, KULLANIM KILAVUZU VE SIKÇA SORULAN SORULAR (S.S.S.) REHBERİ =====
  const BENI_OKU_MADDELER = [
    {
      kategori: 'menu',
      etiket: '🖨️ Menü & Genel',
      soru: '1. Üst bardaki tuşlar ve ☰ Menü nasıl kullanılır?',
      cevap: `Ekranın en üstünde <b>🔄 Yenile</b> ve <b>☰ Menü</b> tuşları bulunur. <b>🔄 Yenile</b> listeyi bilgisayarla eşitler.<br>
        <b>☰ Menü</b> içinde: <b>👤 Kullanıcı</b>, <b>📱 Başka Telefonu Bağla (QR)</b>, <b>🔄 Programı Güncelle</b>, <b>📖 Yardım</b>, <b>☀️ Gece / Gündüz Modu</b>, <b>🖨️ Mobil &amp; BT Yazıcı</b>, <b>🏦 Barkod Veri Bankası</b>, <b>📊 Excel</b> ve <b>⏻ Programı Güvenli Kapat</b> bulunur.`
    },
    {
      kategori: 'menu',
      etiket: '🖨️ Menü & Genel',
      soru: '2. Sayfalar arasında nasıl geçiş yapılır?',
      cevap: `Ekranı parmağınızla <b>sağa veya sola kaydırarak</b> ya da en alttaki <b>3 büyük tuşa</b> dokunarak geçersiniz: <b>🎙️ Sesli Giriş · 📷 Barkod · 📋 Envanter</b>.`
    },
    {
      kategori: 'ses',
      etiket: '🎙️ Ses & Tablo',
      soru: '3. Sesle ürün girişi nasıl yapılır?',
      cevap: `<b>Sesli Giriş</b> sayfasında büyük <b>🎙️ ÜRÜN GİRİŞİ</b> tuşuna basın ve ürünü doğal şekilde söyleyin:<br>
        <i>Örnek: "V yaka tişört siyah M beden 12 adet 350 lira"</i><br>
        Bitince mikrofon tuşuna dokunun ya da yaklaşık 4 saniye susun; ürün adı, fiyat, renk, beden ve adet tabloya yazılır. Kontrol edip <b>✓ KAYDET</b>'e basın. Ses tanıma telefonun içinde çalışır; bilgisayar kapalıyken de konuşarak giriş yapabilirsiniz.`
    },
    {
      kategori: 'ses',
      etiket: '🎙️ Ses & Tablo',
      soru: '4. "Yeni Renk / Beden Ekle" tuşu nasıl çalışır?',
      cevap: `<b>⋯ Diğer İşlemler</b> menüsündedir.<br>
        • <b>Yarım Satır Varsa:</b> Tabloda bedeni veya adedi eksik kalmış bir satır varsa yeni satır açmaz; mikrofonu açarak o eksik satırı tamamlamanızı sağlar.<br>
        • <b>Satır Tamamsa:</b> Üst satırın rengini koruyarak yeni satır açar ve mikrofonu başlatır; aynı veya farklı beden/renk/adedi söyleyip ekleyebilirsiniz.`
    },
    {
      kategori: 'etiket',
      etiket: '🏷️ Etiket & Foto',
      soru: '5. Etiketten ürün bilgisi nasıl alınır?',
      cevap: `<b>Sesli Giriş</b> sayfasındaki <b>📷 ÜRÜN BİLGİSİ AL</b> tuşuna basın:<br>
        1. İsterseniz hızlı şablonlardan (<b>V Yaka, Polo Yaka, Gömlek</b> vb.) ürün cinsini seçin.<br>
        2. Etiketi çerçeveye yaklaştırıp fotoğrafı çekin.<br>
        3. Program yıkama yazılarını ayıklar, <b>ürün adını</b> ve <b>bedeni</b> tabloya yazar.<br>
        Bilgisayar kapalıyken telefon uygulaması fotoğrafı kendisi okur; ilk okumada birkaç saniye sürebilir.`
    },
    {
      kategori: 'barkod',
      etiket: '📷 Barkod',
      soru: '6. Barkod nasıl okutulur? Çift okuma koruması nasıl çalışır?',
      cevap: `<b>Barkod</b> sayfasına geçtiğinizde kamera kendiliğinden açılır:<br>
        • Barkodu kameraya tutun; okununca bip sesi gelir ve <b>ürün adı, renk, beden, fiyat ve stok</b> gösterilir.<br>
        • Üstten <b>➕ GİRİŞ</b> (stoğa ekler) ya da <b>➖ ÇIKIŞ</b> (stoktan düşer) seçin, adedi <b>− / +</b> ile ayarlayıp <b>✓ KAYDET</b>'e basın. Okutmak tek başına kayıt yapmaz.<br>
        • <b>Çift Okuma Koruması:</b> Aynı barkod yanlışlıkla ikinci kez okunmasın diye okunduktan sonra yaklaşık 3,5 saniye beklenir.`
    },
    {
      kategori: 'menu',
      etiket: '🖨️ Menü & Genel',
      soru: '7. Bilgisayar kapalıyken ve Bluetooth yazıcıyla nasıl çalışılır?',
      cevap: `Bilgisayar kapalıyken girdiğiniz ürünler telefonun kendi hafızasında bekler. <b>☰ Menü → 🖨️ Mobil &amp; BT Yazıcı</b> bölümünden eşleştirdiğiniz Bluetooth termal yazıcıdan barkod etiketi basabilirsiniz. Telefon bilgisayara yeniden bağlanınca kayıtlar kendiliğinden ya da <b>🔄 Bekleyenleri PC'ye Aktar</b> tuşuyla aktarılır.`
    },
    {
      kategori: 'menu',
      etiket: '🖨️ Menü & Genel',
      soru: '8. Program nasıl güncellenir ve güvenli şekilde nasıl kapatılır?',
      cevap: `• <b>Güncelleme:</b> Bilgisayar programı tepsi simgesinden imzalı olarak güncellenir; telefon uygulamasının yenisi de bu güncellemeyle gelir. Telefonda <b>☰ Menü → 🔄 Programı Güncelle</b> yeni sürüm olup olmadığını gösterir.<br>
        • <b>Güvenli Kapatma:</b> <b>☰ Menü</b> en altındaki <b>⏻ Programı Güvenli Kapat</b> tuşuna basın; kaydedilmemiş ürün varsa önce sorar, sonra kayıtları kaydedip kapatır.`
    }
  ];

  window.mezatYardimRehberiAc = function () {
    if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
    if ($('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');

    let modal = document.getElementById('mezat-yardim-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mezat-yardim-modal';
      modal.style.cssText = 'position:fixed;inset:0;z-index:99998;background:rgba(2,6,23,0.92);display:flex;align-items:center;justify-content:center;padding:10px';
      modal.innerHTML = `
        <div style="background:#0f172a;border:2px solid #38bdf8;border-radius:16px;max-width:660px;width:100%;max-height:92vh;display:flex;flex-direction:column;box-shadow:0 20px 50px rgba(0,0,0,0.85);color:#f8fafc;overflow:hidden">
          <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 14px;background:#1e293b;border-bottom:2px solid #334155;gap:8px">
            <div style="display:flex;align-items:center;gap:10px">
              <img src="assets/logo-3d/mezatron-3d-amblem.svg" alt="" style="width:36px;height:36px;flex-shrink:0">
              <div>
                <div style="font-size:1rem;font-weight:900;color:#ffffff">📖 Beni Oku &amp; Sıkça Sorulan Sorular</div>
                <div style="font-size:0.76rem;color:#7dd3fc;font-weight:800">Mezatron AI · Adım Adım Kullanım Kılavuzu</div>
              </div>
            </div>
            <button type="button" id="mezat-yardim-kapat-btn" style="padding:8px 14px;border-radius:10px;border:2px solid #fca5a5;background:#dc2626;color:#ffffff;font-weight:900;font-size:0.86rem;cursor:pointer;flex-shrink:0">✕ Kapat</button>
          </div>

          <div style="padding:10px 12px;background:#111c33;border-bottom:1px solid #334155;display:flex;flex-direction:column;gap:8px">
            <div style="display:flex;gap:6px;align-items:center">
              <input id="mezat-yardim-ara" type="search" placeholder="🔍 Kılavuzda ara (Örn: barkod, etiket, ses, kapat, yazıcı)…" style="flex:1;padding:8px 11px;font-size:0.88rem;border-radius:10px;border:1.5px solid #475569;background:#091020;color:#fff;font-weight:800">
              <a href="/BENI_OKU_KULLANIM_KILAVUZU.md" download="MEZATRON_BENI_OKU.md" style="padding:8px 10px;border-radius:10px;background:#059669;border:1.5px solid #6ee7b7;color:#fff;font-weight:900;font-size:0.76rem;text-decoration:none;white-space:nowrap">⬇ .MD İndir</a>
            </div>
            <div id="mezat-yardim-sekmeler" style="display:flex;gap:5px;overflow-x:auto;padding-bottom:2px">
              <button type="button" data-kat="tumu" class="yardim-sekme-btn aktif" style="padding:6px 11px;font-size:0.78rem;border-radius:999px;background:#0284c7;border:1.5px solid #7dd3fc;color:#fff;font-weight:900;white-space:nowrap">Tümü (9)</button>
              <button type="button" data-kat="ses" class="yardim-sekme-btn" style="padding:6px 11px;font-size:0.78rem;border-radius:999px;background:#1e293b;border:1.5px solid #64748b;color:#f8fafc;font-weight:900;white-space:nowrap">🎙️ Ses &amp; Tablo</button>
              <button type="button" data-kat="etiket" class="yardim-sekme-btn" style="padding:6px 11px;font-size:0.78rem;border-radius:999px;background:#1e293b;border:1.5px solid #64748b;color:#f8fafc;font-weight:900;white-space:nowrap">🏷️ Etiket &amp; Foto</button>
              <button type="button" data-kat="barkod" class="yardim-sekme-btn" style="padding:6px 11px;font-size:0.78rem;border-radius:999px;background:#1e293b;border:1.5px solid #64748b;color:#f8fafc;font-weight:900;white-space:nowrap">📷 Barkod</button>
              <button type="button" data-kat="menu" class="yardim-sekme-btn" style="padding:6px 11px;font-size:0.78rem;border-radius:999px;background:#1e293b;border:1.5px solid #64748b;color:#f8fafc;font-weight:900;white-space:nowrap">🖨️ Menü &amp; Genel</button>
            </div>
          </div>

          <div id="mezat-yardim-liste" style="padding:12px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:10px"></div>
        </div>
      `;
      document.body.appendChild(modal);

      let seciliKategori = 'tumu';
      const listeyiCiz = () => {
        const aranan = ($('mezat-yardim-ara') ? $('mezat-yardim-ara').value : '').trim().toLowerCase();
        const kutu = $('mezat-yardim-liste');
        if (!kutu) return;
        const uygunlar = BENI_OKU_MADDELER.filter(m => {
          if (seciliKategori !== 'tumu' && m.kategori !== seciliKategori) return false;
          if (!aranan) return true;
          return m.soru.toLowerCase().includes(aranan) || m.cevap.toLowerCase().includes(aranan) || m.etiket.toLowerCase().includes(aranan);
        });
        if (!uygunlar.length) {
          kutu.innerHTML = `<div style="padding:18px;text-align:center;color:#cbd5e1;font-weight:800">Aranan ifadeye uygun başlık bulunamadı.</div>`;
          return;
        }
        kutu.innerHTML = uygunlar.map(m => `
          <div style="background:#162238;border:1.5px solid #334155;border-radius:12px;padding:11px 13px">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:5px">
              <span style="font-size:0.93rem;font-weight:900;color:#38bdf8">${m.soru}</span>
              <span style="font-size:0.7rem;padding:2px 8px;border-radius:999px;background:#0f172a;border:1px solid #475569;color:#e2e8f0;font-weight:800;white-space:nowrap">${m.etiket}</span>
            </div>
            <div style="font-size:0.85rem;color:#f1f5f9;line-height:1.48;font-weight:600">${m.cevap}</div>
          </div>
        `).join('');
      };

      $('mezat-yardim-kapat-btn').addEventListener('click', () => { modal.style.display = 'none'; });
      modal.addEventListener('click', ev => { if (ev.target === modal) modal.style.display = 'none'; });
      $('mezat-yardim-ara').addEventListener('input', listeyiCiz);
      modal.querySelectorAll('.yardim-sekme-btn').forEach(b => {
        b.addEventListener('click', () => {
          seciliKategori = b.dataset.kat || 'tumu';
          modal.querySelectorAll('.yardim-sekme-btn').forEach(x => {
            const aktif = x === b;
            x.style.background = aktif ? '#0284c7' : '#1e293b';
            x.style.borderColor = aktif ? '#7dd3fc' : '#64748b';
          });
          listeyiCiz();
        });
      });
      listeyiCiz();
    } else {
      modal.style.display = 'flex';
    }
  };

  if ($('yardim-rehber-ac-btn')) {
    $('yardim-rehber-ac-btn').addEventListener('click', () => window.mezatTarayicidaAc('yardim.html'));
  }

  // ===== 📊 EXCEL'E GÖNDER / EXCEL'DEN YÜKLE / PDF YAP MERKEZİ =====
  function htmlKacis(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function a4PdfYazdirPenceresiAc(veri) {
    const satirlar = Array.isArray(veri && veri.satirlar) ? veri.satirlar : [];
    const gun = (veri && veri.gun) || new Date().toISOString().slice(0, 10);
    const trHtml = satirlar.length
      ? satirlar.map(r => `
          <tr>
            <td style="text-align:center">${htmlKacis(r.sira)}</td>
            <td style="font-weight:bold">${htmlKacis(r.urun)}</td>
            <td><code>${htmlKacis(r.barkod)}</code></td>
            <td>${htmlKacis(r.renk)}</td>
            <td style="text-align:center;font-weight:bold">${htmlKacis(r.beden)}</td>
            <td style="text-align:right;font-weight:bold">${htmlKacis(r.kalan)}</td>
            <td style="text-align:right">${htmlKacis(r.fiyat ? r.fiyat + ' TL' : '-')}</td>
            <td>${htmlKacis(r.giren)}</td>
          </tr>`).join('')
      : `<tr><td colspan="8" style="text-align:center;padding:16px">Henüz kayıt girilmedi.</td></tr>`;

    let iframe = document.getElementById('mezat-pdf-yazdir-iframe');
    if (iframe) iframe.remove();
    iframe = document.createElement('iframe');
    iframe.id = 'mezat-pdf-yazdir-iframe';
    iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
    document.body.appendChild(iframe);
    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8"><title>Mezatron Envanter Raporu - ${htmlKacis(gun)}</title>
      <style>
        body { font-family: Arial, sans-serif; color: #0f172a; margin: 18px; }
        .baslik { background: #0f172a; color: #fff; padding: 14px 16px; border-radius: 8px; margin-bottom: 12px; }
        .baslik h1 { margin: 0 0 4px 0; font-size: 16pt; }
        .baslik p { margin: 0; font-size: 10pt; color: #7dd3fc; }
        table { width: 100%; border-collapse: collapse; font-size: 9.5pt; }
        th { background: #1e293b; color: #fff; padding: 7px 6px; border: 1px solid #334155; text-align: left; }
        td { padding: 6px; border: 1px solid #cbd5e1; }
        tr:nth-child(even) td { background: #f8fafc; }
        .toplam { margin-top: 12px; font-weight: bold; font-size: 11pt; text-align: right; padding: 8px; background: #ecfdf5; border: 1px solid #10b981; border-radius: 6px; }
      </style></head><body>
      <div class="baslik">
        <h1>MEZATRON AI · SESLİ ENVANTER VE DEPO RAPORU</h1>
        <p>Tarih: ${htmlKacis(gun)} · Toplam Kalem: ${htmlKacis(veri.urunSayisi || 0)} · Toplam Stok: ${htmlKacis(veri.toplamAdet || 0)} Adet · Toplam Değer: ${veri.toplamTutar ? Number(veri.toplamTutar).toLocaleString('tr-TR') + ' TL' : '-'}</p>
      </div>
      <table>
        <thead><tr><th>No</th><th>Ürün Adı</th><th>Barkod / SKU</th><th>Renk</th><th>Beden</th><th>Adet</th><th>Fiyat</th><th>Giren</th></tr></thead>
        <tbody>${trHtml}</tbody>
      </table>
      <div class="toplam">GENEL TOPLAM: ${htmlKacis(veri.urunSayisi || 0)} Ürün Kalemi · ${htmlKacis(veri.toplamAdet || 0)} Adet ${veri.toplamTutar ? '· ' + Number(veri.toplamTutar).toLocaleString('tr-TR') + ' TL' : ''}</div>
    </body></html>`);
    doc.close();
    setTimeout(() => {
      try {
        iframe.contentWindow.focus();
        iframe.contentWindow.print();
      } catch (_) {}
    }, 250);
  }

  window.mezatExcelPdfMerkeziAc = async function (baslangicSekme = 'gonder') {
    if ($('ust-araclar-cekmece')) $('ust-araclar-cekmece').classList.add('gizli');
    if ($('araclar-menu-btn')) $('araclar-menu-btn').classList.remove('aktif');
    if (baslangicSekme === 'pdf') baslangicSekme = 'gonder';

    let modal = document.getElementById('mezat-excel-pdf-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mezat-excel-pdf-modal';
      modal.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(2,6,23,0.95);display:flex;align-items:center;justify-content:center;padding:10px';
      modal.innerHTML = `
        <div style="background:#0f172a;border:2px solid #38bdf8;border-radius:16px;max-width:600px;width:100%;max-height:92vh;display:flex;flex-direction:column;box-shadow:0 20px 50px rgba(0,0,0,0.9);color:#f8fafc;overflow:hidden">
          <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 14px;background:#1e293b;border-bottom:2px solid #334155;gap:8px">
            <div>
              <div style="font-size:1.05rem;font-weight:900;color:#ffffff">📊 Kalıcı Excel Aktarım Merkezi</div>
              <div style="font-size:0.8rem;color:#7dd3fc;font-weight:800">Excel'e Aktar · Excel'den Yükle</div>
            </div>
            <button type="button" id="mezat-ep-kapat-btn" style="padding:8px 14px;border-radius:10px;border:2px solid #fca5a5;background:#dc2626;color:#ffffff;font-weight:900;font-size:0.88rem;cursor:pointer">✕ Kapat</button>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:10px 12px;background:#111c33;border-bottom:1px solid #334155">
            <button type="button" data-ep-sekme="gonder" class="ep-sekme-btn" style="padding:11px 8px;border-radius:10px;font-weight:900;font-size:0.9rem;cursor:pointer;border:1.5px solid #6ee7b7;background:#059669;color:#fff">📤 Excel'e Aktar</button>
            <button type="button" data-ep-sekme="yukle" class="ep-sekme-btn" style="padding:11px 8px;border-radius:10px;font-weight:900;font-size:0.9rem;cursor:pointer;border:1.5px solid #64748b;background:#1e293b;color:#f8fafc">📥 Excel'den Yükle</button>
          </div>

          <div id="mezat-ep-icerik" style="padding:12px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:10px"></div>
        </div>
      `;
      document.body.appendChild(modal);
      $('mezat-ep-kapat-btn').addEventListener('click', () => { modal.style.display = 'none'; });
      modal.addEventListener('click', ev => { if (ev.target === modal) modal.style.display = 'none'; });
      modal.querySelectorAll('.ep-sekme-btn').forEach(b => {
        b.addEventListener('click', () => epSekmeGoster(b.dataset.epSekme || 'gonder'));
      });
    } else {
      modal.style.display = 'flex';
    }

    async function epSekmeGoster(sekme) {
      modal.querySelectorAll('.ep-sekme-btn').forEach(b => {
        const aktif = b.dataset.epSekme === sekme;
        if (b.dataset.epSekme === 'gonder') {
          b.style.background = aktif ? '#059669' : '#1e293b';
          b.style.borderColor = aktif ? '#6ee7b7' : '#64748b';
        } else {
          b.style.background = aktif ? '#0284c7' : '#1e293b';
          b.style.borderColor = aktif ? '#7dd3fc' : '#64748b';
        }
      });

      const kutu = $('mezat-ep-icerik');
      if (!kutu) return;
      kutu.innerHTML = `<div style="padding:20px;text-align:center;color:#7dd3fc;font-weight:800;font-size:0.95rem">⏳ Hazırlanıyor…</div>`;

      // 1. SEÇENEK: EXCEL'E AKTAR (KALICI BARKODLU ENVANTER LİSTESİ)
      if (sekme === 'gonder') {
        try {
          let r = null;
          try {
            r = await post('/api/envanter/excel-disa-aktar', {});
          } catch (_) {
            if (window.MezatMobilHibrit && typeof window.MezatMobilHibrit.yerelExcelSatirlariniCikar === 'function') {
              const y = window.MezatMobilHibrit.yerelExcelSatirlariniCikar();
              const topAdet = y.satirlar.reduce((t, s) => t + (Number(s.kalan) || 0), 0);
              const topTutar = y.satirlar.reduce((t, s) => t + (Number(s.tutar) || 0), 0);
              r = {
                success: true,
                gun: new Date().toISOString().slice(0, 10),
                urunSayisi: y.kayitlar.length,
                toplamAdet: topAdet,
                toplamTutar: Math.round(topTutar * 100) / 100,
                masaustuXlsYol: 'Masaüstü \\ Mezatron-Kalici-Envanter-Listesi.xls',
                satirlar: y.satirlar
              };
            } else {
              throw new Error('Sunucuya ulaşılamadı.');
            }
          }
          const satirlar = Array.isArray(r.satirlar) ? r.satirlar : [];
          const okunakliSatirlarHtml = satirlar.length
            ? satirlar.slice(0, 25).map(s => `
                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #334155">
                  <div style="min-width:0;flex:1">
                    <div style="font-size:0.92rem;font-weight:900;color:#ffffff">${htmlKacis(s.urun)}</div>
                    <div style="font-size:0.8rem;font-weight:700;color:#93c5fd">${htmlKacis([s.renk, s.beden].filter(Boolean).join(' · ') || 'Standart')} · ${htmlKacis(s.barkod || s.anaBarkod || '')}</div>
                  </div>
                  <div style="text-align:right;flex-shrink:0">
                    <div style="font-size:0.92rem;font-weight:900;color:#6ee7b7">${htmlKacis(s.kalan)} Adet</div>
                    <div style="font-size:0.8rem;font-weight:800;color:#fde68a">${htmlKacis(s.fiyat ? Number(s.fiyat).toLocaleString('tr-TR') + ' TL' : '-')}</div>
                  </div>
                </div>`).join('')
            : `<div style="padding:14px;text-align:center;color:#94a3b8;font-weight:800">Henüz girilmiş ürün yok.</div>`;

          kutu.innerHTML = `
            <div style="background:#064e3b;border:2px solid #34d399;border-radius:14px;padding:14px;color:#ffffff;line-height:1.45">
              <div style="font-size:1.02rem;font-weight:900;color:#6ee7b7;margin-bottom:6px">
                ✅ Kalıcı Excel Dosyası Otomatik Kaydedildi!
              </div>
              <div style="font-size:0.95rem;font-weight:800;color:#ffffff;margin-bottom:4px">
                📊 Toplam: <span style="color:#fde68a">${r.urunSayisi || 0} Ürün Çeşidi</span> · <span style="color:#fde68a">${r.toplamAdet || 0} Adet</span> ${r.toplamTutar ? '· <span style="color:#fde68a">' + Number(r.toplamTutar).toLocaleString('tr-TR') + ' TL</span>' : ''}
              </div>
              <div style="font-size:0.84rem;font-weight:700;color:#d1fae5;word-break:break-word">
                💻 Bilgisayar Masaüstüne <b>Mezatron-Kalici-Envanter-Listesi.xls</b> adıyla doğrudan kaydedildi.
              </div>
            </div>

            <a href="/api/envanter/excel?tur=xls&t=${Date.now()}" download="Mezatron-Kalici-Envanter-${htmlKacis(r.gun)}.xls" id="ep-xls-indir-link" style="display:block;padding:14px;border-radius:12px;border:2px solid #38bdf8;background:linear-gradient(135deg,#0284c7,#0369a1);color:#fff;font-weight:900;font-size:0.96rem;text-align:center;text-decoration:none">
              ⬇️ Kalıcı Excel Dosyasını (.XLS) İndir
            </a>

            <div style="background:#162238;border:1.5px solid #334155;border-radius:12px;overflow:hidden">
              <div style="padding:9px 12px;background:#1e293b;font-size:0.88rem;font-weight:900;color:#7dd3fc">
                📋 Excel'e Aktarılan Ürünler (${satirlar.length} Satır)
              </div>
              <div style="max-height:240px;overflow-y:auto">
                ${okunakliSatirlarHtml}
              </div>
            </div>
          `;
          bipSesi();
          durum(`✅ ${r.urunSayisi || 0} ürün (${r.toplamAdet || 0} adet) kalıcı Excel dosyasına aktarıldı.`);
        } catch (err) {
          kutu.innerHTML = `<div style="padding:14px;color:#fca5a5;font-weight:800;font-size:0.92rem">Excel hazırlanırken hata oluştu: ${htmlKacis(err.message)}</div>`;
        }
        return;
      }

      // 2. SEÇENEK: EXCEL'DEN YÜKLE
      if (sekme === 'yukle') {
        let dosyalar = [];
        try {
          const dRes = await fetch('/api/envanter/excel-dosyalari', { cache: 'no-store' }).then(x => x.json());
          if (dRes && Array.isArray(dRes.dosyalar)) dosyalar = dRes.dosyalar;
        } catch (_) {}

        const pcDosyaListesiHtml = dosyalar.length
          ? dosyalar.map((d, idx) => `
              <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:9px 10px;background:#0f172a;border:1.5px solid #334155;border-radius:10px">
                <div style="min-width:0;flex:1">
                  <div style="font-size:0.88rem;font-weight:900;color:#f8fafc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">📄 ${htmlKacis(d.ad)}</div>
                  <div style="font-size:0.78rem;color:#94a3b8;font-weight:700">${htmlKacis(d.konum)} · ${d.boyutKb} KB</div>
                </div>
                <button type="button" class="pc-excel-yukle-btn" data-idx="${idx}" style="padding:8px 14px;border-radius:9px;border:1.5px solid #38bdf8;background:#0284c7;color:#fff;font-weight:900;font-size:0.84rem;cursor:pointer;flex-shrink:0">📥 Yükle</button>
              </div>`).join('')
          : `<div style="font-size:0.84rem;color:#94a3b8;padding:8px;font-weight:700">Masaüstü veya İndirilenler klasöründe hazır .csv/.xls dosyası bulunamadı.</div>`;

        kutu.innerHTML = `
          <div style="background:#162238;border:1.5px solid #38bdf8;border-radius:12px;padding:12px">
            <div style="font-size:0.92rem;font-weight:900;color:#7dd3fc;margin-bottom:8px">1️⃣ Cihazdan Excel / CSV Dosyası Seçerek Yükle</div>
            <button type="button" id="ep-dosya-sec-btn" style="width:100%;padding:12px;border-radius:10px;border:2px dashed #7dd3fc;background:#0c4a6e;color:#fff;font-weight:900;font-size:0.92rem;cursor:pointer">📂 Dosya Seç (.CSV / .XLS / .TXT)</button>
          </div>

          <div style="background:#162238;border:1.5px solid #475569;border-radius:12px;padding:12px">
            <div style="font-size:0.92rem;font-weight:900;color:#a7f3d0;margin-bottom:8px">2️⃣ Bilgisayar Masaüstü / İndirilenler Klasöründen Tek Tuşla Yükle</div>
            <div style="display:flex;flex-direction:column;gap:6px;max-height:170px;overflow-y:auto">${pcDosyaListesiHtml}</div>
          </div>

          <div style="background:#162238;border:1.5px solid #475569;border-radius:12px;padding:12px">
            <div style="font-size:0.92rem;font-weight:900;color:#fde68a;margin-bottom:6px">3️⃣ Satır Yapıştırarak Hızlı Yükle</div>
            <textarea id="ep-yapistir-alan" rows="3" placeholder="Örnek: Hermes V Yaka Tişört;Siyah;M;10;450" style="width:100%;padding:9px;border-radius:9px;border:1.5px solid #475569;background:#091020;color:#fff;font-size:0.88rem;box-sizing:border-box"></textarea>
            <button type="button" id="ep-yapistir-yukle-btn" style="width:100%;margin-top:8px;padding:11px;border-radius:10px;border:2px solid #6ee7b7;background:#059669;color:#fff;font-weight:900;font-size:0.9rem;cursor:pointer">📥 Satırları Envantere Yükle</button>
          </div>
          <div id="ep-yukle-sonuc" style="font-size:0.9rem;font-weight:900;text-align:center;padding:4px"></div>
        `;

        const yuklemeSonucuIsle = async c => {
          const bilgi = $('ep-yukle-sonuc');
          if (c && c.success) {
            bipSesi();
            if (bilgi) {
              bilgi.style.color = '#6ee7b7';
              bilgi.textContent = `✅ ${c.eklenenUrunSayisi} ürün kalemi (${c.eklenenSatirSayisi} satır, toplam ${c.toplamAdet} adet) envantere ve barkod bankasına yüklendi!`;
            }
            durum(`✅ Excel'den ${c.eklenenUrunSayisi} ürün (${c.toplamAdet} adet) başarıyla yüklendi.`);
            listeSurumu = 0;
            await listeyiYenile(null, false);
            await barkodBankasiniYenile($('banka-arama') ? $('banka-arama').value : '', false);
          } else {
            if (bilgi) {
              bilgi.style.color = '#fca5a5';
              bilgi.textContent = `⚠️ ${(c && c.error) || 'Excel verisi yüklenemedi.'}`;
            }
          }
        };

        $('ep-dosya-sec-btn').addEventListener('click', () => {
          const inp = $('excel-dosya-secici-input');
          if (!inp) return;
          inp.value = '';
          inp.onchange = async () => {
            const f = inp.files && inp.files[0];
            if (!f) return;
            const baytlar = new Uint8Array(await f.arrayBuffer());
            let ikili = '';
            for (let i = 0; i < baytlar.length; i += 0x8000) ikili += String.fromCharCode.apply(null, baytlar.subarray(i, i + 0x8000));
            const c = await post('/api/envanter/excel-yukle', {
              dosyaBase64: btoa(ikili),
              dosyaAdi: f.name,
              giren: ($('giren') && $('giren').value.trim()) || 'Excel Aktarım'
            });
            await yuklemeSonucuIsle(c);
          };
          inp.click();
        });

        kutu.querySelectorAll('.pc-excel-yukle-btn').forEach(btn => {
          btn.addEventListener('click', async () => {
            const d = dosyalar[Number(btn.dataset.idx)];
            if (!d) return;
            btn.textContent = '⏳...';
            const c = await post('/api/envanter/excel-yukle', {
              dosyaYolu: d.tamYol,
              giren: ($('giren') && $('giren').value.trim()) || 'Excel Aktarım'
            });
            btn.textContent = '📥 Yükle';
            await yuklemeSonucuIsle(c);
          });
        });

        $('ep-yapistir-yukle-btn').addEventListener('click', async () => {
          const metin = ($('ep-yapistir-alan') ? $('ep-yapistir-alan').value : '').trim();
          if (!metin) {
            if ($('ep-yukle-sonuc')) {
              $('ep-yukle-sonuc').style.color = '#fca5a5';
              $('ep-yukle-sonuc').textContent = '⚠️ Lütfen önce satırları kutuya yapıştırın.';
            }
            return;
          }
          const c = await post('/api/envanter/excel-yukle', {
            icerik: metin,
            giren: ($('giren') && $('giren').value.trim()) || 'Excel Aktarım'
          });
          await yuklemeSonucuIsle(c);
        });
        return;
      }
    }

    await epSekmeGoster(baslangicSekme);
  };

  if ($('bugun-excel-gonder-btn')) {
    $('bugun-excel-gonder-btn').addEventListener('click', () => window.mezatExcelPdfMerkeziAc('gonder'));
  }
  if ($('bugun-excel-yukle-btn')) {
    $('bugun-excel-yukle-btn').addEventListener('click', () => window.mezatExcelPdfMerkeziAc('yukle'));
  }
  if ($('banka-excel-gonder-btn')) {
    $('banka-excel-gonder-btn').addEventListener('click', () => window.mezatExcelPdfMerkeziAc('gonder'));
  }
  if ($('banka-excel-yukle-btn')) {
    $('banka-excel-yukle-btn').addEventListener('click', () => window.mezatExcelPdfMerkeziAc('yukle'));
  }
  if ($('excel')) {
    $('excel').addEventListener('click', e => {
      e.preventDefault();
      window.mezatExcelPdfMerkeziAc('gonder');
    });
  }
  if ($('mobil-yerel-excel-btn')) {
    $('mobil-yerel-excel-btn').addEventListener('click', e => {
      e.preventDefault();
      window.mezatExcelPdfMerkeziAc('gonder');
    });
  }

  // =========================================================================
  // 🖼️ AKILLI GALERİ & GÖRSEL / XML SEÇİCİ MERKEZİ (Etiket, Barkod, İrsaliye)
  // =========================================================================
  window.mezatGaleriGorselUygula = async function mezatGaleriGorselUygula(mod, veriMetni) {
    if (!veriMetni) return;
    if ($('mezat-galeri-merkezi-modal')) $('mezat-galeri-merkezi-modal').remove();

    if (mod === 'irsaliye-xml') {
      if ($('irsaliye-metin')) $('irsaliye-metin').value = String(veriMetni);
      sonIrsaliyeGorseli = '';
      await irsaliyeyiSunucuyaSor('');
      return;
    }

    await new Promise(resolve => {
      const img = new Image();
      img.onload = async () => {
        try {
          if (mod === 'barkod') {
            durum('▮▯ Seçilen görseldeki barkod okunuyor…');
            await kameradanBarkodKaresiTara(img, true);
          } else if (mod === 'irsaliye') {
            const enBoy = 1280;
            const oran = Math.min(1, enBoy / Math.max(img.width, img.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(img.width * oran));
            canvas.height = Math.max(1, Math.round(img.height * oran));
            canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
            sonIrsaliyeGorseli = canvas.toDataURL('image/jpeg', 0.88);
            if ($('irsaliye-resim')) {
              $('irsaliye-resim').src = sonIrsaliyeGorseli;
              $('irsaliye-resim').classList.remove('gizli');
            }
            if ($('irsaliye-metin')) $('irsaliye-metin').value = '';
            await irsaliyeyiSunucuyaSor(sonIrsaliyeGorseli);
          } else {
            const enBoy = 1024;
            const oran = Math.min(1, enBoy / Math.max(img.width, img.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(img.width * oran));
            canvas.height = Math.max(1, Math.round(img.height * oran));
            canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
            await etiketCanvasIsle(canvas);
          }
        } catch (_) {}
        resolve();
      };
      img.onerror = () => {
        durum('Seçilen görsel yüklenemedi.', true);
        resolve();
      };
      img.src = veriMetni;
    });
  };

  window.mezatGaleriMerkeziAc = async function mezatGaleriMerkeziAc(mod = 'etiket') {
    const mevcut = $('mezat-galeri-merkezi-modal');
    if (mevcut) mevcut.remove();

    const xmlModu = mod === 'irsaliye-xml';
    const hedefInputId = xmlModu
      ? 'irsaliye-xml-dosya'
      : (mod === 'barkod' ? 'barkod-dosya' : (mod === 'irsaliye' ? 'irsaliye-dosya' : 'kamera-dosya'));
    const baslikMetin = xmlModu
      ? '📄 e-İrsaliye XML Dosyası Seçici'
      : (mod === 'barkod'
        ? '🖼️ Barkod Görseli Galerisi'
        : (mod === 'irsaliye' ? '🖼️ İrsaliye & Fiş Galerisi' : '🖼️ Etiket & Ürün Fotoğraf Galerisi'));

    const kap = document.createElement('div');
    kap.id = 'mezat-galeri-merkezi-modal';
    kap.style.cssText = 'position:fixed;inset:0;z-index:100000;background:rgba(2,6,23,0.92);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:10px;font-family:system-ui,-apple-system,sans-serif;';

    kap.innerHTML = `
      <div style="width:100%;max-width:540px;max-height:92vh;background:linear-gradient(165deg,#0f172a,#020617);border:2px solid #38bdf8;border-radius:18px;padding:14px;color:#f8fafc;box-shadow:0 24px 60px rgba(0,0,0,0.85);display:flex;flex-direction:column;overflow:hidden">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px">
          <div style="font-size:0.98rem;font-weight:900;color:#7dd3fc">${baslikMetin}</div>
          <button type="button" id="galeri-modal-kapat-btn" style="background:#b91c1c;border:1.5px solid #f87171;color:#fff;border-radius:8px;padding:4px 10px;font-size:0.82rem;font-weight:900;cursor:pointer">✕ Kapat</button>
        </div>
        <div style="display:grid;grid-template-columns:${xmlModu ? '1fr' : '1fr 1fr'};gap:8px;margin-bottom:10px">
          <label for="${hedefInputId}" id="galeri-cihazdan-sec-label" style="display:flex;align-items:center;justify-content:center;gap:6px;background:linear-gradient(135deg,#0284c7,#0369a1);border:2px solid #7dd3fc;color:#fff;padding:11px 10px;border-radius:12px;font-size:0.84rem;font-weight:900;cursor:pointer;text-align:center;margin:0">
            📂 ${xmlModu ? 'Cihazdan XML Dosyası Seç' : 'Telefon / Cihaz Galerisinden Seç'}
          </label>
          ${xmlModu ? '' : `
          <button type="button" id="galeri-canli-kamera-yakala-btn" style="background:linear-gradient(135deg,#059669,#047857);border:2px solid #6ee7b7;color:#fff;padding:11px 10px;border-radius:12px;font-size:0.84rem;font-weight:900;cursor:pointer">
            📸 Kameradan Anlık Çek
          </button>`}
        </div>
        <div id="galeri-modal-govde" style="flex:1;overflow-y:auto;padding-right:2px;font-size:0.82rem;color:#cbd5e1">
          <div style="padding:16px;text-align:center;color:#93c5fd;font-weight:800">⏳ Galeri ve kayıtlı görseller yükleniyor...</div>
        </div>
      </div>
    `;

    document.body.appendChild(kap);
    $('galeri-modal-kapat-btn').addEventListener('click', () => kap.remove());
    kap.addEventListener('click', e => { if (e.target === kap) kap.remove(); });

    if ($('galeri-canli-kamera-yakala-btn')) {
      $('galeri-canli-kamera-yakala-btn').addEventListener('click', async () => {
        kap.remove();
        if (mod === 'barkod' && $('barkod-anlik-tara-btn')) {
          $('barkod-anlik-tara-btn').click();
        } else if (mod === 'irsaliye' && $('irsaliye-canli-cek-btn')) {
          $('irsaliye-canli-cek-btn').click();
        } else if ($('etiket-canli-cek-btn')) {
          $('etiket-canli-cek-btn').click();
        }
      });
    }

    const govde = $('galeri-modal-govde');
    try {
      const r = await fetch(`/api/envanter/galeri-dosyalari?tur=${xmlModu ? 'xml' : 'gorsel'}&t=${Date.now()}`, { cache: 'no-store' }).then(x => x.json());
      const dosyalar = (r && Array.isArray(r.dosyalar)) ? r.dosyalar : [];

      if (xmlModu) {
        const xmlSatirlar = dosyalar.length
          ? dosyalar.map((d, idx) => `
              <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px 10px;background:rgba(15,23,42,0.85);border:1px solid #334155;border-radius:10px;margin-bottom:6px">
                <div style="min-width:0;flex:1">
                  <div style="font-weight:800;color:#f8fafc;font-size:0.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">📄 ${htmlKacis(d.ad)}</div>
                  <div style="font-size:0.7rem;color:#94a3b8">📂 ${htmlKacis(d.konum)} · ${d.boyutKb} KB · ${htmlKacis(d.tarih)}</div>
                </div>
                <button type="button" class="galeri-dosya-sec-btn" data-idx="${idx}" style="background:#059669;border:1px solid #6ee7b7;color:#fff;padding:6px 12px;border-radius:8px;font-size:0.76rem;font-weight:900;cursor:pointer">📥 Oku</button>
              </div>
            `).join('')
          : `<div style="padding:12px;text-align:center;color:#94a3b8;background:rgba(15,23,42,0.6);border-radius:10px">Masaüstü veya İndirilenler klasöründe .xml dosyası bulunamadı. Üstteki mavi tuştan seçebilir veya aşağıya XML metnini yapıştırabilirsiniz.</div>`;

        govde.innerHTML = `
          <div style="margin-bottom:10px">
            <div style="font-weight:900;color:#7dd3fc;margin-bottom:6px">💻 Bilgisayar Masaüstü / İndirilenler XML Dosyaları</div>
            ${xmlSatirlar}
          </div>
          <div style="background:rgba(15,23,42,0.85);border:1.5px solid #334155;border-radius:12px;padding:10px">
            <div style="font-weight:900;color:#fde68a;margin-bottom:6px">📋 Veya XML / İrsaliye Metnini Yapıştır</div>
            <textarea id="galeri-xml-yapistir-alan" rows="4" placeholder="XML veya irsaliye satırlarını buraya yapıştırın..." style="width:100%;background:#020617;border:1.5px solid #475569;border-radius:8px;color:#f8fafc;padding:8px;font-size:0.78rem;margin-bottom:8px"></textarea>
            <button type="button" id="galeri-xml-uygula-btn" style="width:100%;background:linear-gradient(135deg,#059669,#047857);border:1.5px solid #6ee7b7;color:#fff;padding:10px;border-radius:10px;font-size:0.84rem;font-weight:900;cursor:pointer">✓ Metni İrsaliyeye Aktar</button>
          </div>
        `;

        govde.querySelectorAll('.galeri-dosya-sec-btn').forEach(btn => {
          btn.addEventListener('click', async () => {
            const secilen = dosyalar[Number(btn.dataset.idx)];
            if (!secilen) return;
            btn.disabled = true;
            btn.textContent = '⏳...';
            const ok = await post('/api/envanter/galeri-dosya-oku', { id: secilen.id, tur: 'xml' });
            if (ok && ok.success && ok.xmlMetin) {
              await window.mezatGaleriGorselUygula('irsaliye-xml', ok.xmlMetin);
            } else {
              durum((ok && ok.error) || 'XML okunamadı.', true);
            }
          });
        });

        if ($('galeri-xml-uygula-btn')) {
          $('galeri-xml-uygula-btn').addEventListener('click', async () => {
            const m = ($('galeri-xml-yapistir-alan').value || '').trim();
            if (!m) return;
            await window.mezatGaleriGorselUygula('irsaliye-xml', m);
          });
        }
        return;
      }

      const kartlarHtml = dosyalar.length
        ? `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(135px,1fr));gap:8px;margin-bottom:10px">
            ${dosyalar.map((d, idx) => `
              <button type="button" class="galeri-gorsel-kart-btn" data-idx="${idx}" style="background:#0f172a;border:1.5px solid #334155;border-radius:12px;padding:6px;text-align:left;cursor:pointer;display:flex;flex-direction:column;gap:5px;color:#f8fafc">
                <div style="width:100%;height:92px;border-radius:8px;overflow:hidden;background:#020617;display:flex;align-items:center;justify-content:center">
                  <img src="/api/envanter/galeri-onizleme?id=${encodeURIComponent(d.id)}" alt="${htmlKacis(d.ad)}" loading="lazy" style="width:100%;height:100%;object-fit:cover">
                </div>
                <div style="font-size:0.74rem;font-weight:800;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%">${htmlKacis(d.ad)}</div>
                <div style="font-size:0.66rem;color:#38bdf8;font-weight:700">📂 ${htmlKacis(d.konum)} · ${d.boyutKb} KB</div>
              </button>
            `).join('')}
          </div>`
        : `<div style="padding:14px;text-align:center;color:#94a3b8;background:rgba(15,23,42,0.7);border:1px dashed #334155;border-radius:12px;margin-bottom:10px">
            Henüz kayıtlı etiket/ürün fotoğrafı yok.<br>Üstteki <b>📂 Telefon / Cihaz Galerisinden Seç</b> veya <b>📸 Kameradan Anlık Çek</b> tuşunu kullanabilirsiniz.
          </div>`;

      govde.innerHTML = `
        <div style="font-weight:900;color:#7dd3fc;margin-bottom:6px">🖼️ Kayıtlı Etiketler &amp; Bilgisayar (Masaüstü / İndirilenler) Görselleri (${dosyalar.length})</div>
        <div style="font-size:0.73rem;color:#94a3b8;margin-bottom:8px">Bir görsele dokunduğunuzda anında okunup tabloya aktarılır:</div>
        ${kartlarHtml}
      `;

      govde.querySelectorAll('.galeri-gorsel-kart-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          const secilen = dosyalar[Number(btn.dataset.idx)];
          if (!secilen) return;
          btn.style.borderColor = '#34d399';
          btn.style.opacity = '0.7';
          durum(`🖼️ "${secilen.ad}" görseli yükleniyor ve okunuyor…`);
          const ok = await post('/api/envanter/galeri-dosya-oku', { id: secilen.id, tur: 'gorsel' });
          if (ok && ok.success && ok.dataUrl) {
            await window.mezatGaleriGorselUygula(mod, ok.dataUrl);
          } else {
            durum((ok && ok.error) || 'Görsel okunamadı.', true);
          }
        });
      });
    } catch (err) {
      govde.innerHTML = `<div style="padding:12px;color:#fca5a5">Galeri listesi alınamadı: ${htmlKacis(err.message)}</div>`;
    }
  };

  if (/[?&]kurucu=1\b/i.test(window.location.search) || window.location.hash === '#kurucu') {
    setTimeout(() => envanterKurucuModuDegistir(true), 300);
  }
})();
