# 🧸 Mezatron Sektörel Barkod Bankası & Ürün Sözlüğü: Oyuncakçı & Çocuk Dünyası

Bu dosya, **Oyuncak Mağazaları, Eğitici Oyun & Hobi Merkezleri** için özel olarak hazırlanmıştır.
Beden (S/M/L/XL) gibi giyim terimleri yerine **Yaş Grupları**, **Oyuncak Kategorileri** ve **Model Varyantları** içerir.

> **Nasıl Kullanılır?**
> Mezatron menüsünden **"🧸 Oyuncakçı & Çocuk Dünyası"** sektörünü seçtiğinizde bu katalog otomatik olarak devreye girer. Hem sesli ürün girişinde yabancı oyuncak markaları %100 doğru algılanır, hem de hazır barkod bankasıyla tek tıkla ürünler sayıma ve satışa hazır hale gelir.

---

## 1. Popüler Oyuncak Markaları ve Türkçe Telaffuz Rehberi

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Ana Kategori |
| :--- | :--- | :--- |
| **Lego** | lego, leqo, legolar, leko | Yapı & İnşaat Seti |
| **Barbie** | barbi, barbie, barbi bebek, barby, baarbi | Bebek & Aksesuar |
| **Hot Wheels** | hot vils, hotvil, hat vils, hot vils araba, hotwils, hotwils araba, hatvils | Model Araç & Pist |
| **Fisher-Price** | fişır prays, fişırprays, fişer prays, fisher price, fisir prays | Eğitici Bebek Oyuncağı |
| **Play-Doh** | pley do, pley doh, pley do oyun hamuru, pleydo, play do | Oyun Hamuru & Sanat |
| **Nerf** | nörf, nerf, nerf tabanca, nörf silah | Macera & Hedef Oyunu |
| **Hasbro** | hasbro, hazbro, hesbro | Kutu Oyunu & Figür |
| **Mattel** | matel, mattel | Bebek & Figür |
| **Clementoni** | klementoni, klementoniy, clementoni | Puzzle & Bilim Seti |
| **Pilsan** | pilsan, pilsan oyuncak | Akülü Araç & Park |
| **Dede Oyuncak** | dede, dede oyuncak, fen toys | Eğitici & Plastik Oyuncak |
| **Cipsi / Cobi** | kobi, cobi, cipsi | Askeri Yapı Seti |
| **Baby Alive** | beybi alayv, beybi elayv, baby alive | Et Bebek |
| **Furby** | furbi, börbi, furby | İnteraktif Peluş |
| **Monopoly** | monopoli, monopoliy, monopoli kutu oyunu | Aile Kutu Oyunu |
| **Jenga** | cenga, jenga, cenga tahta denge oyunu | Denge Oyunu |
| **Tabu** | tabu, tabu kutu oyunu, tabu xl | Kelime Oyunu |
| **Uno** | uno, uno kartları | Kart Oyunu |
| **Scrabble** | sıkrabıl, sıkrabıl, skrabıl | Kelime Oyunu |
| **Playmobil** | pley mobil, pleymobil | Figür & Temalı Dünya |
| **Maisto** | maysto, maisto, mayisto | Model Metal Araba |
| **Bburago** | burago, bburago, burakgo | Koleksiyon Model Araç |
| **Bruder** | brudır, bruder, birudır | Gerçekçi İş Makinesi |
| **Sylvanian Families** | silvanyan femilis, silvanyan, silvanian | Minyatür Ev & Aile |
| **Lol Surprise** | lol sürprayz, lol bebek, lol surpriz | Sürpriz Bebek |
| **Paw Patrol** | pov patrol, po patrol, paw patrol figür | Çizgi Dizi Karakter Figürü |
| **Transformers** | transformırs, transformırs figür, transformır | Dönüşen Robot |
| **Marvel / Avengers** | marvel, evencırs, avenjırs, süper kahraman figür | Kahraman Figürü |
| **Hot Wheels Monster Trucks** | monstır traks, manstır trak, canavar kamyon | Büyük Tekerlekli Kamyon |
| **Carrera** | karera, carrera yarış pisti | Elektrikli Yarış Pisti |

---

## 2. Hazır Barkod Bankası & Popüler Oyuncak Ürün Listesi

| Barkod | Ürün Adı | Model / Kategori | Yaş Grubu | Tavsiye Fiyat (TL) |
| :--- | :--- | :--- | :--- | :--- |
| **MZU-OY001** | Lego Classic Yaratıcı Yapım Kutusu | Lego / Yapı | 4-99 Yaş | 750 |
| **MZU-OY002** | Lego City Polis Devriye Arabası | Lego / Yapı | 5+ Yaş | 420 |
| **MZU-OY003** | Barbie Sonsuz Hareket Sarışın Bebek | Bebek | 3+ Yaş | 680 |
| **MZU-OY004** | Hot Wheels 5'li Araba Seti | Model Araba | 3+ Yaş | 450 |
| **MZU-OY005** | Fisher-Price Eğitici Köpekçik | Eğitici Elektronik | 6-36 Ay | 890 |
| **MZU-OY006** | Play-Doh 4'lü Renkli Oyun Hamuru | Oyun Hamuru | 2+ Yaş | 140 |
| **MZU-OY007** | Nerf Elite 2.0 Commander RD-6 | Hedef & Macera | 8+ Yaş | 620 |
| **MZU-OY008** | Monopoly Türkiye Klasik Kutu Oyunu | Kutu Oyunu | 8+ Yaş | 590 |
| **MZU-OY009** | Jenga Klasik Ahşap Denge Oyunu | Denge Oyunu | 6+ Yaş | 380 |
| **MZU-OY010** | Uno Klasik Kart Oyunu | Kart Oyunu | 7+ Yaş | 120 |
| **MZU-OY011** | Clementoni 1000 Parça Manzara Puzzle | Puzzle | 10+ Yaş | 240 |
| **MZU-OY012** | Pilsan 12V Uzaktan Kumandalı Akülü Araba | Akülü Araç | 3-8 Yaş | 6850 |
| **MZU-OY013** | Sevimli Peluş Ayıcık 60 cm | Peluş Oyuncak | 0+ Yaş | 350 |
| **MZU-OY014** | Uzaktan Kumandalı Şarjlı Drift Arabası | Model Araba | 6+ Yaş | 780 |
| **MZU-OY015** | Ahşap Geometrik Şekil Eşleştirme Bultak | Eğitici Ahşap | 1-3 Yaş | 210 |
| **MZU-OY016** | Işıklı & Sesli Müzikli Çocuk Davul Seti | Müzik Aleti | 2-5 Yaş | 490 |
| **MZU-OY017** | Marvel Avengers Spider-Man 30cm Figür | Karakter Figürü | 4+ Yaş | 520 |
| **MZU-OY018** | Manyetik Manyetit Blok İnşaat Seti 64 Parça | Eğitici Set | 3+ Yaş | 580 |
| **MZU-OY019** | Dede Oyuncak Tamir Çantası Seti | Rol Oynama | 3+ Yaş | 260 |
| **MZU-OY020** | Çocuk Kameralı Mini Drone Şarjlı | Hobi & Teknoloji | 10+ Yaş | 1450 |

---

## 3. Oyuncakçılar İçin Menü ve Kategori Eşleme Kuralları

1. **Beden Yerine Yaş Grubu:** Oyuncak mağazasında XS, S, M, L yerine `0-12 Ay`, `1-3 Yaş`, `3-6 Yaş`, `6-9 Yaş`, `10+ Yaş`, `Tüm Yaşlar` kullanılır.
2. **Renk Yerine Kategori / Model:** Giyimdeki kumaş rengi yerine oyuncağın türü (`Lego`, `Peluş`, `Kutu Oyunu`, `Akülü`, `Model Araç`, `Bebek`, `Eğitici`) veya rengi (`Mavi`, `Pembe`, `Renkli`, `Kırmızı`) girilir.
3. **Tek Dokunuşla Hızlı Giriş:** Barkodu okutulan veya kutusu çekilen ürünün barkod bankasındaki adı, yaşı ve tavsiye satış fiyatı ekrana anında gelir.
