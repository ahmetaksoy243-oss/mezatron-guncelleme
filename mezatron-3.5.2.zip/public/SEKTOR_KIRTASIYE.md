# 📚 Mezatron Sektörel Barkod Bankası & Ürün Sözlüğü: Kırtasiye, Kitap & Ofis

Bu dosya, **Kırtasiye Mağazaları, Kitabevleri & Ofis Malzemesi Satıcıları** için hazırlanmıştır.
Beden yerine **Ebat (A4, A5)**, **Kalem Ucu (0.5, 0.7)**, **Sayfa Sayısı (40, 60, 96 YP)** ve **Paket Adedi** içerir.

---

## 1. Popüler Kırtasiye Markaları ve Telaffuz Rehberi

| Doğru Marka Adı | Türkçe Okunuşları ve Ses Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Faber-Castell** | faber kastel, fabır kastel, faberkastel | Kalem & Boya |
| **Scrikss** | sıkriks, skriks, scriks | Dolma & Tükenmez Kalem |
| **Rotring** | rotring, rotrink | Teknik Çizim & Kalem |
| **Gıpta** | gıpta, gipta | Defter & Ajanda |
| **Pritt** | prit, pritt yapıştırıcı | Yapıştırıcı & Düzeltici |
| **Bic** | bik, bic | Tükenmez Kalem |
| **Pelikan** | pelikan | Mürekkep & Silgi |
| **Uni-ball** | yuni bol, unibal | Jel Kalem |
| **Stabilo** | stabilo, sıtabilo | Fosforlu Kalem |
| **Adel** | adel, adel kalem | Ahşap Boya & Kurşun Kalem |

---

## 2. Hazır Barkod Bankası & Popüler Ürün Listesi

| Barkod | Ürün Adı | Tür / Çeşit | Ebat / Birim | Tavsiye Fiyat (TL) |
| :--- | :--- | :--- | :--- | :--- |
| **MZU-KR001** | Faber-Castell 12'li Kuru Boya Kalemi Tüp | RENKLİ | 12'Lİ | 145 |
| **MZU-KR002** | A4 80 gr Fotokopi Kağıdı 500'lü Paket | BEYAZ | 500'LÜ | 140 |
| **MZU-KR003** | Scrikss 0.7 Mekanik Versatil Kalem | MAVİ GÖVDE | 0.7 | 95 |
| **MZU-KR004** | Gıpta Spiralli Sert Kapak Kareli Metot Defteri | DESENLİ | 96YP | 65 |
| **MZU-KR005** | Pritt Stick Katı Yapıştırıcı 43 gr | KIRMIZI | 43G | 70 |
| **MZU-KR006** | Stabilo Boss 4'lü Pastel Fosforlu Kalem Seti | PASTEL | 4'LÜ | 165 |
| **MZU-KR007** | Rotring Tikky 0.7 Versatil Kalem | BORDO | 0.7 | 120 |
| **MZU-KR008** | Faber-Castell Sınav Silgisi Büyük Boy | BEYAZ | STD | 25 |
