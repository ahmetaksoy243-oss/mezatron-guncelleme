# 🔧 Mezatron Sektörel Barkod Bankası & Ürün Sözlüğü: Nalburiye, Hırdavat & Yapı Market

Bu dosya, **Nalbur, Hırdavatçı, Elektrik & Sıhhi Tesisat Satıcıları** için hazırlanmıştır.
Beden yerine **Metrik Ölçüler (1/2", 6mm, 10mm, 50mm)**, **Gramaj/Hacim (280ml, 1kg)** ve **Malzeme Tipi** içerir.

---

## 1. Popüler Hırdavat Markaları ve Telaffuz Rehberi

| Doğru Marka Adı | Türkçe Okunuşları ve Ses Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Bosch** | boş, bosch | Elektrikli El Aleti |
| **Makita** | makita | Şarjlı & Elektrikli |
| **Dewalt** | divalt, devalt, divolt | Profesyonel El Aleti |
| **İzeltaş** | izeltaş, izeltas | El Aletleri & Pense |
| **Selsil** | selsil | Silikon & Yapıştırıcı |
| **Bally** | bali, bally | Kontak Yapıştırıcı |
| **404** | dört yüz dört, 404 yapıştırıcı | Hızlı Yapıştırıcı |
| **Kale Kilit** | kale kilit, kale | Kilit & Güvenlik |
| **Fıratpen** | fırat pen, fırat boru | Tesisat & PVC |
| **Dyo / Marshall** | dyo, marşal, marsal | Boya & Vernik |

---

## 2. Hazır Barkod Bankası & Popüler Ürün Listesi

| Barkod | Ürün Adı | Tip / Malzeme | Ölçü / Ebat | Tavsiye Fiyat (TL) |
| :--- | :--- | :--- | :--- | :--- |
| **MZU-HD001** | Selsil Akrilik Genel Amaçlı Mastik 280ml | BEYAZ | 280ML | 55 |
| **MZU-HD002** | Selsil Çok Amaçlı Şeffaf Silikon 280ml | ŞEFFAF | 280ML | 85 |
| **MZU-HD003** | İzeltaş Yıldız Uçlu Manyetik Tornavida | KROM VANADYUM | 6X100 | 125 |
| **MZU-HD004** | İzeltaş İzoleli Elektrikçi Pensesi 180mm | ÇELİK | 180MM | 320 |
| **MZU-HD005** | Kale Kilit Sarı Pirinç Asma Kilit | PİRİNÇ | 40MM | 145 |
| **MZU-HD006** | 404 Hızlı Japon Yapıştırıcı + Aktivatör | HIZLI YAPIŞTIRICI | 200ML | 80 |
| **MZU-HD007** | Şeffaf Dayanıklı Koli Bandı 45mm x 100mt | AKRİLİK | 100MT | 42 |
| **MZU-HD008** | Plastik Tuğla Dübeli & Yıldız Vida Seti | PLASTİK | 8MM | 35 |
