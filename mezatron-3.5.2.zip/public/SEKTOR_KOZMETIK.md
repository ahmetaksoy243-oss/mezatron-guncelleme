# 💄 Mezatron Sektörel Barkod Bankası & Ürün Sözlüğü: Kozmetik, Parfüm & Kişisel Bakım

Bu dosya, **Parfümeriler, Kozmetik Mağazaları & Kişisel Bakım Merkezleri** için hazırlanmıştır.
Beden yerine **Hacim (30ML, 50ML, 100ML...)**, **Konsantrasyon (EDP, EDT, Extrait)** ve **Ürün Formu** içerir.

---

## 1. Popüler Markalar ve Telaffuz Rehberi

| Doğru Marka Adı | Türkçe Okunuşları ve Ses Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Dior** | diyor, diyor, dıor | Parfüm & Lüks |
| **Chanel** | şanel, sanel, chanel | Parfüm & Makyaj |
| **Tom Ford** | tom ford, tam ford | Niş Parfüm |
| **Nishane** | nişane, nisane | Niş Parfüm |
| **Yves Saint Laurent** | iv sen loran, ivsenloran, ysl | Parfüm & Kozmetik |
| **Armani** | armani, corco armani | Parfüm & Bakım |
| **Versace** | versaçe, vörsaçe, versace | Parfüm |
| **L'Oreal** | loreal, loreyal, l oreal | Saç & Yüz Bakım |
| **Maybelline** | meybilin, meybelin | Makyaj |
| **MAC** | mak, mek | Profesyonel Makyaj |
| **Nivea** | niveya, nivea | Cilt Bakım |
| **The Ordinary** | di ordinari, ordinari | Cilt Serumu |
| **La Roche-Posay** | la roş poze, laroş poze | Dermokozmetik |
| **CeraVe** | serave, seravi | Dermokozmetik |

---

## 2. Hazır Barkod Bankası & Popüler Ürün Listesi

| Barkod | Ürün Adı | Tür / Koku Tipi | Hacim (ML) | Tavsiye Fiyat (TL) |
| :--- | :--- | :--- | :--- | :--- |
| **MZU-KZ001** | Dior Sauvage Erkek Parfüm EDP | EDP Parfüm | 100ML | 4250 |
| **MZU-KZ002** | Chanel Bleu De Chanel Erkek Parfüm | EDP Parfüm | 100ML | 4600 |
| **MZU-KZ003** | Nishane Hacivat Extrait De Parfum | Extrait Niş | 50ML | 4950 |
| **MZU-KZ004** | Tom Ford Black Orchid Unisex Parfüm | EDP Parfüm | 50ML | 3900 |
| **MZU-KZ005** | Loreal Revitalift Hyaluronik Asit Yüz Serumu | Cilt Serumu | 30ML | 340 |
| **MZU-KZ006** | Maybelline Lash Sensational Maskara Extra Black | Maskara | STD | 240 |
| **MZU-KZ007** | MAC Mat Ruj Velvet Teddy | Ruj | STD | 680 |
| **MZU-KZ008** | La Roche-Posay Anthelios SPF50+ Güneş Kremi | Güneş Kremi | 50ML | 480 |
| **MZU-KZ009** | CeraVe Kuru Ciltler İçin Nemlendirici Krem | Nemlendirici | 340G | 390 |
| **MZU-KZ010** | Eyüp Sabri Tuncer Klasik Limon Kolonyası | Kolonya | 400ML | 95 |
