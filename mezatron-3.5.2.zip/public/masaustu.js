// Mezatron Masaüstü & Laptop Yönetim ve Baskı Merkezi
(function () {
  'use strict';

  // --- TEMEL DURUM VE DEĞİŞKENLER ---
  // Gün bilgisayarın kendi saatine göre: Türkiye'de gece 00:00-03:00 arası dün görünmesin
  const yerelGun = () => { const t = new Date(); return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`; };
  let g_gun = yerelGun();
  let g_gunKendiliginden = true; // Kullanıcı geçmiş bir gün seçmediyse gece yarısı liste yeni güne geçer
  let g_kayitlar = [];
  let g_seciliSatirlar = new Set();
  let g_odakliSatirIndex = -1;
  let g_duzenlenenUrun = null;
  let g_pwaPrompt = null;

  // Varsayılan Etiket ve Baskı Ayarları
  let g_baskiAyar = {
    yaziciTuru: 'termal-rulo',
    w: 50,
    h: 30,
    boyutAd: '50x30 mm',
    magazaAdi: localStorage.getItem('mezat_masaustu_magaza') || 'MEZATRON',
    fiyatGoster: true,
    bedenGoster: true,
    renkGoster: true,
    tarihGoster: false,
    barkodTipi: 'code128',
    kapsam: 'tek',
    kopyaModu: 'varyant'
  };

  // Özel Aktarma / Kolon Eşleme Şablonu
  const VARSAYILAN_KOLONLAR = [
    { anahtar: 'sira', ad: 'Sıra', ozelAd: 'SIRA_NO', aktif: true },
    { anahtar: 'barkod', ad: 'Barkod', ozelAd: 'BARKOD', aktif: true },
    { anahtar: 'urun', ad: 'Ürün Adı', ozelAd: 'URUN_ADI', aktif: true },
    { anahtar: 'renk', ad: 'Renk', ozelAd: 'RENK', aktif: true },
    { anahtar: 'beden', ad: 'Beden', ozelAd: 'BEDEN', aktif: true },
    { anahtar: 'adet', ad: 'Kalan Adet', ozelAd: 'MIKTAR', aktif: true },
    { anahtar: 'fiyat', ad: 'Birim Fiyat', ozelAd: 'BIRIM_FIYAT', aktif: true },
    { anahtar: 'tutar', ad: 'Toplam Tutar', ozelAd: 'TOPLAM_TUTAR', aktif: true },
    { anahtar: 'giren', ad: 'Ekleyen Personel', ozelAd: 'PERSONEL', aktif: true },
    { anahtar: 'saat', ad: 'Kayıt Saati', ozelAd: 'SAAT', aktif: true }
  ];

  let g_kolonSablonu = [];
  try {
    const kayitliSablon = localStorage.getItem('mezat_masaustu_kolon_sablonu');
    g_kolonSablonu = kayitliSablon ? JSON.parse(kayitliSablon) : JSON.parse(JSON.stringify(VARSAYILAN_KOLONLAR));
  } catch (_) {
    g_kolonSablonu = JSON.parse(JSON.stringify(VARSAYILAN_KOLONLAR));
  }

  // --- YARDIMCI ELEMENT BULUCU ---
  const $ = id => document.getElementById(id);

  function temaButonunuGuncelle() {
    const btn = $('tema-degistir-btn');
    if (!btn) return;
    const acik = document.body.classList.contains('acik-tema');
    btn.textContent = acik ? '🌙 Gece Modu' : '☀️ Gündüz Modu';
    btn.title = acik ? 'Gece Moduna Geç (Şu an: Gündüz)' : 'Gündüz Moduna Geç (Şu an: Gece)';
  }

  // --- SAYFA BAŞLANGICI ---
  window.addEventListener('DOMContentLoaded', () => {
    // Tema kontrolü (Gündüz / Gece Modu)
    const kayitliTema = localStorage.getItem('urun_girisi_tema') || 'koyu';
    if (kayitliTema === 'acik') {
      document.body.classList.add('acik-tema');
    }
    temaButonunuGuncelle();

    $('tema-degistir-btn')?.addEventListener('click', () => {
      const acik = document.body.classList.toggle('acik-tema');
      localStorage.setItem('urun_girisi_tema', acik ? 'acik' : 'koyu');
      temaButonunuGuncelle();
    });

    const seciliGunEl = $('secili-gun');
    if (seciliGunEl) {
      seciliGunEl.value = g_gun;
      // Sayfa gece açık kalırsa liste kendiliğinden yeni güne geçer
      setInterval(() => {
        if (!g_gunKendiliginden || g_gun === yerelGun()) return;
        g_gun = yerelGun();
        seciliGunEl.value = g_gun;
        verileriYukle();
      }, 60000);
      seciliGunEl.addEventListener('change', e => {
        g_gun = e.target.value || yerelGun();
        g_gunKendiliginden = g_gun === yerelGun();
        const baslikDosya = $('baslik-dosya-adi');
        if (baslikDosya) baslikDosya.textContent = `Envanter-${g_gun}.xlsx`;
        verileriYukle();
      });
    }

    // PWA Masaüstü Kurulum Denetleyicisi
    function pwaKuruluMu() {
      const standalone = window.matchMedia('(display-mode: standalone)').matches ||
                         window.matchMedia('(display-mode: window-controls-overlay)').matches ||
                         window.navigator.standalone === true ||
                         document.referrer.includes('android-app://');
      if (standalone) {
        try { localStorage.setItem('mezat_pwa_kuruldu', '1'); } catch (_) {}
        return true;
      }
      try {
        return localStorage.getItem('mezat_pwa_kuruldu') === '1';
      } catch (_) {
        return false;
      }
    }

    function pwaDurumunuGuncelle() {
      const kurulu = pwaKuruluMu();
      const ustBtn = $('pwa-kur-btn');
      const gorunumBtn = $('gorunum-pwa-kur-btn');

      if (kurulu) {
        if (ustBtn) {
          ustBtn.style.display = 'inline-flex';
          ustBtn.textContent = '✅ Windows\'ta Kurulu';
          ustBtn.title = 'Mezatron 365 uygulaması zaten bu bilgisayara kurulmuş durumda.';
          ustBtn.disabled = true;
          ustBtn.classList.remove('vurgu');
          ustBtn.style.opacity = '0.75';
          ustBtn.style.cursor = 'default';
          ustBtn.style.background = 'rgba(255, 255, 255, 0.08)';
          ustBtn.style.borderColor = 'rgba(255, 255, 255, 0.2)';
          ustBtn.style.color = '#a7f3d0';
        }
        if (gorunumBtn) {
          gorunumBtn.textContent = '✅ Program Zaten Windows\'a Kurulu (Aktif)';
          gorunumBtn.disabled = true;
          gorunumBtn.classList.remove('btn-yesil');
          gorunumBtn.classList.add('btn-ikincil');
          gorunumBtn.style.opacity = '0.75';
          gorunumBtn.style.cursor = 'default';
          gorunumBtn.title = 'Uygulama bilgisayarınıza kurulmuş ve aktif durumdadır.';
        }
      } else {
        if (ustBtn) {
          ustBtn.disabled = false;
          ustBtn.textContent = '💻 Uygulamayı Kur';
          ustBtn.classList.add('vurgu');
          ustBtn.style.opacity = '1';
          ustBtn.style.cursor = 'pointer';
          if (g_pwaPrompt) ustBtn.style.display = 'inline-flex';
        }
        if (gorunumBtn) {
          gorunumBtn.disabled = false;
          gorunumBtn.textContent = '💻 Programı Windows\'a Kur';
          gorunumBtn.classList.add('btn-yesil');
          gorunumBtn.classList.remove('btn-ikincil');
          gorunumBtn.style.opacity = '1';
          gorunumBtn.style.cursor = 'pointer';
        }
      }
    }

    pwaDurumunuGuncelle();

    window.addEventListener('beforeinstallprompt', e => {
      e.preventDefault();
      g_pwaPrompt = e;
      pwaDurumunuGuncelle();
    });

    window.addEventListener('appinstalled', () => {
      try { localStorage.setItem('mezat_pwa_kuruldu', '1'); } catch (_) {}
      g_pwaPrompt = null;
      pwaDurumunuGuncelle();
    });

    function pwaKurulumuBaslat() {
      if (pwaKuruluMu()) {
        alert('Mezatron 365 uygulaması bu bilgisayara zaten kurulu durumdadır. Masaüstündeki simgesinden doğrudan açabilirsiniz.');
        return;
      }
      if (g_pwaPrompt) {
        g_pwaPrompt.prompt();
        g_pwaPrompt.userChoice.then(res => {
          if (res.outcome === 'accepted') {
            try { localStorage.setItem('mezat_pwa_kuruldu', '1'); } catch (_) {}
            pwaDurumunuGuncelle();
          }
          g_pwaPrompt = null;
        });
      } else {
        alert('Mezatron 365 uygulamasını tarayıcınızın adres çubuğundaki "Uygulamayı Yükle / Masaüstüne Ekle" butonuna tıklayarak doğrudan bağımsız Windows / Laptop programı olarak kurabilirsiniz.');
      }
    }
    $('pwa-kur-btn')?.addEventListener('click', pwaKurulumuBaslat);
    $('gorunum-pwa-kur-btn')?.addEventListener('click', pwaKurulumuBaslat);

    // Bilgisayarda ses tanıma: tek tuşla açılır/kapanır (az bellekli bilgisayarlar için)
    async function sesMotoruDurumuGoster(veri) {
      const btn = $('gorunum-ses-motoru-btn'), not = $('gorunum-ses-motoru-not');
      if (!btn) return;
      let d = veri;
      if (!d) { try { d = await (await fetch('/api/sistem/ses-motoru', { cache: 'no-store' })).json(); } catch (_) { d = null; } }
      if (!d || !d.success) { btn.textContent = 'Okunamadı'; btn.disabled = true; return; }
      btn.disabled = false;
      btn.dataset.kapali = d.kapali ? '1' : '0';
      btn.textContent = d.kapali ? 'Kapalı — Aç' : 'Açık — Kapat';
      btn.style.borderColor = d.kapali ? '#f59e0b' : '';
      btn.style.color = d.kapali ? '#f59e0b' : '';
      if (not) {
        const bellek = d.bellekGB ? `Bu bilgisayarın belleği ${String(d.bellekGB).replace('.', ',')} GB. ` : '';
        not.textContent = d.kapali
          ? `${bellek}Kapalı: telefon uygulaması sesi kendisi çözer; tarayıcıdan bağlanan telefonlar telefonun kendi ses tanımasını kullanır.`
          : `${bellek}${d.kapatmaOnerilir ? 'Bellek az; kapatmanız önerilir. ' : ''}Açık: bilgisayar da sesi çözebilir (yaklaşık 1 GB bellek tutar).`;
      }
    }
    $('gorunum-ses-motoru-btn')?.addEventListener('click', async () => {
      const btn = $('gorunum-ses-motoru-btn');
      const kapat = btn.dataset.kapali !== '1';
      btn.disabled = true;
      btn.textContent = kapat ? 'Kapatılıyor…' : 'Açılıyor…';
      try {
        const r = await fetch('/api/sistem/ses-motoru', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kapali: kapat }) });
        const j = await r.json();
        if (!j.success) throw new Error(j.error || 'Ayar değiştirilemedi');
      } catch (e) {
        alert('Ses tanıma ayarı değiştirilemedi: ' + e.message);
      }
      sesMotoruDurumuGoster();
    });
    sesMotoruDurumuGoster();

    // Yapay zekâ hakemi (DeepSeek): müşteri isterse açılır; varsayılan kapalı
    async function hakemDurumuGoster(veri) {
      const btn = $('gorunum-hakem-btn'), not = $('gorunum-hakem-not');
      if (!btn) return;
      let d = veri;
      if (!d) { try { d = await (await fetch('/api/sistem/hakem', { cache: 'no-store' })).json(); } catch (_) { d = null; } }
      if (!d || !d.success) { btn.textContent = 'Okunamadı'; btn.disabled = true; return; }
      btn.disabled = false;
      btn.dataset.acik = d.acik ? '1' : '0';
      btn.textContent = d.acik ? 'Açık — Kapat' : 'Kapalı — Aç';
      btn.style.borderColor = d.acik ? '#f59e0b' : '';
      btn.style.color = d.acik ? '#f59e0b' : '';
      if (not) {
        not.textContent = d.acik
          ? (d.anahtarVar
            ? "Açık: anlaşılamayan sesli girişler ve ekrandaki tablo internet üzerinden DeepSeek'e (yurt dışı) gönderilir."
            : 'Açık, ama bu bilgisayarda DeepSeek anahtarı yok; hakem çalışmaz, hiçbir şey gönderilmez.')
          : 'Kapalı: hiçbir bilgi dışarı gönderilmez. Sesli giriş bilgisayarın ve telefonun kendi motorlarıyla çözülür.';
      }
    }
    $('gorunum-hakem-btn')?.addEventListener('click', async () => {
      const btn = $('gorunum-hakem-btn');
      const ac = btn.dataset.acik !== '1';
      if (ac && !confirm("Yapay zekâ hakemi açılsın mı?\n\nAçıkken anlaşılamayan sesli girişler ve ekrandaki ürün tablosu internet üzerinden DeepSeek'e (yurt dışındaki sunucu) gönderilir. Müşterinin bu konuda onayı olmalıdır.")) return;
      btn.disabled = true;
      btn.textContent = ac ? 'Açılıyor…' : 'Kapatılıyor…';
      try {
        const r = await fetch('/api/sistem/hakem', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ acik: ac }) });
        const k = await r.json();
        if (!k.success) throw new Error(k.error || 'Ayar değiştirilemedi');
      } catch (e) {
        alert('Hakem ayarı değiştirilemedi: ' + e.message);
      }
      hakemDurumuGoster();
    });
    hakemDurumuGoster();

    function tamEkranDegistir() {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    }
    $('tam-ekran-btn')?.addEventListener('click', tamEkranDegistir);
    $('gorunum-tam-ekran-btn')?.addEventListener('click', tamEkranDegistir);

    // --- SEKME GEÇİŞİ, GEÇMİŞ VE GERİ TUŞU YÖNETİMİ ---
    const g_sekmeGecmisi = ['sekme-envanter'];

    function sekmeDegistir(hedefId, gecmiseEkle = true) {
      if (!hedefId) return;
      document.querySelectorAll('.m365-sekme-btn').forEach(b => {
        if (b.dataset.hedef === hedefId) {
          b.classList.add('aktif');
        } else {
          b.classList.remove('aktif');
        }
      });
      document.querySelectorAll('.sekme-icerik').forEach(c => c.classList.remove('aktif'));

      const hedefIcerik = $(hedefId);
      if (hedefIcerik) hedefIcerik.classList.add('aktif');

      if (hedefId === 'sekme-etiket') etiketOnizlemeGuncelle();
      if (hedefId === 'sekme-rapor') raporuOlustur();

      if (gecmiseEkle) {
        if (g_sekmeGecmisi[g_sekmeGecmisi.length - 1] !== hedefId) {
          g_sekmeGecmisi.push(hedefId);
        }
      }

      dosyaMenusuKapat();
    }

    function geriGit() {
      if (g_sekmeGecmisi.length > 1) {
        g_sekmeGecmisi.pop(); // Mevcut sayfayı çıkar
        const oncekiHedef = g_sekmeGecmisi[g_sekmeGecmisi.length - 1] || 'sekme-envanter';
        sekmeDegistir(oncekiHedef, false);
      } else {
        sekmeDegistir('sekme-envanter', false);
      }
    }

    // Şerit Sekme Butonları Dinleyicileri
    document.querySelectorAll('.m365-sekme-btn[data-hedef]').forEach(btn => {
      btn.addEventListener('click', () => {
        sekmeDegistir(btn.dataset.hedef, true);
      });
    });

    // Üst Bar Geri Butonu
    $('ust-geri-btn')?.addEventListener('click', geriGit);

    // Alt Sayfaların İçindeki "Ana Sayfaya Geri Dön" Butonları
    document.querySelectorAll('.geri-don-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        sekmeDegistir('sekme-envanter', true);
      });
    });

    // --- FONKSİYONEL DOSYA AÇILIR MENÜSÜ ---
    const dosyaMenuPanel = $('dosya-acilir-menu');
    function dosyaMenusuAcKapat() {
      if (!dosyaMenuPanel) return;
      const acik = dosyaMenuPanel.style.display === 'block';
      dosyaMenuPanel.style.display = acik ? 'none' : 'block';
    }
    function dosyaMenusuKapat() {
      if (dosyaMenuPanel) dosyaMenuPanel.style.display = 'none';
    }

    $('dosya-menu-btn')?.addEventListener('click', e => {
      e.stopPropagation();
      dosyaMenusuAcKapat();
    });

    document.addEventListener('click', e => {
      if (dosyaMenuPanel && dosyaMenuPanel.style.display === 'block') {
        if (!e.target.closest('#dosya-acilir-menu') && !e.target.closest('#dosya-menu-btn')) {
          dosyaMenusuKapat();
        }
      }
    });

    // --- F5 / TAM SİSTEM VE SAYFA YENİLEME ---
    function tamSistemYenile() {
      try {
        sessionStorage.setItem('mezat_hizli_yenile_v1', '1');
        const aktifBtn = document.querySelector('.m365-sekme-btn.aktif');
        const aktifHedef = aktifBtn?.dataset?.hedef || 'sekme-envanter';
        sessionStorage.setItem('mezat_aktif_sekme', aktifHedef);
      } catch (_) {}

      const hizliBtn = $('hizli-yenile-btn');
      if (hizliBtn) hizliBtn.style.animation = 'spinDonme 0.6s linear infinite';
      const seritBtnIkon = $('yenile-btn')?.querySelector('.ikon');
      if (seritBtnIkon) seritBtnIkon.style.animation = 'spinDonme 0.6s linear infinite';

      masaustuToastGoster('Sistem ve veriler yenileniyor…', 'bilgi');

      setTimeout(() => {
        const urlTemiz = window.location.pathname;
        window.location.href = urlTemiz + '?hizli_yenile=1&t=' + Date.now();
      }, 100);
    }

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        dosyaMenusuKapat();
        modalKapat();
        mobilBaglantiModaliniKapat();
        kullaniciYonetimModaliniKapat();
      } else if (e.key === 'F5') {
        e.preventDefault();
        tamSistemYenile();
      }
    });

    // Dosya Menüsü İçerisindeki Fonksiyonlar
    $('dm-excel-indir')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      excelIndir();
    });
    $('dm-excel-yukle-input')?.addEventListener('change', e => {
      dosyaMenusuKapat();
      excelYukle(e);
    });
    $('dm-a4-yazdir')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      a4ListeYazdir();
    });
    $('dm-yedek-indir')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      yedekJsonIndir();
    });
    $('dm-firma-profili')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      firmaProfiliModalAc();
    });
    $('firma-profil-btn')?.addEventListener('click', firmaProfiliModalAc);
    $('ust-cep-modu-btn')?.addEventListener('click', mobilBaglantiModaliniAc);
    $('ust-yonetici-btn')?.addEventListener('click', kullaniciYonetimModaliniAc);
    $('el-terminali-btn')?.addEventListener('click', elTerminaliModaliniAc);
    $('dm-sistem-tam-yedek')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      sistemTamYedegiIndir();
    });
    $('dm-rehber-ac')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      masaustuKullanimKilavuzunuAc();
    });
    $('dm-guvenli-kapat')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      guvenliSistemiKapat();
    });
    $('dm-baski-istasyonu')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      sekmeDegistir('sekme-etiket', true);
    });
    $('dm-canli-mezat')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      canliMezataGonder();
    });
    $('dm-ozel-erp')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      sekmeDegistir('sekme-aktarim', true);
    });
    $('dm-rapor')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      sekmeDegistir('sekme-rapor', true);
    });
    $('dm-yenile')?.addEventListener('click', () => {
      dosyaMenusuKapat();
      tamSistemYenile();
    });
    $('dm-kapat')?.addEventListener('click', dosyaMenusuKapat);

    $('serit-rapor-btn')?.addEventListener('click', () => {
      sekmeDegistir('sekme-rapor', true);
    });
    $('rapor-tazele-btn')?.addEventListener('click', async () => {
      await verileriYukle();
      raporuOlustur();
      masaustuToastGoster('Rapor verileri başarıyla tazelendi!');
    });
    $('rapor-yazdir-btn')?.addEventListener('click', raporYazdir);
    $('rapor-excel-indir-btn')?.addEventListener('click', raporExcelIndir);
    $('rapor-urun-ara')?.addEventListener('input', raporModelFiltrele);

    $('hizli-yenile-btn')?.addEventListener('click', () => {
      tamSistemYenile();
    });
    $('hizli-yeni-btn')?.addEventListener('click', () => modalAc(null));
    $('serit-etiket-istasyonu-btn')?.addEventListener('click', () => {
      sekmeDegistir('sekme-etiket', true);
    });
    $('serit-canli-aktar-btn')?.addEventListener('click', canliMezataGonder);
    $('gorunum-tema-btn')?.addEventListener('click', () => $('tema-degistir-btn')?.click());

    $('rehber-ac-btn')?.addEventListener('click', masaustuKullanimKilavuzunuAc);
    $('guvenli-cikis-btn')?.addEventListener('click', guvenliSistemiKapat);
    $('serit-rehber-btn')?.addEventListener('click', masaustuKullanimKilavuzunuAc);
    $('serit-guvenli-kapat-btn')?.addEventListener('click', guvenliSistemiKapat);
    $('gorunum-rehber-btn')?.addEventListener('click', masaustuKullanimKilavuzunuAc);
    $('gorunum-tam-yedek-btn')?.addEventListener('click', sistemTamYedegiIndir);
    $('gorunum-guvenli-kapat-btn')?.addEventListener('click', guvenliSistemiKapat);

    // Arama ve filtreler
    $('tablo-arama')?.addEventListener('input', tabloyuCiz);
    $('filtre-beden')?.addEventListener('change', tabloyuCiz);
    $('filtre-renk')?.addEventListener('change', tabloyuCiz);
    $('yenile-btn')?.addEventListener('click', () => {
      tamSistemYenile();
    });

    // Tümünü seç
    $('tumunu-sec-chk')?.addEventListener('change', e => {
      if (e.target.checked) {
        duzlestirilmisSatirlar().forEach((s, idx) => g_seciliSatirlar.add(idx));
      } else {
        g_seciliSatirlar.clear();
      }
      seciliSayilariGuncelle();
      tabloyuCiz();
    });

    // Buton aksiyonları
    $('yeni-urun-btn')?.addEventListener('click', () => modalAc(null));
    $('excel-indir-btn')?.addEventListener('click', excelIndir);
    $('excel-yukle-input')?.addEventListener('change', excelYukle);
    $('a4-yazdir-btn')?.addEventListener('click', a4ListeYazdir);
    $('secili-duzenle-btn')?.addEventListener('click', () => {
      const satirlar = duzlestirilmisSatirlar();
      if (!satirlar.length) {
        alert('Düzenlenecek ürün bulunamadı. Lütfen önce ürün ekleyin.');
        return;
      }
      let hedefIdx = -1;
      if (g_seciliSatirlar.size > 0) {
        hedefIdx = [...g_seciliSatirlar][0];
      } else if (g_odakliSatirIndex >= 0 && g_odakliSatirIndex < satirlar.length) {
        hedefIdx = g_odakliSatirIndex;
      } else {
        hedefIdx = 0;
      }
      if (satirlar[hedefIdx]) modalAc(satirlar[hedefIdx].anaKayit, satirlar[hedefIdx].satirIndex);
      else modalAc(null);
    });
    $('secili-sil-btn')?.addEventListener('click', async () => {
      if (!g_seciliSatirlar.size) {
        alert('Lütfen silmek istediğiniz satırları seçin.');
        return;
      }
      if (!confirm(`Seçilen ${g_seciliSatirlar.size} ürünü silmek istediğinize emin misiniz?`)) return;
      const satirlar = duzlestirilmisSatirlar();
      for (const idx of g_seciliSatirlar) {
        if (satirlar[idx]) await urunSil(satirlar[idx].id, satirlar[idx].satirIndex);
      }
      g_seciliSatirlar.clear();
      seciliSayilariGuncelle();
      verileriYukle();
    });

    $('toplu-etiket-btn')?.addEventListener('click', () => {
      document.querySelector('[data-hedef="sekme-etiket"]')?.click();
      const seciliRadio = document.querySelector('input[name="baski-kapsam"][value="secililer"]');
      if (seciliRadio) seciliRadio.checked = true;
      g_baskiAyar.kapsam = 'secililer';
      etiketOnizlemeGuncelle();
    });

    // Etiket İstasyonu Boyut Seçiciler
    document.querySelectorAll('.boyut-kart').forEach(kart => {
      kart.addEventListener('click', () => {
        document.querySelectorAll('.boyut-kart').forEach(k => k.classList.remove('aktif'));
        kart.classList.add('aktif');
        const w = kart.dataset.w;
        const h = kart.dataset.h;
        if (w === 'ozel') {
          $('ozel-boyut-satir').style.display = 'flex';
          g_baskiAyar.w = Number($('ozel-genislik').value) || 50;
          g_baskiAyar.h = Number($('ozel-yukseklik').value) || 30;
          g_baskiAyar.boyutAd = `${g_baskiAyar.w}x${g_baskiAyar.h} mm (Özel)`;
        } else if (w === 'a4') {
          $('ozel-boyut-satir').style.display = 'none';
          g_baskiAyar.w = 210;
          g_baskiAyar.h = 297;
          g_baskiAyar.boyutAd = 'A4 Tabaka (24 Etiket)';
        } else {
          $('ozel-boyut-satir').style.display = 'none';
          g_baskiAyar.w = Number(w);
          g_baskiAyar.h = Number(h);
          g_baskiAyar.boyutAd = `${w}x${h} mm`;
        }
        $('aktif-boyut-metin').textContent = g_baskiAyar.boyutAd;
        $('kpi-yazici').textContent = g_baskiAyar.boyutAd;
        etiketOnizlemeGuncelle();
      });
    });

    $('ozel-genislik')?.addEventListener('input', e => {
      g_baskiAyar.w = Number(e.target.value) || 50;
      g_baskiAyar.boyutAd = `${g_baskiAyar.w}x${g_baskiAyar.h} mm (Özel)`;
      etiketOnizlemeGuncelle();
    });
    $('ozel-yukseklik')?.addEventListener('input', e => {
      g_baskiAyar.h = Number(e.target.value) || 30;
      g_baskiAyar.boyutAd = `${g_baskiAyar.w}x${g_baskiAyar.h} mm (Özel)`;
      etiketOnizlemeGuncelle();
    });

    // Etiket Detay Kontrolleri
    $('etiket-firma-adi')?.addEventListener('input', e => {
      g_baskiAyar.magazaAdi = e.target.value.trim();
      localStorage.setItem('mezat_masaustu_magaza', g_baskiAyar.magazaAdi);
      etiketOnizlemeGuncelle();
    });
    $('chk-fiyat')?.addEventListener('change', e => { g_baskiAyar.fiyatGoster = e.target.checked; etiketOnizlemeGuncelle(); });
    $('chk-beden')?.addEventListener('change', e => { g_baskiAyar.bedenGoster = e.target.checked; etiketOnizlemeGuncelle(); });
    $('chk-renk')?.addEventListener('change', e => { g_baskiAyar.renkGoster = e.target.checked; etiketOnizlemeGuncelle(); });
    $('chk-tarih')?.addEventListener('change', e => { g_baskiAyar.tarihGoster = e.target.checked; etiketOnizlemeGuncelle(); });
    $('barkod-tipi')?.addEventListener('change', e => { g_baskiAyar.barkodTipi = e.target.value; etiketOnizlemeGuncelle(); });
    $('baski-kopya-modu')?.addEventListener('change', e => { g_baskiAyar.kopyaModu = e.target.value; });

    document.querySelectorAll('input[name="baski-kapsam"]').forEach(r => {
      r.addEventListener('change', e => {
        g_baskiAyar.kapsam = e.target.value;
        etiketOnizlemeGuncelle();
      });
    });

    $('simdi-yazdir-btn')?.addEventListener('click', baskiCalistir);

    // Modal butonları
    $('modal-kapat-btn')?.addEventListener('click', modalKapat);
    $('modal-iptal-btn')?.addEventListener('click', modalKapat);
    $('modal-kaydet-btn')?.addEventListener('click', modalKaydet);

    // Özel Aktarım Arayüzü
    kolonEslemeTablosuCiz();
    $('sablon-varsayilan-btn')?.addEventListener('click', () => {
      g_kolonSablonu = JSON.parse(JSON.stringify(VARSAYILAN_KOLONLAR));
      localStorage.removeItem('mezat_masaustu_kolon_sablonu');
      kolonEslemeTablosuCiz();
    });
    $('sablon-kaydet-btn')?.addEventListener('click', () => {
      localStorage.setItem('mezat_masaustu_kolon_sablonu', JSON.stringify(g_kolonSablonu));
      $('aktarim-durum-mesaj').textContent = '✅ Kolon şablonu tarayıcı hafızasına güvenle kaydedildi!';
      setTimeout(() => { $('aktarim-durum-mesaj').textContent = ''; }, 3500);
    });
    $('ozel-aktar-indir-btn')?.addEventListener('click', ozelAktarimDosyasiIndir);
    $('mezatron-canli-aktar-btn')?.addEventListener('click', canliMezataGonder);

    // İlk verileri sunucudan çek
    verileriYukle();
    lisansDurumuKontrolEt();
    acilisAnimasyonuBaslat();

    // Yenileme sonrası aktif sekmeyi geri yükle
    try {
      const sonAktifSekme = sessionStorage.getItem('mezat_aktif_sekme');
      if (sonAktifSekme && sonAktifSekme !== 'sekme-envanter') {
        sessionStorage.removeItem('mezat_aktif_sekme');
        setTimeout(() => sekmeDegistir(sonAktifSekme, false), 80);
      }
    } catch (_) {}
  });

  // --- AÇILIŞ ANİMASYONU (6 SANİYE SİNEMATİK LOGO VE VİTRİN) ---
  let acilisSayacTimer = null;
  function acilisAnimasyonuBaslat() {
    const ekran = $('mezat-acilis-ekrani');
    if (!ekran) return;

    // Hızlı yenileme parametresi veya session kontrolü
    const hizliYenile = /[?&]hizli_yenile=1\b/.test(window.location.search || '') || sessionStorage.getItem('mezat_hizli_yenile_v1') === '1';
    if (hizliYenile) {
      try { sessionStorage.removeItem('mezat_hizli_yenile_v1'); } catch (_) {}
      ekran.classList.add('acilis-bitti');
      ekran.style.display = 'none';
      if (window.history && window.history.replaceState) {
        window.history.replaceState({}, document.title, window.location.pathname);
      }
      setTimeout(() => {
        masaustuToastGoster('✅ Sistem ve veriler başarıyla yenilendi!');
      }, 350);
      return;
    }

    ekran.style.display = 'flex';
    ekran.classList.remove('acilis-bitti');
    const cubuk = $('mezat-acilis-cubuk');
    const durumEl = $('mezat-acilis-durum');
    const TOPLAM_SANIYE = 6;
    let kalan = TOPLAM_SANIYE;

    const asamalar = {
      6: '🚀 Mezatron 365 Masaüstü Envanter Merkezi başlatılıyor…',
      5: '🛡️ Güvenlik zırhı ve veritabanı kontrol ediliyor…',
      4: '📊 Microsoft 365 Excel arayüzü ve şerit hazırlanıyor…',
      3: '🖨️ Termal rulo ve lazer barkod şablonları yükleniyor…',
      2: '🔄 Canlı Mezat Yayın Köprüsü ve ERP formatları senkronize ediliyor…',
      1: '✅ Sistem hazır! Masaüstü çalışma paneli açılıyor…'
    };

    if (cubuk) cubuk.style.width = '12%';
    if (durumEl) durumEl.textContent = `${asamalar[6]} (${kalan} sn)`;

    if (acilisSayacTimer) clearInterval(acilisSayacTimer);
    acilisSayacTimer = setInterval(() => {
      kalan -= 1;
      if (kalan > 0) {
        const yuzde = Math.min(98, Math.round(((TOPLAM_SANIYE - kalan) / TOPLAM_SANIYE) * 100) + 12);
        if (cubuk) cubuk.style.width = `${yuzde}%`;
        const metin = asamalar[kalan] || '🚀 Sistem hazırlanıyor…';
        if (durumEl) durumEl.textContent = `${metin} (${kalan} sn)`;
      } else {
        clearInterval(acilisSayacTimer);
        acilisSayacTimer = null;
        if (cubuk) cubuk.style.width = '100%';
        if (durumEl) durumEl.textContent = '✅ Sistem hazır!';
        ekran.classList.add('acilis-bitti');
        setTimeout(() => {
          ekran.style.display = 'none';
        }, 450);
      }
    }, 1000);
  }

  // --- M365 TOAST BİLDİRİMİ ---
  function masaustuToastGoster(mesaj, tur = 'basari') {
    let eski = document.querySelector('.m365-toast');
    if (eski) eski.remove();
    const toast = document.createElement('div');
    toast.className = 'm365-toast';
    if (tur === 'hata') {
      toast.style.background = '#991b1b';
      toast.style.borderColor = '#f87171';
    } else if (tur === 'bilgi') {
      toast.style.background = '#0369a1';
      toast.style.borderColor = '#38bdf8';
    }
    const simge = tur === 'hata' ? '⚠️' : (tur === 'bilgi' ? 'ℹ️' : '✅');
    toast.innerHTML = `<span style="font-size:1.15rem">${simge}</span><span>${mesaj}</span>`;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-8px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 320);
    }, 2800);
  }

  // --- 1. VERİLERİ SUNUCUDAN YÜKLE ---
  async function verileriYukle() {
    try {
      const yanit = await fetch(`/api/envanter?gun=${encodeURIComponent(g_gun)}&t=${Date.now()}`);
      if (!yanit.ok) throw new Error('Sunucu hatası: ' + yanit.status);
      const veri = await yanit.json();
      g_kayitlar = Array.isArray(veri.kayitlar) ? veri.kayitlar : [];
      g_seciliSatirlar.clear();
      filtreleriGuncelle();
      tabloyuCiz();
      kpiGuncelle();
      etiketOnizlemeGuncelle();
      if ($('sekme-rapor')?.classList.contains('aktif')) raporuOlustur();
      const durumEl = document.querySelector('.m365-kayit-durum');
      if (durumEl) {
        const simdi = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        durumEl.textContent = `🟢 Güncel (${simdi})`;
      }
      return g_kayitlar;
    } catch (e) {
      console.error('Envanter yüklenemedi:', e);
      const govde = $('tablo-govde');
      if (govde) govde.innerHTML = `<tr><td colspan="12" style="text-align:center; padding:24px; color:#f87171">⚠️ Veri yüklenemedi (${e.message}). Bağlantıyı kontrol edin.</td></tr>`;
      throw e;
    }
  }

  // --- DÜZLEŞTİRİLMİŞ SATIR LİSTESİ ---
  function duzlestirilmisSatirlar() {
    const sonuc = [];
    let sira = 0;
    g_kayitlar.forEach(k => {
      if (!k || !k.urun || !String(k.urun).trim() || k.urun.toLocaleLowerCase('tr-TR') === 'isimsiz ürün') return;
      const satirlar = (Array.isArray(k.satirlar) && k.satirlar.length)
        ? k.satirlar.filter(Boolean)
        : [];
      if (!satirlar.length) return;
      satirlar.forEach((s, sIndex) => {
        sira++;
        const adet = Math.max(0, Number(s.adet) || 0);
        const fiyat = Number(k.fiyat) || 0;
        const barkod = s.barkod || k.barkod || 'MZU-0001';
        let beden = String(s.beden || k.beden || '').trim();
        // Eğer satırda beden boşsa ama barkod varyant son eki içeriyorsa (-L, -M, -S, -XL, -XXL, -42)
        if (!beden && barkod) {
          const m = barkod.match(/-(XS|S|M|L|XL|XXL|3XL|4XL|5XL|\d{2,3})$/i);
          if (m) beden = m[1].toUpperCase();
        }
        let renk = String(s.renk || k.renk || '').trim();
        sonuc.push({
          sira,
          id: k.id,
          satirIndex: sIndex,
          urun: k.urun || 'İsimsiz Ürün',
          barkod,
          renk,
          beden,
          adet,
          fiyat,
          tutar: adet * fiyat,
          giren: k.giren || 'Personel',
          saat: k.saat || (k.guncelleme ? new Date(k.guncelleme).toLocaleTimeString('tr-TR').slice(0, 5) : '--:--'),
          anaKayit: k,
          satirVeri: s
        });
      });
    });
    return sonuc;
  }

  // --- FİLTRELERİ GÜNCELLE ---
  function filtreleriGuncelle() {
    const bedenler = new Set();
    const renkler = new Set();
    duzlestirilmisSatirlar().forEach(s => {
      if (s.beden) bedenler.add(s.beden.toUpperCase());
      if (s.renk) renkler.add(s.renk.toUpperCase());
    });

    const bedenSelect = $('filtre-beden');
    if (bedenSelect) {
      const secili = bedenSelect.value;
      bedenSelect.innerHTML = '<option value="">Tüm Bedenler</option>' +
        [...bedenler].sort().map(b => `<option value="${b}">${b}</option>`).join('');
      bedenSelect.value = secili;
    }

    const renkSelect = $('filtre-renk');
    if (renkSelect) {
      const secili = renkSelect.value;
      renkSelect.innerHTML = '<option value="">Tüm Renkler</option>' +
        [...renkler].sort().map(r => `<option value="${r}">${r}</option>`).join('');
      renkSelect.value = secili;
    }
  }

  // --- TABLOYU ÇİZ ---
  function tabloyuCiz() {
    const govde = $('tablo-govde');
    if (!govde) return;

    const arama = ($('tablo-arama')?.value || '').toLowerCase().trim();
    const filtreBeden = ($('filtre-beden')?.value || '').toUpperCase().trim();
    const filtreRenk = ($('filtre-renk')?.value || '').toUpperCase().trim();

    const tumSatirlar = duzlestirilmisSatirlar();
    const filtrelenmis = tumSatirlar.filter(s => {
      if (filtreBeden && s.beden.toUpperCase() !== filtreBeden) return false;
      if (filtreRenk && s.renk.toUpperCase() !== filtreRenk) return false;
      if (arama) {
        const metin = `${s.barkod} ${s.urun} ${s.renk} ${s.beden} ${s.giren}`.toLowerCase();
        if (!metin.includes(arama)) return false;
      }
      return true;
    });

    if (!filtrelenmis.length) {
      govde.innerHTML = `<tr><td colspan="12" style="text-align:center; padding:32px; color:var(--yazi-soluk)">Kriterlere uygun kayıt bulunamadı.</td></tr>`;
      return;
    }

    govde.innerHTML = filtrelenmis.map(s => {
      const secili = g_seciliSatirlar.has(s.sira - 1);
      return `
        <tr class="${secili ? 'secili' : ''}" data-sira="${s.sira - 1}">
          <td style="text-align:center">
            <input type="checkbox" class="satir-sec-chk" data-sira="${s.sira - 1}" ${secili ? 'checked' : ''}>
          </td>
          <td style="color:var(--yazi-soluk); font-weight:700">${s.sira}</td>
          <td><span class="rozet-barkod">${s.barkod}</span></td>
          <td class="urun-adi-hucre">${s.urun}</td>
          <td style="min-width:100px; font-weight:700">${s.renk ? `<span class="hucre-renk">${s.renk}</span>` : '<span style="color:var(--yazi-soluk); opacity:0.5">—</span>'}</td>
          <td style="min-width:80px; text-align:center; font-weight:800">${s.beden ? `<span class="hucre-beden">${s.beden}</span>` : '<span style="color:var(--yazi-soluk); opacity:0.5">—</span>'}</td>
          <td class="adet-hucre">${s.adet}</td>
          <td class="fiyat-hucre">${s.fiyat ? `${s.fiyat} TL` : '—'}</td>
          <td class="tutar-hucre">${s.tutar ? `${s.tutar} TL` : '0 TL'}</td>
          <td class="personel-hucre">${s.giren}</td>
          <td class="saat-hucre">${s.saat}</td>
          <td style="text-align:center">
            <div style="display:inline-flex; gap:4px">
              <button type="button" class="btn btn-sari satir-etiket-btn" data-sira="${s.sira - 1}" style="padding:4px 8px; font-size:0.75rem" title="Etiket Bas">🖨️</button>
              <button type="button" class="btn btn-birincil satir-duzenle-btn" data-id="${s.id}" data-satir="${s.satirIndex}" style="padding:4px 8px; font-size:0.75rem" title="Düzenle">✏️</button>
              <button type="button" class="btn btn-tehlike satir-sil-btn" data-id="${s.id}" data-satir="${s.satirIndex}" style="padding:4px 8px; font-size:0.75rem" title="Sil">🗑️</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    // Satır seçim eventleri
    govde.querySelectorAll('.satir-sec-chk').forEach(chk => {
      chk.addEventListener('change', e => {
        const idx = Number(e.target.dataset.sira);
        if (e.target.checked) g_seciliSatirlar.add(idx);
        else g_seciliSatirlar.delete(idx);
        seciliSayilariGuncelle();
        tabloyuCiz();
      });
    });

    govde.querySelectorAll('.satir-etiket-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        const idx = Number(btn.dataset.sira);
        g_seciliSatirlar.clear();
        g_seciliSatirlar.add(idx);
        seciliSayilariGuncelle();
        document.querySelector('[data-hedef="sekme-etiket"]')?.click();
        etiketOnizlemeGuncelle();
      });
    });

    govde.querySelectorAll('.satir-duzenle-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        const satirIndex = Number(btn.dataset.satir);
        const urun = g_kayitlar.find(k => k.id === id);
        if (urun) modalAc(urun, satirIndex);
      });
    });

    govde.querySelectorAll('.satir-sil-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        const satirIndex = Number(btn.dataset.satir);
        if (!confirm('Bu ürünü / varyantı envanterden silmek istediğinize emin misiniz?')) return;
        await urunSil(id, satirIndex);
      });
    });

    // Satıra tıklayınca satırı odakla ve Excel Hücre Ad Kutusunu Güncelle (örn: B1, B2)
    govde.querySelectorAll('tr').forEach(tr => {
      tr.addEventListener('click', e => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON') return;
        const siraStr = tr.dataset.sira;
        if (siraStr != null && siraStr !== '') {
          g_odakliSatirIndex = Number(siraStr);
        }
        const sira = tr.querySelector('td:nth-child(2)')?.textContent || '1';
        const hucreAd = $('hucre-ad-kutusu');
        if (hucreAd) hucreAd.textContent = `B${sira}`;
      });

      // Çift tıklamayla doğrudan düzenleme penceresini aç
      tr.addEventListener('dblclick', e => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON') return;
        const duzenleBtn = tr.querySelector('.satir-duzenle-btn');
        if (duzenleBtn) duzenleBtn.click();
      });
    });
  }

  function seciliSayilariGuncelle() {
    const sayi = g_seciliSatirlar.size;
    if ($('secili-sayi')) $('secili-sayi').textContent = sayi;
    if ($('baski-secili-sayi')) $('baski-secili-sayi').textContent = sayi;
  }

  // --- KPI ÖZETLERİNİ GÜNCELLE ---
  function kpiGuncelle() {
    const satirlar = duzlestirilmisSatirlar();
    let toplamAdet = 0;
    let toplamTutar = 0;
    satirlar.forEach(s => {
      toplamAdet += s.adet;
      toplamTutar += s.tutar;
    });

    $('kpi-cesit').textContent = `${g_kayitlar.length} Çeşit`;
    $('kpi-adet').textContent = `${toplamAdet.toLocaleString('tr-TR')} Adet`;
    $('kpi-tutar').textContent = `${toplamTutar.toLocaleString('tr-TR')} TL`;
  }

  // --- 2. BARKOD & ETİKET BASKI İSTASYONU ---
  function etiketOnizlemeGuncelle() {
    const onizlemeKutu = $('fiziksel-etiket-onizleme');
    if (!onizlemeKutu) return;

    const satirlar = duzlestirilmisSatirlar();
    let hedefSatir = satirlar[0] || {
      urun: 'BIGAZZI TRIKO KAZAK',
      barkod: 'MZU-10001',
      renk: 'SİYAH',
      beden: 'L',
      fiyat: 750,
      adet: 1
    };

    // Eğer seçili olan varsa ilk seçileni göster
    if (g_seciliSatirlar.size > 0) {
      const ilkIndex = [...g_seciliSatirlar][0];
      if (satirlar[ilkIndex]) hedefSatir = satirlar[ilkIndex];
    }

    const { w, h, magazaAdi, fiyatGoster, bedenGoster, renkGoster, tarihGoster, barkodTipi } = g_baskiAyar;
    
    // Önizleme kutusunu milimetrik oranda boyutlandır (1mm ~ 3.78px ekran ölçeği)
    const olcek = 3.6;
    onizlemeKutu.style.width = `${Math.min(520, Math.max(160, w * olcek))}px`;
    onizlemeKutu.style.minHeight = `${Math.min(380, Math.max(100, h * olcek))}px`;

    // Barkod SVG'si üret
    let barkodHtml = '';
    if (barkodTipi === 'qr' && typeof QRCode !== 'undefined') {
      const qrDiv = document.createElement('div');
      try {
        new QRCode(qrDiv, { text: hedefSatir.barkod, width: 80, height: 80 });
        barkodHtml = qrDiv.innerHTML;
      } catch (_) {
        barkodHtml = `<b style="font-size:0.8rem">${hedefSatir.barkod}</b>`;
      }
    } else if (window.MezatBarkod && typeof window.MezatBarkod.svg === 'function') {
      try {
        barkodHtml = window.MezatBarkod.svg(hedefSatir.barkod, { yukseklik: Math.max(28, h * 1.1), metinGoster: false });
      } catch (_) {
        barkodHtml = `<b style="font-size:0.9rem">${hedefSatir.barkod}</b>`;
      }
    } else {
      barkodHtml = `<b style="font-size:0.9rem">${hedefSatir.barkod}</b>`;
    }

    onizlemeKutu.innerHTML = `
      ${magazaAdi ? `<div style="text-align:center; font-size:0.75rem; font-weight:900; letter-spacing:0.5px; border-bottom:1px solid #ccc; padding-bottom:2px; margin-bottom:4px; text-transform:uppercase">${magazaAdi}</div>` : ''}
      <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:6px">
        <span style="font-weight:900; font-size:1.05rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap">${hedefSatir.urun}</span>
        ${bedenGoster && hedefSatir.beden ? `<span style="border:2px solid #000; font-weight:900; font-size:1.15rem; padding:0 4px; border-radius:3px">${hedefSatir.beden}</span>` : ''}
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin:3px 0; font-size:0.85rem">
        <span>${renkGoster && hedefSatir.renk ? hedefSatir.renk : 'STANDART'}</span>
        ${fiyatGoster && hedefSatir.fiyat ? `<b style="font-size:1.1rem">${hedefSatir.fiyat} TL</b>` : ''}
      </div>
      <div style="flex:1; display:flex; align-items:center; justify-content:center; min-height:0; margin:4px 0">
        ${barkodHtml}
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; font-size:0.75rem; font-weight:700">
        <span style="letter-spacing:1px; flex:1; text-align:center">${hedefSatir.barkod}</span>
        ${tarihGoster ? `<span style="font-size:0.68rem; color:#444">${new Date().toLocaleDateString('tr-TR')}</span>` : ''}
      </div>
    `;
  }

  // --- BASKIYI ÇALIŞTIR (@media print) ---
  function baskiCalistir() {
    const baskiAlani = $('masaustu-baski-alani');
    if (!baskiAlani) return;

    const satirlar = duzlestirilmisSatirlar();
    let basilacaklar = [];

    if (g_baskiAyar.kapsam === 'secililer' && g_seciliSatirlar.size > 0) {
      basilacaklar = [...g_seciliSatirlar].map(idx => satirlar[idx]).filter(Boolean);
    } else if (g_baskiAyar.kapsam === 'tumu') {
      basilacaklar = satirlar;
    } else {
      // Tek ürün
      const ilkIndex = g_seciliSatirlar.size > 0 ? [...g_seciliSatirlar][0] : 0;
      if (satirlar[ilkIndex]) basilacaklar = [satirlar[ilkIndex]];
    }

    if (!basilacaklar.length) {
      alert('Yazdırılacak ürün bulunamadı. Lütfen tablodan seçim yapın.');
      return;
    }

    // Kopya modu: stok adedi kadar mı yoksa 1 adet mi?
    const etiketListesi = [];
    basilacaklar.forEach(item => {
      const kopya = g_baskiAyar.kopyaModu === 'stok-adeti' ? Math.max(1, Math.min(200, item.adet)) : 1;
      for (let i = 0; i < kopya; i++) {
        etiketListesi.push(item);
      }
    });

    const { w, h, magazaAdi, fiyatGoster, bedenGoster, renkGoster, tarihGoster } = g_baskiAyar;

    // Sayfa boyutu stilini dinamik enjekte et
    const stilEl = $('dinamik-sayfa-baski-stili');
    if (stilEl) {
      stilEl.textContent = `
        @media print {
          @page { size: ${w}mm ${h}mm; margin: 0; }
          .baski-sayfa-etiket {
            width: ${w}mm;
            height: ${h}mm;
            padding: 2.2mm 2.8mm;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            overflow: hidden;
            background: #fff;
            color: #000;
            page-break-after: always;
            break-after: page;
          }
          .baski-sayfa-etiket:last-child { page-break-after: auto; break-after: auto; }
        }
      `;
    }

    baskiAlani.innerHTML = etiketListesi.map(item => {
      let bHtml = '';
      if (window.MezatBarkod && typeof window.MezatBarkod.svg === 'function') {
        bHtml = window.MezatBarkod.svg(item.barkod, { yukseklik: Math.max(26, h * 1.1), metinGoster: false });
      } else {
        bHtml = `<b>${item.barkod}</b>`;
      }
      return `
        <div class="baski-sayfa-etiket">
          ${magazaAdi ? `<div style="text-align:center; font-size:6.5pt; font-weight:900; letter-spacing:0.5px; border-bottom:0.5px solid #000; padding-bottom:1px; margin-bottom:1mm; text-transform:uppercase">${magazaAdi}</div>` : ''}
          <div style="display:flex; justify-content:space-between; align-items:center; gap:2mm">
            <span style="font-weight:900; font-size:9.5pt; white-space:nowrap; overflow:hidden; text-overflow:ellipsis">${item.urun}</span>
            ${bedenGoster && item.beden ? `<span style="border:1.5px solid #000; font-weight:900; font-size:11pt; padding:0 1.2mm">${item.beden}</span>` : ''}
          </div>
          <div style="display:flex; justify-content:space-between; font-size:8pt; font-weight:700">
            <span>${renkGoster && item.renk ? item.renk : 'STANDART'}</span>
            ${fiyatGoster && item.fiyat ? `<b>${item.fiyat} TL</b>` : ''}
          </div>
          <div style="flex:1; display:flex; align-items:center; justify-content:center; min-height:0">
            ${bHtml}
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center; font-size:7.5pt; font-weight:800">
            <span style="flex:1; text-align:center">${item.barkod}</span>
            ${tarihGoster ? `<span style="font-size:6.5pt">${new Date().toLocaleDateString('tr-TR')}</span>` : ''}
          </div>
        </div>
      `;
    }).join('');

    setTimeout(() => {
      window.print();
    }, 150);
  }

  // --- 3. EXCEL / A4 İŞLEMLERİ ---
  function excelIndir() {
    window.location.href = `/api/envanter/excel?gun=${encodeURIComponent(g_gun)}&tur=xls&t=${Date.now()}`;
  }

  async function excelYukle(e) {
    const dosya = e.target.files && e.target.files[0];
    if (!dosya) return;
    const okuyucu = new FileReader();
    okuyucu.onload = async () => {
      try {
        const baytlar = new Uint8Array(okuyucu.result);
        let ikili = '';
        for (let i = 0; i < baytlar.length; i += 0x8000) ikili += String.fromCharCode.apply(null, baytlar.subarray(i, i + 0x8000));
        const resp = await fetch('/api/envanter/excel-yukle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ dosyaBase64: btoa(ikili), dosyaAdi: dosya.name, gun: g_gun, giren: 'Masaüstü Excel' })
        });
        const res = await resp.json();
        if (res.success) {
          alert(`✅ Excel yüklendi: ${res.eklenenUrunSayisi || 0} ürün, ${res.eklenenSatirSayisi || 0} satır, toplam ${res.toplamAdet || 0} adet.`);
          verileriYukle();
        } else {
          alert('Excel yüklenemedi: ' + (res.error || 'Bilinmeyen hata'));
        }
      } catch (err) {
        alert('Hata: ' + err.message);
      }
    };
    okuyucu.readAsArrayBuffer(dosya);
    e.target.value = '';
  }

  function a4ListeYazdir() {
    window.open(`/api/envanter/pdf?gun=${encodeURIComponent(g_gun)}&t=${Date.now()}`, '_blank');
  }

  // --- 4. ÖZEL AKTARMA & MUHASEBE FORMAT DÜZENLEYİCİ ---
  function kolonEslemeTablosuCiz() {
    const kapsayici = $('kolon-esleme-listesi');
    if (!kapsayici) return;

    kapsayici.innerHTML = g_kolonSablonu.map((k, idx) => `
      <div class="kolon-esleme-satir">
        <input type="checkbox" class="kolon-aktif-chk" data-idx="${idx}" ${k.aktif ? 'checked' : ''}>
        <span style="font-weight:700; width:130px; font-size:0.84rem; color:var(--yazi-ana)">${k.ad}</span>
        <span style="color:var(--yazi-soluk)">➔</span>
        <input type="text" class="kolon-ozel-ad" data-idx="${idx}" value="${k.ozelAd}" placeholder="Özel Başlık" style="flex:1; padding:4px 8px; font-size:0.8rem">
      </div>
    `).join('');

    kapsayici.querySelectorAll('.kolon-aktif-chk').forEach(chk => {
      chk.addEventListener('change', e => {
        const idx = Number(e.target.dataset.idx);
        g_kolonSablonu[idx].aktif = e.target.checked;
      });
    });

    kapsayici.querySelectorAll('.kolon-ozel-ad').forEach(inp => {
      inp.addEventListener('input', e => {
        const idx = Number(e.target.dataset.idx);
        g_kolonSablonu[idx].ozelAd = e.target.value.trim() || g_kolonSablonu[idx].ad;
      });
    });
  }

  function ozelAktarimDosyasiIndir() {
    const seciliBicim = document.querySelector('input[name="aktar-bicim"]:checked')?.value || 'xlsx';
    const satirlar = duzlestirilmisSatirlar();
    const aktifKolonlar = g_kolonSablonu.filter(k => k.aktif);

    if (!aktifKolonlar.length) {
      alert('Lütfen en az bir kolon seçin.');
      return;
    }

    if (seciliBicim === 'json') {
      const veriJson = satirlar.map(s => {
        const oge = {};
        aktifKolonlar.forEach(k => {
          oge[k.ozelAd] = s[k.anahtar];
        });
        return oge;
      });
      dosyaIndir(`Mezatron-Envanter-${g_gun}.json`, JSON.stringify(veriJson, null, 2), 'application/json');
      return;
    }

    const ayirici = seciliBicim === 'csv-tr' ? ';' : (seciliBicim === 'csv-virgul' ? ',' : '\t');
    const baslikSatiri = aktifKolonlar.map(k => `"${k.ozelAd}"`).join(ayirici);
    const veriSatirlari = satirlar.map(s => aktifKolonlar.map(k => `"${String(s[k.anahtar] ?? '').replace(/"/g, '""')}"`).join(ayirici));
    const metin = '\uFEFF' + [baslikSatiri, ...veriSatirlari].join('\r\n');

    if (seciliBicim === 'xlsx') {
      dosyaIndir(`Mezatron-Ozel-Envanter-${g_gun}.xls`, metin, 'application/vnd.ms-excel;charset=utf-8');
    } else {
      dosyaIndir(`Mezatron-Ozel-Envanter-${g_gun}.csv`, metin, 'text/csv;charset=utf-8');
    }
  }

  function dosyaIndir(ad, icerik, mime) {
    const blob = new Blob([icerik], { type: mime });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = ad;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  function yedekJsonIndir() {
    try {
      const yedekPaketi = {
        yazilim: 'Mezatron Envanter 365 Masaüstü',
        tarih: g_gun,
        olusturulma: new Date().toISOString(),
        toplamUrunCesidi: g_kayitlar.length,
        kayitlar: g_kayitlar,
        baskiAyarlari: g_baskiAyar,
        kolonSablonu: g_kolonSablonu
      };
      const jsonStr = JSON.stringify(yedekPaketi, null, 2);
      dosyaIndir(`Mezatron-Envanter-Yedek-${g_gun}.json`, jsonStr, 'application/json;charset=utf-8');
    } catch (e) {
      alert('Yedek indirilemedi: ' + e.message);
    }
  }

  function sistemTamYedegiIndir() {
    // Sunucudan tüm verileri, barkodları ve ayarları içeren tek paket JSON dosyasını çeker
    try {
      window.location.href = '/api/sistem/tam-yedek-indir';
    } catch (e) {
      alert('Tam sistem yedeği indirilemedi: ' + e.message);
    }
  }

  // --- 4. GÜVENLİ KAPATMA & ANINDA YEDEKLEME MOTORU ---
  let g_kapanisSayacTimer = null;
  async function guvenliSistemiKapat() {
    const onay = confirm(
      '⚠️ PROGRAMI GÜVENLİ KAPATMAK ÜZERESİNİZ\n\n' +
      'Kapatılırken:\n' +
      '1. Tüm envanter kayıtları kaydedilecek,\n' +
      '2. Barkod bankası ve sistem ayarlarının canlı yedeği alınacak,\n' +
      '3. Sistem güvenle kapatma moduna geçecektir.\n\n' +
      'Devam etmek ve sistemi güvenle kapatmak istiyor musunuz?'
    );
    if (!onay) return;

    // 1. Ekranı Kapanış Vitrinine hazırla
    const acilisEkrani = $('mezat-acilis-ekrani');
    const durumEl = $('mezat-acilis-durum');
    const cubuk = $('mezat-acilis-cubuk');

    if (acilisEkrani) {
      acilisEkrani.style.display = 'flex';
      acilisEkrani.classList.remove('acilis-bitti');
      if (cubuk) {
        cubuk.style.background = 'linear-gradient(90deg, #f59e0b, #10b981)';
        cubuk.style.width = '100%';
      }
      if (durumEl) {
        durumEl.innerHTML = '💾 <b>Sistem ve tüm dosyaların yedeği alınıyor…</b> Lütfen bekleyiniz.';
      }
    }

    // 2. Sunucuya zorunlu canlı yedekleme emri ver
    try {
      const resp = await fetch('/api/sistem/guvenli-kapat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gun: g_gun })
      });
      const res = await resp.json();
      console.log('Güvenli yedek sonucu:', res);
    } catch (err) {
      console.warn('Güvenli yedekleme isteği:', err.message);
    }

    // 3. Kapanış sayacını (6 saniye) başlat ve güvenli şekilde kapat
    const KAPANIS_SURESI_SN = 6;
    let kalanSn = KAPANIS_SURESI_SN;

    if (g_kapanisSayacTimer) clearInterval(g_kapanisSayacTimer);
    g_kapanisSayacTimer = setInterval(() => {
      kalanSn -= 1;
      if (kalanSn > 0) {
        const yuzde = Math.max(0, Math.round((kalanSn / KAPANIS_SURESI_SN) * 100));
        if (cubuk) cubuk.style.width = `${yuzde}%`;
        if (durumEl) {
          durumEl.innerHTML = `✅ <b>Tüm veriler ve sistem yedeği başarıyla alındı.</b><br>${kalanSn} saniye içinde güvenle kapanıyor…`;
        }
      } else {
        clearInterval(g_kapanisSayacTimer);
        if (cubuk) cubuk.style.width = '0%';
        if (durumEl) {
          durumEl.innerHTML = '⏻ <b>Sistem güvenle kapatıldı.</b><br><small style="color:#94a3b8">Pencereyi kapatabilir veya masaüstü kısayolundan tekrar açabilirsiniz.</small>';
        }

        // Pencereyi kapatmayı dene (PWA / Standalone / Web)
        try { window.close(); } catch (_) {}
      }
    }, 1000);
  }

  // --- 5. MASAÜSTÜ KULLANIM KILAVUZU & SSS REHBERİ (MOBİL İLE BİREBİR EŞLEŞİK) ---
  const BENI_OKU_MADDELER = [
    {
      kategori: 'yedek',
      etiket: '🛡️ Güvenlik & Yedek',
      soru: '1. Sistem verilerini ne sıklıkla yedeklemeliyim? Verilerim nasıl korunur?',
      cevap: `• <b>Otomatik Yedek:</b> Program arka planda her 5 dakikada bir (veri değiştiyse) ve her 10 yeni kayıtta bir, bozulup bozulmadığı denetlenebilen bir yedek alır.<br>
        • <b>⏻ Güvenli Kapatma:</b> Üst bardaki veya Dosya menüsündeki kırmızı <b>⏻ Güvenli Kapat</b> tuşuna bastığınızda tüm envanter, barkod bankası ve ayarların son kopyası otomatik yedeklenir.<br>
        • <b>Tavsiye Edilen Yedekleme Disiplini:</b><br>
        - <b>Günlük Yedekleme:</b> Gün sonunda <code>📁 Dosya</code> -> <b>💾 Tam Veritabanı Yedeği Al</b> veya <b>📥 Excel İndir</b> yaparak yedeği USB belleğe veya Google Drive / OneDrive bulutuna kopyalayınız.<br>
        - <b>Haftalık Arşivleme:</b> Haftanın son günü <code>📁 Dosya</code> -> <b>📦 Sistem &amp; Dosyaların Tam Kopyasını İndir</b> seçeneğiyle tarihli bir arşiv klasörü oluşturunuz.`
    },
    {
      kategori: 'menu',
      etiket: '🖨️ Menü & Ekran',
      soru: '2. Bilgisayar ekranı ve üst menü nasıl kullanılır?',
      cevap: `Bilgisayar ekranı Excel tablosuna benzer:<br>
        • <b>⬅ Geri:</b> Bir önceki ekrana veya ana sayfaya döner.<br>
        • <b>📁 Dosya:</b> Excel indirme/yükleme, A4 liste yazdırma, tam yedek alma, Barkod &amp; Termal Etiket İstasyonu ve Canlı Mezat Köprüsü burada.<br>
        • <b>🏠 Giriş (Ana Sayfa):</b> Tüm ürün listesini, arama ve süzme araçlarını gösteren ana ekrandır.<br>
        • <b>Görünüm &amp; Ayarlar:</b> Tema (gece/gündüz), tam ekran ve <b>🎙️ Bilgisayarda Ses Tanıma</b> düğmesi buradadır.`
    },
    {
      kategori: 'barkod',
      etiket: '🔒 Barkod & Güvenlik',
      soru: '3. Barkod değiştirilebilir mi? Yapılan düzenlemeler diğer cihazlara nasıl yansır?',
      cevap: `• <b>Barkod Kilitlidir:</b> Ürün bir kez kaydedilip barkod üretildiğinde o barkod numarası sabittir ve değiştirilemez. Böylece Barkod Bankası ile basılmış etiketler birbirini tutar.<br>
        • <b>İsim, Fiyat, Renk, Beden ve Adet Düzenlenebilir:</b> Düzenlediğiniz anda hem envanter hem de <b>Barkod Bankası</b> güncellenir. O barkod telefonda okutulduğunda en son bilgiler gelir.`
    },
    {
      kategori: 'etiket',
      etiket: '🏷️ Baskı İstasyonu',
      soru: '4. Barkod etiketleri masaüstünden ve telefondan nasıl yazdırılır?',
      cevap: `• <b>Bilgisayar / Barkod İstasyonu:</b> <code>🖨️ Barkod Baskı</code> sekmesinden ya da <code>📁 Dosya</code> → <b>Barkod &amp; Termal Etiket İstasyonu</b>'ndan 50x30 mm, 80x50 mm termal rulo etiket ve A4 tabaka etiket basabilirsiniz.<br>
        • <b>Telefon:</b> Menü → <b>🖨️ Mobil &amp; BT Yazıcı</b> bölümünden taşınabilir Bluetooth termal yazıcıyla 50x30 mm veya 80x50 mm etiket basılabilir.`
    },
    {
      kategori: 'mobil',
      etiket: '📱 Telefon & PC',
      soru: '5. Bilgisayar kapalıyken telefondan girilen ürünler kaybolur mu?',
      cevap: `Hayır. Telefon uygulaması bilgisayar kapalıyken de çalışır ve sesi kendisi çözer. Girilen ürünler telefonun kendi hafızasında bekler. Telefon bilgisayara yeniden bağlandığında kendiliğinden ya da telefonda Menü → <b>🖨️ Mobil &amp; BT Yazıcı</b> → <b>🔄 Bekleyenleri PC'ye Aktar</b> tuşuyla bilgisayara gönderilir.<br>
        • Etiket ve irsaliye fotoğrafından okuma şimdilik yalnız telefon bilgisayara bağlıyken çalışır.`
    },
    {
      kategori: 'ses',
      etiket: '🎙️ Ses Tanıma',
      soru: '6. Bilgisayar yavaşsa ses tanımayı kapatabilir miyim?',
      cevap: `Evet. <b>Görünüm &amp; Ayarlar</b> → <b>🎙️ Bilgisayarda Ses Tanıma</b> düğmesiyle bilgisayardaki ses tanıma kapatılır. Belleği az (örneğin 4 GB) bilgisayarlarda program hızlanır. Kapalıyken telefon uygulaması sesi kendisi çözmeye devam eder.`
    },
    {
      kategori: 'guncelleme',
      etiket: '🔄 Güncelleme',
      soru: '7. Program nasıl güncellenir?',
      cevap: `Güncellemeler imzalı olarak gelir. Ekranın sağ altındaki <b>Mezatron tepsi simgesine</b> sağ tıklayın: <b>Güncellemeleri denetle</b> yeni sürümü arar; yeni sürüm varsa <b>Güncelleme var — kur</b> seçeneğiyle kurulur. İnternet yoksa <b>Güncelleme dosyası yükle (USB)</b> kullanılabilir. Yeni sürüm açılmazsa program önceki sürüme kendiliğinden döner; verileriniz etkilenmez. Telefon uygulamasının yenisi de bu güncellemeyle bilgisayara gelir.`
    },
    {
      kategori: 'lisans',
      etiket: '🎫 Lisans',
      soru: '8. Kaç kişi kullanabilir?',
      cevap: `Standart lisans <b>3 kullanıcı</b> içindir (lisans sahibi + 2 çalışan). Daha fazla kullanıcı için lisans kodu gerekir; kod <b>Kullanıcı &amp; PIN</b> bölümündeki <b>🔑 Lisansı Aktifleştir</b> ile girilir. İlk hesap (lisans sahibi) dükkan bilgisayarından açılır; sonraki hesaplar lisans sahibi onaylayınca giriş yapabilir.`
    }
  ];

  function masaustuKullanimKilavuzunuAc() {
    let modal = $('mezat-yardim-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mezat-yardim-modal';
      modal.style.cssText = 'position:fixed;inset:0;z-index:99998;background:rgba(2,6,23,0.85);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:16px';
      modal.innerHTML = `
        <div style="background:#0f172a;border:2px solid #38bdf8;border-radius:14px;max-width:760px;width:100%;max-height:90vh;display:flex;flex-direction:column;box-shadow:0 25px 60px rgba(0,0,0,0.85);color:#f8fafc;overflow:hidden">
          <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 18px;background:#1e293b;border-bottom:2px solid #334155;gap:12px">
            <div style="display:flex;align-items:center;gap:12px">
              <span style="font-size:1.8rem">📖</span>
              <div>
                <div style="font-size:1.05rem;font-weight:900;color:#ffffff">Mezatron AI · Masaüstü Kullanım Kılavuzu &amp; Veri Güvenliği</div>
                <div style="font-size:0.78rem;color:#7dd3fc;font-weight:700">Günlük &amp; Haftalık Yedekleme Disiplini, Barkod Bankası ve İş Akışları</div>
              </div>
            </div>
            <button type="button" id="myk-kapat-btn" style="padding:6px 14px;border-radius:8px;border:1px solid #f87171;background:#dc2626;color:#ffffff;font-weight:900;font-size:0.86rem;cursor:pointer">✕ Kapat</button>
          </div>

          <div style="padding:10px 16px;background:#111c33;border-bottom:1px solid #334155;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <input id="myk-arama" type="search" placeholder="🔍 Kılavuzda ara (Örn: yedek, barkod, kapat, excel, etiket)…" style="flex:1;min-width:240px;padding:8px 12px;font-size:0.84rem;border-radius:8px;border:1.5px solid #475569;background:#091020;color:#fff;font-weight:700">
            <button type="button" id="myk-tam-yedek-btn" style="padding:7px 12px;border-radius:8px;background:#059669;border:1.5px solid #6ee7b7;color:#fff;font-weight:800;font-size:0.78rem;cursor:pointer">💾 Şimdi Tam Yedek Al</button>
            <a href="/BENI_OKU_KULLANIM_KILAVUZU.md" download="MEZATRON_BENI_OKU.md" style="padding:7px 12px;border-radius:8px;background:#0284c7;border:1.5px solid #7dd3fc;color:#fff;font-weight:800;font-size:0.78rem;text-decoration:none;white-space:nowrap">⬇ .MD Kılavuz İndir</a>
          </div>

          <div id="myk-liste" style="padding:16px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:12px"></div>

          <div style="padding:10px 16px;background:#091020;border-top:1px solid #334155;display:flex;justify-content:space-between;align-items:center;font-size:0.78rem;color:#94a3b8">
            <span>🛡️ Otomatik Yedekleme: <b>Aktif (5 dk / 10 kayıt)</b></span>
            <span style="color:#e2e8f0;font-weight:700">Mezatron AI · Sesli Envanter Asistanı v3.4</span>
          </div>
        </div>
      `;
      document.body.appendChild(modal);

      const listeyiCiz = () => {
        const aranan = ($('myk-arama') ? $('myk-arama').value : '').trim().toLowerCase();
        const kutu = $('myk-liste');
        if (!kutu) return;
        const uygunlar = BENI_OKU_MADDELER.filter(m => {
          if (!aranan) return true;
          return m.soru.toLowerCase().includes(aranan) || m.cevap.toLowerCase().includes(aranan) || m.etiket.toLowerCase().includes(aranan);
        });
        if (!uygunlar.length) {
          kutu.innerHTML = '<div style="padding:24px;text-align:center;color:#94a3b8;font-weight:800">Aramanıza uygun bir kılavuz başlığı bulunamadı.</div>';
          return;
        }
        kutu.innerHTML = uygunlar.map(m => `
          <div style="background:#162238;border:1.5px solid #334155;border-radius:10px;padding:14px">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:6px">
              <span style="font-size:0.95rem;font-weight:900;color:#38bdf8">${m.soru}</span>
              <span style="font-size:0.72rem;padding:2px 8px;border-radius:999px;background:#0f172a;border:1px solid #475569;color:#e2e8f0;font-weight:800;white-space:nowrap">${m.etiket}</span>
            </div>
            <div style="font-size:0.86rem;color:#f1f5f9;line-height:1.55;font-weight:500">${m.cevap}</div>
          </div>
        `).join('');
      };

      $('myk-kapat-btn')?.addEventListener('click', () => { modal.style.display = 'none'; });
      modal.addEventListener('click', ev => { if (ev.target === modal) modal.style.display = 'none'; });
      $('myk-arama')?.addEventListener('input', listeyiCiz);
      $('myk-tam-yedek-btn')?.addEventListener('click', sistemTamYedegiIndir);
      listeyiCiz();
    } else {
      modal.style.display = 'flex';
    }
  }

  async function canliMezataGonder() {
    try {
      const resp = await fetch('/api/mezatron/kopru-aktar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gun: g_gun })
      });
      const res = await resp.json();
      if (res.success) {
        alert('🎉 Envanter başarıyla Canlı Mezat Yayın sistemine (Port 3001) aktarıldı!');
      } else {
        alert('Aktarım uyarısı: ' + (res.error || 'Port 3001 açık olmayabilir.'));
      }
    } catch (e) {
      alert('Canlı Mezat Köprüsü hatası: ' + e.message);
    }
  }

  // --- 5. MODAL (YENİ ÜRÜN & DÜZENLEME) ---
  function modalAc(urun, satirIndex = 0) {
    g_duzenlenenUrun = urun ? {
      ...urun,
      aktifSatirIndex: satirIndex,
      surum: urun.surum || 1,
      gun: urun.gun || g_gun,
      giren: urun.giren || localStorage.getItem('urun_girisi_giren') || 'Masaüstü Yönetici'
    } : null;
    const modal = $('urun-modal');
    if (!modal) return;

    const barkodInp = $('modal-barkod');
    const barkodLabel = $('modal-barkod-label');
    const barkodIpucu = $('modal-barkod-ipucu');

    if (urun) {
      $('modal-baslik-yazi').textContent = '✏️ Ürünü Düzenle';
      $('modal-urun-adi').value = urun.urun || '';
      $('modal-fiyat').value = urun.fiyat != null ? urun.fiyat : '';
      const s = (urun.satirlar && urun.satirlar[satirIndex]) || {};
      const mevcutBarkod = s.barkod || urun.barkod || '';
      if (barkodInp) {
        barkodInp.value = mevcutBarkod;
        barkodInp.readOnly = true;
        barkodInp.style.background = 'rgba(15, 23, 42, 0.45)';
        barkodInp.style.color = '#94a3b8';
        barkodInp.style.cursor = 'not-allowed';
      }
      if (barkodLabel) {
        barkodLabel.innerHTML = 'Barkod No: <span style="font-size:0.72rem; color:#fde047; font-weight:800">🔒 Sabit (Değiştirilemez)</span>';
      }
      if (barkodIpucu) barkodIpucu.style.display = 'block';

      $('modal-renk').value = s.renk || urun.renk || '';
      let bedenDegeri = String(s.beden || urun.beden || '').trim();
      if (!bedenDegeri && mevcutBarkod) {
        const m = mevcutBarkod.match(/-(XS|S|M|L|XL|XXL|3XL|4XL|5XL|\d{2,3})$/i);
        if (m) bedenDegeri = m[1].toUpperCase();
      }
      $('modal-beden').value = bedenDegeri;
      $('modal-adet').value = s.adet || 1;
    } else {
      $('modal-baslik-yazi').textContent = '➕ Yeni Ürün Ekle';
      $('modal-urun-adi').value = '';
      $('modal-fiyat').value = '';
      if (barkodInp) {
        barkodInp.value = 'MZU-' + Math.floor(10000 + Math.random() * 90000);
        barkodInp.readOnly = false;
        barkodInp.style.background = '';
        barkodInp.style.color = '';
        barkodInp.style.cursor = '';
      }
      if (barkodLabel) barkodLabel.textContent = 'Barkod No:';
      if (barkodIpucu) barkodIpucu.style.display = 'none';

      $('modal-renk').value = '';
      $('modal-beden').value = '';
      $('modal-adet').value = 1;
    }

    modal.style.display = 'flex';
  }

  function modalKapat() {
    const modal = $('urun-modal');
    if (modal) modal.style.display = 'none';
    g_duzenlenenUrun = null;
  }

  async function modalKaydet() {
    const urunAdi = $('modal-urun-adi').value.trim();
    if (!urunAdi) {
      alert('Lütfen ürün adını girin.');
      return;
    }
    const fiyatHam = $('modal-fiyat').value.trim();
    const fiyat = (fiyatHam === '' || fiyatHam == null) ? null : Number(fiyatHam);
    const barkod = $('modal-barkod').value.trim();
    const renk = $('modal-renk').value.trim().toLocaleUpperCase('tr-TR');
    const beden = $('modal-beden').value.trim().toLocaleUpperCase('tr-TR');
    const adet = Math.max(1, Number($('modal-adet').value) || 1);

    let payload = {};
    if (g_duzenlenenUrun) {
      const satirlar = Array.isArray(g_duzenlenenUrun.satirlar) ? [...g_duzenlenenUrun.satirlar] : [];
      const satirIdx = Number.isInteger(g_duzenlenenUrun.aktifSatirIndex) ? g_duzenlenenUrun.aktifSatirIndex : 0;

      const guncelSatir = {
        renk,
        beden,
        adet,
        barkod: (satirlar[satirIdx] && satirlar[satirIdx].barkod) || g_duzenlenenUrun.barkod || ''
      };
      if (satirlar[satirIdx]) {
        satirlar[satirIdx] = { ...satirlar[satirIdx], ...guncelSatir };
      } else {
        satirlar.push(guncelSatir);
      }

      payload = {
        id: g_duzenlenenUrun.id,
        surum: g_duzenlenenUrun.surum || 1,
        zorla: true, // Çakışma uyarısı vermeden doğrudan düzenlemeyi kaydet
        urun: urunAdi,
        fiyat,
        barkod: g_duzenlenenUrun.barkod || '', // 🛡️ Barkod asla değiştirilemez, Barkod Bankası ile çapraz eşitlik korunur
        satirlar,
        gun: g_duzenlenenUrun.gun || g_gun,
        giren: g_duzenlenenUrun.giren || localStorage.getItem('urun_girisi_giren') || 'Masaüstü Yönetici'
      };
    } else {
      payload = {
        urun: urunAdi,
        fiyat,
        barkod: barkod || ('MZU-' + Math.floor(10000 + Math.random() * 90000)),
        satirlar: [{ renk, beden, adet, barkod }],
        gun: g_gun,
        giren: localStorage.getItem('urun_girisi_giren') || 'Masaüstü Yönetici'
      };
    }

    try {
      const resp = await fetch('/api/envanter/kaydet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const res = await resp.json();
      if (res.success) {
        modalKapat();
        verileriYukle();
      } else {
        alert('Kaydedilemedi: ' + (res.error || 'Hata'));
      }
    } catch (e) {
      alert('Bağlantı hatası: ' + e.message);
    }
  }

  async function urunSil(id, satirIndex) {
    try {
      const urun = g_kayitlar.find(k => k.id === id);
      if (!urun) return;

      if (urun.satirlar && urun.satirlar.length > 1) {
        // Sadece ilgili varyantı sil
        const yeniSatirlar = urun.satirlar.filter((_, idx) => idx !== satirIndex);
        await fetch('/api/envanter/kaydet', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...urun, satirlar: yeniSatirlar, gun: g_gun, zorla: true, surum: urun.surum || 1 })
        });
      } else {
        // Tüm ürünü sil
        await fetch('/api/envanter/sil', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id, gun: g_gun })
        });
      }
      verileriYukle();
    } catch (e) {
      alert('Silinemedi: ' + e.message);
    }
  }

  // --- 6. LİSANS VE TİCARİ DURUM KONTROLÜ ---
  async function lisansDurumuKontrolEt() {
    try {
      const resp = await fetch('/api/ticari/durum');
      if (!resp.ok) return;
      const veri = await resp.json();
      const el = $('lisans-durum');
      if (el) {
        if (veri.argeModu) {
          el.textContent = '🔬 AR-GE / Sınırsız Mod';
          el.classList.remove('pasif');
        } else if (veri.kilitli) {
          el.textContent = '🔒 Lisans Kilitli';
          el.style.borderColor = '#ef4444';
          el.style.color = '#fca5a5';
        } else {
          el.textContent = `🎫 Lisans: ${veri.kalanGun} Gün Kaldı`;
        }
      }
    } catch (_) {}
  }

  // --- 7. FİRMA PROFİLİ & SEKTÖREL BARKOD KATALOĞU MOTORU ---
  let g_firmaProfili = null;
  const SEKTOR_KATALOGLARI = {
    giyim: {
      ad: 'Tekstil, Giyim & Ayakkabı',
      urunler: [
        { urun: 'Nike Tişört', fiyat: 450, beden: 'M', renk: 'SİYAH' },
        { urun: 'Adidas Eşofman Altı', fiyat: 850, beden: 'L', renk: 'LACİVERT' },
        { urun: 'Puma Spor Çorap', fiyat: 120, beden: 'STD', renk: 'BEYAZ' },
        { urun: 'Columbia Polar Ceket', fiyat: 1850, beden: 'XL', renk: 'HAKİ' },
        { urun: 'North Face Yağmurluk', fiyat: 2400, beden: 'L', renk: 'SİYAH' },
        { urun: 'Lacoste Polo Tişört', fiyat: 950, beden: 'M', renk: 'BEYAZ' },
        { urun: 'Tommy Hilfiger Gömlek', fiyat: 1100, beden: 'L', renk: 'MAVİ' },
        { urun: 'Mavi Kot Pantolon', fiyat: 750, beden: '32', renk: 'KOT MAVİ' },
        { urun: 'Zara Keten Pantolon', fiyat: 650, beden: '38', renk: 'BEJ' },
        { urun: 'Koton V Yaka Kazak', fiyat: 420, beden: 'S', renk: 'GRİ' }
      ]
    },
    kozmetik: {
      ad: 'Kozmetik, Parfüm & Kişisel Bakım',
      urunler: [
        { urun: 'Dior Sauvage Parfüm 100ml', fiyat: 3850, beden: '100ML', renk: 'ORİJİNAL' },
        { urun: 'Chanel Bleu De Chanel 100ml', fiyat: 4200, beden: '100ML', renk: 'ORİJİNAL' },
        { urun: 'Nishane Hacivat Extrait 50ml', fiyat: 4900, beden: '50ML', renk: 'ORİJİNAL' },
        { urun: 'Loreal Yüz Nemlendirici Krem', fiyat: 280, beden: '50ML', renk: 'BEYAZ' },
        { urun: 'Nivea Güneş Koruyucu Sprey', fiyat: 340, beden: '200ML', renk: 'SARI' },
        { urun: 'Maybelline Maskara Siyah', fiyat: 220, beden: 'STD', renk: 'SİYAH' },
        { urun: 'Mac Mat Ruj Velvet Teddy', fiyat: 650, beden: 'STD', renk: 'NUDE' },
        { urun: 'Pantene Onarıcı Şampuan', fiyat: 110, beden: '400ML', renk: 'ALTIN' }
      ]
    },
    elektronik: {
      ad: 'Elektronik, Telefon & Aksesuar',
      urunler: [
        { urun: 'Apple iPhone 15 Kılıf MagSafe', fiyat: 450, beden: 'STD', renk: 'ŞEFFAF' },
        { urun: 'Samsung Type-C Hızlı Şarj Cihazı 25W', fiyat: 380, beden: '25W', renk: 'BEYAZ' },
        { urun: 'Anker Powerbank 10000mAh', fiyat: 750, beden: '10000MAH', renk: 'SİYAH' },
        { urun: 'JBL Wave Bluetooth Kulaklık', fiyat: 1250, beden: 'STD', renk: 'SİYAH' },
        { urun: 'Baseus 3in1 Hızlı Şarj Kablosu', fiyat: 180, beden: '1.2M', renk: 'KIRMIZI' },
        { urun: 'Xiaomi Akıllı Saat Bileklik Kordon', fiyat: 120, beden: 'STD', renk: 'LACİVERT' }
      ]
    },
    market: {
      ad: 'Market, Gıda & Şarküteri',
      urunler: [
        { urun: 'Torku Doğal Süt 1 Lt', fiyat: 38, beden: '1LT', renk: 'TAM YAĞLI' },
        { urun: 'Çaykur Rize Turist Çay 1 Kg', fiyat: 165, beden: '1KG', renk: 'SARI' },
        { urun: 'Sütaş Kaşar Peyniri 600g', fiyat: 185, beden: '600G', renk: 'SARI' },
        { urun: 'Marmarabirlik Zeytin 500g', fiyat: 110, beden: '500G', renk: 'SİYAH' },
        { urun: 'Yudum Ayçiçek Yağı 5 Lt', fiyat: 245, beden: '5LT', renk: 'TENİKE' },
        { urun: 'Pınar Sucuk Kangal 300g', fiyat: 220, beden: '300G', renk: 'ACILI' }
      ]
    },
    kirtasiye: {
      ad: 'Kırtasiye, Kitap & Ofis',
      urunler: [
        { urun: 'Faber-Castell 12li Boya Kalemi', fiyat: 140, beden: '12Lİ', renk: 'RENKLİ' },
        { urun: 'A4 Fotokopi Kağıdı 80g 500lü', fiyat: 135, beden: '500LÜ', renk: 'BEYAZ' },
        { urun: 'Scrikss Tükenmez Kalem 0.7', fiyat: 95, beden: '0.7', renk: 'MAVİ' },
        { urun: 'Gıpta Kareli Metot Defteri 96 Yaprak', fiyat: 55, beden: '96YP', renk: 'DESENLİ' },
        { urun: 'Pritt Stick Yapıştırıcı 43g', fiyat: 65, beden: '43G', renk: 'KIRMIZI' }
      ]
    },
    ayakkabi: {
      ad: 'Yalnız Ayakkabı & Çanta',
      urunler: [
        { urun: 'Hakiki Deri Erkek Klasik Ayakkabı', fiyat: 1450, beden: '42', renk: 'SİYAH' },
        { urun: 'Kadın Topuklu Stiletto Ayakkabı', fiyat: 1150, beden: '38', renk: 'BEJ' },
        { urun: 'Deri Çapraz Omuz Askılı Çanta', fiyat: 750, beden: 'STD', renk: 'KAHVE' },
        { urun: 'Ortopedik Günlük Spor Ayakkabı', fiyat: 890, beden: '41', renk: 'BEYAZ' },
        { urun: 'Hakiki Deri Erkek Cüzdan & Kemer Seti', fiyat: 480, beden: 'STD', renk: 'SİYAH' }
      ]
    },
    oyuncak: {
      ad: 'Oyuncakçı & Çocuk Dünyası',
      urunler: [
        { urun: 'Lego Classic Yaratıcı Yapım Kutusu', fiyat: 750, beden: '4-99 YAŞ', renk: 'LEGO / YAPI', barkod: 'MZU-OY001' },
        { urun: 'Lego City Polis Devriye Arabası', fiyat: 420, beden: '5+ YAŞ', renk: 'LEGO / YAPI', barkod: 'MZU-OY002' },
        { urun: 'Barbie Sonsuz Hareket Sarışın Bebek', fiyat: 680, beden: '3+ YAŞ', renk: 'BEBEK', barkod: 'MZU-OY003' },
        { urun: 'Hot Wheels 5li Araba Seti', fiyat: 450, beden: '3+ YAŞ', renk: 'MODEL ARABA', barkod: 'MZU-OY004' },
        { urun: 'Fisher-Price Eğitici Köpekçik', fiyat: 890, beden: '6-36 AY', renk: 'EĞİTİCİ ELEKTRONİK', barkod: 'MZU-OY005' },
        { urun: 'Play-Doh 4lü Renkli Oyun Hamuru', fiyat: 140, beden: '2+ YAŞ', renk: 'OYUN HAMURU', barkod: 'MZU-OY006' },
        { urun: 'Nerf Elite 2.0 RD-6 Dart Tabancası', fiyat: 620, beden: '8+ YAŞ', renk: 'HEDEF & MACERA', barkod: 'MZU-OY007' },
        { urun: 'Monopoly Türkiye Klasik Kutu Oyunu', fiyat: 590, beden: '8+ YAŞ', renk: 'KUTU OYUNU', barkod: 'MZU-OY008' },
        { urun: 'Jenga Klasik Ahşap Denge Oyunu', fiyat: 380, beden: '6+ YAŞ', renk: 'DENGE OYUNU', barkod: 'MZU-OY009' },
        { urun: 'Uno Klasik Kart Oyunu', fiyat: 120, beden: '7+ YAŞ', renk: 'KART OYUNU', barkod: 'MZU-OY010' },
        { urun: 'Pilsan 12V Uzaktan Kumandalı Akülü Araba', fiyat: 6850, beden: '3-8 YAŞ', renk: 'AKÜLÜ ARAÇ', barkod: 'MZU-OY012' },
        { urun: 'Sevimli Peluş Ayıcık 60 cm', fiyat: 350, beden: '0+ YAŞ', renk: 'PELUŞ OYUNCAK', barkod: 'MZU-OY013' }
      ]
    },
    hirdavat: {
      ad: 'Nalburiye, Hırdavat & Yapı Market',
      urunler: [
        { urun: 'Selsil Akrilik Genel Amaçlı Mastik 280ml', fiyat: 55, beden: '280ML', renk: 'BEYAZ', barkod: 'MZU-HD001' },
        { urun: 'Selsil Çok Amaçlı Şeffaf Silikon 280ml', fiyat: 85, beden: '280ML', renk: 'ŞEFFAF', barkod: 'MZU-HD002' },
        { urun: 'İzeltaş Yıldız Uçlu Manyetik Tornavida', fiyat: 125, beden: '6X100', renk: 'KROM VANADYUM', barkod: 'MZU-HD003' },
        { urun: 'İzeltaş İzoleli Elektrikçi Pensesi 180mm', fiyat: 320, beden: '180MM', renk: 'ÇELİK', barkod: 'MZU-HD004' },
        { urun: 'Kale Kilit Sarı Pirinç Asma Kilit 40mm', fiyat: 145, beden: '40MM', renk: 'PİRİNÇ', barkod: 'MZU-HD005' },
        { urun: '404 Hızlı Japon Yapıştırıcı + Aktivatör', fiyat: 80, beden: '200ML', renk: 'HIZLI YAPIŞTIRICI', barkod: 'MZU-HD006' }
      ]
    },
    genel: {
      ad: 'Genel Perakende & Çoklu Kategori',
      urunler: [
        { urun: 'Genel Barkodlu Ürün A', fiyat: 150, beden: 'STD', renk: 'BEYAZ' },
        { urun: 'Genel Barkodlu Ürün B', fiyat: 250, beden: 'STD', renk: 'SİYAH' },
        { urun: 'Genel Barkodlu Ürün C', fiyat: 350, beden: 'STD', renk: 'KIRMIZI' }
      ]
    }
  };

  async function firmaProfiliniYukle() {
    try {
      const resp = await fetch('/api/sistem/firma-profili');
      if (!resp.ok) return;
      const veri = await resp.json();
      if (veri.success && veri.profil) {
        g_firmaProfili = veri.profil;
        baslikFirmaBilgisiGuncelle();
      }
    } catch (_) {}
  }

  function baslikFirmaBilgisiGuncelle() {
    if (!g_firmaProfili) return;
    const adEl = $('baslik-firma-adi');
    const sekEl = $('baslik-sektor-adi');
    if (adEl && g_firmaProfili.firmaAdi) adEl.textContent = g_firmaProfili.firmaAdi;
    if (sekEl && g_firmaProfili.sektorAdi) sekEl.textContent = g_firmaProfili.sektorAdi;
    document.title = `${g_firmaProfili.firmaAdi || 'Mezatron'} · Sesli Envanter & Depo Yönetimi`;
  }

  function firmaProfiliModalAc() {
    const modal = $('firma-profil-modal');
    if (!modal) return;
    if (g_firmaProfili) {
      if ($('fp-firma-adi')) $('fp-firma-adi').value = g_firmaProfili.firmaAdi || '';
      if ($('fp-yetkili')) $('fp-yetkili').value = g_firmaProfili.yetkili || '';
      if ($('fp-barkod-onek')) $('fp-barkod-onek').value = g_firmaProfili.barkodOnEk || 'MZU';
      if ($('fp-telefon')) $('fp-telefon').value = g_firmaProfili.telefon || '';
      if ($('fp-sektor-secim') && g_firmaProfili.sektor) $('fp-sektor-secim').value = g_firmaProfili.sektor;
      const rozet = $('fp-katalog-durum-rozet');
      if (rozet) {
        rozet.textContent = (g_firmaProfili.sektorAdi || 'Tekstil') + ' Kataloğu Aktif';
      }
    }
    modal.style.display = 'flex';
  }

  async function firmaProfiliniKaydet() {
    const firmaAdi = ($('fp-firma-adi')?.value || '').trim();
    if (!firmaAdi) {
      alert('Lütfen firmanızın adını giriniz.');
      $('fp-firma-adi')?.focus();
      return;
    }
    const yetkili = ($('fp-yetkili')?.value || '').trim();
    const barkodOnEk = ($('fp-barkod-onek')?.value || 'MZU').trim().toUpperCase();
    const telefon = ($('fp-telefon')?.value || '').trim();
    const sektorSecim = $('fp-sektor-secim')?.value || 'giyim';
    const sektorAdi = SEKTOR_KATALOGLARI[sektorSecim] ? SEKTOR_KATALOGLARI[sektorSecim].ad : sektorSecim;

    try {
      const resp = await fetch('/api/sistem/firma-profili', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ firmaAdi, yetkili, barkodOnEk, telefon, sektor: sektorSecim, sektorAdi })
      });
      const res = await resp.json();
      if (res.success && res.profil) {
        g_firmaProfili = res.profil;
        baslikFirmaBilgisiGuncelle();
        $('firma-profil-modal').style.display = 'none';
        alert(`✅ Firma bilgileri başarıyla kaydedildi:\n\nFirma: ${g_firmaProfili.firmaAdi}\nSektör: ${g_firmaProfili.sektorAdi}\nBarkod Ön Eki: ${g_firmaProfili.barkodOnEk}`);
      } else {
        alert('Kaydedilemedi: ' + (res.error || 'Bilinmeyen hata'));
      }
    } catch (err) {
      alert('Kaydedilemedi: ' + err.message);
    }
  }

  async function sektorelKataloguYukle() {
    const secilenSektor = $('fp-sektor-secim')?.value || 'giyim';
    const kat = SEKTOR_KATALOGLARI[secilenSektor];
    if (!kat) return;

    const onay = confirm(
      `📦 ${kat.ad.toUpperCase()} SEKTÖR KATALOĞU YÜKLENSİN Mİ?\n\n` +
      `Bu işlem:\n` +
      `1. Sektöre özel popüler ürün ve hazır barkodları veri bankasına işler,\n` +
      `2. Sesli ve etiket OCR okumada ürünlerin anında tanınmasını sağlar,\n` +
      `3. Mevcut envanterinizi silmez, üzerine ilave ürün kataloğu olarak ekler.\n\n` +
      `Devam etmek istiyor musunuz?`
    );
    if (!onay) return;

    const bilgiEl = $('fp-katalog-bilgi');
    if (bilgiEl) {
      bilgiEl.style.display = 'block';
      bilgiEl.textContent = '⏳ Sektörel ürünler ve barkod bankası işleniyor…';
    }

    try {
      const resp = await fetch('/api/sistem/sektor-katalog-yukle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sektor: secilenSektor,
          sektorAdi: kat.ad,
          urunler: kat.urunler
        })
      });
      const res = await resp.json();
      if (res.success) {
        if (bilgiEl) {
          bilgiEl.textContent = `✅ ${res.mesaj} (Toplam Barkod Bankası: ${res.toplamBarkodBankasi} adet)`;
        }
        if ($('fp-katalog-durum-rozet')) {
          $('fp-katalog-durum-rozet').textContent = kat.ad + ' Yüklendi';
        }
        if (res.profil) {
          g_firmaProfili = res.profil;
          baslikFirmaBilgisiGuncelle();
        }
        alert(`✅ ${res.mesaj}`);
      } else {
        alert('Yüklenemedi: ' + (res.error || 'Bilinmeyen hata'));
      }
    } catch (err) {
      alert('Yükleme hatası: ' + err.message);
    }
  }

  // --- 11. DETAYLI STOK, KATEGORİ & DEPO TUTARI RAPOR MOTORU ---
  function urunGrubuBelirle(urunAdi) {
    if (!urunAdi || typeof urunAdi !== 'string') return { grup: 'Genel Ürünler', ikon: '📦' };
    const u = urunAdi.toLocaleLowerCase('tr-TR');

    if (/\b(ayakkab[ıi]|bot|çizme|sneaker|spor|kundura|terlik|sandalet|babet|iskarpin|makosen|loafer)\b/i.test(u)) {
      return { grup: 'Ayakkabı', ikon: '👟' };
    }
    if (/\b(mont|kaban|palto|parka|trençkot|rüzgarlık|anorak|yelek)\b/i.test(u)) {
      return { grup: 'Mont', ikon: '🧥' };
    }
    if (/\b(gömlek|gomlek|oxford|oduncu)\b/i.test(u)) {
      return { grup: 'Gömlek', ikon: '👔' };
    }
    if (/\b(tişört|tisort|t-shirt|tshirt|polo|atlet|body)\b/i.test(u)) {
      return { grup: 'Tişört', ikon: '👕' };
    }
    if (/\b(pantolon|jean|kot|kanvas|kargo|chino|şalvar)\b/i.test(u)) {
      return { grup: 'Pantolon', ikon: '👖' };
    }
    if (/\b(kazak|triko|hırka|hirka|süveter|suveter|balıkçı)\b/i.test(u)) {
      return { grup: 'Kazak & Triko', ikon: '🧶' };
    }
    if (/\b(sweat|sweatshirt|kapüşonlu|hoodie)\b/i.test(u)) {
      return { grup: 'Sweatshirt', ikon: '🧥' };
    }
    if (/\b(ceket|blazer|takım)\b/i.test(u)) {
      return { grup: 'Ceket & Blazer', ikon: '🤵' };
    }
    if (/\b(elbise|etek|tunik|jile|abiye)\b/i.test(u)) {
      return { grup: 'Elbise & Etek', ikon: '👗' };
    }
    if (/\b(eşofman|esofman|şort|sort|tayt|bermuda)\b/i.test(u)) {
      return { grup: 'Eşofman & Şort', ikon: '🩳' };
    }
    if (/\b(çorap|corap|pijama|boxer|külot|kulot|sutyen|sütyen|iç çamaşır)\b/i.test(u)) {
      return { grup: 'İç Giyim & Çorap', ikon: '🧦' };
    }
    if (/\b(çanta|canta|cüzdan|cuzdan|valiz|bavul|kemer)\b/i.test(u)) {
      return { grup: 'Çanta & Aksesuar', ikon: '👜' };
    }
    if (/\b(şapka|sapka|bere|atkı|atki|eldiven|gözlük|gozluk|saat|parfüm)\b/i.test(u)) {
      return { grup: 'Aksesuar & Takı', ikon: '🧢' };
    }

    const kelimeler = urunAdi.trim().split(/\s+/);
    if (kelimeler.length > 1) {
      const sonKelime = kelimeler[kelimeler.length - 1];
      if (sonKelime.length >= 3 && !/^\d+$/.test(sonKelime)) {
        const basHarfBuyuk = sonKelime.charAt(0).toLocaleUpperCase('tr-TR') + sonKelime.slice(1).toLocaleLowerCase('tr-TR');
        return { grup: basHarfBuyuk, ikon: '🏷️' };
      }
    }

    return { grup: 'Genel Ürünler', ikon: '📦' };
  }

  let g_raporModelVerileri = [];

  function raporuOlustur() {
    const satirlar = duzlestirilmisSatirlar();
    
    // Kategori, beden, renk ve model istatistikleri
    const gruplar = {};
    const bedenSayilari = {};
    const renkSayilari = {};
    const modelGruplari = {};

    let genelToplamAdet = 0;
    let genelToplamTutar = 0;

    satirlar.forEach(s => {
      const { grup, ikon } = urunGrubuBelirle(s.urun);
      const adet = Number(s.adet) || 1;
      const fiyat = Number(s.fiyat) || 0;
      const tutar = adet * fiyat;

      genelToplamAdet += adet;
      genelToplamTutar += tutar;

      // Kategori grubu
      if (!gruplar[grup]) {
        gruplar[grup] = {
          grup,
          ikon,
          toplamAdet: 0,
          toplamTutar: 0,
          fiyatlar: [],
          modeller: new Set()
        };
      }
      gruplar[grup].toplamAdet += adet;
      gruplar[grup].toplamTutar += tutar;
      if (fiyat > 0) gruplar[grup].fiyatlar.push(fiyat);
      gruplar[grup].modeller.add(s.urun);

      // Beden dağılımı
      const beden = s.beden ? String(s.beden).trim() : 'Standart';
      bedenSayilari[beden] = (bedenSayilari[beden] || 0) + adet;

      // Renk dağılımı
      const renk = s.renk ? String(s.renk).trim() : 'Belirtilmemiş';
      renkSayilari[renk] = (renkSayilari[renk] || 0) + adet;

      // Model grubu
      const modelKey = s.urun;
      if (!modelGruplari[modelKey]) {
        modelGruplari[modelKey] = {
          urun: s.urun,
          kategori: grup,
          fiyat,
          toplamAdet: 0,
          toplamTutar: 0,
          kirilim: []
        };
      }
      modelGruplari[modelKey].toplamAdet += adet;
      modelGruplari[modelKey].toplamTutar += tutar;
      modelGruplari[modelKey].kirilim.push(`${s.beden || '-'}/${s.renk || '-'}: ${adet} ad`);
    });

    const kategoriDizisi = Object.values(gruplar).sort((a, b) => b.toplamAdet - a.toplamAdet);
    const modelDizisi = Object.values(modelGruplari).sort((a, b) => b.toplamAdet - a.toplamAdet);
    g_raporModelVerileri = modelDizisi;

    // 1. KPI Göstergeleri
    const elToplamAdet = $('rk-toplam-adet');
    const elToplamCesit = $('rk-toplam-cesit');
    const elToplamTutar = $('rk-toplam-tutar');
    const elOrtalamaFiyat = $('rk-ortalama-fiyat');
    const elLiderKategori = $('rk-lider-kategori');
    const elLiderAdetAlt = $('rk-lider-adet-alt');
    const elDegerliKategori = $('rk-degerli-kategori');
    const elDegerliTutarAlt = $('rk-degerli-tutar-alt');
    const elCesitAlt = $('rk-cesit-alt');

    const toplamCesitSayisi = modelDizisi.length;
    const ortalamaFiyat = genelToplamAdet > 0 ? Math.round(genelToplamTutar / genelToplamAdet) : 0;

    if (elToplamAdet) elToplamAdet.textContent = `${genelToplamAdet.toLocaleString('tr-TR')} Adet`;
    if (elCesitAlt) elCesitAlt.textContent = `${toplamCesitSayisi} farklı model / ${kategoriDizisi.length} kategori`;
    if (elToplamCesit) elToplamCesit.textContent = `${toplamCesitSayisi} Model`;
    if (elToplamTutar) elToplamTutar.textContent = `${genelToplamTutar.toLocaleString('tr-TR')} ₺`;
    if (elOrtalamaFiyat) elOrtalamaFiyat.textContent = `${ortalamaFiyat.toLocaleString('tr-TR')} ₺ / Adet`;

    if (kategoriDizisi.length > 0) {
      const enCokAdet = kategoriDizisi[0];
      const enCokTutar = [...kategoriDizisi].sort((a, b) => b.toplamTutar - a.toplamTutar)[0];

      if (elLiderKategori) elLiderKategori.textContent = `${enCokAdet.ikon} ${enCokAdet.grup}`;
      if (elLiderAdetAlt) elLiderAdetAlt.textContent = `${enCokAdet.toplamAdet} Adet (%${genelToplamAdet > 0 ? Math.round((enCokAdet.toplamAdet / genelToplamAdet) * 100) : 0})`;

      if (elDegerliKategori) elDegerliKategori.textContent = `${enCokTutar.ikon} ${enCokTutar.grup}`;
      if (elDegerliTutarAlt) elDegerliTutarAlt.textContent = `${enCokTutar.toplamTutar.toLocaleString('tr-TR')} ₺ (%${genelToplamTutar > 0 ? Math.round((enCokTutar.toplamTutar / genelToplamTutar) * 100) : 0})`;
    } else {
      if (elLiderKategori) elLiderKategori.textContent = '—';
      if (elDegerliKategori) elDegerliKategori.textContent = '—';
    }

    // 2. Kategori Tablosunu Çiz
    const katGovde = $('rapor-kategori-govde');
    if (katGovde) {
      if (!kategoriDizisi.length) {
        katGovde.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:24px; color:var(--yazi-soluk)">Henüz kayıtlı ürün bulunmuyor.</td></tr>';
      } else {
        let katHtml = '';
        kategoriDizisi.forEach(k => {
          const yuzde = genelToplamAdet > 0 ? Math.round((k.toplamAdet / genelToplamAdet) * 100) : 0;
          const minFiyat = k.fiyatlar.length ? Math.min(...k.fiyatlar) : 0;
          const maxFiyat = k.fiyatlar.length ? Math.max(...k.fiyatlar) : 0;
          const katOrtalama = k.toplamAdet > 0 ? Math.round(k.toplamTutar / k.toplamAdet) : 0;
          const ornekModeller = Array.from(k.modeller).slice(0, 3).join(', ') + (k.modeller.size > 3 ? '…' : '');
          const fiyatAraligi = minFiyat === maxFiyat ? `${minFiyat} ₺` : `${minFiyat} - ${maxFiyat} ₺`;

          katHtml += `
            <tr>
              <td style="font-weight:800; font-size:0.9rem">
                <span style="font-size:1.15rem; margin-right:6px">${k.ikon}</span>${k.grup}
              </td>
              <td style="text-align:center; font-weight:700; color:var(--yazi-soluk)">${k.modeller.size} çeşit</td>
              <td style="text-align:right; font-weight:900; font-size:1rem; color:#10b981">
                ${k.toplamAdet.toLocaleString('tr-TR')} Adet
              </td>
              <td>
                <div style="display:flex; align-items:center; gap:8px">
                  <div class="rapor-bar-kapsayici">
                    <div class="rapor-bar-dolu" style="width:${Math.max(4, yuzde)}%"></div>
                  </div>
                  <span style="font-size:0.75rem; font-weight:800; min-width:32px">%${yuzde}</span>
                </div>
              </td>
              <td style="text-align:right; font-weight:600; color:var(--yazi-soluk)">${fiyatAraligi}</td>
              <td style="text-align:right; font-weight:700">${katOrtalama.toLocaleString('tr-TR')} ₺</td>
              <td style="text-align:right; font-weight:900; font-size:0.95rem; color:#fbbf24">
                ${k.toplamTutar.toLocaleString('tr-TR')} ₺
              </td>
              <td style="color:var(--yazi-soluk); font-size:0.75rem">${ornekModeller}</td>
            </tr>
          `;
        });

        // Toplam Satırı
        katHtml += `
          <tr class="toplam-satir">
            <td style="font-weight:900; font-size:0.95rem">GENEL TOPLAM (${kategoriDizisi.length} Grup)</td>
            <td style="text-align:center; font-weight:900">${toplamCesitSayisi} çeşit</td>
            <td style="text-align:right; font-weight:900; font-size:1.05rem; color:#10b981">${genelToplamAdet.toLocaleString('tr-TR')} Adet</td>
            <td><span style="font-weight:900">%100</span></td>
            <td style="text-align:right">—</td>
            <td style="text-align:right; font-weight:900">${ortalamaFiyat.toLocaleString('tr-TR')} ₺</td>
            <td style="text-align:right; font-weight:900; font-size:1.1rem; color:#fbbf24">${genelToplamTutar.toLocaleString('tr-TR')} ₺</td>
            <td style="font-weight:700; color:#10b981">Tüm Depo Hazır</td>
          </tr>
        `;
        katGovde.innerHTML = katHtml;
      }
    }

    // 3. Beden Dağılımını Çiz
    const bedenGovde = $('rapor-beden-govde');
    if (bedenGovde) {
      const bedenDizisi = Object.entries(bedenSayilari).sort((a, b) => b[1] - a[1]);
      if (!bedenDizisi.length) {
        bedenGovde.innerHTML = '<tr><td colspan="3" style="text-align:center; padding:12px; color:var(--yazi-soluk)">Kayıt yok</td></tr>';
      } else {
        bedenGovde.innerHTML = bedenDizisi.map(([beden, adet]) => {
          const y = genelToplamAdet > 0 ? Math.round((adet / genelToplamAdet) * 100) : 0;
          return `
            <tr>
              <td style="font-weight:800">${beden}</td>
              <td style="text-align:right; font-weight:900; color:#38bdf8">${adet} Adet</td>
              <td>
                <div style="display:flex; align-items:center; gap:6px">
                  <div class="rapor-bar-kapsayici"><div class="rapor-bar-dolu" style="width:${Math.max(4, y)}%; background:linear-gradient(90deg, #0284c7, #38bdf8)"></div></div>
                  <span style="font-size:0.72rem; font-weight:700">%${y}</span>
                </div>
              </td>
            </tr>
          `;
        }).join('');
      }
    }

    // 4. Renk Dağılımını Çiz
    const renkGovde = $('rapor-renk-govde');
    if (renkGovde) {
      const renkDizisi = Object.entries(renkSayilari).sort((a, b) => b[1] - a[1]);
      if (!renkDizisi.length) {
        renkGovde.innerHTML = '<tr><td colspan="3" style="text-align:center; padding:12px; color:var(--yazi-soluk)">Kayıt yok</td></tr>';
      } else {
        renkGovde.innerHTML = renkDizisi.map(([renk, adet]) => {
          const y = genelToplamAdet > 0 ? Math.round((adet / genelToplamAdet) * 100) : 0;
          return `
            <tr>
              <td style="font-weight:800">${renk}</td>
              <td style="text-align:right; font-weight:900; color:#a855f7">${adet} Adet</td>
              <td>
                <div style="display:flex; align-items:center; gap:6px">
                  <div class="rapor-bar-kapsayici"><div class="rapor-bar-dolu" style="width:${Math.max(4, y)}%; background:linear-gradient(90deg, #7c3aed, #c084fc)"></div></div>
                  <span style="font-size:0.72rem; font-weight:700">%${y}</span>
                </div>
              </td>
            </tr>
          `;
        }).join('');
      }
    }

    // 5. Model Detay Tablosunu Çiz
    raporModelTablosunuCiz(modelDizisi);
  }

  function raporModelTablosunuCiz(modeller) {
    const govde = $('rapor-model-govde');
    if (!govde) return;
    if (!modeller.length) {
      govde.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:20px; color:var(--yazi-soluk)">Eşleşen model bulunamadı.</td></tr>';
      return;
    }
    govde.innerHTML = modeller.map((m, idx) => `
      <tr>
        <td style="text-align:center; color:var(--yazi-soluk); font-weight:700">${idx + 1}</td>
        <td style="font-weight:800">${m.urun}</td>
        <td><span style="background:var(--bg-kart); border:1px solid var(--kenar); padding:2px 8px; border-radius:4px; font-size:0.75rem; font-weight:700">${m.kategori}</span></td>
        <td style="font-size:0.75rem; color:var(--yazi-soluk)">${m.kirilim.join(', ')}</td>
        <td style="text-align:right; font-weight:700">${m.fiyat.toLocaleString('tr-TR')} ₺</td>
        <td style="text-align:right; font-weight:900; color:#10b981">${m.toplamAdet} Adet</td>
        <td style="text-align:right; font-weight:900; color:#fbbf24">${m.toplamTutar.toLocaleString('tr-TR')} ₺</td>
      </tr>
    `).join('');
  }

  function raporModelFiltrele() {
    const q = ($('rapor-urun-ara')?.value || '').trim().toLocaleLowerCase('tr-TR');
    if (!q) {
      raporModelTablosunuCiz(g_raporModelVerileri);
      return;
    }
    const filtrelenmis = g_raporModelVerileri.filter(m => 
      m.urun.toLocaleLowerCase('tr-TR').includes(q) || 
      m.kategori.toLocaleLowerCase('tr-TR').includes(q)
    );
    raporModelTablosunuCiz(filtrelenmis);
  }

  function raporYazdir() {
    window.print();
  }

  function raporExcelIndir() {
    const satirlar = duzlestirilmisSatirlar();
    if (!satirlar.length) {
      alert('Raporlanacak envanter kaydı bulunamadı.');
      return;
    }
    
    // Grupları hesapla
    const gruplar = {};
    let toplamAdet = 0;
    let toplamTutar = 0;
    satirlar.forEach(s => {
      const { grup } = urunGrubuBelirle(s.urun);
      const adet = Number(s.adet) || 1;
      const tutar = adet * (Number(s.fiyat) || 0);
      toplamAdet += adet;
      toplamTutar += tutar;
      if (!gruplar[grup]) gruplar[grup] = { grup, adet: 0, tutar: 0, modeller: new Set() };
      gruplar[grup].adet += adet;
      gruplar[grup].tutar += tutar;
      gruplar[grup].modeller.add(s.urun);
    });

    let html = `\uFEFF<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>Mezatron Stok ve Depo Raporu</title></head>
<body>
  <h2>MEZATRON 365 — STOK, KATEGORİ VE DEPO TUTARI RAPORU</h2>
  <p><b>Rapor Tarihi:</b> ${new Date().toLocaleString('tr-TR')}</p>
  <p><b>Genel Toplam Stok:</b> ${toplamAdet} Adet | <b>Genel Toplam Tutar:</b> ${toplamTutar} TL</p>
  <br>
  <table border="1" cellpadding="6" cellspacing="0">
    <tr style="background:#047857; color:#ffffff; font-weight:bold">
      <th>Ürün Grubu / Kategori</th>
      <th>Model Çeşidi</th>
      <th>Toplam Stok (Adet)</th>
      <th>Stok Payı (%)</th>
      <th>Toplam Tutar (TL)</th>
      <th>Ortalama Birim Fiyat (TL)</th>
      <th>İçerdiği Modeller</th>
    </tr>`;

    Object.values(gruplar).sort((a, b) => b.adet - a.adet).forEach(g => {
      const yuzde = toplamAdet > 0 ? Math.round((g.adet / toplamAdet) * 100) : 0;
      const ort = g.adet > 0 ? Math.round(g.tutar / g.adet) : 0;
      html += `<tr>
        <td><b>${g.grup}</b></td>
        <td align="center">${g.modeller.size}</td>
        <td align="right">${g.adet}</td>
        <td align="center">%${yuzde}</td>
        <td align="right">${g.tutar} ₺</td>
        <td align="right">${ort} ₺</td>
        <td>${Array.from(g.modeller).join(', ')}</td>
      </tr>`;
    });

    html += `<tr style="background:#e2e8f0; font-weight:bold">
      <td>GENEL TOPLAM</td>
      <td align="center">${Object.keys(gruplar).length} Grup</td>
      <td align="right">${toplamAdet} Adet</td>
      <td align="center">%100</td>
      <td align="right">${toplamTutar} ₺</td>
      <td align="right">${toplamAdet > 0 ? Math.round(toplamTutar / toplamAdet) : 0} ₺</td>
      <td>Tüm Depo</td>
    </tr>
  </table>
  <br><br>
  <h3>ÜRÜN MODELİ VE VARYANT DETAY DÖKÜMÜ</h3>
  <table border="1" cellpadding="6" cellspacing="0">
    <tr style="background:#0284c7; color:#ffffff; font-weight:bold">
      <th>Sıra</th><th>Barkod</th><th>Ürün Adı</th><th>Renk</th><th>Beden</th><th>Adet</th><th>Birim Fiyat</th><th>Toplam Tutar</th>
    </tr>`;

    satirlar.forEach((s, idx) => {
      html += `<tr>
        <td align="center">${idx + 1}</td>
        <td>${s.barkod}</td>
        <td>${s.urun}</td>
        <td>${s.renk || '-'}</td>
        <td align="center">${s.beden || '-'}</td>
        <td align="right">${s.adet}</td>
        <td align="right">${s.fiyat} ₺</td>
        <td align="right">${s.tutar} ₺</td>
      </tr>`;
    });

    html += `</table></body></html>`;

    const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Mezatron_Stok_Kategori_Raporu_${g_gun}.xls`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 500);
    masaustuToastGoster('Stok raporu Excel olarak indirildi!');
  }

  // Firma Profili Modal Olayları
  $('firma-modal-kapat-btn')?.addEventListener('click', () => { $('firma-profil-modal').style.display = 'none'; });
  $('fp-iptal-btn')?.addEventListener('click', () => { $('firma-profil-modal').style.display = 'none'; });
  $('fp-kaydet-btn')?.addEventListener('click', firmaProfiliniKaydet);
  $('fp-katalog-yukle-btn')?.addEventListener('click', sektorelKataloguYukle);

  // --- MOBİL BAĞLANTI & QR KODU İSTASYONU ---
  function yerelKarekodUret(metin) {
    try {
      if (typeof window.qrcode !== 'function') return '';
      const q = window.qrcode(0, 'M');
      q.addData(String(metin));
      q.make();
      return q.createDataURL(6, 12);
    } catch (e) {
      console.error('QR üretilemedi:', e);
      return '';
    }
  }

  async function mobilBaglantiModaliniAc() {
    const modal = $('mobil-baglanti-modal');
    if (!modal) return;
    modal.style.display = 'flex';

    const apkQrKutu = $('mbm-apk-qr-kutu');
    const webQrKutu = $('mbm-web-qr-kutu');
    const apkUrlMetin = $('mbm-apk-url-metin');
    const webUrlMetin = $('mbm-web-url-metin');
    const ipBilgi = $('mbm-ip-bilgi');
    const webAcLink = $('mbm-web-ac-link');
    const apkIndirBtn = $('mbm-apk-indir-btn');

    if (apkQrKutu) apkQrKutu.innerHTML = '<div style="color:#0f172a; font-weight:800; font-size:0.82rem">QR Üretiliyor…</div>';
    if (webQrKutu) webQrKutu.innerHTML = '<div style="color:#0f172a; font-weight:800; font-size:0.82rem">QR Üretiliyor…</div>';

    try {
      const v = await fetch('/api/mobil-baglanti', { cache: 'no-store' }).then(r => r.json());
      const yerelIp = v.yerelIp || '127.0.0.1';
      const port = v.port || 3002;
      const apkUrl = `http://${yerelIp}:${port}/Mezatron-Envanter.apk`;
      const webUrl = `http://${yerelIp}:${port}/urun-girisi.html`;

      if (ipBilgi) ipBilgi.innerHTML = `📡 Bilgisayar IP: <b>${yerelIp}:${port}</b> · Telefonla aynı Wi-Fi ağında olunmalıdır.`;
      if (apkUrlMetin) apkUrlMetin.textContent = apkUrl;
      if (webUrlMetin) webUrlMetin.textContent = webUrl;
      if (apkIndirBtn) apkIndirBtn.href = `/Mezatron-Envanter.apk`;
      if (webAcLink) webAcLink.href = `/urun-girisi.html`;

      const apkQrSrc = yerelKarekodUret(apkUrl);
      const webQrSrc = yerelKarekodUret(webUrl);

      // Telefon uygulamasını bu bilgisayara bağlayan kare kod: adres ve bilgisayarın kimliği (parmak izi) içinde
      const eslesmeMetni = `${v.httpsUrl || `https://${yerelIp}:${v.httpsPort || 3442}`}/?mezatron-baglan=${v.tlsParmakIzi || ''}`;
      const eslesmeQr = yerelKarekodUret(eslesmeMetni);
      let uygKutu = $('mbm-uygulama-kutu');
      const kapsayan = modal.firstElementChild || modal;
      if (!uygKutu) {
        uygKutu = document.createElement('div');
        uygKutu.id = 'mbm-uygulama-kutu';
        uygKutu.style.cssText = 'margin-top:12px;padding:12px;border:2px solid #10b981;border-radius:10px;background:#ecfdf5;color:#064e3b;text-align:center;font-size:0.86rem;line-height:1.4';
        kapsayan.appendChild(uygKutu);
      }
      uygKutu.innerHTML = `<b style="font-size:0.95rem">📲 Telefon uygulamasını bu bilgisayara bağla</b><br>`
        + `Telefonda uygulamayı açın, <b>Barkod</b> sayfasında bu kare kodu kameraya okutun.<br>`
        + `<small>Kare kod okunmazsa aşağıdaki adresi Barkod kutusuna yazıp <b>Uygula</b>'ya dokunun.</small><br>`
        + (eslesmeQr ? `<img src="${eslesmeQr}" alt="Bağlantı kare kodu" style="width:190px;height:190px;image-rendering:pixelated;margin:8px auto;display:block;background:#fff;padding:6px;border-radius:6px">` : '<b style="color:#b91c1c">Kare kod oluşturulamadı</b><br>')
        + `<span style="font-family:monospace;font-size:0.8rem">${v.httpsUrl || ''}</span>`
        + (v.httpsAktif ? '' : '<br><b style="color:#b91c1c">Güvenli bağlantı açılamadı, telefon uygulaması bağlanamaz. Programı yeniden başlatın.</b>');

      // iPhone: uygulama mağazası olmadan, Safari'den kurulum sayfasıyla bağlanır
      let iphoneKutu = $('mbm-iphone-kutu');
      if (!iphoneKutu) {
        iphoneKutu = document.createElement('div');
        iphoneKutu.id = 'mbm-iphone-kutu';
        iphoneKutu.style.cssText = 'margin-top:12px;padding:12px;border:2px solid #38bdf8;border-radius:10px;background:#f0f9ff;color:#0c4a6e;text-align:center;font-size:0.86rem;line-height:1.4';
        kapsayan.appendChild(iphoneKutu);
      }
      const iphoneKurulum = v.iphoneKurulumUrl || `http://${yerelIp}:${port}/iphone.html`;
      const iphoneQr = yerelKarekodUret(iphoneKurulum);
      iphoneKutu.innerHTML = `<b style="font-size:0.95rem">🍏 iPhone bağla</b><br>`
        + `iPhone kamerasıyla bu kare kodu okutun, açılan sayfayı <b>Safari</b>'de izleyin.<br>`
        + (iphoneQr ? `<img src="${iphoneQr}" alt="iPhone kurulum kare kodu" style="width:170px;height:170px;image-rendering:pixelated;margin:8px auto;display:block;background:#fff;padding:6px;border-radius:6px">` : '<b style="color:#b91c1c">Kare kod oluşturulamadı</b><br>')
        + `<span style="font-family:monospace;font-size:0.8rem">${iphoneKurulum}</span>`
        + (v.iphoneAktif ? '' : '<br><b style="color:#b91c1c">iPhone kapısı açılamadı. Programı yeniden başlatın.</b>');

      if (apkQrKutu) {
        apkQrKutu.innerHTML = apkQrSrc 
          ? `<img src="${apkQrSrc}" alt="APK QR" style="width:180px; height:180px; image-rendering:pixelated; border-radius:6px">` 
          : `<div style="color:#b91c1c; font-weight:800; font-size:0.82rem">QR oluşturulamadı</div>`;
      }
      if (webQrKutu) {
        webQrKutu.innerHTML = webQrSrc 
          ? `<img src="${webQrSrc}" alt="Web QR" style="width:180px; height:180px; image-rendering:pixelated; border-radius:6px">` 
          : `<div style="color:#b91c1c; font-weight:800; font-size:0.82rem">QR oluşturulamadı</div>`;
      }

      // Adres Kopyala Butonu
      const kopyalaBtn = $('mbm-url-kopyala-btn');
      if (kopyalaBtn) {
        kopyalaBtn.onclick = () => {
          navigator.clipboard.writeText(webUrl).then(() => {
            masaustuToastGoster('Bağlantı adresi kopyalandı: ' + webUrl);
          }).catch(() => {
            prompt('Bağlantı adresi:', webUrl);
          });
        };
      }
    } catch (e) {
      if (ipBilgi) ipBilgi.textContent = '⚠️ Yerel ağ bilgisi alınamadı: ' + e.message;
    }
  }

  function mobilBaglantiModaliniKapat() {
    const modal = $('mobil-baglanti-modal');
    if (modal) modal.style.display = 'none';
  }

  // --- KULLANICI, TELEFON & PIN YÖNETİMİ ---
  async function kullaniciYonetimModaliniAc() {
    const modal = $('kullanici-yonetim-modal');
    if (!modal) return;
    modal.style.display = 'flex';
    kullaniciVePinVerileriniYukle();
  }

  function kullaniciYonetimModaliniKapat() {
    const modal = $('kullanici-yonetim-modal');
    if (modal) modal.style.display = 'none';
  }

  function telKacis(m) { return String(m == null ? '' : m).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function telZaman(t) { try { return t ? new Date(t).toLocaleString('tr-TR') : '-'; } catch (_) { return '-'; } }
  async function telefonListesiniYukle() {
    const kutu = $('kym-telefon-liste');
    const sayac = $('kym-telefon-sayac');
    if (!kutu) return;
    try {
      const j = await fetch('/api/kullanici/telefonlar', { cache: 'no-store' }).then(r => r.json());
      if (!j.success) { kutu.innerHTML = `<div style="color:#f87171; padding:12px; text-align:center">${telKacis(j.error || 'Telefon listesi alınamadı.')}</div>`; return; }
      if (sayac) sayac.textContent = `${j.onayliTelefon} / ${j.telefonLimiti}`;
      const liste = j.telefonlar || [];
      if (!liste.length) { kutu.innerHTML = '<div style="text-align:center; padding:12px; color:var(--yazi-soluk); font-size:0.86rem">Henüz bağlanan telefon yok.</div>'; return; }
      const dolu = j.onayliTelefon >= j.telefonLimiti;
      kutu.innerHTML = liste.map(t => `
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; padding:10px 12px; border-radius:10px; border:1px solid ${t.onayli ? 'rgba(16,185,129,0.45)' : 'rgba(245,158,11,0.55)'}; background:var(--kart-arka, rgba(15,23,42,0.4))">
          <div style="min-width:0">
            <div style="font-weight:900; color:var(--yazi-ana)">${/iphone|ipad/i.test(t.ad) ? '🍏' : '📱'} ${telKacis(t.ad || 'Telefon')}
              <span style="font-size:0.74rem; font-weight:800; margin-left:6px; color:${t.onayli ? '#10b981' : '#f59e0b'}">${t.onayli ? 'ONAYLI' : 'ONAY BEKLİYOR'}</span></div>
            <div style="font-size:0.76rem; color:var(--yazi-soluk)">İlk bağlantı: ${telKacis(telZaman(t.ilkGorulme))} · Son: ${telKacis(telZaman(t.sonGorulme))}</div>
          </div>
          <div style="display:flex; gap:6px">
            ${t.onayli ? '' : `<button type="button" class="btn" data-tel-onayla="${telKacis(t.kimlik)}" ${dolu ? 'disabled title="Lisanstaki telefon sayısı dolu"' : ''} style="padding:4px 10px; font-size:0.78rem; font-weight:800; border-radius:6px">✅ Onayla</button>`}
            <button type="button" class="btn btn-ikincil" data-tel-kaldir="${telKacis(t.kimlik)}" style="padding:4px 10px; font-size:0.78rem; font-weight:800; border-radius:6px">🗑️ Kaldır</button>
          </div>
        </div>`).join('') + (dolu ? '<div style="font-size:0.8rem; color:#f59e0b; padding:4px 2px">Lisanstaki telefon sayısı dolu. Daha fazla telefon için lisansı artırın ya da bir telefonu kaldırın.</div>' : '');
      kutu.querySelectorAll('[data-tel-onayla]').forEach(b => b.addEventListener('click', () => telefonIslem('telefon-onayla', b.getAttribute('data-tel-onayla'))));
      kutu.querySelectorAll('[data-tel-kaldir]').forEach(b => b.addEventListener('click', () => {
        if (confirm('Bu telefon kaldırılsın mı? Telefon yeniden bağlanırsa yine onay bekler.')) telefonIslem('telefon-kaldir', b.getAttribute('data-tel-kaldir'));
      }));
    } catch (e) {
      kutu.innerHTML = `<div style="color:#f87171; padding:12px; text-align:center">Telefon listesi alınamadı: ${telKacis(e.message)}</div>`;
    }
  }
  async function telefonIslem(islem, kimlik) {
    try {
      const j = await fetch('/api/kullanici/' + islem, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kimlik }) }).then(r => r.json());
      masaustuToastGoster(j.success ? (islem === 'telefon-onayla' ? 'Telefon onaylandı.' : 'Telefon kaldırıldı.') : (j.error || 'İşlem yapılamadı.'));
    } catch (e) { masaustuToastGoster('İşlem yapılamadı: ' + e.message); }
    kullaniciVePinVerileriniYukle();
  }

  async function kullaniciVePinVerileriniYukle() {
    // 1. PIN Durumu
    try {
      const p = await fetch('/api/pin-durum', { cache: 'no-store' }).then(r => r.json());
      const gosterge = $('kym-aktif-pin-gosterge');
      if (gosterge && p.aktifPin) gosterge.textContent = p.aktifPin;
    } catch (_) {}

    // 1b. Telefonlar (lisanstaki telefon sayısı kadar, yönetici onayıyla)
    telefonListesiniYukle();

    // 2. Kullanıcılar ve Lisans
    const listeKutusu = $('kym-kullanici-liste');
    const toplamEl = $('kym-toplam-kullanici');
    const lisansBaslik = $('kym-lisans-baslik');
    const lisansRozet = $('kym-lisans-rozet');

    if (listeKutusu) listeKutusu.innerHTML = '<div style="text-align:center; padding:16px; color:var(--yazi-soluk); font-size:0.86rem">Kullanıcılar yükleniyor…</div>';

    try {
      const j = await fetch('/api/kullanici/liste', { cache: 'no-store' }).then(r => r.json());
      if (!j.success) {
        if (listeKutusu) listeKutusu.innerHTML = `<div style="color:#f87171; padding:12px; text-align:center">${j.error || 'Kullanıcı listesi alınamadı.'}</div>`;
        return;
      }

      if (j.lisans) {
        if (lisansBaslik) lisansBaslik.textContent = `🎫 Lisans: ${j.lisans.onayliSayisi} / ${j.lisans.kullaniciLimiti} Kullanıcı · ${j.lisans.onayliTelefon ?? 0} / ${j.lisans.telefonLimiti ?? j.lisans.kullaniciLimiti} Telefon`;
        if (lisansRozet) lisansRozet.textContent = j.lisans.musteri || 'Standart Lisans';
        const kodEl = $('kym-bilgisayar-kodu');
        if (kodEl && j.lisans.bilgisayarKodu) kodEl.textContent = j.lisans.bilgisayarKodu;
        const hataEl = $('kym-lisans-hata');
        if (hataEl) { hataEl.textContent = j.lisans.hata ? '⚠ ' + j.lisans.hata : ''; hataEl.style.display = j.lisans.hata ? 'block' : 'none'; }
      }

      const kullanicilar = (j.kullanicilar || []).sort((a, b) => (a.onayli - b.onayli) || a.ad.localeCompare(b.ad, 'tr'));
      if (toplamEl) toplamEl.textContent = String(kullanicilar.length);

      if (!kullanicilar.length) {
        if (listeKutusu) listeKutusu.innerHTML = '<div style="text-align:center; padding:16px; color:var(--yazi-soluk); font-size:0.86rem">Henüz kayıtlı telefon/kullanıcı yok. Telefondan bağlanan ilk kullanıcı yönetici olur.</div>';
        return;
      }

      if (listeKutusu) {
        listeKutusu.innerHTML = '';
        kullanicilar.forEach(k => {
          const kart = document.createElement('div');
          kart.style.cssText = `border:1.5px solid ${k.onayli ? 'var(--kenar-parlak)' : '#f59e0b'}; border-radius:10px; padding:12px 14px; background:${k.onayli ? 'var(--bg-kart)' : 'rgba(245,158,11,0.08)'}; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px`;
          
          const rolRozet = k.rol === 'sahip' 
            ? '<span style="background:#0284c7; color:#fff; font-size:0.75rem; font-weight:900; padding:2px 8px; border-radius:4px">👑 Lisans Sahibi</span>' 
            : (k.onayli 
              ? '<span style="background:#16a34a; color:#fff; font-size:0.75rem; font-weight:900; padding:2px 8px; border-radius:4px">✅ Onaylı</span>' 
              : '<span style="background:#f59e0b; color:#fff; font-size:0.75rem; font-weight:900; padding:2px 8px; border-radius:4px">⏳ Onay Bekliyor</span>');

          const tarih = t => t ? new Date(t).toLocaleString('tr-TR', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' }) : '—';

          kart.innerHTML = `
            <div>
              <div style="display:flex; align-items:center; gap:8px">
                <span style="font-weight:900; font-size:0.96rem; color:var(--yazi-ana)">👤 ${k.ad.replace(/</g, '&lt;')}</span>
                ${rolRozet}
              </div>
              <div style="font-size:0.76rem; color:var(--yazi-soluk); margin-top:3px">
                Kayıt: ${tarih(k.olusturma)} · Son Giriş: ${tarih(k.sonGiris)}
              </div>
            </div>
            <div style="display:flex; gap:6px; flex-wrap:wrap" class="kym-kart-aksiyonlar"></div>
          `;

          const aksiyonlar = kart.querySelector('.kym-kart-aksiyonlar');
          
          if (!k.onayli) {
            const onaylaBtn = document.createElement('button');
            onaylaBtn.type = 'button';
            onaylaBtn.className = 'btn btn-yesil';
            onaylaBtn.style.cssText = 'padding:6px 12px; font-size:0.8rem; font-weight:900; border-radius:6px';
            onaylaBtn.textContent = '✓ Onayla';
            onaylaBtn.onclick = async () => {
              const r = await fetch('/api/kullanici/onayla', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ad: k.ad }) }).then(res => res.json()).catch(() => ({}));
              if (!r.success) alert(r.error || 'Onaylanamadı');
              else { masaustuToastGoster(`${k.ad} kullanıcısı onaylandı!`); kullaniciVePinVerileriniYukle(); }
            };
            aksiyonlar.appendChild(onaylaBtn);
          }

          const sifreBtn = document.createElement('button');
          sifreBtn.type = 'button';
          sifreBtn.className = 'btn btn-ikincil';
          sifreBtn.style.cssText = 'padding:6px 10px; font-size:0.8rem; font-weight:800; border-radius:6px';
          sifreBtn.textContent = '🔑 Şifre Sıfırla';
          sifreBtn.onclick = async () => {
            if (!confirm(`${k.ad} kişisinin şifresi sıfırlansın mı? Bir sonraki girişte yeni şifresini kendisi belirleyecek.`)) return;
            const r = await fetch('/api/kullanici/sifre-sifirla', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ad: k.ad }) }).then(res => res.json()).catch(() => ({}));
            if (!r.success) alert(r.error || 'İşlem başarısız');
            else { masaustuToastGoster(`${k.ad} şifresi sıfırlandı!`); kullaniciVePinVerileriniYukle(); }
          };
          aksiyonlar.appendChild(sifreBtn);

          if (k.rol !== 'sahip') {
            const silBtn = document.createElement('button');
            silBtn.type = 'button';
            silBtn.className = 'btn';
            silBtn.style.cssText = 'background:#dc2626; color:#fff; border:none; padding:6px 10px; font-size:0.8rem; font-weight:800; border-radius:6px; cursor:pointer';
            silBtn.textContent = k.onayli ? '⛔ Erişimi Kaldır' : '✕ Reddet';
            silBtn.onclick = async () => {
              if (!confirm(`${k.ad} kişisinin erişimi kaldırılsın mı?`)) return;
              const r = await fetch('/api/kullanici/reddet', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ad: k.ad }) }).then(res => res.json()).catch(() => ({}));
              if (!r.success) alert(r.error || 'Silinemedi');
              else { masaustuToastGoster(`${k.ad} kaldırıldı.`); kullaniciVePinVerileriniYukle(); }
            };
            aksiyonlar.appendChild(silBtn);
          }

          listeKutusu.appendChild(kart);
        });
      }
    } catch (e) {
      if (listeKutusu) listeKutusu.innerHTML = `<div style="color:#f87171; padding:12px; text-align:center">Hata: ${e.message}</div>`;
    }
  }

  async function pinGuncelle() {
    const inp = $('kym-yeni-pin');
    const mesajEl = $('kym-pin-mesaj');
    if (!inp) return;
    const yeniPin = (inp.value || '').trim();
    if (!/^\d{4,6}$/.test(yeniPin)) {
      if (mesajEl) { mesajEl.style.color = '#f87171'; mesajEl.textContent = '⚠️ Şifre 4, 5 ya da 6 rakam olmalı. 6 rakam daha güvenlidir.'; }
      return;
    }
    try {
      const r = await fetch('/api/pin-degistir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ yeniPin })
      }).then(res => res.json());
      if (r.success) {
        if (mesajEl) { mesajEl.style.color = '#10b981'; mesajEl.textContent = '✅ PIN başarıyla güncellendi!'; }
        inp.value = '';
        const gosterge = $('kym-aktif-pin-gosterge');
        if (gosterge) gosterge.textContent = r.pin;
        masaustuToastGoster('Mağaza şifresi güncellendi.');
      } else {
        if (mesajEl) { mesajEl.style.color = '#f87171'; mesajEl.textContent = '❌ ' + (r.error || 'Değiştirilemedi.'); }
      }
    } catch (e) {
      if (mesajEl) { mesajEl.style.color = '#f87171'; mesajEl.textContent = '❌ Hata: ' + e.message; }
    }
  }

  async function lisansKoduAktiflestir() {
    const inp = $('kym-lisans-input');
    if (!inp) return;
    const kod = (inp.value || '').trim();
    if (!kod) { alert('Lütfen lisans kodunu yapıştırın.'); return; }
    try {
      const r = await fetch('/api/kullanici/lisans-yukle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lisansKodu: kod })
      }).then(res => res.json());
      if (!r.success) {
        alert('❌ ' + (r.error || 'Lisans doğrulanamadı.'));
      } else {
        alert('✅ Lisans aktifleştirildi! Yeni kullanıcı limiti: ' + (r.lisans?.kullaniciLimiti || '3'));
        inp.value = '';
        kullaniciVePinVerileriniYukle();
      }
    } catch (e) {
      alert('Hata: ' + e.message);
    }
  }

  // --- EL TERMİNALİ VE BARKOD TABANCASI İSTASYONU ---
  let g_elTerminaliSesAcik = true;
  let g_elTerminaliKip = 'ekle'; // 'ekle' veya 'dus'
  let g_elTerminaliOkumaSayisi = 0;
  let g_elTerminaliToplamAdet = 0;
  let g_elTerminaliGecmisi = [];

  function elTerminaliBip(tur = 'basarili') {
    if (!g_elTerminaliSesAcik) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (tur === 'basarili') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1900, ctx.currentTime);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.08);
      } else {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(260, ctx.currentTime);
        gain.gain.setValueAtTime(0.35, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.22);
      }
    } catch (_) {}
  }

  function elTerminaliModaliniAc() {
    const modal = $('el-terminali-modal');
    if (!modal) return;
    modal.style.display = 'flex';
    elTerminaliArayuzuGuncelle();
    setTimeout(() => {
      const inp = $('et-barkod-input');
      if (inp) { inp.value = ''; inp.focus(); }
    }, 100);
  }

  function elTerminaliModaliniKapat() {
    const modal = $('el-terminali-modal');
    if (modal) modal.style.display = 'none';
  }

  function elTerminaliArayuzuGuncelle() {
    const btnEkle = $('et-kip-ekle');
    const btnDus = $('et-kip-dus');
    if (btnEkle && btnDus) {
      if (g_elTerminaliKip === 'ekle') {
        btnEkle.className = 'btn btn-yesil';
        btnEkle.style.background = '#10b981';
        btnEkle.style.color = '#ffffff';
        btnDus.className = 'btn btn-ikincil';
        btnDus.style.background = '';
        btnDus.style.color = '';
      } else {
        btnDus.className = 'btn btn-kirmizi';
        btnDus.style.background = '#dc2626';
        btnDus.style.color = '#ffffff';
        btnEkle.className = 'btn btn-ikincil';
        btnEkle.style.background = '';
        btnEkle.style.color = '';
      }
    }
  }

  function elTerminaliKpiGuncelle() {
    const elOkuma = $('et-kpi-okuma-sayisi');
    const elAdet = $('et-kpi-toplam-adet');
    if (elOkuma) elOkuma.textContent = g_elTerminaliOkumaSayisi.toLocaleString('tr-TR');
    if (elAdet) elAdet.textContent = `${g_elTerminaliToplamAdet > 0 ? '+' : ''}${g_elTerminaliToplamAdet.toLocaleString('tr-TR')} Adet`;
  }

  function elTerminaliAkisCiz() {
    const govde = $('et-akis-govde');
    if (!govde) return;
    if (!g_elTerminaliGecmisi.length) {
      govde.innerHTML = '<tr><td colspan="6" style="padding:16px; text-align:center; color:var(--yazi-soluk)">Henüz bir barkod okutulmadı. Tabancayı tetiğe basıp bir barkod okutun.</td></tr>';
      return;
    }
    govde.innerHTML = g_elTerminaliGecmisi.slice(0, 15).map(g => {
      const basarili = g.durum === 'success';
      const badgeRenk = basarili ? (g.degisim.startsWith('+') ? '#10b981' : '#f87171') : '#ef4444';
      return `
        <tr style="border-bottom:1px solid var(--kenar); background:${basarili ? 'transparent' : 'rgba(239,68,68,0.06)'}">
          <td style="padding:7px 10px; color:var(--yazi-soluk); font-family:monospace; font-size:0.75rem">${g.saat}</td>
          <td style="padding:7px 10px; font-weight:800; font-family:monospace; color:#38bdf8">${g.barkod}</td>
          <td style="padding:7px 10px; font-weight:800; color:${basarili ? 'var(--yazi-ana)' : '#f87171'}">${g.urun}</td>
          <td style="padding:7px 10px; color:var(--yazi-soluk)">${g.varyant}</td>
          <td style="padding:7px 10px; text-align:center; font-weight:900; color:${badgeRenk}">${g.degisim}</td>
          <td style="padding:7px 10px; text-align:center; font-weight:800">${g.yeniStok}</td>
        </tr>
      `;
    }).join('');
  }

  async function elTerminaliBarkodIsle(kod) {
    const barkod = String(kod || '').trim();
    if (!barkod) return;

    const durumRozet = $('et-durum-rozet');
    const sonZaman = $('et-son-zaman');
    const saatStr = new Date().toLocaleTimeString('tr-TR');
    if (sonZaman) sonZaman.textContent = saatStr;

    const carpanSecim = $('et-carpan-secim');
    const miktar = Math.max(1, parseInt(carpanSecim?.value || '1', 10));
    const islem = g_elTerminaliKip === 'ekle' ? 'stok-ekle' : 'satis-dus';

    if (durumRozet) {
      durumRozet.style.color = '#38bdf8';
      durumRozet.textContent = `⏳ ${barkod} işleniyor...`;
    }

    try {
      const res = await fetch('/api/envanter/barkod', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          barkod,
          islem,
          adet: miktar,
          gun: g_gun
        })
      }).then(r => r.json());

      if (res.success) {
        elTerminaliBip('basarili');
        g_elTerminaliOkumaSayisi++;
        const degisim = g_elTerminaliKip === 'ekle' ? miktar : -miktar;
        g_elTerminaliToplamAdet += degisim;

        const varyantStr = [res.renk, res.beden].filter(Boolean).join(' / ') || 'Standart';
        const yeniStokStr = res.yeniAdet != null ? `${res.yeniAdet} Adet` : (res.urunToplamKalan != null ? `${res.urunToplamKalan} Adet` : 'Güncellendi');

        if (durumRozet) {
          durumRozet.style.color = '#10b981';
          durumRozet.textContent = `✅ ${res.urun} (${varyantStr}) -> ${g_elTerminaliKip === 'ekle' ? '+' : '-'}${miktar} (Yeni Stok: ${yeniStokStr})`;
        }

        const sonUrunEl = $('et-kpi-son-urun');
        if (sonUrunEl) sonUrunEl.textContent = `${res.urun} (${varyantStr})`;

        g_elTerminaliGecmisi.unshift({
          saat: saatStr,
          barkod,
          urun: res.urun,
          varyant: varyantStr,
          degisim: `${degisim > 0 ? '+' : ''}${degisim}`,
          yeniStok: yeniStokStr,
          durum: 'success'
        });

        elTerminaliAkisCiz();
        elTerminaliKpiGuncelle();
        verileriYukle();
      } else {
        elTerminaliBip('hata');
        if (durumRozet) {
          durumRozet.style.color = '#f87171';
          durumRozet.textContent = `❌ ${res.error || 'Barkod bulunamadı!'}`;
        }
        g_elTerminaliGecmisi.unshift({
          saat: saatStr,
          barkod,
          urun: 'Tanımsız / Bulunamadı',
          varyant: '-',
          degisim: '-',
          yeniStok: '-',
          durum: 'error',
          hata: res.error || 'Bulunamadı'
        });
        elTerminaliAkisCiz();
      }
    } catch (err) {
      elTerminaliBip('hata');
      if (durumRozet) {
        durumRozet.style.color = '#f87171';
        durumRozet.textContent = `❌ Sunucu hatası: ${err.message}`;
      }
    } finally {
      const inp = $('et-barkod-input');
      if (inp) {
        inp.value = '';
        inp.focus();
      }
    }
  }

  // Donanım Barkod Okuyucu (HID Klavye) Tamponu
  let g_hidBarkodBuffer = '';
  let g_hidSonTusZamani = 0;

  window.addEventListener('keydown', (e) => {
    const aktifEl = document.activeElement;
    const modalAcik = $('el-terminali-modal')?.style.display === 'flex';

    if (modalAcik && aktifEl && aktifEl.id === 'et-barkod-input') {
      return;
    }

    // Arama, ürün adı gibi bir yazı kutusundaysa okunan kod o kutuya yazılır; stok değişmez
    const yaziAlani = aktifEl && aktifEl !== document.body && (
      aktifEl.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(aktifEl.tagName)
    );
    if (yaziAlani) {
      g_hidBarkodBuffer = '';
      return;
    }

    const simdi = Date.now();
    const aralik = simdi - g_hidSonTusZamani;
    g_hidSonTusZamani = simdi;

    if (e.key === 'Enter') {
      if (g_hidBarkodBuffer.length >= 3 && aralik < 120) {
        const taranan = g_hidBarkodBuffer;
        g_hidBarkodBuffer = '';
        if (!modalAcik) {
          elTerminaliModaliniAc();
        }
        elTerminaliBarkodIsle(taranan);
        e.preventDefault();
      }
      g_hidBarkodBuffer = '';
      return;
    }

    if (e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) {
      if (aralik > 150) {
        g_hidBarkodBuffer = '';
      }
      g_hidBarkodBuffer += e.key;
    }
  });

  // El Terminali Modal Olay Dinleyicileri
  $('etm-kapat-btn')?.addEventListener('click', elTerminaliModaliniKapat);
  $('etm-alt-kapat-btn')?.addEventListener('click', elTerminaliModaliniKapat);

  $('et-kip-ekle')?.addEventListener('click', () => {
    g_elTerminaliKip = 'ekle';
    elTerminaliArayuzuGuncelle();
    $('et-barkod-input')?.focus();
  });

  $('et-kip-dus')?.addEventListener('click', () => {
    g_elTerminaliKip = 'dus';
    elTerminaliArayuzuGuncelle();
    $('et-barkod-input')?.focus();
  });

  $('et-ses-btn')?.addEventListener('click', () => {
    g_elTerminaliSesAcik = !g_elTerminaliSesAcik;
    const metinEl = $('et-ses-durum-metin');
    if (metinEl) metinEl.textContent = `Lazer Sesi: ${g_elTerminaliSesAcik ? 'Açık' : 'Kapalı'}`;
  });

  $('et-temizle-btn')?.addEventListener('click', () => {
    g_elTerminaliGecmisi = [];
    g_elTerminaliOkumaSayisi = 0;
    g_elTerminaliToplamAdet = 0;
    $('et-kpi-son-urun').textContent = '-';
    elTerminaliAkisCiz();
    elTerminaliKpiGuncelle();
    $('et-barkod-input')?.focus();
  });

  $('et-barkod-input')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const val = ($('et-barkod-input')?.value || '').trim();
      if (val) elTerminaliBarkodIsle(val);
    }
  });

  // Mobil Bağlantı & Kullanıcı Yönetimi Olay Dinleyicileri
  $('mbm-kapat-btn')?.addEventListener('click', mobilBaglantiModaliniKapat);
  $('mbm-alt-kapat-btn')?.addEventListener('click', mobilBaglantiModaliniKapat);
  $('mbm-kullanici-yonetim-gecis-btn')?.addEventListener('click', () => {
    mobilBaglantiModaliniKapat();
    kullaniciYonetimModaliniAc();
  });

  $('kym-kapat-btn')?.addEventListener('click', kullaniciYonetimModaliniKapat);
  $('kym-alt-kapat-btn')?.addEventListener('click', kullaniciYonetimModaliniKapat);
  $('kym-pin-kaydet-btn')?.addEventListener('click', pinGuncelle);
  $('kym-lisans-yukle-btn')?.addEventListener('click', lisansKoduAktiflestir);
  $('kym-bilgisayar-kodu-kopyala')?.addEventListener('click', async () => {
    const kod = ($('kym-bilgisayar-kodu')?.textContent || '').trim();
    if (!kod || kod === '…') return;
    try { await navigator.clipboard.writeText(kod); $('kym-bilgisayar-kodu-kopyala').textContent = 'Kopyalandı ✓'; }
    catch (_) { prompt('Bilgisayar kodu (kopyalayın):', kod); }
    setTimeout(() => { if ($('kym-bilgisayar-kodu-kopyala')) $('kym-bilgisayar-kodu-kopyala').textContent = 'Kopyala'; }, 2000);
  });
  $('kym-kullanici-tazele-btn')?.addEventListener('click', kullaniciVePinVerileriniYukle);

  // Başlangıç yüklemeleri
  lisansDurumuKontrolEt();
  firmaProfiliniYukle();

})();
