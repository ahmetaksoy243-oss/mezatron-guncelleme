// ============================================================================
// MEZATRON HİBRİT MOBİL MOTORU (mobil-hibrit.js)
// 1. Bilgisayar Kapalıyken (Offline/Standalone):
//    - Telefon kendi WebSpeech ses motorunu + yerel Türkçe telaffuz/beden/marka
//      çözümleyicisini (envanterCozYerel) kullanır.
//    - Tüm envanter kayıtlarını telefon hafızasında (localStorage + IndexedDB)
//      saklar, CSV/Excel olarak indirir veya WhatsApp'tan paylaşır.
// 2. Wi-Fi ile Bilgisayara Bağlandığında (Online Sync):
//    - Bilgisayarı (Port 3002 / 3442 veya kullanıcının girdiği Ev/Ofis PC IP'si)
//      algıladığı saniye bekleyen mobil kayıtları otomatik bilgisayara aktarır.
// 3. Bluetooth Termal Etiket Yazıcı (Web Bluetooth BLE + RawBT + Sistem Baskı):
//    - Bilgisayara ihtiyaç duymadan telefondan doğrudan Bluetooth termal yazıcıya
//      (TSPL / ESC-POS / Termal Şablon) barkod etiketi basar.
// ============================================================================

(function () {
  const DEPO_ANAHTAR_KUYRUK = 'mezatron_mobil_bekleyen_kuyruk_v1';
  const DEPO_ANAHTAR_ARSIV = 'mezatron_mobil_yerel_envanter_v1';
  const DEPO_ANAHTAR_PC_URL = 'mezatron_mobil_hedef_pc_url';
  const DEPO_ANAHTAR_YAZICI_KIP = 'mezatron_mobil_bt_yazici_kip'; // 'ble' | 'rawbt' | 'sistem'
  const DEPO_ANAHTAR_ETIKET_BOYUT = 'mezatron_mobil_etiket_boyut'; // 'kucuk' (50x30mm) | 'buyuk' (80x50mm)
  const DEPO_ANAHTAR_ETIKET_AYARLAR = 'mezatron_mobil_etiket_ayarlar_v2';

  function etiketAyarVarsayilan() {
    return {
      boyut: localStorage.getItem(DEPO_ANAHTAR_ETIKET_BOYUT) || 'kucuk',
      magazaAdi: '',
      fiyatGoster: true,
      bedenGoster: true,
      renkGoster: true,
      tarihGoster: false,
      kodGoster: true
    };
  }

  function etiketAyarOku() {
    try {
      const raw = localStorage.getItem(DEPO_ANAHTAR_ETIKET_AYARLAR);
      if (!raw) return etiketAyarVarsayilan();
      const parsed = JSON.parse(raw);
      return { ...etiketAyarVarsayilan(), ...parsed };
    } catch (_) {
      return etiketAyarVarsayilan();
    }
  }

  function etiketAyarKaydet(yeniAyar) {
    const guncel = { ...etiketAyarOku(), ...yeniAyar };
    if (guncel.boyut) localStorage.setItem(DEPO_ANAHTAR_ETIKET_BOYUT, guncel.boyut);
    localStorage.setItem(DEPO_ANAHTAR_ETIKET_AYARLAR, JSON.stringify(guncel));
    return guncel;
  }

  // --- 1. YEREL TÜRKÇE TELAFFUZ, MARKA, RENK VE BEDEN ÇÖZÜMLEYİCİ (TARAYICI İÇİ) ---
  const RENK_LISTESI = [
    ['YEŞİL ÇİZGİLİ', ['yeşil çizgili', 'yesil cizgili', 'çizgili yeşil']],
    ['YEŞİL GRİ', ['yeşil gri', 'yesil gri', 'gri yeşil']],
    ['SİYAH BEYAZ', ['siyah beyaz', 'beyaz siyah']],
    ['SİYAH GRİ', ['siyah gri', 'gri siyah']],
    ['SİYAH', ['siyah', 'siyahi', 'siya']],
    ['BEYAZ', ['beyaz', 'beyas', 'bayaz']],
    ['EKRU', ['ekru', 'kırık beyaz']],
    ['KREM', ['krem']],
    ['BEJ', ['bej']],
    ['VİZON', ['vizon']],
    ['TABA', ['taba', 'camel']],
    ['KAHVERENGİ', ['kahverengi', 'kahve rengi', 'kahve']],
    ['LACİVERT', ['lacivert', 'laci']],
    ['MAVİ', ['mavi', 'bebe mavisi', 'saks', 'indigo', 'petrol']],
    ['YEŞİL', ['yeşil', 'yesil', 'haki', 'su yeşili', 'mint']],
    ['KIRMIZI', ['kırmızı', 'kirmizi']],
    ['BORDO', ['bordo', 'kiremit']],
    ['PEMBE', ['pembe', 'pudra', 'fuşya', 'gül kurusu']],
    ['MOR', ['mor', 'lila']],
    ['SARI', ['sarı', 'sari', 'hardal']],
    ['TURUNCU', ['turuncu', 'somon']],
    ['GRİ', ['gri', 'antrasit', 'füme', 'fume']],
    ['GOLD', ['gold', 'altın rengi', 'altın']],
    ['GÜMÜŞ', ['gümüş', 'gumus']],
    ['MUHTELİF', ['muhtelif', 'karışık', 'çok renkli', 'rengarenk']],
    ['ÇİZGİLİ', ['çizgili', 'cizgili']],
    ['KARELİ', ['kareli', 'ekose']],
    ['DESENLİ', ['desenli', 'çiçekli', 'leopar']]
  ];

  function telaffuzDuzeltYerel(metin) {
    let s = String(metin || '')
      .replace(/(?<![\p{L}\p{N}])fiyaht(\p{L}*)/giu, 'fiyat$1')
      .replace(/(?<![\p{L}\p{N}])(?:yat|f[ıi]rat|[üu]cret\p{L}*)(?=\s+(?:\d|bir|iki|[üu][çc]|d[öo]rt|be[şs]|alt[ıi]|yedi|sekiz|dokuz|on|yirmi|otuz|k[ıi]rk|elli|altm[ıi][şs]|yetmi[şs]|seksen|doksan|y[üu]z|bin)\b)/giu, 'fiyat')
      .replace(/(?<![\p{L}\p{N}])g[üu]mlek(\p{L}*)(?![\p{L}\p{N}])/giu, 'gömlek$1')
      .replace(/(?<![\p{L}\p{N}])g[öo]mleki(?![\p{L}\p{N}])/giu, 'gömlek')
      .replace(/\brenk\s+(?:siyah|beyaz|gri|mavi|lacivert|ye[şs]il|k[ıi]rm[ıi]z[ıi]|sar[ıi]|kahverengi|bej|pembe|mor|turuncu|bordo|ekru|krem|muhtelif)[\s,.;]+renk\s+/giu, 'renk ')
      .replace(/(?<![\p{L}\p{N}])(?:be\s*den\s*le|bedenle|denle|beden\s+el)(?![\p{L}\p{N}])/giu, 'beden L')
      .replace(/(?<![\p{L}\p{N}])(?:be\s*den\s*em|bedenem|denem|beden\s+em|beden\s+me)(?![\p{L}\p{N}])/giu, 'beden M')
      .replace(/(?<![\p{L}\p{N}])(?:be\s*den\s*se|bedense|dense|beden\s+ise|beden\s+es)(?![\p{L}\p{N}])/giu, 'beden S')
      .replace(/(?<![\p{L}\p{N}])(?:v\s*y\s*k|vyk|(?:v|ve)\s*yak(?:aka|ak|ı|i|a|al[ıi]?))(?![\p{L}\p{N}])/giu, 'V Yaka')
      .replace(/(?<![\p{L}\p{N}])meden(?=\s+(?:\d{1,2}|xxs|xs|s|m|l|xl|xxl|2xl|3xl))(?![\p{L}\p{N}])/giu, 'beden')
      .replace(/(?<![\p{L}\p{N}])(?:kriği|krigi|krii)(?![\p{L}\p{N}])/giu, 'gri')
      .replace(/(?<![\p{L}\p{N}])kod\s+(mont|pantolon|ceket|g[öo]mlek|etek|yelek|şort)(?![\p{L}\p{N}])/giu, 'kot $1')
      .replace(/(?<![\p{L}\p{N}])(?:xide|x[\s\-]*side|iksayd)(?![\p{L}\p{N}])/giu, 'Xside')
      .replace(/(?<![\p{L}\p{N}])(?:bigastim|bigazi|bigazzi)(?![\p{L}\p{N}])/giu, 'Bigazzi')
      .replace(/(?<![\p{L}\p{N}])(?:jolun|jollman|rolman|rollman)(?=\s+ayakkab[ıi])(?![\p{L}\p{N}])/giu, 'Rollmann')
      .replace(/(?<![\p{L}\p{N}])(?:n[üu]rt\s*fajr[ıi]|nord\s*falce|nordfalce|nord\s*project|north\s*s|nord\s*face|nort\s*feys|nord)(?=\s+(?:ti[şs][öo]rt|t-?shirt|mont|polar|yelek|ceket|sweatshirt))(?![\p{L}\p{N}])/giu, 'North Face')
      .replace(/(?<![\p{L}\p{N}])t-?shirt(?![\p{L}\p{N}])/giu, 'tişört')
      .replace(/(?<![\p{L}\p{N}])(?:jengri|rengri|cenk\s*gri|ren\s*gri)(?![\p{L}\p{N}])/giu, 'renk gri')
      .replace(/(?<![\p{L}\p{N}])(?:gen[çc]\s*ya|gen[çc]\s*siyah|cenk\s*siyah|ren\s*siyah|renk\s*siya)(?![\p{L}\p{N}])/giu, 'renk siyah')
      .replace(/(?<![\p{L}\p{N}])(?:k[üu]l[üu][şs]\s*terlik|p[üu]l[üu][şs]\s*terlik|pelu[şs]\s*terlik)(?![\p{L}\p{N}])/giu, 'pelüş terlik')
      .replace(/(?<![\p{L}\p{N}])(?:rebok|ribok)(?![\p{L}\p{N}])/giu, 'Reebok')
      .replace(/(?<![\p{L}\p{N}])(?:grayder|greder|crader|grader|greyder)(?![\p{L}\p{N}])/giu, 'Greyder')
      .replace(/(?<![\p{L}\p{N}])(?:e[\s\-]*sharp|e[\s\-]*[şs]arp|e[şs]ak|e[şs]ap|e[şs]arf|e[şs]ar|esarf|esarp)(?![\p{L}\p{N}])/giu, 'eşarp')
      .replace(/(?<![\p{L}\p{N}])momma[\s\-]*i(?![\p{L}\p{N}])/giu, 'Moncler')
      .replace(/(?<![\p{L}\p{N}])(?:m\s*b|mb|n\s*b|nb|em\s*b|emb)['’.\-\s]*d[ae]n(?![\p{L}\p{N}])/giu, 'M beden')
      .replace(/(?<![\p{L}\p{N}])(?:l\s*b|lb|el\s*b|elb)['’.\-\s]*d[ae]n(?![\p{L}\p{N}])/giu, 'L beden')
      .replace(/(?<![\p{L}\p{N}])(?:s\s*b|sb|es\s*b|esb)['’.\-\s]*d[ae]n(?![\p{L}\p{N}])/giu, 'S beden')
      .replace(/(?<![\p{L}\p{N}])(?:parfum|parf[üu]n|perfume|tar[ıi]k[çc][ıi])(?![\p{L}\p{N}])/giu, 'Parfüm')
      .replace(/(?<![\p{L}\p{N}])(?:elle|elli|50)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '50ML')
      .replace(/(?<![\p{L}\p{N}])(?:y[üu]z|100)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '100ML')
      .replace(/(?<![\p{L}\p{N}])(\d{2,3})\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '$1ML')
      .replace(/\b(fiyat\p{L}*\s*:?\s*)([1-9]\d)(3[4-9]|4\d|5[0-6])(?=\s*(?:beden|numara)\b)/giu, '$1$200 $3');
    for (const k of mobilMarkaKurallari) {
      s = s.replace(k.regex, k.hedef);
    }
    return s;
  }

  let mobilMarkaKurallari = [];
  function mobilMarkaMdCoz(md) {
    if (!md) return;
    const kurallar = [];
    const kacir = str => String(str || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    for (const satir of String(md).split(/\r?\n/)) {
      const m = satir.match(/^\|\s*\*\*(.+?)\*\*\s*\|\s*([^|]+)\|/);
      if (!m) continue;
      const resmiMarka = m[1].trim();
      const varyantlar = m[2].split(',').map(x => x.trim().toLocaleLowerCase('tr-TR')).filter(x => x.length >= 2);
      for (const v of varyantlar) {
        const desenMetni = v.split(/\s+/).map(kacir).join('[\\s\\-._]*');
        kurallar.push({
          uzunluk: v.length,
          regex: new RegExp(`(?<![\\p{L}\\p{N}])(?:${desenMetni})(?![\\p{L}\\p{N}])`, 'giu'),
          hedef: resmiMarka
        });
      }
    }
    kurallar.sort((a, b) => b.uzunluk - a.uzunluk);
    mobilMarkaKurallari = kurallar;
  }
  try {
    const yerelMd = localStorage.getItem('mezatron_mobil_marka_sozluk_md_v1');
    if (yerelMd) mobilMarkaMdCoz(yerelMd);
    ortakSozlukGuncelle('MARKA_TELAFFUZ_SOZLUGU.md', localStorage.getItem('mezatron_mobil_marka_sozluk_md_v1'));
    ortakSozlukGuncelle('RENK_TELAFFUZ_SOZLUGU.md', localStorage.getItem('mezatron_mobil_renk_sozluk_md_v1'));
    fetch('./MARKA_TELAFFUZ_SOZLUGU.md', { cache: 'no-store' })
      .then(r => (r.ok ? r.text() : ''))
      .then(md => {
        if (md && md.includes('| **Nike** |')) {
          localStorage.setItem('mezatron_mobil_marka_sozluk_md_v1', md);
          ortakSozlukGuncelle('MARKA_TELAFFUZ_SOZLUGU.md', md);
          mobilMarkaMdCoz(md);
        }
      })
      .catch(() => {});
    const yerelRenkMd = localStorage.getItem('mezatron_mobil_renk_sozluk_md_v1');
    const renkMdUygula = md => {
      if (!md) return;
      for (const satir of String(md).split(/\r?\n/)) {
        const m = satir.match(/^\|\s*\*\*(.+?)\*\*\s*\|\s*([^|]+)\|/);
        if (!m) continue;
        const ad = m[1].trim().toLocaleUpperCase('tr-TR');
        const yazilislar = m[2].split(',').map(x => x.trim().toLocaleLowerCase('tr-TR')).filter(x => x.length >= 2);
        const mevcut = RENK_LISTESI.find(r => r[0] === ad);
        if (mevcut) {
          for (const y of yazilislar) { if (!mevcut[1].includes(y)) mevcut[1].push(y); }
        } else {
          RENK_LISTESI.push([ad, yazilislar]);
        }
      }
    };
    if (yerelRenkMd) renkMdUygula(yerelRenkMd);
    fetch('./RENK_TELAFFUZ_SOZLUGU.md', { cache: 'no-store' })
      .then(r => (r.ok ? r.text() : ''))
      .then(md => {
        if (md && md.includes('| **SİYAH** |')) {
          localStorage.setItem('mezatron_mobil_renk_sozluk_md_v1', md);
          ortakSozlukGuncelle('RENK_TELAFFUZ_SOZLUGU.md', md);
          renkMdUygula(md);
        }
      })
      .catch(() => {});
  } catch (_) {}

  function basHarflerBuyuk(str) {
    return String(str || '')
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .map(w => w.charAt(0).toLocaleUpperCase('tr-TR') + w.slice(1).toLocaleLowerCase('tr-TR'))
      .join(' ');
  }

  let sonUyarilanRed = 0;
  function kuyrukUyarisiGoster(metin) {
    const kutu = document.createElement('div');
    kutu.textContent = metin;
    kutu.style.cssText = 'position:fixed;left:12px;right:12px;bottom:18px;z-index:99999;padding:12px 14px;border-radius:10px;background:#7f1d1d;color:#fff;font-weight:800;font-size:15px;text-align:center';
    kutu.onclick = () => kutu.remove();
    document.body.appendChild(kutu);
    setTimeout(() => kutu.remove(), 12000);
  }

  function ortakSozlukGuncelle(dosya, metin) {
    const C = window.MezatEnvanterCozucu;
    if (C && typeof C.sozlukGuncelle === 'function') C.sozlukGuncelle(dosya, metin);
  }

  // Bilgisayardaki anlama kodunun telefondaki kopyası (envanter-cozucu.js). Yüklenemezse eski basit yönteme düşülür.
  function ortakCozucuyleCoz(hamMetin, yazili) {
    const C = window.MezatEnvanterCozucu;
    if (!C || typeof C.coz !== 'function') return null;
    try {
      const metin = String(hamMetin || '').slice(0, 2000);
      const c = C.coz(metin);
      const anlamli = (Array.isArray(c.satirlar) ? c.satirlar : []).filter(s => s && (s.renk || s.beden || (s.adet != null && Number(s.adet) > 0)));
      if (c.halusinasyon || (!c.urun && !c.fiyat && anlamli.length === 0) || (!yazili && !C.gecerliEnvanterSozuMu(metin, c, null))) {
        return { success: false, ortamSesiReddedildi: true, error: '⚠️ Ortam / TV sesi algılandı, geçerli bir ürün veya beden/adet duyulmadı.' };
      }
      const barkod = c.barkod || (c.urun ? C.otomatikBarkodUret(c.urun) : '');
      return {
        success: true, cevrimdisiMobil: true, metin, hamMetin: metin, ...c, barkod, otomatikBarkod: barkod,
        satirlar: (c.satirlar || []).map(s => ({ ...s, barkod: s.barkod || (c.urun ? C.otomatikBarkodUret(c.urun, s.renk, s.beden) : '') }))
      };
    } catch (_) {
      return null;
    }
  }

  function otomatikBarkodUretYerel(urunAdi, renk = '', beden = '') {
    const C = window.MezatEnvanterCozucu;
    if (C && typeof C.otomatikBarkodUret === 'function' && String(urunAdi || '').trim()) return C.otomatikBarkodUret(urunAdi, renk, beden);
    const temiz = String(urunAdi || 'URUN')
      .toLocaleUpperCase('tr-TR')
      .replace(/[ÇĞİÖŞÜ]/g, c => ({ Ç: 'C', Ğ: 'G', İ: 'I', Ö: 'O', Ş: 'S', Ü: 'U' }[c] || c))
      .replace(/[^A-Z0-9\s]/g, ' ')
      .trim();
    const kelimeler = temiz.split(/\s+/).filter(Boolean);
    const kok = ((kelimeler[0] || 'URN').slice(0, 3) + (kelimeler[1] || '').slice(0, 3)).padEnd(4, 'X').slice(0, 6);
    let hash = 0;
    for (let i = 0; i < temiz.length; i++) hash = (hash * 31 + temiz.charCodeAt(i)) % 900;
    const ana = `MZU-${kok}-${String(100 + hash)}`;
    const rKod = String(renk || '').toLocaleUpperCase('tr-TR').replace(/[ÇĞİÖŞÜ]/g, c => ({ Ç: 'C', Ğ: 'G', İ: 'I', Ö: 'O', Ş: 'S', Ü: 'U' }[c] || c)).replace(/[^A-Z0-9]/g, '').slice(0, 3);
    const bKod = String(beden || '').toLocaleUpperCase('tr-TR').replace(/[^A-Z0-9]/g, '').slice(0, 4);
    return [ana, rKod, bKod].filter(Boolean).join('-');
  }

  // Bilgisayar kapalıyken telefondaki ses/yazı metnini anında ürün + fiyat + renk + beden + adet tablosuna çevirir
  function envanterCozYerel(hamMetin, secenek = {}) {
    const ortak = ortakCozucuyleCoz(hamMetin, Boolean(secenek.yazili));
    if (ortak && (secenek.yazili || !ortak.success)) return ortak;
    const duzeltilmis = telaffuzDuzeltYerel(hamMetin);
    let kalan = duzeltilmis;

    // 1. Fiyat yakala ("fiyat 1500", "1250 lira", "fiyatı 400 TL")
    let fiyat = null;
    const fiyatEs1 = kalan.match(/\bfiyat\p{L}*\s*:?\s*(\d{2,6})(?:\s*(?:tl|lira|₺))?\b/iu);
    const fiyatEs2 = kalan.match(/\b(\d{2,6})\s*(?:tl|lira|₺)\b/iu);
    if (fiyatEs1) {
      fiyat = Number(fiyatEs1[1]);
      kalan = kalan.replace(fiyatEs1[0], ' ');
    } else if (fiyatEs2) {
      fiyat = Number(fiyatEs2[1]);
      kalan = kalan.replace(fiyatEs2[0], ' ');
    }

    // 2. Renk yakala
    let renk = '';
    const kucuk = kalan.toLocaleLowerCase('tr-TR');
    for (const [standartRenk, varyantlar] of RENK_LISTESI) {
      const bulundu = varyantlar.find(v => new RegExp(`(?<![\\p{L}\\p{N}])(?:renk\\s+)?${v}(?![\\p{L}\\p{N}])`, 'iu').test(kucuk));
      if (bulundu) {
        renk = standartRenk;
        kalan = kalan.replace(new RegExp(`(?<![\\p{L}\\p{N}])(?:renk\\s+)?${bulundu}(?:\\s+renk(?:te|li)?)?(?![\\p{L}\\p{N}])`, 'giu'), ' ');
        break;
      }
    }

    // 3. Beden / Hacim yakala ("beden XL", "42 beden", "40 numara", "beden 3", "50ML", "100ML")
    let beden = '';
    const mlEs = kalan.match(/\b(\d{2,3}ML)\b/iu);
    const bedenEs1 = kalan.match(/\b(?:beden|numara)\s*:?\s*(xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|5xl|\d{1,2})\b/iu);
    const bedenEs2 = kalan.match(/\b(xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|5xl|\d{2})\s*(?:beden|numara)\b/iu);
    if (mlEs) {
      beden = mlEs[1].toUpperCase();
      kalan = kalan.replace(mlEs[0], ' ');
    } else if (bedenEs1) {
      beden = bedenEs1[1].toUpperCase();
      kalan = kalan.replace(bedenEs1[0], ' ');
    } else if (bedenEs2) {
      beden = bedenEs2[1].toUpperCase();
      kalan = kalan.replace(bedenEs2[0], ' ');
    }

    // 4. Adet yakala ("5 adet", "adet 15", "10 tane")
    let adet = 1;
    const adetEs1 = kalan.match(/\b(?:adet|tane)\s*:?\s*(\d{1,4})\b/iu);
    const adetEs2 = kalan.match(/\b(\d{1,4})\s*(?:adet|tane)\b/iu);
    if (adetEs1) {
      adet = Number(adetEs1[1]);
      kalan = kalan.replace(adetEs1[0], ' ');
    } else if (adetEs2) {
      adet = Number(adetEs2[1]);
      kalan = kalan.replace(adetEs2[0], ' ');
    }

    // 5. Kalan temiz kelimeler ürün adıdır
    const urunHam = kalan
      .replace(/\b(?:renk|beden|numara|fiyat|fiyatı|adet|tane|lira|tl)\b/giu, ' ')
      .replace(/[.,;:!?'"()[\]{}]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    const urun = basHarflerBuyuk(urunHam);
    const giyimKategoriVar = /\b(ti[şs][öo]rt|t-?shirt|g[öo]mlek|kazak|triko|s[üu]veter|s[üu]eter|h[ıi]rka|yelek|mont|kaban|tren[çc]kot|tren[çc]|ceket|pantolon|jean|kot|jogger|[şs]ort|etek|elbise|tulum|e[şs]ofman|sweat|polar|bluz|tunik|b[üu]stiyer|kimono|pareo|kaftan|ferace|pan[çc]o|badi|atlet|tayt|tak[ıi]m|pijama|[çc]orap|ayakkab[ıi]|bot|loafer|[çc]ar[ıi]k|terlik|sandalet|[çc]anta|c[üu]zdan|kemer|[şs]apka|bere|atk[ıi]|e[şs]arp|[şs]al|fular|g[öo]zl[üu]k|parf[üu]m|deodorant|kolonya|krem|[şs]ampuan|sabun|havlu|bornoz|nevresim|battaniye|yast[ıi]k|perde|hal[ıi]|yaka|keten|ipek|pamuk|ka[şs]mir|deri|pel[üu][şs])\b/iu.test(duzeltilmis);
    const kuraldanMarkaVar = mobilMarkaKurallari.some(k =>
      duzeltilmis.toLocaleLowerCase('tr-TR').includes(String(k.hedef || '').toLocaleLowerCase('tr-TR'))
    );
    const eskiMarkaListesi = [
      ...(typeof MARKA_LISTESI !== 'undefined' && Array.isArray(MARKA_LISTESI) ? MARKA_LISTESI : []),
      ...(typeof dinamikMarkaListesi !== 'undefined' && Array.isArray(dinamikMarkaListesi) ? dinamikMarkaListesi : [])
    ];
    const sozlukMarkaVar = kuraldanMarkaVar || eskiMarkaListesi.some(([resmi]) =>
      duzeltilmis.toLocaleLowerCase('tr-TR').includes(String(resmi || '').toLocaleLowerCase('tr-TR'))
    );
    const acikAnahtarVar = /\b(beden|numara|adet|tane|fiyat|lira|tl|renk)\b/iu.test(hamMetin || '');
    if (!giyimKategoriVar && !sozlukMarkaVar && !acikAnahtarVar && !fiyat && !renk && !beden) {
      return {
        success: false,
        ortamSesiReddedildi: true,
        error: '⚠️ Ortam / TV sesi algılandı, geçerli bir ürün veya beden/adet duyulmadı.'
      };
    }
    // Ses, yukarıdaki ortam sesi süzgecinden geçtikten sonra bilgisayarla aynı kodla çözülür
    if (ortak) return ortak;
    const barkod = urun ? otomatikBarkodUretYerel(urun) : '';
    const satirBarkod = urun ? otomatikBarkodUretYerel(urun, renk, beden) : '';

    return {
      success: true,
      cevrimdisiMobil: true,
      metin: duzeltilmis,
      urun,
      fiyat,
      barkod,
      satirlar: [{ renk, beden, adet: adet || 1, barkod: satirBarkod }],
      uyarilar: []
    };
  }

  // Telefondaki iki motorun (Seda ve Balbal) yazdığını, bilgisayarla aynı anlama koduyla tek sonuca çevirir
  function telefonMotorSonucu(m) {
    const C = window.MezatEnvanterCozucu;
    const sayi = t => (C && typeof C.turkceSayiItn === 'function') ? C.turkceSayiItn(t) : t;
    const adaylar = [m && m.seda, m && (m.balbal || m.mihu)]
      .map(t => String(t || '').trim())
      .filter(Boolean)
      .map(t => envanterCozYerel(sayi(t)))
      .filter(r => r && r.success);
    if (!adaylar.length) return { success: false, error: 'Ses anlaşılmadı. Tekrar söyleyin.' };
    const ana = { ...adaylar[0], satirlar: (adaylar[0].satirlar || []).map(s => ({ ...s })) };
    const diger = adaylar[1];
    const sade = t => String(t || '').toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]/gu, '');
    let motorlarAyrildi = false;
    if (diger) {
      if (!ana.urun && diger.urun) ana.urun = diger.urun;
      else if (ana.urun && diger.urun && sade(ana.urun) !== sade(diger.urun)) motorlarAyrildi = true;
      if (!ana.fiyat && diger.fiyat) ana.fiyat = diger.fiyat;
      const ds = (diger.satirlar || [])[0];
      if (!ana.satirlar.length) ana.satirlar = (diger.satirlar || []).map(s => ({ ...s }));
      else if (ds) {
        const s = ana.satirlar[0];
        if (!s.renk && ds.renk) s.renk = ds.renk;
        if (!s.beden && ds.beden) s.beden = ds.beden;
        if (s.adet == null && ds.adet != null) s.adet = ds.adet;
      }
    }
    if (ana.urun) {
      ana.barkod = otomatikBarkodUretYerel(ana.urun);
      ana.otomatikBarkod = ana.barkod;
      ana.satirlar = ana.satirlar.map(s => ({ ...s, barkod: otomatikBarkodUretYerel(ana.urun, s.renk, s.beden) }));
    }
    return { ...ana, motorlarAyrildi };
  }

  // --- 2. YEREL DEPO VE OTOMATİK WI-FI BİLGİSAYAR SENKRONİZASYONU ---
  // Uygulamanın kalıcı deposu: bilgisayardan açılan sayfa ile telefondaki sayfa aynı kayıtları görür. Tarayıcıda eskisi gibi çalışır.
  function kaliciDepoVarMi() {
    try { return Boolean(window.MezatNativeApp && typeof window.MezatNativeApp.depoYaz === 'function'); } catch (_) { return false; }
  }
  function depoOku(anahtar) {
    if (kaliciDepoVarMi()) {
      const deger = window.MezatNativeApp.depoOku(anahtar);
      if (deger) return deger;
    }
    return localStorage.getItem(anahtar) || '';
  }
  function depoYaz(anahtar, metin) {
    if (kaliciDepoVarMi() && window.MezatNativeApp.depoYaz(anahtar, metin)) {
      try { localStorage.removeItem(anahtar); } catch (_) {}
      return;
    }
    localStorage.setItem(anahtar, metin);
  }
  // Eski sürümden kalan kayıtları kalıcı depoya taşır, aynı kayıt iki kez eklenmez
  (function eskiKayitlariTasi() {
    if (!kaliciDepoVarMi()) return;
    try {
      const tasi = (anahtar, ayni) => {
        const eski = localStorage.getItem(anahtar);
        if (!eski) return;
        const liste = JSON.parse(eski);
        const mevcut = JSON.parse(window.MezatNativeApp.depoOku(anahtar) || '[]');
        const yeni = liste.filter(x => !mevcut.some(m => ayni(m, x)));
        if (!yeni.length || window.MezatNativeApp.depoYaz(anahtar, JSON.stringify([...mevcut, ...yeni]))) localStorage.removeItem(anahtar);
      };
      tasi(DEPO_ANAHTAR_KUYRUK, (a, b) => Boolean(a.istekId) && a.istekId === b.istekId);
      tasi(DEPO_ANAHTAR_ARSIV, (a, b) => (a.id && a.id === b.id) || String(a.urun || '').toLocaleLowerCase('tr-TR') === String(b.urun || '').toLocaleLowerCase('tr-TR'));
    } catch (_) {}
  })();

  function bekleyenKuyruguOku() {
    try {
      return JSON.parse(depoOku(DEPO_ANAHTAR_KUYRUK) || '[]');
    } catch (_) {
      return [];
    }
  }

  function bekleyenKuyruguYaz(liste) {
    try {
      depoYaz(DEPO_ANAHTAR_KUYRUK, JSON.stringify(liste || []));
    } catch (_) {}
    kuyrukRozetiGuncelle();
  }

  function yerelEnvanteriOku() {
    try {
      return JSON.parse(depoOku(DEPO_ANAHTAR_ARSIV) || '[]');
    } catch (_) {
      return [];
    }
  }

  function yerelEnvanteriYaz(liste) {
    try {
      depoYaz(DEPO_ANAHTAR_ARSIV, JSON.stringify(liste || []));
    } catch (_) {}
  }

  // Bilgisayar kapalıyken telefondaki kaydı yerel hafızaya ve senkron kuyruğuna ekler
  function ceptenCevrimdisiKaydet(girdi) {
    const simdi = Date.now();
    const urun = basHarflerBuyuk(girdi.urun || '');
    if (!urun) return { success: false, error: 'Ürün adı boş bırakılamaz.' };
    const fiyat = girdi.fiyat ? Number(String(girdi.fiyat).replace(',', '.')) : null;
    const anaBarkod = girdi.barkod || otomatikBarkodUretYerel(urun);
    const satirlar = (Array.isArray(girdi.satirlar) && girdi.satirlar.length ? girdi.satirlar : [{ renk: '', beden: '', adet: 1 }])
      .filter(s => s && Number(s.adet) > 0)
      .map(s => ({
        renk: String(s.renk || '').trim().toLocaleUpperCase('tr-TR'),
        beden: String(s.beden || '').trim().toLocaleUpperCase('tr-TR'),
        adet: Number(s.adet) || 1,
        barkod: s.barkod || otomatikBarkodUretYerel(urun, s.renk, s.beden)
      }));

    if (!satirlar.length) return { success: false, error: 'En az 1 geçerli beden/adet satırı girin.' };

    const kayit = {
      id: girdi.id || `MOBIL-${simdi}-${Math.floor(Math.random() * 900 + 100)}`,
      istekId: girdi.istekId || `mobil-istek-${simdi}`,
      urun,
      fiyat: Number.isFinite(fiyat) && fiyat > 0 ? fiyat : null,
      barkod: anaBarkod,
      satirlar,
      giren: girdi.giren || 'Mobil Depo',
      soz: girdi.soz || '',
      zamanMs: simdi,
      surum: 1,
      mobilCevrimdisi: true
    };

    const arsiv = yerelEnvanteriOku();
    const mevcutIdx = arsiv.findIndex(x => x.id === kayit.id || x.urun.toLocaleLowerCase('tr-TR') === urun.toLocaleLowerCase('tr-TR'));
    if (mevcutIdx >= 0 && !girdi.ayriKayit) {
      arsiv[mevcutIdx] = {
        ...arsiv[mevcutIdx],
        fiyat: kayit.fiyat != null ? kayit.fiyat : arsiv[mevcutIdx].fiyat,
        satirlar: [...arsiv[mevcutIdx].satirlar, ...kayit.satirlar],
        duzeltildiMs: simdi
      };
    } else {
      arsiv.push(kayit);
    }
    yerelEnvanteriYaz(arsiv);

    const kuyruk = bekleyenKuyruguOku();
    kuyruk.push({
      ...girdi,
      id: undefined,
      birlestir: undefined,
      ayriKayit: false,
      urun: kayit.urun,
      fiyat: kayit.fiyat,
      barkod: kayit.barkod,
      satirlar: kayit.satirlar,
      giren: kayit.giren,
      soz: kayit.soz,
      istekId: kayit.istekId,
      zamanMs: simdi
    });
    bekleyenKuyruguYaz(kuyruk);

    return {
      success: true,
      mobilCevrimdisi: true,
      kayit,
      bekleyenSayisi: kuyruk.length
    };
  }

  // --- BARKOD BANKASI: bilgisayardaki banka telefona alınır, bilgisayar kapalıyken buradan bakılır ---
  const DEPO_ANAHTAR_BANKA = 'mezatron_mobil_barkod_bankasi_v1';

  function barkodBankasiOku() {
    try {
      const v = JSON.parse(depoOku(DEPO_ANAHTAR_BANKA) || 'null');
      if (v && Array.isArray(v.urunler)) return v;
    } catch (_) {}
    return { urunler: [], toplamUrun: 0, toplamBarkod: 0, zamanMs: 0 };
  }

  // Yalnız aramasız, tam liste verilir. Boş ya da hatalı cevap eldeki bankayı silmez.
  function barkodBankasiniSakla(veri) {
    const eski = barkodBankasiOku();
    if (!kaliciDepoVarMi() || !veri || !veri.success || !Array.isArray(veri.urunler)) return { saklandi: false, toplamBarkod: eski.toplamBarkod };
    const urunler = veri.urunler.filter(u => u && u.urun).map(u => ({
      urun: u.urun,
      anaBarkod: u.anaBarkod || '',
      fiyat: u.fiyat != null ? u.fiyat : null,
      zamanMs: u.zamanMs || 0,
      varyantlar: (u.varyantlar || []).filter(v => v && v.barkod).map(v => ({
        barkod: v.barkod,
        renk: v.renk || '',
        beden: v.beden || '',
        fiyat: v.fiyat != null ? v.fiyat : null,
        sonAdet: v.sonAdet || 1
      }))
    }));
    if (!urunler.length && eski.urunler.length) return { saklandi: false, toplamBarkod: eski.toplamBarkod };
    const toplamBarkod = Number(veri.toplamBarkod) || 0;
    if (JSON.stringify(urunler) === JSON.stringify(eski.urunler)) return { saklandi: false, ayni: true, toplamBarkod };
    depoYaz(DEPO_ANAHTAR_BANKA, JSON.stringify({ urunler, toplamUrun: urunler.length, toplamBarkod, zamanMs: Date.now() }));
    return { saklandi: true, toplamBarkod };
  }

  // Bilgisayarda liste temizlendiyse telefondaki eski kopya da temizlenir; temizlikten sonra telefonda yapılanlar kalır
  const DEPO_ANAHTAR_SIFIRLAMA = 'mezatron_mobil_sifirlama_ms_v1';
  function bilgisayarTemizliginiUygula(sifirlamaMs) {
    const ms = Number(sifirlamaMs) || 0;
    if (!ms || !kaliciDepoVarMi()) return { temizlendi: false };
    const bilinen = Number(depoOku(DEPO_ANAHTAR_SIFIRLAMA) || 0) || 0;
    if (ms <= bilinen) return { temizlendi: false };
    const sonraMi = x => Number((x && (x.duzeltildiMs || x.zamanMs)) || 0) > ms;
    yerelEnvanteriYaz(yerelEnvanteriOku().filter(sonraMi));
    bekleyenKuyruguYaz(bekleyenKuyruguOku().filter(x => Number((x && x.zamanMs) || 0) > ms));
    depoYaz(DEPO_ANAHTAR_BANKA, JSON.stringify({ urunler: [], toplamUrun: 0, toplamBarkod: 0, zamanMs: Date.now() }));
    depoYaz(DEPO_ANAHTAR_SIFIRLAMA, String(ms));
    try { kuyrukRozetiGuncelle(); } catch (_) {}
    return { temizlendi: true };
  }

  // Bilgisayarsız fiyat değişikliği: telefondaki liste ve bankada güncellenir, bilgisayar açılınca uygulanır
  function telefondaFiyatDegistir({ barkod = '', fiyat = null, urun = '', renk = '', beden = '' } = {}) {
    const kod = String(barkod || '').trim().toUpperCase();
    const yeni = Math.round(Number(String(fiyat == null ? '' : fiyat).replace(',', '.')) * 100) / 100;
    if (!Number.isFinite(yeni) || yeni <= 0) return { success: false, error: 'Fiyat geçersiz.' };
    const banka = kod ? bankadaBarkodBul(kod) : null;
    const ad = (banka && banka.urun) || String(urun || '').trim();
    if (!ad) return { success: false, error: 'Ürün bulunamadı.' };
    const anahtar = String(ad).toLocaleLowerCase('tr-TR');
    const arsiv = yerelEnvanteriOku();
    let degisti = false;
    for (const k of arsiv) if (String(k.urun || '').toLocaleLowerCase('tr-TR') === anahtar) { k.fiyat = yeni; k.duzeltildiMs = Date.now(); degisti = true; }
    if (degisti) yerelEnvanteriYaz(arsiv);
    try {
      const b = barkodBankasiOku();
      let bd = false;
      for (const u of b.urunler) if (String(u.urun || '').toLocaleLowerCase('tr-TR') === anahtar) { u.fiyat = yeni; (u.varyantlar || []).forEach(v => { v.fiyat = yeni; }); bd = true; }
      if (bd && kaliciDepoVarMi()) depoYaz(DEPO_ANAHTAR_BANKA, JSON.stringify(b));
    } catch (_) {}
    const simdi = Date.now();
    const kuyruk = bekleyenKuyruguOku();
    kuyruk.push({ tur: 'barkod-islem', islem: 'fiyat', barkod: kod, fiyat: yeni, adet: 1, urun: ad, renk: renk || '', beden: beden || '', giren: 'Mobil Depo',
      istekId: `mobil-fiyat-${simdi}-${Math.floor(Math.random() * 90000 + 10000)}`, zamanMs: simdi });
    bekleyenKuyruguYaz(kuyruk);
    try { kuyrukRozetiGuncelle(); } catch (_) {}
    return { success: true, sadeceKuyruk: true, urun: ad, fiyat: yeni };
  }

  function bankadaBarkodBul(hamKod) {
    const kod = String(hamKod || '').trim().toUpperCase();
    if (!kod) return null;
    for (const u of barkodBankasiOku().urunler) {
      const v = (u.varyantlar || []).find(x => String(x.barkod || '').toUpperCase() === kod);
      if (v) return { success: true, bulundu: true, bankadan: true, barkod: kod, anaBarkod: u.anaBarkod || kod, urun: u.urun, fiyat: v.fiyat != null ? v.fiyat : u.fiyat, renk: v.renk || '', beden: v.beden || '' };
      if (String(u.anaBarkod || '').toUpperCase() === kod) return { success: true, bulundu: true, bankadan: true, barkod: kod, anaBarkod: u.anaBarkod, urun: u.urun, fiyat: u.fiyat, renk: '', beden: '' };
    }
    return null;
  }

  // Bilgisayarsız barkodla stok girişi: telefondaki listeye eklenir, bilgisayara yalnız eklenen adet gider (çift sayılmaz)
  function telefondaStokEkle({ urun = '', fiyat = null, anaBarkod = '', barkod = '', renk = '', beden = '', adet = 1, giren = '' } = {}) {
    const ad = basHarflerBuyuk(urun);
    const kod = String(barkod || '').trim().toUpperCase();
    if (!ad || !kod) return { success: false, error: 'Ürün veya barkod eksik.' };
    const miktar = Math.max(1, Math.round(Number(adet) || 1));
    const R = String(renk || '').trim().toLocaleUpperCase('tr-TR');
    const B = String(beden || '').trim().toLocaleUpperCase('tr-TR');
    const ana = String(anaBarkod || kod).toUpperCase();
    const fiyatSayi = Number(fiyat);
    const gecerliFiyat = Number.isFinite(fiyatSayi) && fiyatSayi > 0 ? fiyatSayi : null;
    const simdi = Date.now();
    const ek = Math.floor(Math.random() * 900 + 100);
    const arsiv = yerelEnvanteriOku();
    const adKucuk = ad.toLocaleLowerCase('tr-TR');
    let k = arsiv.find(x => String(x.urun || '').toLocaleLowerCase('tr-TR') === adKucuk);
    if (!k) {
      k = { id: `MOBIL-${simdi}-${ek}`, istekId: `mobil-istek-${simdi}-${ek}`, urun: ad, fiyat: gecerliFiyat, barkod: ana, satirlar: [], giren: giren || 'Mobil Depo', soz: '', zamanMs: simdi, surum: 1, mobilCevrimdisi: true };
      arsiv.push(k);
    }
    k.satirlar = k.satirlar || [];
    const satir = k.satirlar.find(s => String(s.barkod || '').toUpperCase() === kod) || k.satirlar.find(s => String(s.renk || '') === R && String(s.beden || '') === B);
    if (satir) satir.adet = (Number(satir.adet) || 0) + miktar;
    else k.satirlar.push({ renk: R, beden: B, adet: miktar, barkod: kod });
    k.duzeltildiMs = simdi;
    yerelEnvanteriYaz(arsiv);
    const kuyruk = bekleyenKuyruguOku();
    kuyruk.push({ urun: ad, fiyat: gecerliFiyat, barkod: ana, satirlar: [{ renk: R, beden: B, adet: miktar, barkod: kod }], giren: giren || k.giren || 'Mobil Depo', soz: '', istekId: `mobil-stok-${simdi}-${ek}`, zamanMs: simdi });
    bekleyenKuyruguYaz(kuyruk);
    return { success: true, mobilCevrimdisi: true, kayitId: k.id, bekleyenSayisi: kuyruk.length };
  }

  // Bilgisayar adresi telefon uygulamasında saklanır (kare kodla eşleme, ağda arama ya da elle yazma)
  function hedefPcKokUrl() {
    const ozel = (localStorage.getItem(DEPO_ANAHTAR_PC_URL) || '').trim().replace(/\/+$/, '');
    if (window.location.protocol === 'file:') {
      if (window.MezatNativeApp && typeof window.MezatNativeApp.sunucuUrlOku === 'function') {
        try {
          const okunan = String(window.MezatNativeApp.sunucuUrlOku() || '').trim().replace(/\/+$/, '');
          if (okunan) return okunan;
        } catch (_) {}
      }
      return ozel || 'https://192.168.8.3:3442';
    }
    if (ozel) return ozel;
    if (window.MezatNativeApp && typeof window.MezatNativeApp.sunucuUrlKaydet === 'function' && window.location.origin && window.location.origin.startsWith('http')) {
      try { window.MezatNativeApp.sunucuUrlKaydet(window.location.origin); } catch (_) {}
    }
    return '';
  }

  // Bilgisayarın kabul etmediği barkod işlemleri (satış, giriş, iade…) silinmez; bu ayrı listede saklanır
  const DEPO_ANAHTAR_UYGULANAMAYAN = 'mezatron_mobil_uygulanamayan_v1';
  function uygulanamayanlariOku() {
    try { return JSON.parse(depoOku(DEPO_ANAHTAR_UYGULANAMAYAN) || '[]'); } catch (_) { return []; }
  }
  function uygulanamayanlaraEkle(liste) {
    if (!liste.length) return;
    try { depoYaz(DEPO_ANAHTAR_UYGULANAMAYAN, JSON.stringify([...uygulanamayanlariOku(), ...liste].slice(-500))); } catch (_) {}
  }
  // Kuyruktaki bir kaydın kimliği: istekId; eski kayıtlarda kaydın tamamı
  const kuyrukAnahtari = x => (x && x.istekId) ? `i:${x.istekId}` : `j:${JSON.stringify(x)}`;

  let senkronCalisiyor = false;
  async function bekleyenleriBilgisayaraAktar(manuel = false) {
    if (senkronCalisiyor) return { aktandi: 0, kalan: bekleyenKuyruguOku().length };
    const kuyruk = bekleyenKuyruguOku();
    if (!kuyruk.length) {
      kuyrukRozetiGuncelle();
      return { aktandi: 0, kalan: 0 };
    }
    senkronCalisiyor = true;
    const kok = hedefPcKokUrl();
    let aktarilan = 0;
    let reddedilen = 0;
    // Yalnız bilgisayara gerçekten ulaşan (ya da ayrı listeye alınan) kayıtlar kuyruktan çıkar.
    // Aktarma sürerken eklenen yeni kayıtlar bu yüzden kaybolmaz.
    const bitenler = new Set();
    const reddedilenIslemler = [];

    const uygulanamayan = [];
    for (let i = 0; i < kuyruk.length; i++) {
      const kalem = kuyruk[i];
      try {
        if (kalem && kalem.tur === 'barkod-islem') {
          const res = await fetch(`${kok}/api/envanter/barkod`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ islem: kalem.islem, barkod: kalem.barkod, adet: kalem.adet, fiyat: kalem.fiyat, urun: kalem.urun, renk: kalem.renk, beden: kalem.beden, giren: kalem.giren, istekId: kalem.istekId }),
            signal: AbortSignal.timeout(3500)
          });
          const j = await res.json();
          if (j && j.success) aktarilan++;
          else {
            const neden = (j && j.error) || 'uygulanamadı';
            uygulanamayan.push(`${kalem.urun || kalem.barkod}: ${neden}`);
            reddedilenIslemler.push({ ...kalem, hata: neden, reddedildiMs: Date.now() });
          }
          bitenler.add(kuyrukAnahtari(kalem));
          continue;
        }
        // Telefonda açılan ürünün kimliği bilgisayarda yoktur: düzeltme değil yeni kayıt olarak gider
        const gidecek = { ...kalem };
        if (String(gidecek.id || '').startsWith('MOBIL-')) { delete gidecek.id; delete gidecek.surum; }
        const res = await fetch(`${kok}/api/envanter/kaydet`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(gidecek),
          signal: AbortSignal.timeout(3500)
        });
        const j = await res.json();
        let tamam = Boolean(j && j.success);
        // Eğer aynı ürün bilgisayarda zaten varsa üstüne birleştir; sonucu doğrulanmadan kuyruktan silinmez
        if (j && j.cift && j.mevcut && j.mevcut.id) {
          const res2 = await fetch(`${kok}/api/envanter/kaydet`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...gidecek, birlestir: j.mevcut.id, ayriKayit: false, istekId: `${kalem.istekId || kalem.id || kalem.urun}-birlestir` }),
            signal: AbortSignal.timeout(3500)
          });
          const j2 = await res2.json();
          tamam = Boolean(j2 && j2.success);
        }
        if (tamam) {
          aktarilan++;
          bitenler.add(kuyrukAnahtari(kalem));
        } else {
          reddedilen++; // kuyrukta kalır, sonra yeniden denenir
        }
      } catch (_) {
        // Bilgisayara ulaşılamadı: sıra bozulmasın diye bu ve sonraki kayıtlar bekler
        break;
      }
    }

    // Önce reddedilenleri sakla, sonra kuyruğu GÜNCEL hâlinden temizle (aradaki yeni kayıtlar korunur)
    uygulanamayanlaraEkle(reddedilenIslemler);
    const kalanlar = bekleyenKuyruguOku().filter(x => !bitenler.has(kuyrukAnahtari(x)));
    bekleyenKuyruguYaz(kalanlar);
    if (uygulanamayan.length) {
      kuyrukUyarisiGoster(`⚠️ Bilgisayarsız yapılan ${uygulanamayan.length} işlem bilgisayarda uygulanamadı: ${uygulanamayan.slice(0, 3).join(' · ')}. Bu işlemler telefonda saklandı; bilgisayardaki adedi kontrol edin.`);
    }
    senkronCalisiyor = false;
    kuyrukRozetiGuncelle();
    if (reddedilen > 0 && reddedilen !== sonUyarilanRed) {
      sonUyarilanRed = reddedilen;
      kuyrukUyarisiGoster(`⚠️ ${reddedilen} kayıt bilgisayara aktarılamadı. Bilgisayardaki kayıt değişmiş olabilir, kontrol edin.`);
    } else if (reddedilen === 0) {
      sonUyarilanRed = 0;
    }

    if (aktarilan > 0 && typeof window.mobilSenkronBildir === 'function') {
      window.mobilSenkronBildir(aktarilan, kalanlar.length, manuel);
    }
    return { aktandi: aktarilan, aktarilan, kalan: kalanlar.length };
  }

  // Sunucuya kaydedilen ürünü de cep telefonundaki kalıcı envanter dosyasına yansıtır
  function yerelEnvantereYansit(kayit) {
    if (!kayit || !kayit.urun) return;
    try {
      const arsiv = yerelEnvanteriOku();
      const anaBarkod = kayit.barkod || yerelAnaBarkodUret(kayit.urun);
      const satirlar = (kayit.satirlar || []).map(s => ({
        ...s,
        barkod: s.barkod || yerelVaryantBarkodUret(anaBarkod, s.renk, s.beden)
      }));
      const kopya = {
        ...kayit,
        barkod: anaBarkod,
        satirlar,
        zamanMs: kayit.zamanMs || Date.now()
      };
      const idx = arsiv.findIndex(x => (kopya.id && x.id === kopya.id) || String(x.urun || '').toLocaleLowerCase('tr-TR') === String(kopya.urun || '').toLocaleLowerCase('tr-TR'));
      if (idx >= 0) {
        arsiv[idx] = kopya;
      } else {
        arsiv.push(kopya);
      }
      yerelEnvanteriYaz(arsiv);
    } catch (_) {}
  }

  function yerelEnvanterdenSil(id, urunAdi = '') {
    try {
      const arananId = String(id || '').trim();
      const arananAd = String(urunAdi || '').trim().toLocaleLowerCase('tr-TR');
      const arsiv = yerelEnvanteriOku().filter(x => {
        if (arananId && x.id === arananId) return false;
        if (arananAd && String(x.urun || '').trim().toLocaleLowerCase('tr-TR') === arananAd) return false;
        return true;
      });
      yerelEnvanteriYaz(arsiv);
      const kuyruk = bekleyenKuyruguOku().filter(x => {
        if (arananId && x.id === arananId) return false;
        if (arananAd && String(x.urun || '').trim().toLocaleLowerCase('tr-TR') === arananAd) return false;
        return true;
      });
      bekleyenKuyruguYaz(kuyruk);
    } catch (_) {}
  }

  function yerelEnvanteriSifirla() {
    try {
      yerelEnvanteriYaz([]);
      bekleyenKuyruguYaz([]);
      kuyrukRozetiGuncelle();
    } catch (_) {}
  }

  function yerelBarkodSatisDus({ barkod = '', adet = 1, geriAl = false, cevrimdisiKuyrugaEkle = false, urun = '', renk = '', beden = '' } = {}) {
    const kod = String(barkod || '').trim().toUpperCase();
    if (!kod) return { success: false, error: 'Barkod numarası geçersiz.' };
    const miktar = Math.max(1, Math.round(Number(adet) || 1));
    const arsiv = yerelEnvanteriOku();

    let kIdx = -1;
    let sIdx = -1;
    for (let i = 0; i < arsiv.length; i++) {
      const k = arsiv[i];
      const sList = k.satirlar || [];
      const vIdx = sList.findIndex(s =>
        (s.barkod && String(s.barkod).toUpperCase() === kod) ||
        otomatikBarkodUretYerel(k.urun, s.renk, s.beden).toUpperCase() === kod
      );
      if (vIdx >= 0) {
        kIdx = i;
        sIdx = vIdx;
        break;
      }
      const anaKod = String(k.barkod || yerelAnaBarkodUret(k.urun)).toUpperCase();
      if (anaKod === kod && sList.length > 0) {
        kIdx = i;
        const stoklu = sList.findIndex(s => (Number(s.adet) || 0) > 0);
        sIdx = stoklu >= 0 ? stoklu : 0;
        break;
      }
    }

    if (kIdx < 0 || sIdx < 0) {
      // Telefondaki listede yok ama barkod bankasında (ya da okutulan bilgide) varsa: işlem saklanır, bilgisayar açılınca uygulanır
      const banka = bankadaBarkodBul(kod);
      const ad = (banka && banka.urun) || String(urun || '').trim();
      if (cevrimdisiKuyrugaEkle && ad) {
        const R = (banka ? banka.renk : renk) || '';
        const B = (banka ? banka.beden : beden) || '';
        const simdi = Date.now();
        const kuyruk = bekleyenKuyruguOku();
        kuyruk.push({ tur: 'barkod-islem', islem: geriAl ? 'stok-ekle' : 'satis-dus', barkod: kod, adet: miktar, urun: ad, renk: R, beden: B, giren: 'Mobil Depo',
          istekId: `mobil-islem-${simdi}-${Math.floor(Math.random() * 90000 + 10000)}`, zamanMs: simdi });
        bekleyenKuyruguYaz(kuyruk);
        try { kuyrukRozetiGuncelle(); } catch (_) {}
        return { success: true, sadeceKuyruk: true, islem: geriAl ? 'iade' : 'satis-dus', barkod: kod, urun: ad, renk: R, beden: B, dusulenAdet: miktar, kalanAdet: null, bekleyenSayisi: kuyruk.length };
      }
      return { success: false, error: `Bu barkod (${kod}) telefonda bulunamadı. Barkod bankasını bilgisayar açıkken yenileyin.` };
    }

    const k = arsiv[kIdx];
    const satir = k.satirlar[sIdx];
    const oncekiAdet = Number(satir.adet) || 0;
    if (!geriAl && oncekiAdet <= 0) {
      return {
        success: false,
        stokBitti: true,
        urun: k.urun,
        renk: satir.renk || '',
        beden: satir.beden || '',
        kalanAdet: 0,
        error: `⚠️ ${k.urun} (${[satir.renk, satir.beden].filter(Boolean).join(' ') || 'STD'}) stoğu zaten 0 (tükenmiş)!`
      };
    }

    const yeniAdet = geriAl ? (oncekiAdet + miktar) : Math.max(0, oncekiAdet - miktar);
    satir.adet = yeniAdet;
    k.duzeltildiMs = Date.now();
    yerelEnvanteriYaz(arsiv);

    if (cevrimdisiKuyrugaEkle) {
      try {
        // Ürünün tamamı değil yalnız yapılan işlem saklanır: bilgisayardaki adetten düşülür ya da eklenir
        const kuyruk = bekleyenKuyruguOku();
        const simdi = Date.now();
        kuyruk.push({
          tur: 'barkod-islem',
          islem: geriAl ? 'stok-ekle' : 'satis-dus',
          barkod: String(satir.barkod || otomatikBarkodUretYerel(k.urun, satir.renk, satir.beden) || kod).toUpperCase(),
          adet: miktar,
          urun: k.urun,
          renk: satir.renk || '',
          beden: satir.beden || '',
          giren: 'Mobil Depo',
          istekId: `mobil-islem-${simdi}-${Math.floor(Math.random() * 90000 + 10000)}`,
          zamanMs: simdi
        });
        bekleyenKuyruguYaz(kuyruk);
        kuyrukRozetiGuncelle();
      } catch (_) {}
    }

    const urunToplamKalan = k.satirlar.reduce((t, s) => t + Math.max(0, Number(s.adet) || 0), 0);
    return {
      success: true,
      islem: geriAl ? 'iade' : 'satis-dus',
      barkod: satir.barkod || k.barkod || kod,
      anaBarkod: k.barkod || yerelAnaBarkodUret(k.urun),
      kayitId: k.id,
      urun: k.urun,
      fiyat: k.fiyat,
      renk: satir.renk || '',
      beden: satir.beden || '',
      oncekiAdet,
      dusulenAdet: miktar,
      kalanAdet: yeniAdet,
      urunToplamKalan,
      kayit: k
    };
  }

  function yerelExcelSatirlariniCikar() {
    const kayitlar = yerelEnvanteriOku();
    const satirlar = [];
    let sira = 0;
    kayitlar.forEach(k => {
      sira++;
      const anaBarkod = k.barkod || yerelAnaBarkodUret(k.urun || `URUN-${sira}`);
      const saat = new Date(k.duzeltildiMs || k.zamanMs || Date.now()).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
      const fiyat = k.fiyat != null && k.fiyat !== '' ? Number(k.fiyat) : '';
      (k.satirlar || []).forEach(s => {
        const kalan = Number(s.adet) || 0;
        const varyantBarkod = s.barkod || yerelVaryantBarkodUret(anaBarkod, s.renk, s.beden);
        const tutar = fiyat !== '' ? Math.round(fiyat * kalan * 100) / 100 : '';
        satirlar.push({
          sira,
          barkod: varyantBarkod,
          anaBarkod,
          urun: k.urun || '',
          renk: s.renk || 'Standart',
          beden: s.beden || 'STD',
          kalan,
          fiyat,
          tutar,
          giren: k.giren || 'Mobil Depo',
          saat
        });
      });
    });
    return { kayitlar, satirlar };
  }

  // Telefondaki yerel envanteri bilgisayara ihtiyaç duymadan Excel (.xls) veya CSV olarak indirir
  function yerelExcelIndir(tur = 'xls') {
    const { kayitlar, satirlar } = yerelExcelSatirlariniCikar();
    const gun = new Date().toISOString().slice(0, 10);
    if (String(tur).toLowerCase() === 'xls') {
      const toplamAdet = satirlar.reduce((t, s) => t + (Number(s.kalan) || 0), 0);
      const toplamTutar = satirlar.reduce((t, s) => t + (Number(s.tutar) || 0), 0);
      const trSatirlar = satirlar.map(s => `
        <tr>
          <td style="text-align:center">${s.sira}</td>
          <td style="font-weight:bold;mso-number-format:'\\@'">${s.barkod}</td>
          <td style="font-weight:bold">${s.urun}</td>
          <td>${s.renk}</td>
          <td style="text-align:center;font-weight:bold">${s.beden}</td>
          <td style="text-align:right;font-weight:bold">${s.kalan}</td>
          <td style="text-align:right">${s.fiyat !== '' ? s.fiyat : ''}</td>
          <td style="text-align:right;font-weight:bold">${s.tutar !== '' ? s.tutar : ''}</td>
          <td>${s.giren}</td>
          <td style="text-align:center">${s.saat}</td>
        </tr>`).join('');
      const htmlIcerik = '\uFEFF' + `<!DOCTYPE html><html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"></head><body>
        <table border="1" cellspacing="0" cellpadding="5" style="border-collapse:collapse;font-family:Calibri,Arial,sans-serif;font-size:11pt">
          <thead>
            <tr style="background:#0f172a;color:#ffffff;font-weight:bold"><th colspan="10">MEZATRON AI — BARKODLU KALICI ENVANTER LİSTESİ (${gun})</th></tr>
            <tr style="background:#1e3a8a;color:#ffffff;font-weight:bold">
              <th>Sıra</th><th>Barkod Numarası</th><th>Ürün Adı</th><th>Renk</th><th>Beden</th><th>Kalan Adet</th><th>Birim Fiyat (TL)</th><th>Toplam Tutar (TL)</th><th>Sayımı Yapan</th><th>Saat</th>
            </tr>
          </thead>
          <tbody>${trSatirlar}</tbody>
          <tfoot>
            <tr style="background:#dcfce7;font-weight:bold">
              <td colspan="5">GENEL TOPLAM (${kayitlar.length} Ürün Çeşidi)</td>
              <td style="text-align:right">${toplamAdet}</td>
              <td></td>
              <td style="text-align:right">${Math.round(toplamTutar * 100) / 100} TL</td>
              <td colspan="2"></td>
            </tr>
          </tfoot>
        </table>
      </body></html>`;
      const blob = new Blob([htmlIcerik], { type: 'application/vnd.ms-excel;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Mezatron-Kalici-Envanter-${gun}.xls`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      return;
    }
    const basliklar = ['Sıra', 'Barkod Numarası', 'Ürün Adı', 'Renk', 'Beden', 'Kalan Adet', 'Birim Fiyat (TL)', 'Toplam Tutar (TL)', 'Sayımı Yapan', 'Saat'];
    const csvSatirlar = satirlar.map(s => [s.sira, s.barkod, s.urun, s.renk, s.beden, s.kalan, s.fiyat, s.tutar, s.giren, s.saat]);
    const csvIcerik = '\uFEFF' + [basliklar, ...csvSatirlar]
      .map(r => r.map(h => `"${String(h ?? '').replace(/"/g, '""')}"`).join(';'))
      .join('\r\n');
    const blob = new Blob([csvIcerik], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Mezatron-Kalici-Envanter-${gun}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  // --- 3. BLUETOOTH TERMAL ETİKET YAZICI MOTORU (BLE + RawBT + Sistem Baskı) ---
  let btCihaz = null;
  let btKarakteristik = null;

  // Yazıcıya giden yazı: Türkçe harfler sadeleşir, tırnak komutu bozmasın diye değişir, yazıcının bilmediği işaret ? olur
  function turkceAsciiTemizle(metin) {
    return String(metin || '')
      .replace(/[çÇğĞıİöÖşŞüÜ]/g, c => ({
        ç: 'c', Ç: 'C', ğ: 'g', Ğ: 'G', ı: 'i', İ: 'I', ö: 'o', Ö: 'O', ş: 's', Ş: 'S', ü: 'u', Ü: 'U'
      }[c] || c))
      .replace(/"/g, "'")
      .replace(/[^\x20-\x7e]/g, '?');
  }

  // --- Telefon uygulamasının kendi Bluetooth bağlantısı (klasik Bluetooth, eşleşmiş yazıcı) ---
  const ORTAK_YAZICI_ANAHTARI = 'bt_yazici';
  function yerelYaziciVarMi() {
    return Boolean(window.MezatNativeApp && typeof window.MezatNativeApp.yaziciGonder === 'function');
  }
  // Seçim telefon uygulamasında saklanır: bilgisayardan ya da telefondan açılan sayfa aynı yazıcıyı görür
  function yerelYaziciOku() {
    try {
      const k = window.MezatNativeApp;
      const ham = k && typeof k.ortakOku === 'function' ? k.ortakOku(ORTAK_YAZICI_ANAHTARI) : '';
      const y = ham ? JSON.parse(ham) : null;
      return y && y.adres ? y : null;
    } catch (_) {
      return null;
    }
  }
  function yerelYaziciKaydet(y) {
    const k = window.MezatNativeApp;
    if (!k || typeof k.ortakYaz !== 'function') return;
    const dil = y && ['tspl', 'escpos', 'cpcl'].includes(y.dil) ? y.dil : 'tspl';
    k.ortakYaz(ORTAK_YAZICI_ANAHTARI, y && y.adres ? JSON.stringify({ ad: String(y.ad || '').slice(0, 60), adres: String(y.adres), dil }) : '');
  }
  function yerelYaziciListesi() {
    const k = window.MezatNativeApp;
    if (!k || typeof k.yaziciListesi !== 'function') return { liste: [], hata: 'Telefon uygulamanız eski, yazıcı listesi alınamıyor.' };
    try { return JSON.parse(k.yaziciListesi()) || { liste: [] }; } catch (_) { return { liste: [], hata: 'Yazıcı listesi alınamadı.' }; }
  }
  function metinBaytlari(m) {
    const b = [];
    for (const ch of String(m)) { const c = ch.charCodeAt(0); b.push(c < 128 ? c : 63); }
    return b;
  }
  function etiketParcalari(kayit, satir, ayarlar) {
    const parcalar = [];
    if (ayarlar.renkGoster !== false && satir.renk) parcalar.push(satir.renk);
    if (ayarlar.bedenGoster !== false && satir.beden) parcalar.push(`Beden:${satir.beden}`);
    return {
      urun: turkceAsciiTemizle(kayit.urun || 'URUN'),
      varyant: turkceAsciiTemizle(parcalar.join(' ') || 'Standart'),
      fiyat: (ayarlar.fiyatGoster !== false && kayit.fiyat) ? `${kayit.fiyat} TL` : '',
      barkod: turkceAsciiTemizle(satir.barkod || kayit.barkod || 'MZU-0001'),
      magaza: turkceAsciiTemizle(ayarlar.magazaAdi || '').slice(0, 30)
    };
  }
  // ESC/POS (fiş yazıcıları): ortalı yazı ve CODE128 barkod
  function escposEtiketBaytlari(kayit, satir, ayarlar) {
    const e = etiketParcalari(kayit, satir, ayarlar);
    const b = [0x1b, 0x40, 0x1b, 0x61, 0x01];
    if (e.magaza) b.push(...metinBaytlari(e.magaza), 0x0a);
    b.push(0x1b, 0x45, 0x01, ...metinBaytlari(e.urun.slice(0, 32)), 0x1b, 0x45, 0x00, 0x0a);
    b.push(...metinBaytlari(`${e.varyant}  ${e.fiyat}`.trim().slice(0, 32)), 0x0a);
    const kod = '{B' + e.barkod.slice(0, 40);
    b.push(0x1d, 0x68, 60, 0x1d, 0x77, 2, 0x1d, 0x48, 2, 0x1d, 0x6b, 73, kod.length, ...metinBaytlari(kod));
    b.push(0x0a, 0x0a, 0x0a);
    return b;
  }
  // CPCL (cep yazıcıları)
  function cpclEtiketKomutuUret(kayit, satir, ayarlar) {
    const e = etiketParcalari(kayit, satir, ayarlar);
    const buyuk = ayarlar.boyut === 'buyuk';
    const ust = e.magaza ? 34 : 0;
    return [
      `! 0 200 200 ${buyuk ? 400 : 240} 1`,
      e.magaza ? `TEXT 7 0 16 8 ${e.magaza}` : '',
      `TEXT 4 0 16 ${8 + ust} ${e.urun.slice(0, buyuk ? 30 : 22)}`,
      `TEXT 7 0 16 ${56 + ust} ${e.varyant}  ${e.fiyat}`,
      `BARCODE 128 1 1 ${buyuk ? 80 : 50} 16 ${84 + ust} ${e.barkod}`,
      `TEXT 7 0 16 ${(buyuk ? 170 : 140) + ust} ${e.barkod}`,
      'FORM',
      'PRINT',
      ''
    ].filter(s => s !== '').join('\r\n') + '\r\n';
  }
  function yerelKomutBaytlari(dil, kayit, satir, ayarlar) {
    if (dil === 'escpos') return escposEtiketBaytlari(kayit, satir, ayarlar);
    if (dil === 'cpcl') return metinBaytlari(cpclEtiketKomutuUret(kayit, satir, ayarlar));
    return metinBaytlari(tsplEtiketKomutuUret(kayit, satir, ayarlar) + '\r\n');
  }
  function hedefPcAdresiKaydet(url) {
    const temiz = String(url || '').trim().replace(/\/+$/, '');
    localStorage.setItem(DEPO_ANAHTAR_PC_URL, temiz);
    const k = window.MezatNativeApp;
    if (temiz && k && typeof k.sunucuUrlKaydet === 'function') { try { k.sunucuUrlKaydet(temiz); } catch (_) {} }
    return temiz;
  }

  // 2 Boyutlu Taşınabilir Termal Etiket için TSPL ve ESC/POS Komut Üretici (50x30mm veya 80x50mm)
  function tsplEtiketKomutuUret(kayit, satir, ayarlar = etiketAyarOku()) {
    const buyukMu = ayarlar.boyut === 'buyuk';
    const urun = turkceAsciiTemizle(kayit.urun || 'URUN').slice(0, buyukMu ? 34 : 26);
    const parcalar = [];
    if (ayarlar.renkGoster !== false && satir.renk) parcalar.push(satir.renk);
    if (ayarlar.bedenGoster !== false && satir.beden) parcalar.push(`Beden:${satir.beden}`);
    const varyant = turkceAsciiTemizle(parcalar.join(' ') || 'Standart');
    const fiyat = (ayarlar.fiyatGoster !== false && kayit.fiyat) ? `${kayit.fiyat} TL` : '';
    const barkod = turkceAsciiTemizle(satir.barkod || kayit.barkod || 'MZU-0001');
    const magaza = turkceAsciiTemizle(ayarlar.magazaAdi || '').slice(0, 30);
    const tarih = ayarlar.tarihGoster ? new Date().toLocaleDateString('tr-TR') : '';

    if (buyukMu) {
      // 80x50mm Taşınabilir Geniş Sticker
      return [
        'SIZE 80 mm, 50 mm',
        'GAP 2 mm, 0 mm',
        'DIRECTION 1',
        'CLS',
        magaza ? `TEXT 24,16,"3",0,1,1,"${magaza}"` : '',
        `TEXT 24,${magaza ? 50 : 24},"4",0,1,1,"${urun}"`,
        `TEXT 24,${magaza ? 95 : 68},"3",0,1,1,"${varyant}  ${fiyat}"`,
        `BARCODE 24,${magaza ? 140 : 110},"128",80,1,0,2,3,"${barkod}"`,
        `TEXT 24,${magaza ? 235 : 205},"2",0,1,1,"${barkod}  ${tarih}"`,
        'PRINT 1,1',
        ''
      ].filter(Boolean).join('\r\n');
    }

    // 50x30mm Standart Küçük Sticker
    return [
      'SIZE 50 mm, 30 mm',
      'GAP 2 mm, 0 mm',
      'DIRECTION 1',
      'CLS',
      magaza ? `TEXT 16,8,"2",0,1,1,"${magaza}"` : '',
      `TEXT 16,${magaza ? 32 : 14},"3",0,1,1,"${urun}"`,
      `TEXT 16,${magaza ? 64 : 46},"2",0,1,1,"${varyant}  ${fiyat}"`,
      `BARCODE 16,${magaza ? 92 : 78},"128",55,1,0,2,2,"${barkod}"`,
      'PRINT 1,1',
      ''
    ].filter(Boolean).join('\r\n');
  }

  async function bluetoothYaziciBagla() {
    if (!navigator.bluetooth) {
      throw new Error('Bu tarayıcıda doğrudan Web Bluetooth kapalı. "Sistem / RawBT" kipiyle tüm Bluetooth yazıcılara çıktı alabilirsiniz.');
    }
    btCihaz = await navigator.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: [
        '000018f0-0000-1000-8000-00805f9b34fb',
        'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
        '49535343-fe7d-4ae5-8fa9-9fafd205e455',
        '0000ff00-0000-1000-8000-00805f9b34fb'
      ]
    });
    const sunucu = await btCihaz.gatt.connect();
    const servisler = await sunucu.getPrimaryServices();
    for (const s of servisler) {
      const karList = await s.getCharacteristics();
      const yazilabilir = karList.find(k => k.properties.write || k.properties.writeWithoutResponse);
      if (yazilabilir) {
        btKarakteristik = yazilabilir;
        break;
      }
    }
    if (!btKarakteristik) throw new Error('Yazıcı karakteristiği bulunamadı.');
    return btCihaz.name || 'Bluetooth Termal Yazıcı';
  }

  // Telefondan doğrudan Bluetooth Termal Etiket Yazdırır (2 Boy: 50x30mm Küçük veya 80x50mm Büyük)
  async function bluetoothTermalEtiketBas(kayit, kip = 'varyant') {
    const yaziciKip = localStorage.getItem(DEPO_ANAHTAR_YAZICI_KIP) || 'sistem';
    const ayarlar = etiketAyarOku();
    const buyukMu = ayarlar.boyut === 'buyuk';
    const wMm = buyukMu ? 80 : 50;
    const hMm = buyukMu ? 50 : 30;
    const boyutMetin = buyukMu ? 'Büyük Sticker (80x50mm)' : 'Küçük Sticker (50x30mm)';

    const tumAdetlerMi = kip === 'tum-adetler';
    const hamSatirlar = (Array.isArray(kayit.satirlar) && kayit.satirlar.length)
      ? kayit.satirlar
      : [{ renk: '', beden: '', adet: 1, barkod: kayit.barkod || otomatikBarkodUretYerel(kayit.urun) }];

    const basilacakEtiketler = [];
    hamSatirlar.forEach(s => {
      const kopyaSayisi = tumAdetlerMi ? Math.min(200, Math.max(1, Number(s.adet) || 1)) : 1;
      for (let i = 0; i < kopyaSayisi; i++) {
        basilacakEtiketler.push({
          ...s,
          etiketKopyaNo: i + 1,
          etiketToplamKopya: kopyaSayisi,
          tumAdetlerMi
        });
      }
    });

    // 0. Telefon uygulamasının kendi Bluetooth bağlantısı: seçili eşleşmiş yazıcıya doğrudan (TSPL, ESC/POS ya da CPCL)
    const yerelYazici = yerelYaziciVarMi() ? yerelYaziciOku() : null;
    if (yerelYazici && (yaziciKip === 'otomatik' || yaziciKip === 'sistem' || yaziciKip === 'sistem-termal')) {
      const baytlar = [];
      for (const s of basilacakEtiketler) baytlar.push(...yerelKomutBaytlari(yerelYazici.dil, kayit, s, ayarlar));
      let ikili = '';
      for (const x of baytlar) ikili += String.fromCharCode(x);
      const hata = String(window.MezatNativeApp.yaziciGonder(yerelYazici.adres, btoa(ikili)) || '');
      if (hata) throw new Error(hata);
      return { success: true, yontem: `Bluetooth (${yerelYazici.ad || 'yazıcı'})`, kip: tumAdetlerMi ? 'Tüm Adetler' : 'Varyant Özeti', adet: basilacakEtiketler.length };
    }

    // 1. Web Bluetooth (BLE) Doğrudan Gönderim
    if ((yaziciKip === 'ble' || yaziciKip === 'ble-tspl') && btKarakteristik) {
      const enc = new TextEncoder();
      for (const s of basilacakEtiketler) {
        const veri = enc.encode(tsplEtiketKomutuUret(kayit, s, ayarlar));
        for (let i = 0; i < veri.length; i += 120) {
          const parca = veri.slice(i, i + 120);
          if (btKarakteristik.properties.writeWithoutResponse) {
            await btKarakteristik.writeValueWithoutResponse(parca);
          } else {
            await btKarakteristik.writeValue(parca);
          }
        }
      }
      return { success: true, yontem: `Web Bluetooth (${boyutMetin})`, kip: tumAdetlerMi ? 'Tüm Adetler' : 'Varyant Özeti', adet: basilacakEtiketler.length };
    }

    // 2. Android RawBT Köprüsü (Tek tıkla sessiz Bluetooth yazdırma)
    if (yaziciKip === 'rawbt') {
      const tumKomut = basilacakEtiketler.map(s => tsplEtiketKomutuUret(kayit, s, ayarlar)).join('\r\n');
      const b64 = btoa(unescape(encodeURIComponent(tumKomut)));
      window.location.href = `rawbt:base64,${b64}`;
      return { success: true, yontem: `RawBT Bluetooth (${boyutMetin})`, kip: tumAdetlerMi ? 'Tüm Adetler' : 'Varyant Özeti', adet: basilacakEtiketler.length };
    }

    // 3. Evrensel Mobil Termal Etiket Penceresi (Taşınabilir Bluetooth/Wi-Fi Sistem Yazıcısı)
    let yazdirAlan = document.getElementById('mobil-bt-etiket-cerceve');
    if (!yazdirAlan) {
      yazdirAlan = document.createElement('iframe');
      yazdirAlan.id = 'mobil-bt-etiket-cerceve';
      yazdirAlan.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
      document.body.appendChild(yazdirAlan);
    }

    const etiketlerHtml = basilacakEtiketler.map(s => {
      const kod = s.barkod || kayit.barkod || otomatikBarkodUretYerel(kayit.urun, s.renk, s.beden);
      let svgHtml = '';
      if (window.MezatBarkod && typeof window.MezatBarkod.svgUret === 'function') {
        svgHtml = window.MezatBarkod.svgUret(kod, { yukseklik: buyukMu ? 48 : 34 });
      }
      const renkStr = (ayarlar.renkGoster !== false && s.renk) ? s.renk : '';
      const ortaBilgi = s.tumAdetlerMi
        ? `${renkStr || 'STANDART'} · Parça ${s.etiketKopyaNo}/${s.etiketToplamKopya}`
        : `${renkStr || 'STANDART'} · Toplam ${s.adet || 1} Adet`;
      const fiyatHtml = (ayarlar.fiyatGoster !== false && kayit.fiyat) ? `<b>${kayit.fiyat} TL</b>` : '';
      const magazaHtml = ayarlar.magazaAdi ? `<div class="magaza">${ayarlar.magazaAdi}</div>` : '';
      const bedenHtml = (ayarlar.bedenGoster !== false && s.beden) ? `<span class="beden">${s.beden}</span>` : '';
      const tarihHtml = ayarlar.tarihGoster ? `<span class="tarih">${new Date().toLocaleDateString('tr-TR')}</span>` : '';

      return `
        <div class="etiket">
          ${magazaHtml}
          <div class="ust">
            <span class="urun">${ kayit.urun || 'Ürün' }</span>
            ${ bedenHtml }
          </div>
          <div class="orta">
            <span>${ ortaBilgi }</span>
            ${ fiyatHtml }
          </div>
          <div class="barkod">${ svgHtml }</div>
          <div class="kod-satir">
            <span class="kod">${ kod }</span>
            ${ tarihHtml }
          </div>
        </div>
      `;
    }).join('');

    const doc = yazdirAlan.contentWindow.document;
    doc.open();
    doc.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><style>
      @page { size: ${wMm}mm ${hMm}mm; margin: 0; }
      body { margin: 0; padding: 0; font-family: Arial, sans-serif; background: #fff; color: #000; }
      .etiket { width: ${wMm}mm; height: ${hMm}mm; padding: ${buyukMu ? '2.5mm 3mm' : '1.8mm 2mm'}; box-sizing: border-box; page-break-after: always; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; }
      .etiket:last-child { page-break-after: auto; }
      .magaza { font-size: ${buyukMu ? '8.5pt' : '6.5pt'}; font-weight: 800; letter-spacing: 0.5px; text-transform: uppercase; color: #1e293b; text-align: center; border-bottom: 0.5px solid #cbd5e1; padding-bottom: 0.8mm; margin-bottom: 0.8mm; }
      .ust { display: flex; justify-content: space-between; align-items: center; gap: 2mm; }
      .urun { font-weight: 900; font-size: ${buyukMu ? '12pt' : '9.5pt'}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .beden { font-weight: 900; font-size: ${buyukMu ? '14pt' : '11pt'}; border: 1.5px solid #000; padding: 0 1.5mm; }
      .orta { display: flex; justify-content: space-between; font-size: ${buyukMu ? '10pt' : '8pt'}; font-weight: 700; margin: 0.5mm 0; }
      .barkod { flex: 1; display: flex; align-items: center; justify-content: center; min-height: 0; }
      .barkod svg { width: 100%; height: ${buyukMu ? '15mm' : '11mm'}; }
      .kod-satir { display: flex; justify-content: space-between; align-items: center; }
      .kod { text-align: center; font-size: ${buyukMu ? '9pt' : '7.5pt'}; font-weight: 800; letter-spacing: 0.5px; flex: 1; }
      .tarih { font-size: 6.5pt; color: #64748b; }
    </style></head><body>${etiketlerHtml}</body></html>`);
    doc.close();
    setTimeout(() => {
      try {
        yazdirAlan.contentWindow.focus();
        yazdirAlan.contentWindow.print();
      } catch (_) {}
    }, 180);

    return { success: true, yontem: `Mobil Termal Yazıcı (${boyutMetin})`, kip: tumAdetlerMi ? 'Tüm Adetler' : 'Varyant Özeti', adet: basilacakEtiketler.length };
  }

  function kuyrukRozetiGuncelle() {
    const kuyruk = bekleyenKuyruguOku();
    const rozet = document.getElementById('mobil-senkron-rozet');
    if (rozet) {
      if (kuyruk.length > 0) {
        rozet.textContent = `📲 ${kuyruk.length} Kayıt PC Bekliyor`;
        rozet.style.display = 'inline-flex';
      } else {
        rozet.style.display = 'none';
      }
    }
  }

  // PWA Kurulum İstemcisi ve Tam Ekran (Adres Çubuğunu Gizleme) Paketlemesi
  let ertelenenPwaKurulum = null;
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    ertelenenPwaKurulum = e;
  });

  function tamEkranButonGuncelle() {
    const aktif = Boolean(document.fullscreenElement || document.webkitFullscreenElement);
    document.body.classList.toggle('tam-ekran-kipi', aktif);
    const tamBtn = document.getElementById('tam-ekran-btn');
    if (tamBtn) {
      tamBtn.classList.toggle('aktif', aktif);
      tamBtn.textContent = aktif ? '⛶ Normal' : '⛶ Tam Ekran';
    }
  }

  function tamEkranDegistir() {
    try {
      if (window.MezatNativeApp && typeof window.MezatNativeApp.tamEkranDegistir === 'function') {
        const aktif = Boolean(window.MezatNativeApp.tamEkranDegistir());
        document.body.classList.toggle('tam-ekran-kipi', aktif);
        const tamBtn = document.getElementById('tam-ekran-btn');
        if (tamBtn) {
          tamBtn.classList.toggle('aktif', aktif);
          tamBtn.textContent = aktif ? '⛶ Normal' : '⛶ Tam Ekran';
        }
        return;
      }
      const fsEl = document.fullscreenElement || document.webkitFullscreenElement;
      if (!fsEl) {
        const el = document.documentElement;
        if (el.requestFullscreen) {
          el.requestFullscreen({ navigationUI: 'hide' }).then(tamEkranButonGuncelle).catch(() => {});
        } else if (el.webkitRequestFullscreen) {
          el.webkitRequestFullscreen();
          setTimeout(tamEkranButonGuncelle, 150);
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen().then(tamEkranButonGuncelle).catch(() => {});
        } else if (document.webkitExitFullscreen) {
          document.webkitExitFullscreen();
          setTimeout(tamEkranButonGuncelle, 150);
        }
      }
    } catch (_) {}
  }

  document.addEventListener('fullscreenchange', tamEkranButonGuncelle);
  document.addEventListener('webkitfullscreenchange', tamEkranButonGuncelle);

  async function pwaUygulamaKur() {
    const cekmece = document.getElementById('ust-araclar-cekmece');
    if (cekmece) cekmece.classList.add('gizli');
    if (ertelenenPwaKurulum) {
      try {
        ertelenenPwaKurulum.prompt();
        await ertelenenPwaKurulum.userChoice;
        ertelenenPwaKurulum = null;
        return;
      } catch (_) {}
    }
    window.location.href = '/Mezatron-Envanter.apk';
  }

  window.addEventListener('DOMContentLoaded', () => {
    ['tam-ekran-btn', 'barkod-foto-sec-btn', 'etiket-tekrar'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.remove();
    });
    const kapatIcBtn = document.getElementById('menu-kapat-ic-btn');
    if (kapatIcBtn) {
      kapatIcBtn.addEventListener('click', () => {
        const cekmece = document.getElementById('ust-araclar-cekmece');
        if (cekmece) cekmece.classList.add('gizli');
      });
    }
    // Menü açıkken dışarı dokununca menüyü otomatik kapat
    document.addEventListener('click', e => {
      const cekmece = document.getElementById('ust-araclar-cekmece');
      const menuBtn = document.getElementById('araclar-menu-btn');
      if (!cekmece || cekmece.classList.contains('gizli')) return;
      if (cekmece.contains(e.target) || (menuBtn && menuBtn.contains(e.target))) return;
      cekmece.classList.add('gizli');
    });
    kuyrukRozetiGuncelle();
    // Sürekli bilgisayara arama/telemetri sinyali gönderme döngüsü kaldırıldı (telefonda gecikme ve bağlantı kilitlenmesini önlemek için)
  });

  // PWA Service Worker kaydı (Bilgisayar kapalıyken de sayfanın telefonda açılabilmesi için; file:// protokolünde çalıştırılmaz)
  if ('serviceWorker' in navigator && (window.location.protocol === 'http:' || window.location.protocol === 'https:')) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').then(reg => {
        try { reg.update(); } catch (_) {}
      }).catch(() => {});
    });
  }

  // ── Bilgisayara ulaşılamazken etiket ve irsaliye fotoğrafını telefonda okuma ──
  // Okuma parçası (Tesseract, Apache-2.0) yalnız telefon uygulamasının içinde durur; uygulama onu bu adresten verir.
  // Yazı okunduktan sonra bilgisayardaki çözücünün telefondaki kopyası (envanter-cozucu.js) kullanılır.
  const OCR_KOK = window.MEZAT_OCR_KOK || (window.MezatNativeApp ? 'https://appassets.androidplatform.net/telefon-ocr/' : '');
  let ocrIsciSozu = null;
  // Dosyalar sayfanın kendisi tarafından alınır (uygulama yalnız sayfa isteklerini kesin olarak görür);
  // okuma işçisine hazır blob adresi ve Türkçe veri doğrudan verilir: işçi kendisi hiçbir şey indirmez.
  function sureli(soz, ms, ne) {
    let z;
    return Promise.race([soz, new Promise((_, no) => { z = setTimeout(() => no(new Error(`${ne} ${Math.round(ms / 1000)} saniyede bitmedi`)), ms); })]).finally(() => clearTimeout(z));
  }
  function varlikAl(ad) {
    return new Promise((ok, no) => {
      const x = new XMLHttpRequest();
      x.open('GET', OCR_KOK + ad);
      x.responseType = 'arraybuffer';
      x.timeout = 30000;
      x.onload = () => (x.response && x.response.byteLength > 0 && (x.status === 200 || x.status === 0)) ? ok(x.response) : no(new Error(`${ad} alınamadı (${x.status})`));
      x.onerror = () => no(new Error(`${ad} alınamadı`));
      x.ontimeout = () => no(new Error(`${ad} zaman aşımı`));
      x.send();
    });
  }
  const blobAdresi = (veri, ek = '') => URL.createObjectURL(new Blob([veri], { type: 'application/javascript' })) + ek;
  function simdVarMi() {
    try { return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 10, 1, 8, 0, 65, 0, 253, 15, 253, 98, 11])); } catch (_) { return false; }
  }
  function ocrIsciHazirla(adim = () => {}) {
    if (!OCR_KOK) return Promise.reject(new Error('Bu cihazda fotoğraftan yazı okuma yok.'));
    if (typeof WebAssembly !== 'object') return Promise.reject(new Error('Bu telefonun tarayıcısı okuma parçasını çalıştıramıyor (WebAssembly yok).'));
    if (!ocrIsciSozu) {
      ocrIsciSozu = (async () => {
        adim('1/4 okuma parçası yükleniyor');
        if (!window.Tesseract) {
          const ana = await sureli(varlikAl('tesseract.min.js'), 30000, 'okuma parçası');
          await new Promise((ok, no) => { const s = document.createElement('script'); s.src = blobAdresi(ana); s.onload = ok; s.onerror = () => no(new Error('okuma parçası çalışmadı')); document.head.appendChild(s); });
          if (!window.Tesseract) throw new Error('okuma parçası çalışmadı');
        }
        adim('2/4 okuma motoru yükleniyor');
        const simd = simdVarMi();
        const [isciKod, cekirdek, dil] = await sureli(Promise.all([
          varlikAl('worker.min.js'), varlikAl(simd ? 'tesseract-core-simd-lstm.wasm.js' : 'tesseract-core-lstm.wasm.js'), varlikAl('tur.traineddata')
        ]), 60000, 'okuma motoru');
        adim('3/4 Türkçe yazı bilgisi hazırlanıyor');
        return sureli(window.Tesseract.createWorker('tur', 1, {
          // Dosya yerine blob adresi: işçi "<langPath>/tur.traineddata" ister, # sonrası adreste yok sayılır
          workerPath: blobAdresi(isciKod), workerBlobURL: false, corePath: blobAdresi(cekirdek, '#tesseract-core.wasm.js'),
          langPath: URL.createObjectURL(new Blob([dil], { type: 'application/octet-stream' })) + '#dil', cacheMethod: 'none', gzip: false,
          errorHandler: () => {}
        }), 90000, 'okuma motorunun açılması');
      })();
      ocrIsciSozu.catch(() => { ocrIsciSozu = null; });
    }
    return ocrIsciSozu;
  }
  function metindenBarkodBul(metin) {
    const ust = String(metin || '').toUpperCase().replace(/https?:\/\/\S+/g, ' ');
    const m = ust.match(/\bMZ[\s_-]*2026[\s_-]*\d{3,5}\b/) || ust.match(/\bMZU-[A-Z0-9-]{3,}\b/) || ust.match(/(?<![\d])(\d{13}|\d{12}|\d{8})(?![\d])/);
    if (!m) return '';
    const k = m[0].replace(/\s+/g, '');
    return /^MZ[_-]*2026/.test(k) ? `MZ-2026-${k.replace(/^MZ[_-]*2026[_-]*/, '')}` : k;
  }
  async function telefondaYaziOku(gorsel, adim = () => {}) {
    if (!gorsel) throw new Error('Fotoğraf yok.');
    const isci = await ocrIsciHazirla(adim);
    adim('4/4 fotoğraftaki yazı okunuyor');
    const { data } = await sureli(isci.recognize(gorsel), 90000, 'yazı okuma');
    const metin = String((data && data.text) || '').split(/\r?\n/).map(s => s.replace(/[ \t]+/g, ' ').trim()).filter(Boolean).join('\n');
    return { metin, ilkBarkod: metindenBarkodBul(metin) };
  }
  // /api/envanter/fotograf cevabıyla aynı biçimde döner
  async function telefondaEtiketOku({ gorsel = '', etiketMetni = '', model = '', barkod = '', adim } = {}) {
    const C = window.MezatEnvanterCozucu;
    if (!C || typeof C.etiketCoz !== 'function') throw new Error('Telefondaki çözücü yüklenemedi.');
    const o = await telefondaYaziOku(gorsel, adim);
    const metin = [String(etiketMetni || '').trim(), o.metin].filter(Boolean).join('\n');
    const c = C.etiketCoz({ etiketMetni: metin, model, barkod: barkod || o.ilkBarkod });
    const kod = String(c.barkod || barkod || o.ilkBarkod || '').trim();
    const b = kod ? bankadaBarkodBul(kod) : null;
    if (b && b.urun) {
      if (!c.urun) c.urun = b.urun;
      if (!c.fiyat && b.fiyat) c.fiyat = b.fiyat;
      if ((!Array.isArray(c.bedenler) || !c.bedenler.length) && b.beden) {
        c.bedenler = [b.beden];
        c.satirlar = [{ renk: b.renk || '', beden: b.beden, adet: 1, barkod: kod }];
        c.uyarilar = [];
      }
    }
    return { success: true, telefondaOkundu: true, ...c, barkod: c.barkod || kod, ocrMetin: o.metin };
  }
  // /api/envanter/irsaliye cevabıyla aynı biçimde döner
  async function telefondaIrsaliyeOku({ gorsel = '', irsaliyeNo = '', irsaliyeMetni = '', soz = '', adim = () => {} } = {}) {
    const C = window.MezatEnvanterCozucu;
    if (!C || typeof C.irsaliyeCoz !== 'function') throw new Error('Telefondaki çözücü yüklenemedi.');
    let metin = String(irsaliyeMetni || '').trim();
    let ocrMetin = '';

    // Eğer görsel varsa ve mobil internet üzerinden Gemini API anahtarı mevcutsa doğrudan Gemini Vision ile el yazısını çöz
    const apiKey = localStorage.getItem('mezat_gemini_api_key') || '';
    if (gorsel && !metin && navigator.onLine && apiKey) {
      try {
        adim('Mobil yapay zekâ (Gemini Vision) ile el yazısı ve çeteleler çözülüyor');
        const ham = String(gorsel || '').trim();
        const eslesme = ham.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
        const mimeType = eslesme ? eslesme[1] : 'image/jpeg';
        const base64Data = eslesme ? eslesme[2] : ham;
        const prompt = `Sen uzman bir Türk tekstil, giyim ve toptan/perakende irsaliye çözümleyicisisin.
Bu görseldeki belge; matbu baskılı olabileceği gibi çoğunlukla TÜKENMEZ KALEM, KURŞUN KALEM veya PİLOT KALEMLE EL YAZISIYLA yazılmış bir sevk irsaliyesi, çeki listesi, sipariş fişi veya mal kabul makbuzudur.

Görseldeki el yazılarını, çeteleleri ve tablo satırlarını çözümlerken şu kurallara kesinlikle uy:
1. EL YAZISI VE KISALTMALARI ÇÖZ: Trk -> Tunik, Pnt -> Pantolon, Gml -> Gömlek, Kz -> Kazak, Kbn -> Kaban, Tkm -> Takım, Swt -> Sweatshirt vb. Marka varsa dahil et.
2. RENKLER: Siyah, Beyaz, Lacivert, Haki, Taş, Vizon, Camel, Ekru, Pudra vb.
3. BEDENLER VE ÇETELE / ADETLER: Beden sütunları altındaki el yazısı rakam veya çizik/çetele çizgilerini (|, ||, |||, IIII) her beden için ayrı kalem olarak listele.
4. İRSALİYE BAŞLIK VE METNİ: İrsaliye No veya tedarikçi adını yaz.
5. FİYAT: Varsa sayı olarak yaz, yoksa null bırak.
Sadece şu JSON formatında yanıt ver:
{"irsaliyeNo":"","irsaliyeMetni":"","kalemler":[{"urun":"","renk":"","beden":"","adet":1,"fiyat":null}]}`;

        const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: mimeType, data: base64Data } }] }],
            generationConfig: { temperature: 0.1, responseMimeType: 'application/json' }
          }),
          signal: AbortSignal.timeout(25000)
        });
        if (r.ok) {
          const j = await r.json();
          const txt = j?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
          const p = JSON.parse(txt.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim());
          const c = C.irsaliyeCoz({ irsaliyeNo: p.irsaliyeNo || irsaliyeNo, irsaliyeMetni: p.irsaliyeMetni || '', kalemler: p.kalemler || [], soz });
          return { success: true, telefondaOkundu: true, elYazisiGemini: true, ocrMetin: p.irsaliyeMetni || '', ocrSatirlar: [], ...c };
        }
      } catch (geminiHata) {
        console.warn('Mobil Gemini el yazısı çözümü başarısız, yerel motora geçiliyor:', geminiHata);
      }
    }

    if (!metin && gorsel) { ocrMetin = (await telefondaYaziOku(gorsel, adim)).metin; metin = ocrMetin; }
    let no = String(irsaliyeNo || '').trim();
    if (!no && metin) {
      const e = metin.match(/(?:irsaliye\s*(?:no|numaras[ıi])?|belge\s*no|seri\s*no)\s*[:#-]?\s*([A-Z0-9-]{4,24})/i) || metin.match(/\b(IRS[-A-Z0-9]{4,20}|GIB\d{9,16})\b/i);
      if (e) no = e[1].toUpperCase();
    }
    const c = C.irsaliyeCoz({ irsaliyeNo: no, irsaliyeMetni: metin, kalemler: [], soz });
    return { success: true, telefondaOkundu: true, ocrMetin: ocrMetin || metin, ocrSatirlar: [], ...c };
  }

  window.MezatMobilHibrit = {
    telefondaYaziOku,
    telefondaEtiketOku,
    telefondaIrsaliyeOku,
    telefondaOkumaVarMi: () => Boolean(OCR_KOK),
    envanterCozYerel,
    telefonMotorSonucu,
    ceptenCevrimdisiKaydet,
    bekleyenKuyruguOku,
    uygulanamayanlariOku,
    yerelEnvanteriOku,
    barkodBankasiOku,
    barkodBankasiniSakla,
    bankadaBarkodBul,
    telefondaStokEkle,
    yerelEnvantereYansit,
    yerelEnvanterdenSil,
    yerelEnvanteriSifirla,
    bilgisayarTemizliginiUygula,
    telefondaFiyatDegistir,
    yerelBarkodSatisDus,
    yerelExcelSatirlariniCikar,
    bekleyenleriBilgisayaraAktar,
    yerelExcelIndir,
    bluetoothYaziciBagla,
    bluetoothTermalEtiketBas,
    kuyrukRozetiGuncelle,
    rozetGuncelle: kuyrukRozetiGuncelle,
    hedefPcKokUrl,
    hedefPcUrlOku: () => localStorage.getItem(DEPO_ANAHTAR_PC_URL) || '',
    hedefPcKaydet: url => hedefPcAdresiKaydet(url),
    hedefPcUrlKaydet: url => hedefPcAdresiKaydet(url),
    yerelYaziciVarMi,
    yerelYaziciListesi,
    yerelYaziciOku,
    yerelYaziciKaydet,
    yaziciKipKaydet: kip => {
      localStorage.setItem(DEPO_ANAHTAR_YAZICI_KIP, String(kip || 'otomatik'));
    },
    yaziciKipAyarla: kip => {
      localStorage.setItem(DEPO_ANAHTAR_YAZICI_KIP, String(kip || 'otomatik'));
    },
    yaziciKipOku: () => localStorage.getItem(DEPO_ANAHTAR_YAZICI_KIP) || 'otomatik',
    yaziciDurumu: () => ({
      bagli: Boolean((btCihaz && btCihaz.gatt && btCihaz.gatt.connected) || (yerelYaziciVarMi() && yerelYaziciOku())),
      ad: (yerelYaziciVarMi() && yerelYaziciOku() && yerelYaziciOku().ad) || (btCihaz && btCihaz.name ? btCihaz.name : 'Termal Yazıcı'),
      kip: localStorage.getItem(DEPO_ANAHTAR_YAZICI_KIP) || 'otomatik'
    }),
    btBagliMi: () => Boolean(btCihaz && btCihaz.gatt && btCihaz.gatt.connected),
    etiketAyarOku,
    etiketAyarKaydet,
    etiketBoyutuAyarla: boyut => etiketAyarKaydet({ boyut }),
    etiketBoyutuOku: () => etiketAyarOku().boyut,
    tamEkranDegistir,
    pwaUygulamaKur
  };
})();
