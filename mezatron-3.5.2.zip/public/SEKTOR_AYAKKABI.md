# 👟 Mezatron Sektörel Barkod Bankası & Ürün Sözlüğü: Ayakkabı, Çanta & Deri

Bu dosya, **Ayakkabı Mağazaları, Çanta & Deri Aksesuar Satıcıları** için özel olarak hazırlanmıştır.
Kıyafet bedenleri (S/M/L) yerine **Ayakkabı Numaraları (35-46)**, **Deri / Kumaş Malzeme Türleri** ve **Kalıp Tipleri** içerir.

---

## 1. Popüler Ayakkabı & Çanta Markaları ve Telaffuz Rehberi

| Doğru Marka Adı | Türkçe Okunuşları ve Ses Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Nike** | nayk, nayki, naik, naiki | Sneaker & Spor |
| **Adidas** | adıdas, adidaz, edidas | Sneaker & Spor |
| **Puma** | puma, pumma | Sneaker & Spor |
| **Skechers** | skeçırs, sikeçırs, skeçır, sıkeçır | Yürüyüş & Konfor |
| **New Balance** | niv balans, nü balans, nü belens | Sneaker & Koşu |
| **Converse** | konvers, konvörs, kanvers | Bez Ayakkabı |
| **Vans** | vens, vanz, venz | Kaykay & Sneaker |
| **Timberland** | timbırlend, tımbırlend, timberlend | Outdoor & Bot |
| **Harley Davidson** | harli deyvidsın, harli davidsın | Deri Çizme & Bot |
| **Crocs** | kroks, kıroks, kuroks | Terlik & Sandalet |
| **Birkenstock** | birkenştok, birkınştok | Anatomik Terlik |
| **Clarks** | klayrks, klarks, klerks | Klasik & Konfor |
| **Ecco** | eko, ekko | Deri & Yürüyüş |
| **Kemal Tanca** | kemal tanca, tanca | Deri & Klasik |
| **İnci** | inci, inci deri | Kadın & Erkek Kundura |
| **Derimod** | derimod, derymod | Deri Mont & Çanta |
| **Greyder** | greyder, grayder | Outdoor Bot |
| **Samsonite** | samsonayt, semsonayt | Valiz & Sırt Çantası |
| **Eastpak** | istpek, iystpak, istpak | Sırt Çantası |

---

## 2. Hazır Barkod Bankası & Popüler Ayakkabı / Çanta Ürün Listesi

| Barkod | Ürün Adı | Renk / Malzeme | Numara | Tavsiye Fiyat (TL) |
| :--- | :--- | :--- | :--- | :--- |
| **MZU-AY001** | Erkek Hakiki Deri Klasik Kösele Ayakkabı | SİYAH / DERİ | 42 | 1650 |
| **MZU-AY002** | Kadın Topuklu Stiletto Abiye Ayakkabı | BEJ / RUGAN | 38 | 1250 |
| **MZU-AY003** | Günlük Hafif Ortopedik Yürüyüş Sneaker | BEYAZ | 41 | 980 |
| **MZU-AY004** | Hakiki Deri Erkek Kışlık Su Geçirmez Bot | KAHVE / NUBUK | 43 | 2400 |
| **MZU-AY005** | Kadın Fermuarlı Diz Altı Süet Çizme | SİYAH / SÜET | 37 | 1850 |
| **MZU-AY006** | Hakiki Deri Çapraz Askılı Omuz Çantası | TABA / DERİ | STD | 850 |
| **MZU-AY007** | Kadın Büyük Boy Fermuarlı Kol Çantası | VİZON | STD | 720 |
| **MZU-AY008** | Su İtici Kumaş Unisex Laptop Sırt Çantası | SİYAH | STD | 650 |
| **MZU-AY009** | Hakiki Deri Erkek Cüzdan & Kemer Hediye Seti | SİYAH / DERİ | STD | 490 |
| **MZU-AY010** | Ortopedik Mantar Taban Çift Bantlı Terlik | BEYAZ | 39 | 580 |
