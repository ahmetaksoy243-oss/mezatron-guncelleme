// Ölçme düzeni: yayındaki ses parçalarını isteğe bağlı saklar, doğru cevabı işaretletir.
// Varsayılan kapalı. Her şey veri klasöründe (Git dışı) kalır, dışarı gönderilmez, süresi dolan ses silinir.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const VARSAYILAN_GUN = 14;
const EN_AZ_GUN = 1;
const EN_COK_GUN = 90;
const SINAV_ORANI = 0.2;
const GUN_MS = 24 * 60 * 60 * 1000;
const SONUCLAR = new Set(['siparis', 'siparis_degil', 'anlasilmiyor']);

// Motorun cevabından yalnız güven bilgisi alınır; eski biçimde bilgi yoksa null kalır
function guvenOzeti(cevap) {
  const parcalar = Array.isArray(cevap && cevap.segments) ? cevap.segments : [];
  if (!parcalar.length) return null;
  const sayilar = alan => parcalar.map(p => p[alan]).filter(s => typeof s === 'number' && Number.isFinite(s));
  const yuvarla = s => Number(s.toFixed(3));
  const log = sayilar('avg_logprob');
  const sessiz = sayilar('no_speech_prob');
  const kelimeler = parcalar.flatMap(p => p.words || []).map(k => k.probability).filter(s => typeof s === 'number');
  return {
    ortalamaLog: log.length ? yuvarla(log.reduce((a, b) => a + b, 0) / log.length) : null,
    enDusukLog: log.length ? yuvarla(Math.min(...log)) : null,
    konusmaYok: sessiz.length ? yuvarla(Math.max(...sessiz)) : null,
    enDusukKelime: kelimeler.length ? yuvarla(Math.min(...kelimeler)) : null,
    parca: parcalar.length
  };
}

function olcumOlustur({ veriKlasoru, simdi = () => Date.now(), rastgele = Math.random }) {
  const kok = path.join(veriKlasoru, 'olcum');
  const kayitKlasoru = path.join(kok, 'kayitlar');
  const ayarYolu = path.join(kok, 'ayar.json');
  const bolumYolu = path.join(kok, 'bolumler.json');
  const jsonOku = (yol, varsayilan) => {
    try {
      return JSON.parse(fs.readFileSync(yol, 'utf8'));
    } catch (err) {
      return varsayilan;
    }
  };
  const jsonYaz = (yol, veri) => {
    fs.mkdirSync(path.dirname(yol), { recursive: true });
    const gecici = `${yol}.tmp`;
    fs.writeFileSync(gecici, JSON.stringify(veri, null, 1), 'utf8');
    fs.renameSync(gecici, yol);
  };

  let ayarlar = { acik: false, gun: VARSAYILAN_GUN, ...jsonOku(ayarYolu, {}) };
  let bolumler = jsonOku(bolumYolu, {});
  let sira = 0;

  const kimlikGecerli = id => /^[0-9A-Za-z-]+$/.test(String(id));
  const jsonYolu = id => path.join(kayitKlasoru, `${id}.json`);
  const sesYolu = id => (kimlikGecerli(id) ? path.join(kayitKlasoru, `${id}.wav`) : null);
  const kayitOku = id => (kimlikGecerli(id) ? jsonOku(jsonYolu(id), null) : null);

  function yeniKimlik() {
    const tarih = new Date(simdi()).toISOString().replace(/[-:T.Z]/g, '');
    sira++;
    return `${tarih}-${String(sira).padStart(4, '0')}-${crypto.randomBytes(2).toString('hex')}`;
  }

  // Aynı üründeki sözler birbirine benzer: bölüm söz başına değil yayın ve ürün başına seçilir, sonra değişmez
  function bolumSec(yayin, urunSirasi) {
    const anahtar = `${yayin}|${urunSirasi}`;
    if (!bolumler[anahtar]) {
      bolumler[anahtar] = rastgele() < SINAV_ORANI ? 'sinav' : 'gelistirme';
      jsonYaz(bolumYolu, bolumler);
    }
    return bolumler[anahtar];
  }

  // Kayıt sorunu yayını durdurmaz
  function guvenli(is) {
    try {
      return is();
    } catch (err) {
      console.error('[OLCUM] Kayıt hatası:', err.message);
      return null;
    }
  }

  function kaydet(id, wav, { yayin = 'yayin', urunSirasi = 0, urun = '' } = {}) {
    if (!ayarlar.acik) return null;
    return guvenli(() => {
      fs.mkdirSync(kayitKlasoru, { recursive: true });
      fs.writeFileSync(sesYolu(id), wav);
      const kayit = {
        id,
        zaman: new Date(simdi()).toISOString(),
        yayin,
        urunSirasi,
        urun,
        bolum: bolumSec(yayin, urunSirasi),
        sistem: { siparisler: [] },
        isaret: null
      };
      jsonYaz(jsonYolu(id), kayit);
      return id;
    });
  }

  function sonucEkle(id, alanlar) {
    guvenli(() => {
      const kayit = kayitOku(id);
      if (!kayit) return;
      kayit.sistem = { ...kayit.sistem, ...alanlar };
      jsonYaz(jsonYolu(id), kayit);
    });
  }

  function siparisEkle(id, siparis) {
    guvenli(() => {
      const kayit = kayitOku(id);
      if (!kayit) return;
      kayit.sistem.siparisler.push(siparis);
      jsonYaz(jsonYolu(id), kayit);
    });
  }

  function hepsi() {
    if (!fs.existsSync(kayitKlasoru)) return [];
    return fs.readdirSync(kayitKlasoru)
      .filter(ad => ad.endsWith('.json') && !ad.endsWith('.tmp'))
      .sort()
      .map(ad => jsonOku(path.join(kayitKlasoru, ad), null))
      .filter(Boolean);
  }

  // Sınav bölümünde sistemin ne duyduğu gösterilmez: işaretleyen etkilenmez, kural yazan görmez
  function liste(bolum) {
    return hepsi()
      .filter(k => !bolum || k.bolum === bolum)
      .map(k => ({
        id: k.id,
        zaman: k.zaman,
        urun: k.urun,
        bolum: k.bolum,
        isaret: k.isaret,
        sesVar: fs.existsSync(sesYolu(k.id)),
        sistem: k.bolum === 'sinav' ? null : k.sistem
      }));
  }

  function isaretle(id, { dogruSoz = '', kararlar = [], sonuc, not = '' }) {
    const kayit = kayitOku(id);
    if (!kayit) return { success: false, error: 'Kayıt bulunamadı.' };
    if (!SONUCLAR.has(sonuc)) return { success: false, error: 'Sonuç seçilmedi.' };
    const temiz = (Array.isArray(kararlar) ? kararlar : [])
      .map(k => ({ musteri: String(k.musteri || '').trim(), beden: String(k.beden || '').trim() }))
      .filter(k => k.musteri);
    if (sonuc === 'siparis' && !temiz.length) return { success: false, error: 'Sipariş seçildiyse müşteri yazılmalı.' };
    kayit.isaret = {
      dogruSoz: String(dogruSoz).trim(),
      kararlar: sonuc === 'siparis' ? temiz : [],
      sonuc,
      not: String(not).trim(),
      zaman: new Date(simdi()).toISOString()
    };
    jsonYaz(jsonYolu(id), kayit);
    return { success: true };
  }

  // Süresi dolan ses silinir. İşaretlenmişin yalnız yazısı kalır, ölçüm kaybolmasın; işaretlenmemiş tümden gider.
  function temizle() {
    let silinen = 0;
    const sinir = simdi() - ayarlar.gun * GUN_MS;
    for (const kayit of hepsi()) {
      if (Date.parse(kayit.zaman) >= sinir) continue;
      guvenli(() => {
        if (fs.existsSync(sesYolu(kayit.id))) silinen++;
        fs.rmSync(sesYolu(kayit.id), { force: true });
        if (!kayit.isaret) fs.rmSync(jsonYolu(kayit.id), { force: true });
      });
    }
    return silinen;
  }

  function hepsiniSil() {
    fs.rmSync(kayitKlasoru, { recursive: true, force: true });
    return { success: true };
  }

  function ayar() {
    const kayitlar = hepsi();
    return { ...ayarlar, kayit: kayitlar.length, isaretli: kayitlar.filter(k => k.isaret).length };
  }

  function ayarla({ acik, gun }) {
    if (gun !== undefined) {
      const sayi = Number(gun);
      if (!Number.isInteger(sayi) || sayi < EN_AZ_GUN || sayi > EN_COK_GUN) {
        return { success: false, error: `Saklama süresi ${EN_AZ_GUN} ile ${EN_COK_GUN} gün arasında olmalı.` };
      }
      ayarlar.gun = sayi;
    }
    if (acik !== undefined) ayarlar.acik = acik === true;
    jsonYaz(ayarYolu, { acik: ayarlar.acik, gun: ayarlar.gun });
    temizle();
    return { success: true, ...ayar() };
  }

  return { yeniKimlik, kaydet, sonucEkle, siparisEkle, liste, hepsi, isaretle, temizle, hepsiniSil, ayar, ayarla, sesYolu };
}

module.exports = { olcumOlustur, guvenOzeti };
