// Evrensel Ses Motoru ve Gürültü Temizleme (DSP) Yardımcıları
// Her bilgisayarda (Nvidia GPU, AMD/Intel Vulkan iGPU, Sadece CPU, Yerel Ağ, Tarayıcı WebSpeech)
// ve Türkçe/boşluklu dosya yollarında sorunsuz çalışmayı sağlar.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const ASCII_BRIDGE_ROOT = process.platform === 'win32'
  ? 'C:\\Users\\Public\\mezatron_ascii'
  : '/tmp/mezatron_ascii';

/**
 * Türkçe karakter (ı, İ, ş, ğ, ü, ö, ç) veya boşluk içeren klasör yollarını
 * C++ motorlarının (whisper-server.exe, sherpa-onnx-node) güvenle açabilmesi için
 * saf ASCII bir NTFS Junction köprüsüne bağlar.
 */
function ensureAsciiPathBridge(targetDir, aliasName = 'engine') {
  if (!targetDir || !fs.existsSync(targetDir)) return targetDir;
  if (/^[\x20-\x7E]+$/.test(targetDir) && !targetDir.includes(' ')) {
    return targetDir;
  }
  try {
    fs.mkdirSync(ASCII_BRIDGE_ROOT, { recursive: true });
    const safeAlias = String(aliasName || 'engine').replace(/[^a-zA-Z0-9_-]/g, '_');
    const linkPath = path.join(ASCII_BRIDGE_ROOT, safeAlias);
    if (fs.existsSync(linkPath)) {
      try {
        const realTarget = fs.realpathSync(linkPath);
        const expectedTarget = fs.realpathSync(targetDir);
        if (realTarget.toLowerCase() === expectedTarget.toLowerCase()) {
          return linkPath;
        }
      } catch (_) {}
      try { fs.rmSync(linkPath, { recursive: true, force: true }); } catch (_) {}
    }
    if (process.platform === 'win32') {
      execFileSync('cmd.exe', ['/c', 'mklink', '/J', linkPath, targetDir], { windowsHide: true, stdio: 'ignore' });
    } else {
      fs.symlinkSync(targetDir, linkPath, 'dir');
    }
    if (fs.existsSync(linkPath)) return linkPath;
  } catch (err) {
    console.warn('[EVRENSEL-MOTOR] ASCII yol köprüsü oluşturulamadı, asıl yol kullanılacak:', err.message);
  }
  return targetDir;
}

/**
 * Bilgisayarın işlemci çekirdek sayısına göre en verimli Whisper iş parçacığı (thread) sayısını hesaplar.
 * Sabit -t 4 yerine mantıksal çekirdeklerin %75'ini (2 ile 8 arası) kullanır.
 */
function optimalCpuThreads() {
  const logicalCores = (os.cpus() && os.cpus().length) || 4;
  return Math.max(2, Math.min(8, Math.floor(logicalCores * 0.75)));
}

/**
 * 16 kHz, 16-bit mono WAV dosyasının gerçek süresine göre Whisper audio_ctx değerini hesaplar.
 * Sabit 1500 (30 sn) yerine kısa onaylarda ("Ahmet Bey'e sattım") 256 (~5 sn) vererek
 * CPU ve dahili ekran kartlarında 3-5 kat hızlanma sağlar.
 */
function calculateDynamicAudioCtx(wavBuffer) {
  if (!wavBuffer || wavBuffer.length <= 44) return 512;
  const pcmBytes = Math.max(0, wavBuffer.length - 44);
  const durationSec = Math.max(0.5, pcmBytes / 32000); // 16000 Hz * 2 byte = 32000 byte/sn
  const neededCtx = Math.ceil(((durationSec + 1.2) / 30.0) * 1500);
  const alignedCtx = Math.ceil(neededCtx / 64) * 64;
  return Math.max(256, Math.min(1500, alignedCtx));
}

/**
 * WAV tamponundaki (buffer) ses verisini okur ve 16-bit PCM örneklerinin başlangıç/uzunluk bilgisini döner.
 */
function locateWavPcm(buffer) {
  if (!buffer || buffer.length < 44) return null;
  if (buffer.toString('latin1', 0, 4) !== 'RIFF' || buffer.toString('latin1', 8, 12) !== 'WAVE') return null;
  let offset = 12;
  let sampleRate = 16000;
  let channels = 1;
  let bitsPerSample = 16;
  while (offset + 8 <= buffer.length) {
    const id = buffer.toString('latin1', offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    const start = offset + 8;
    if (id === 'fmt ') {
      const audioFormat = buffer.readUInt16LE(start);
      channels = buffer.readUInt16LE(start + 2);
      sampleRate = buffer.readUInt32LE(start + 4);
      bitsPerSample = buffer.readUInt16LE(start + 14);
      if (audioFormat !== 1 || bitsPerSample !== 16) return null;
    } else if (id === 'data') {
      const validBytes = Math.min(size, buffer.length - start);
      const sampleCount = Math.floor(validBytes / 2);
      return { start, sampleCount, sampleRate, channels };
    }
    offset = start + size + (size % 2);
  }
  return null;
}

/**
 * Gürültülü depo ve mezat ortamları için WAV ses sinyalini analiz eder:
 * Süre (sn), RMS (dBFS), Tepe/Peak (dBFS), Gürültü Tabanı (dBFS), Sinyal-Gürültü Oranı (SNR dB) ve Konuşma Oranı.
 */
function analizWavSinyali(wavBuffer) {
  const info = locateWavPcm(wavBuffer);
  if (!info || info.sampleCount === 0) {
    return { gecerli: false, sureSn: 0, rmsDb: -100, peakDb: -100, gurultuTabaniDb: -100, snrDb: 0, konusmaOrani: 0, kirpilmaOrani: 0 };
  }
  const { start, sampleCount, sampleRate } = info;
  const frameSamples = Math.max(160, Math.floor(sampleRate * 0.02)); // 20 ms çerçeveler
  const frameRmsList = [];
  let sumSq = 0;
  let peak = 0;
  let clipped = 0;

  for (let i = 0; i < sampleCount; i++) {
    const s = wavBuffer.readInt16LE(start + i * 2) / 32768.0;
    const abs = Math.abs(s);
    if (abs > peak) peak = abs;
    if (abs >= 0.99) clipped++;
    sumSq += s * s;
  }

  for (let f = 0; f + frameSamples <= sampleCount; f += frameSamples) {
    let fSq = 0;
    for (let j = 0; j < frameSamples; j++) {
      const s = wavBuffer.readInt16LE(start + (f + j) * 2) / 32768.0;
      fSq += s * s;
    }
    frameRmsList.push(Math.sqrt(fSq / frameSamples));
  }

  const globalRms = Math.sqrt(sumSq / sampleCount);
  const sortedFrames = frameRmsList.slice().sort((a, b) => a - b);
  // En sessiz %20 çerçeveyi arka plan gürültü tabanı kabul et
  const floorCount = Math.max(1, Math.floor(sortedFrames.length * 0.2));
  let floorSum = 0;
  for (let i = 0; i < floorCount; i++) floorSum += sortedFrames[i];
  const noiseFloorRms = Math.max(0.0001, floorSum / floorCount);

  // En yüksek %30 çerçeveyi aktif konuşma enerjisi kabul et
  const speechStartIdx = Math.floor(sortedFrames.length * 0.7);
  let speechSum = 0;
  let speechCount = 0;
  for (let i = speechStartIdx; i < sortedFrames.length; i++) {
    speechSum += sortedFrames[i];
    speechCount++;
  }
  const speechRms = Math.max(globalRms, speechCount > 0 ? speechSum / speechCount : globalRms);

  const activeThreshold = Math.max(0.008, noiseFloorRms * 2.2);
  const activeFrames = frameRmsList.filter(r => r >= activeThreshold).length;
  const konusmaOrani = frameRmsList.length > 0 ? Number((activeFrames / frameRmsList.length).toFixed(2)) : 0;

  const toDb = val => Number((20 * Math.log10(Math.max(val, 1e-5))).toFixed(1));
  const rmsDb = toDb(globalRms);
  const peakDb = toDb(peak);
  const gurultuTabaniDb = toDb(noiseFloorRms);
  const speechDb = toDb(speechRms);
  const snrDb = Number(Math.max(0, speechDb - gurultuTabaniDb).toFixed(1));

  return {
    gecerli: true,
    sureSn: Number((sampleCount / sampleRate).toFixed(2)),
    rmsDb,
    peakDb,
    gurultuTabaniDb,
    snrDb,
    konusmaOrani,
    kirpilmaOrani: Number((clipped / sampleCount).toFixed(4)),
    gurultuluMu: gurultuTabaniDb > -38 || snrDb < 10
  };
}

/**
 * 2. Derece Butterworth / Biquad IIR Filtre katsayılarını hesaplar (High-pass veya Low-pass).
 */
function createBiquadFilter(type, cutoffHz, sampleRate, Q = 0.7071) {
  const omega = (2 * Math.PI * cutoffHz) / sampleRate;
  const sinW = Math.sin(omega);
  const cosW = Math.cos(omega);
  const alpha = sinW / (2 * Q);

  let b0, b1, b2, a0, a1, a2;
  if (type === 'highpass') {
    b0 = (1 + cosW) / 2;
    b1 = -(1 + cosW);
    b2 = (1 + cosW) / 2;
    a0 = 1 + alpha;
    a1 = -2 * cosW;
    a2 = 1 - alpha;
  } else {
    // lowpass
    b0 = (1 - cosW) / 2;
    b1 = 1 - cosW;
    b2 = (1 - cosW) / 2;
    a0 = 1 + alpha;
    a1 = -2 * cosW;
    a2 = 1 - alpha;
  }

  const cB0 = b0 / a0;
  const cB1 = b1 / a0;
  const cB2 = b2 / a0;
  const cA1 = a1 / a0;
  const cA2 = a2 / a0;
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;

  return function processSample(x) {
    const y = cB0 * x + cB1 * x1 + cB2 * x2 - cA1 * y1 - cA2 * y2;
    x2 = x1;
    x1 = x;
    y2 = y1;
    y1 = y;
    return y;
  };
}

/**
 * Gürültülü depo veya mezat ortamında kaydedilen WAV sesini temizler ve güçlendirir:
 * 1. 90 Hz High-Pass filtre (klima, fan, masa vurması, bas müzik uğultusunu keser)
 * 2. 4200 Hz Low-Pass filtre (barkod/termal yazıcı tiz sesi, koli bandı cızırtısını keser)
 * 3. Dinamik Gürültü Kapısı (Spectral/Energy Noise Gate: konuşma olmayan gürültü tabanını bastırır)
 * 4. Otomatik Kazanç Normalizasyonu (Auto-Gain: uzak mikrofon sesini -3 dBFS seviyesine dengeler)
 */
function temizleVeGuclendirWav(wavBuffer, secenekler = {}) {
  const info = locateWavPcm(wavBuffer);
  if (!info || info.sampleCount < 160) return { buffer: wavBuffer, analiz: analizWavSinyali(wavBuffer), temizlendi: false };

  const oncekiAnaliz = analizWavSinyali(wavBuffer);
  const { start, sampleCount, sampleRate } = info;
  const outBuffer = Buffer.from(wavBuffer);

  const hpFilter = createBiquadFilter('highpass', secenekler.highpassHz || 90, sampleRate, 0.7071);
  const lpFilter = createBiquadFilter('lowpass', secenekler.lowpassHz || 4200, sampleRate, 0.7071);

  const filtered = new Float32Array(sampleCount);
  for (let i = 0; i < sampleCount; i++) {
    const raw = wavBuffer.readInt16LE(start + i * 2) / 32768.0;
    filtered[i] = lpFilter(hpFilter(raw));
  }

  // 20ms çerçevelerle gürültü tabanını bul ve yumuşak gürültü kapısı (soft noise gate) uygula
  const frameSize = Math.max(160, Math.floor(sampleRate * 0.02));
  const frameRms = [];
  for (let f = 0; f < sampleCount; f += frameSize) {
    const end = Math.min(sampleCount, f + frameSize);
    let sq = 0;
    for (let i = f; i < end; i++) sq += filtered[i] * filtered[i];
    frameRms.push(Math.sqrt(sq / (end - f)));
  }

  const sorted = frameRms.slice().sort((a, b) => a - b);
  const floorCount = Math.max(1, Math.floor(sorted.length * 0.2));
  let floorSum = 0;
  for (let i = 0; i < floorCount; i++) floorSum += sorted[i];
  const noiseFloor = Math.max(0.0002, floorSum / floorCount);
  // Bluetooth kulaklıklar kendi donanımında gürültüyü sıfırladığı için (gurultuTabaniDb <= -62 dB)
  // ikinci bir gürültü kapısı (noise gate) uygulamak sessiz harfleri (B, G, S, Z) bozar. Bluetooth sinyallerinde kapıyı devre dışı bırak!
  const bluetoothTemizSinyalMi = oncekiAnaliz.gurultuTabaniDb <= -62;
  const gateThreshold = bluetoothTemizSinyalMi ? 0 : noiseFloor * (secenekler.gateCarpani || 1.45);

  let maxAbs = 0;
  let currentGain = 1.0;
  for (let f = 0, fIdx = 0; f < sampleCount; f += frameSize, fIdx++) {
    const end = Math.min(sampleCount, f + frameSize);
    const rms = frameRms[fIdx] || 0;
    const targetGateGain = (!bluetoothTemizSinyalMi && rms < gateThreshold)
      ? Math.max(0.45, Math.pow(rms / Math.max(gateThreshold, 1e-5), 1.15))
      : 1.0;

    for (let i = f; i < end; i++) {
      currentGain = currentGain * 0.96 + targetGateGain * 0.04;
      filtered[i] *= currentGain;
      const abs = Math.abs(filtered[i]);
      if (abs > maxAbs) maxAbs = abs;
    }
  }

  // Otomatik kazanç normalizasyonu (Çok kısık ortam gürültüsünü 4.5x patlatıp halüsinasyon yaptırmamak için en fazla 2.6x büyüt)
  const targetPeak = 0.68;
  const normGain = maxAbs > 0.012 ? Math.min(2.6, Math.max(0.85, targetPeak / maxAbs)) : 1.0;

  for (let i = 0; i < sampleCount; i++) {
    let val = filtered[i] * normGain;
    // Yumuşak sınırlayıcı (soft clipper)
    if (val > 0.98) val = 0.98;
    else if (val < -0.98) val = -0.98;
    const intSample = Math.max(-32768, Math.min(32767, Math.round(val * 32767)));
    outBuffer.writeInt16LE(intSample, start + i * 2);
  }

  const sonrakiAnaliz = analizWavSinyali(outBuffer);
  return {
    buffer: outBuffer,
    analiz: sonrakiAnaliz,
    oncekiAnaliz,
    temizlendi: true,
    uygulananKazanc: Number(normGain.toFixed(2))
  };
}

module.exports = {
  ASCII_BRIDGE_ROOT,
  ensureAsciiPathBridge,
  optimalCpuThreads,
  calculateDynamicAudioCtx,
  analizWavSinyali,
  temizleVeGuclendirWav
};
