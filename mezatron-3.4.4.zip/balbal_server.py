# -*- coding: utf-8 -*-
"""
balbal-v2-manas (313M TR+EN Amiral Gemisi) & balbal-v2 Yerel Ses Tanıma Sunucusu (Port 3101)
Mimari:
  - FastConformer-CTC + 3-Pass Loop Refiner + Product-Key Acoustic Memory (1M Anahtar)
  - Resmi balbal 0.6.3 C++ FastCTCDecoder + HotwordLM (MARKA_TELAFFUZ_SOZLUGU.md & RENK_TELAFFUZ_SOZLUGU.md Trie Ödüllendirme)
  - Türkçe Ters Metin Normalizasyonu (ITN: "altı yüz elli" -> "650", "otuz sekiz" -> "38")
  - ~70 ms CPU çıkarım süresi (2026 Mu-Bench Türkçe Telefon/Bluetooth Dünya 1.'si - %8.20 WER)
"""

import io
import json
import os
import re
import sys
import time
import wave
from http.server import BaseHTTPRequestHandler, HTTPServer

import numpy as np
import onnxruntime as ort

MANAS_DIR = r"C:\Users\Public\mezatron_ascii\balbal_v2_manas"
V2_DIR = r"C:\Users\Public\mezatron_ascii\balbal_v2"
DEFAULT_DIR = MANAS_DIR if os.path.exists(os.path.join(MANAS_DIR, "model-plain.onnx")) else V2_DIR
MODEL_DIR = os.environ.get("BALBAL_MODEL_DIR", DEFAULT_DIR)
PORT = int(os.environ.get("BALBAL_PORT", "3101"))
THREADS = int(os.environ.get("BALBAL_THREADS", "6"))
MIN_SAMPLES = 4000

# Türkçe Sayı -> Rakam (ITN) Sözlüğü (Envanter bağlam duyarlı)
ONES = {"bir": 1, "iki": 2, "üç": 3, "dört": 4, "dörd": 4, "beş": 5, "altı": 6, "yedi": 7, "sekiz": 8, "dokuz": 9}
TENS = {"on": 10, "yirmi": 20, "otuz": 30, "kırk": 40, "elli": 50, "altmış": 60, "yetmiş": 70, "seksen": 80, "doksan": 90}
NUM_WORDS = {**ONES, **TENS, "yüz": 100, "bin": 1000}
ANCHOR_PREV = {"fiyat", "fiyatı", "beden", "bedeni", "adet", "adedi", "tane", "numara"}


def turkce_itn(text: str) -> str:
    """Sözlü Türkçe sayıları ('bin beş yüz', 'kırk iki', 'on beş') rakama çevirir."""
    if not text:
        return ""
    tokens = text.split()
    out = []
    i = 0
    n = len(tokens)
    while i < n:
        w_raw = tokens[i]
        w_clean = re.sub(r"[.,!?;:]+$", "", w_raw).replace("İ", "i").replace("I", "ı").lower()
        if w_clean in NUM_WORDS:
            j = i
            words = []
            last_punct = ""
            while j < n:
                t_raw = tokens[j]
                t_clean = re.sub(r"[.,!?;:]+$", "", t_raw).replace("İ", "i").replace("I", "ı").lower()
                if t_clean in NUM_WORDS:
                    words.append(t_clean)
                    last_punct = t_raw[len(t_clean):] if len(t_raw) > len(t_clean) else ""
                    j += 1
                else:
                    break
            prev_word = re.sub(r"[.,!?;:]+$", "", out[-1]).replace("İ", "i").replace("I", "ı").lower() if out else ""
            next_word = re.sub(r"[.,!?;:]+$", "", tokens[j]).replace("İ", "i").replace("I", "ı").lower() if j < n else ""
            is_inventory_num = (
                len(words) >= 2
                or words[0] in TENS
                or words[0] in ("yüz", "bin")
                or prev_word in ANCHOR_PREV
                or next_word in ("lira", "tl", "adet", "tane", "beden", "numara")
            )
            if is_inventory_num and not (len(words) == 1 and words[0] == "bir" and prev_word not in ANCHOR_PREV and next_word not in ("adet", "tane")):
                nums = []
                total = 0
                group = 0
                has_hundreds = False
                has_tens = False
                has_ones = False
                for nw in words:
                    if nw == "bin":
                        if has_tens or has_ones or has_hundreds:
                            total += (group or 1) * 1000
                            group = 0
                            has_hundreds = False
                            has_tens = False
                            has_ones = False
                        elif total > 0:
                            nums.append(total + group)
                            total = 1000
                            group = 0
                        else:
                            total = 1000
                    elif nw == "yüz":
                        if has_hundreds or has_tens:
                            nums.append(total + group)
                            total = 0
                            group = 100
                            has_hundreds = True
                            has_tens = False
                            has_ones = False
                        else:
                            group = (group or 1) * 100
                            has_hundreds = True
                            has_ones = False
                    elif nw in TENS:
                        if has_tens or has_ones:
                            nums.append(total + group)
                            total = 0
                            group = TENS[nw]
                            has_hundreds = False
                            has_tens = True
                            has_ones = False
                        else:
                            group += TENS[nw]
                            has_tens = True
                    elif nw in ONES:
                        if has_ones:
                            nums.append(total + group)
                            total = 0
                            group = ONES[nw]
                            has_hundreds = False
                            has_tens = False
                            has_ones = True
                        else:
                            group += ONES[nw]
                            has_ones = True
                if total + group > 0:
                    nums.append(total + group)
                if nums:
                    rendered = ", ".join(str(x) for x in nums)
                    out.append(f"{rendered}{last_punct}")
                    i = j
                    continue
        out.append(w_raw)
        i += 1
    return mezat_fonetik_duzelt(" ".join(out))


def mezat_fonetik_duzelt(text: str) -> str:
    """Canlı yayın ve envanter konuşmalarında sık görülen beden/marka birleşmelerini düzeltir."""
    if not text:
        return ""
    s = text
    # Marka fonetik düzeltmeleri
    s = re.sub(r"\b(?:hadidas|hadi\s*das|adi\s+da(?:s)?)\b", "Adidas", s, flags=re.IGNORECASE)
    s = re.sub(r"\b(?:cucci|guçi|kuçi)\b", "Gucci", s, flags=re.IGNORECASE)
    s = re.sub(r"\b(?:yip\s*ekbir|yi\s*pekbir)\b", "ipek bir", s, flags=re.IGNORECASE)
    # Beden birleşmeleri (M beden, S beden, L beden, XL, XXL)
    s = re.sub(r"\b(?:meyveden|meybeden|mebeden|meğabeden|meb['’]?den|neb['’]?den|mhb['’]?den)\b", "M beden", s, flags=re.IGNORECASE)
    s = re.sub(r"\b(?:seybeden|sebeden|sev\s+beden|sb['’]?den)\b", "S beden", s, flags=re.IGNORECASE)
    s = re.sub(r"\b(?:leybeden|lebeden|leveden|lb['’]?den)\b", "L beden", s, flags=re.IGNORECASE)
    s = re.sub(r"\b(?:x\s+x\s+[dlte]|xx[dt]|x\s+x\s+ile|x\s+xe|x\s+x\s+lira(?=\s+istemiş))\b", "XXL", s, flags=re.IGNORECASE)
    s = re.sub(r"\b(?:x['’]?le|x['’]?te)(?=\s+(?:istiyor|istemiş|aldı|verdim|verdik|beden))\b", "XL", s, flags=re.IGNORECASE)
    s = re.sub(r"\bs\s*ml\b", "S M L", s, flags=re.IGNORECASE)
    s = re.sub(r"\bsmlxx['’]?\w*\b", "S M L XL XXL", s, flags=re.IGNORECASE)
    s = re.sub(r"\b(?:40|kırk|kır)\s+(bir|iki|üç|dört|dörd|beş|altı|yedi|sekiz|dokuz)(['’]?\w*)\b",
               lambda m: f"{40 + {'bir':1,'iki':2,'üç':3,'dört':4,'dörd':4,'beş':5,'altı':6,'yedi':7,'sekiz':8,'dokuz':9}[m.group(1).lower()]}" + (f"'{m.group(2).lstrip('’')}" if m.group(2) else ""),
               s, flags=re.IGNORECASE)
    s = re.sub(r"\b(?:kırk|kır)\s*([1-9])\b", r"4\1", s, flags=re.IGNORECASE)
    s = re.sub(r"\bk\s+(3[5-9]|4[0-9])\b", r"\1", s, flags=re.IGNORECASE)
    s = re.sub(r"\bhayıryırlı\b", "hayırlı", s, flags=re.IGNORECASE)
    return s



def sozluklerden_hotword_yukle() -> list:
    """MARKA_TELAFFUZ_SOZLUGU.md ve RENK_TELAFFUZ_SOZLUGU.md dosyalarından C++ HotwordLM için anahtar kelimeleri yükler."""
    hotwords = [
        "ürün", "fiyat", "fiyatı", "beden", "adet", "renk", "numara", "lira",
        "gömlek", "pantolon", "ayakkabı", "terlik", "gözlük", "ceket", "tişört",
        "elbise", "kazak", "mont", "çanta", "parfüm", "eşarp", "şort", "etek",
        "sattım", "verdim", "aldı", "sipariş", "iptal", "polo", "yaka"
    ]
    here = os.path.dirname(os.path.abspath(__file__))
    parent = os.path.dirname(here)
    for md_name in ("MARKA_TELAFFUZ_SOZLUGU.md", "RENK_TELAFFUZ_SOZLUGU.md"):
        for base in (parent, here, os.path.join(here, "public")):
            p = os.path.join(base, md_name)
            if os.path.exists(p):
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        content = f.read()
                    for m in re.finditer(r"\|\s*\*\*([^*|]+)\*\*\s*\|", content):
                        val = m.group(1).strip()
                        if 2 <= len(val) <= 24 and not val.lower().startswith("resmi"):
                            hotwords.append(val)
                except Exception:
                    pass
                break
    # Tekilleştir ve en fazla 180 anahtar kelime tut (C++ HotwordLM hızı için ideal boyut)
    seen = set()
    uniq = []
    for w in hotwords:
        k = w.lower()
        if k not in seen:
            seen.add(k)
            uniq.append(w)
    return uniq[:182]


class BalbalAsrEngine:
    def __init__(self, model_dir: str, threads: int = 6):
        self.model_dir = model_dir
        self.model_name = "balbal-v2-manas" if "manas" in model_dir.lower() else "balbal-v2"
        model_path = os.path.join(model_dir, "model-plain.onnx")

        opts = ort.SessionOptions()
        opts.intra_op_num_threads = threads
        opts.inter_op_num_threads = 1
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        opts.enable_mem_pattern = False
        opts.log_severity_level = 3
        self.session = ort.InferenceSession(model_path, opts, providers=["CPUExecutionProvider"])

        # Resmi balbal 0.6.3 C++ FastCTCDecoder + HotwordLM + SentencePiece
        self.cpp_decoder = None
        self.hotwords = sozluklerden_hotword_yukle()
        lm_dir = os.path.join(model_dir, "lm")
        tok_model = os.path.join(lm_dir, "tokenizer.model")
        if os.path.exists(tok_model):
            try:
                from balbal.decoder import KenLMDecoder
                settings = {
                    "alpha": 0.0,
                    "beta": 0.0,
                    "beam": 16,
                    "top_tokens": 20,
                    "threshold": 25.0,
                    "blank_collapse": 0.98,
                    "hotword_bonus": 0.35
                }
                self.cpp_decoder = KenLMDecoder(lm_dir, settings)
                # Hotword trie önbelleğini ısıt
                dummy_lp = np.zeros((20, self.cpp_decoder.vocab_size + 1), dtype=np.float32)
                self.cpp_decoder.decode(dummy_lp, hotwords=self.hotwords)
            except Exception as e:
                print(f"[BALBAL] C++ HotwordLM yuklenemedi, SentencePiece/Greedy yedegine geciliyor: {e}", flush=True)

        # Yedek SentencePiece veya vocab.txt
        self.sp = None
        if os.path.exists(tok_model):
            try:
                import sentencepiece as spm
                self.sp = spm.SentencePieceProcessor(model_file=tok_model)
            except Exception:
                pass

        vocab_path = os.path.join(model_dir, "vocab.txt")
        self.vocab = []
        if os.path.exists(vocab_path):
            with open(vocab_path, "r", encoding="utf-8") as f:
                self.vocab = [line.rstrip("\r\n") for line in f]
        self.vocab_size = self.sp.vocab_size() if self.sp else len(self.vocab)

        # Akustik ısınma
        self.session.run(None, {"audio": np.zeros((1, 16000), dtype=np.float32)})

    def decode_lp(self, log_probs: np.ndarray) -> str:
        if self.cpp_decoder is not None:
            try:
                raw_text = self.cpp_decoder.decode(log_probs, hotwords=self.hotwords)
                return turkce_itn(raw_text.strip())
            except Exception:
                pass
        if self.sp is not None:
            best_ids = np.argmax(log_probs, axis=-1)
            dedup = []
            prev = -1
            blank = self.sp.vocab_size()
            for idx in best_ids:
                idx = int(idx)
                if idx != prev and 0 <= idx < blank:
                    dedup.append(idx)
                prev = idx
            return turkce_itn(self.sp.decode(dedup).strip())

        best_ids = np.argmax(log_probs, axis=-1)
        pieces = []
        raw_bytes = bytearray()
        prev = -1
        for idx in best_ids:
            idx = int(idx)
            if idx != prev and 0 <= idx < len(self.vocab):
                p = self.vocab[idx]
                if p.startswith("<0x") and p.endswith(">") and len(p) == 6:
                    raw_bytes.append(int(p[3:5], 16))
                else:
                    if raw_bytes:
                        pieces.append(raw_bytes.decode("utf-8", errors="replace"))
                        raw_bytes.clear()
                    pieces.append(p)
            prev = idx
        if raw_bytes:
            pieces.append(raw_bytes.decode("utf-8", errors="replace"))
        text = "".join(pieces).replace("▁", " ").strip()
        return turkce_itn(text)

    def transcribe_wav_bytes(self, wav_bytes: bytes) -> dict:
        t0 = time.perf_counter()
        with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
            pcm = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
        if len(pcm) < MIN_SAMPLES:
            pcm = np.pad(pcm, (0, MIN_SAMPLES - len(pcm)))
        max_len = 30 * 16000
        if len(pcm) <= max_len:
            lp = self.session.run(None, {"audio": pcm[None]})[0]
        else:
            chunks = [self.session.run(None, {"audio": pcm[i:i + max_len][None]})[0] for i in range(0, len(pcm), max_len)]
            lp = np.concatenate(chunks, axis=0)
        text = self.decode_lp(lp)
        elapsed_ms = round((time.perf_counter() - t0) * 1000, 1)
        return {"text": text, "sureMs": elapsed_ms, "model": self.model_name}


ENGINE = None


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_GET(self):
        if self.path.startswith("/health"):
            body = json.dumps({
                "ok": True,
                "model": ENGINE.model_name if ENGINE else "balbal-v2-manas",
                "cppHotwordLm": bool(ENGINE and ENGINE.cpp_decoder is not None),
                "hotwordCount": len(ENGINE.hotwords) if ENGINE else 0
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
            wav_bytes = self.rfile.read(length)
            res = ENGINE.transcribe_wav_bytes(wav_bytes)
            body = json.dumps(res, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            body = json.dumps({"text": "", "error": str(e)}, ensure_ascii=False).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)


if __name__ == "__main__":
    ENGINE = BalbalAsrEngine(MODEL_DIR, THREADS)
    server = HTTPServer(("127.0.0.1", PORT), Handler)
    print(
        f"[BALBAL-MANAS] Hazir: http://127.0.0.1:{PORT} (model={ENGINE.model_name}, C++ HotwordLM={ENGINE.cpp_decoder is not None}, hotwords={len(ENGINE.hotwords)})",
        flush=True
    )
    server.serve_forever()
