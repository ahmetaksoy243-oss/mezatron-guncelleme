// Code 128 (A/B/C kümesi) barkod çizimi ve 360° çok açılı (yatay, dikey, çapraz, ters) 1D barkod okuyucu.
// Tarayıcıda window.MezatBarkod, Node'da require('./public/barkod') olarak kullanılır.
(function (kok) {
  // 0-105 arası simgelerin çizgi/boşluk genişlikleri (her biri 11 modül), 106 = bitiş (13 modül)
  const DESENLER = [
    '212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213',
    '221312', '231212', '112232', '122132', '122231', '113222', '123122', '123221', '223211', '221132',
    '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211',
    '212123', '212321', '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313',
    '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121', '313121', '211331',
    '231131', '213113', '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111',
    '314111', '221411', '431111', '111224', '111422', '121124', '121421', '141122', '141221', '112214',
    '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111',
    '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141',
    '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311', '113141',
    '114131', '311141', '411131', '211412', '211214', '211232', '2331112'
  ];
  const BASLA_A = 103;
  const BASLA_B = 104;
  const BASLA_C = 105;
  const BITIS = 106;

  // Web sitesi/reklam QR linklerini (https://vfselfservis.page.link/... vb.) ürün/sipariş barkodu olarak kabul etme
  function gecerliBarkodMu(hamKod) {
    const s = String(hamKod || '').trim();
    if (!s || s.length < 4 || s.length > 40) return false;
    if (/^(?:https?:\/\/|www\.|mailto:|tel:|javascript:)/i.test(s)) return false;
    if (/\.(?:com|net|org|tr|link|io|app|page\.link)\b/i.test(s)) return false;
    return /^[A-Z0-9\-_.#/]+$/i.test(s);
  }

  function barkodSec(adaylar = []) {
    const temizler = [];
    for (const a of adaylar) {
      const ham = typeof a === 'string' ? a : (a && a.rawValue ? a.rawValue : '');
      const k = String(ham || '').trim().toUpperCase();
      if (gecerliBarkodMu(k) && !temizler.includes(k)) temizler.push(k);
    }
    if (!temizler.length) return '';
    // Öncelik: MZ- sipariş barkodu -> MZU- ürün barkodu -> CUST- müşteri barkodu -> diğer geçerli 1D barkodlar
    return (
      temizler.find(x => /^MZ-\d{4}-/.test(x)) ||
      temizler.find(x => /^MZU-/.test(x)) ||
      temizler.find(x => /^CUST-/.test(x)) ||
      temizler[0]
    );
  }

  // Metin → simge değerleri (başlangıç, karakterler, sağlama, bitiş). Code 128 B yalnız 32-126 arası ASCII taşır.
  function degerler(metin) {
    const yazi = String(metin);
    const karakterler = [...yazi].map(c => c.charCodeAt(0));
    if (!karakterler.length || karakterler.some(k => k < 32 || k > 126)) {
      throw new Error('Barkoda yalnız Türkçe harfsiz düz yazı girebilir (A-Z, 0-9, -).');
    }
    const veri = karakterler.map(k => k - 32);
    const toplam = veri.reduce((t, d, i) => t + d * (i + 1), BASLA_B);
    return [BASLA_B, ...veri, toplam % 103, BITIS];
  }

  // Çizgi genişlikleri dizisi: çizgi, boşluk, çizgi... (modül cinsinden)
  function genislikler(metin) {
    return degerler(metin).flatMap(d => [...DESENLER[d]].map(Number));
  }

  // SVG: genişlik ve yükseklik dışarıdan (mm ya da %) verilir, çizgiler her ölçüde keskin kalır
  function svg(metin, { yukseklik = 40, sessizBolge = 10 } = {}) {
    const g = genislikler(metin);
    const toplam = g.reduce((t, x) => t + x, 0) + sessizBolge * 2;
    let x = sessizBolge;
    let cizgiler = '';
    g.forEach((w, i) => {
      if (i % 2 === 0) cizgiler += `<rect x="${x}" y="0" width="${w}" height="${yukseklik}"/>`;
      x += w;
    });
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${toplam} ${yukseklik}" preserveAspectRatio="none" shape-rendering="crispEdges" fill="#000">${cizgiler}</svg>`;
  }

  // Saf JavaScript 1D Code-128 (A/B/C) Tarama Çizgisi Çözücü
  const DESEN_HARITA = new Map();
  DESENLER.forEach((d, idx) => DESEN_HARITA.set(d, idx));

  function sembolleriMetneCevir(basKod, veriSembolleri) {
    let kume = basKod === BASLA_C ? 'C' : (basKod === BASLA_A ? 'A' : 'B');
    let cikti = '';
    for (const s of veriSembolleri) {
      if (kume === 'C') {
        if (s === 100) { kume = 'B'; continue; }
        if (s === 101) { kume = 'A'; continue; }
        if (s >= 0 && s <= 99) cikti += String(s).padStart(2, '0');
      } else if (kume === 'B') {
        if (s === 99) { kume = 'C'; continue; }
        if (s === 101) { kume = 'A'; continue; }
        if (s >= 0 && s <= 94) cikti += String.fromCharCode(s + 32);
      } else {
        if (s === 99) { kume = 'C'; continue; }
        if (s === 100) { kume = 'B'; continue; }
        if (s >= 0 && s <= 63) cikti += String.fromCharCode(s + 32);
      }
    }
    return cikti.trim();
  }

  function tekYondeCode128Coz(griDizi, genislik) {
    let min = 255, max = 0;
    for (let i = 0; i < genislik; i++) {
      const v = griDizi[i];
      if (v < min) min = v;
      if (v > max) max = v;
    }
    if (max - min < 28) return '';
    const esik = (min + max) * 0.5;
    const kosular = [];
    let aktifRenk = griDizi[0] < esik ? 1 : 0;
    let uzunluk = 1;
    for (let i = 1; i < genislik; i++) {
      const r = griDizi[i] < esik ? 1 : 0;
      if (r === aktifRenk) {
        uzunluk++;
      } else {
        kosular.push({ renk: aktifRenk, u: uzunluk });
        aktifRenk = r;
        uzunluk = 1;
      }
    }
    kosular.push({ renk: aktifRenk, u: uzunluk });

    for (let i = 0; i + 6 < kosular.length; i++) {
      if (kosular[i].renk !== 1) continue;
      const top6 = kosular[i].u + kosular[i + 1].u + kosular[i + 2].u + kosular[i + 3].u + kosular[i + 4].u + kosular[i + 5].u;
      if (top6 < 9) continue;
      const modul = top6 / 11;
      const sembolOku = bas => {
        if (bas + 6 > kosular.length) return -1;
        let t = 0;
        for (let k = 0; k < 6; k++) t += kosular[bas + k].u;
        const m = t / 11;
        if (m < modul * 0.5 || m > modul * 1.9) return -1;
        const ham = [];
        let topYuvar = 0;
        for (let k = 0; k < 6; k++) {
          const d = Math.max(1, Math.min(4, Math.round(kosular[bas + k].u / m)));
          ham.push(d);
          topYuvar += d;
        }
        if (topYuvar !== 11) return -1;
        const kod = DESEN_HARITA.get(ham.join(''));
        return kod !== undefined ? kod : -1;
      };

      const basKod = sembolOku(i);
      if (basKod !== BASLA_A && basKod !== BASLA_B && basKod !== BASLA_C) continue;

      const semboller = [basKod];
      let imlec = i + 6;
      while (imlec + 6 <= kosular.length && semboller.length < 48) {
        const s = sembolOku(imlec);
        if (s < 0) break;
        semboller.push(s);
        imlec += 6;
        if (semboller.length >= 3) {
          const c = semboller[semboller.length - 1];
          const veri = semboller.slice(1, -1);
          const top = veri.reduce((acc, val, idx) => acc + val * (idx + 1), basKod);
          if (top % 103 === c && veri.length >= 3) {
            const metin = sembolleriMetneCevir(basKod, veri);
            if (gecerliBarkodMu(metin)) return metin;
          }
        }
      }
    }
    return '';
  }

  // EAN-13 (868..., 869... fabrika barkodları) L, G, R tablo desenleri ve parite haritası
  const EAN_L = { '3211': 0, '2221': 1, '2122': 2, '1411': 3, '1132': 4, '1231': 5, '1114': 6, '1312': 7, '1213': 8, '3112': 9 };
  const EAN_G = { '1123': 0, '1222': 1, '2212': 2, '1141': 3, '2311': 4, '1321': 5, '4111': 6, '2131': 7, '3121': 8, '2113': 9 };
  const EAN_R = { '3211': 0, '2221': 1, '2122': 2, '1411': 3, '1132': 4, '1231': 5, '1114': 6, '1312': 7, '1213': 8, '3112': 9 };
  const EAN_PARITE = {
    'LLLLLL': 0, 'LLGLGG': 1, 'LLGGLG': 2, 'LLGGGL': 3, 'LGLLGG': 4,
    'LGGLLG': 5, 'LGGGLL': 6, 'LGLGLG': 7, 'LGLGGL': 8, 'LGGLGL': 9
  };

  function tekYondeEan13Coz(griDizi, genislik) {
    let min = 255, max = 0;
    for (let i = 0; i < genislik; i++) {
      const v = griDizi[i];
      if (v < min) min = v;
      if (v > max) max = v;
    }
    if (max - min < 80) return '';
    const esik = (min + max) * 0.5;
    const kosular = [];
    let aktifRenk = griDizi[0] < esik ? 1 : 0;
    let uzunluk = 1;
    for (let i = 1; i < genislik; i++) {
      const r = griDizi[i] < esik ? 1 : 0;
      if (r === aktifRenk) uzunluk++;
      else { kosular.push({ renk: aktifRenk, u: uzunluk }); aktifRenk = r; uzunluk = 1; }
    }
    kosular.push({ renk: aktifRenk, u: uzunluk });

    // EAN-13 toplam 59 çubuk/boşluk koşusundan oluşur (3 başlangıç + 24 sol + 5 orta + 24 sağ + 3 bitiş)
    for (let i = 1; i + 59 < kosular.length; i++) {
      if (kosular[i].renk !== 1) continue;
      const b1 = kosular[i].u, b2 = kosular[i + 1].u, b3 = kosular[i + 2].u;
      const mBas = (b1 + b2 + b3) / 3;
      if (mBas < 1.2 || Math.abs(b1 - mBas) > mBas * 0.55 || Math.abs(b2 - mBas) > mBas * 0.55 || Math.abs(b3 - mBas) > mBas * 0.55) continue;
      // Sol sessiz bölge (Quiet Zone) doğrulaması
      if (kosular[i - 1].u < mBas * 4) continue;

      let parite = '';
      let solRakamlar = '';
      let hata = false;
      let imlec = i + 3;
      for (let d = 0; d < 6; d++) {
        const u0 = kosular[imlec].u, u1 = kosular[imlec + 1].u, u2 = kosular[imlec + 2].u, u3 = kosular[imlec + 3].u;
        const m = (u0 + u1 + u2 + u3) / 7;
        if (m < mBas * 0.72 || m > mBas * 1.38) { hata = true; break; }
        const k = [u0, u1, u2, u3].map(u => Math.max(1, Math.min(4, Math.round(u / m))));
        const top = k[0] + k[1] + k[2] + k[3];
        if (top !== 7) { hata = true; break; }
        const desen = k.join('');
        if (EAN_L[desen] !== undefined) { parite += 'L'; solRakamlar += String(EAN_L[desen]); }
        else if (EAN_G[desen] !== undefined) { parite += 'G'; solRakamlar += String(EAN_G[desen]); }
        else { hata = true; break; }
        imlec += 4;
      }
      if (hata || EAN_PARITE[parite] === undefined) continue;
      // Orta koruma (5 koşu: 0-1-0-1-0, her biri ~1 modül)
      for (let g = 0; g < 5; g++) {
        if (Math.abs(kosular[imlec + g].u - mBas) > mBas * 0.65) { hata = true; break; }
      }
      if (hata) continue;
      imlec += 5;
      let sagRakamlar = '';
      for (let d = 0; d < 6; d++) {
        const u0 = kosular[imlec].u, u1 = kosular[imlec + 1].u, u2 = kosular[imlec + 2].u, u3 = kosular[imlec + 3].u;
        const m = (u0 + u1 + u2 + u3) / 7;
        if (m < mBas * 0.72 || m > mBas * 1.38) { hata = true; break; }
        const k = [u0, u1, u2, u3].map(u => Math.max(1, Math.min(4, Math.round(u / m))));
        if (k[0] + k[1] + k[2] + k[3] !== 7) { hata = true; break; }
        const desen = k.join('');
        if (EAN_R[desen] === undefined) { hata = true; break; }
        sagRakamlar += String(EAN_R[desen]);
        imlec += 4;
      }
      if (hata) continue;
      // Sağ bitiş koruması (3 koşu: 1-0-1) ve sağ sessiz bölge
      for (let g = 0; g < 3; g++) {
        if (Math.abs(kosular[imlec + g].u - mBas) > mBas * 0.65) { hata = true; break; }
      }
      if (hata) continue;
      if (imlec + 3 < kosular.length && kosular[imlec + 3].u < mBas * 4) continue;
      const tam = String(EAN_PARITE[parite]) + solRakamlar + sagRakamlar;
      // EAN-13 sağlama toplamı (Check Digit) doğrulaması
      let toplam = 0;
      for (let j = 0; j < 13; j++) {
        toplam += Number(tam[j]) * (j % 2 === 0 ? 1 : 3);
      }
      if (toplam % 10 === 0) return tam;
    }
    return '';
  }

  function satirdanCode128Coz(griDizi, genislik) {
    const duz = tekYondeCode128Coz(griDizi, genislik) || tekYondeEan13Coz(griDizi, genislik);
    if (duz) return duz;
    // Ters (180° / 270° baş aşağı) tutulan barkodlar için diziyi ters çevirip dene
    const ters = new Uint8Array(genislik);
    for (let i = 0; i < genislik; i++) ters[i] = griDizi[genislik - 1 - i];
    return tekYondeCode128Coz(ters, genislik) || tekYondeEan13Coz(ters, genislik);
  }

  let taramaCanvas = null;
  function goruntudenOku(kaynak) {
    try {
      const w = kaynak.videoWidth || kaynak.naturalWidth || kaynak.width || 0;
      const h = kaynak.videoHeight || kaynak.naturalHeight || kaynak.height || 0;
      if (w < 80 || h < 40) return '';
      if (!taramaCanvas && typeof document !== 'undefined') {
        taramaCanvas = document.createElement('canvas');
      }
      if (!taramaCanvas) return '';
      const hedefW = Math.min(800, w);
      const hedefH = Math.min(600, h);
      taramaCanvas.width = hedefW;
      taramaCanvas.height = hedefH;
      const ctx = taramaCanvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(kaynak, 0, 0, hedefW, hedefH);
      const tamVeri = ctx.getImageData(0, 0, hedefW, hedefH).data;
      const griPiksel = (x, y) => {
        const p = (y * hedefW + x) * 4;
        return (tamVeri[p] * 77 + tamVeri[p + 1] * 150 + tamVeri[p + 2] * 29) >> 8;
      };

      const oranlar = [0.5, 0.44, 0.56, 0.38, 0.62, 0.32, 0.68, 0.24, 0.76];
      const eanAdaySayac = new Map();
      const adayKontrol = okunan => {
        if (!okunan) return '';
        if (/^\d{8,14}$/.test(okunan)) {
          const say = (eanAdaySayac.get(okunan) || 0) + 1;
          eanAdaySayac.set(okunan, say);
          return say >= 2 ? okunan : '';
        }
        return okunan;
      };

      // 1) Yatay tarama çizgileri (0° ve 180°)
      const griYatay = new Uint8Array(hedefW);
      for (const o of oranlar) {
        const y = Math.floor(hedefH * o);
        for (let x = 0; x < hedefW; x++) griYatay[x] = griPiksel(x, y);
        const okunan = adayKontrol(satirdanCode128Coz(griYatay, hedefW));
        if (okunan) return okunan;
      }

      // 2) Dikey tarama çizgileri (90° ve 270° - telefon dikey tutulduğunda!)
      const griDikey = new Uint8Array(hedefH);
      for (const o of oranlar) {
        const x = Math.floor(hedefW * o);
        for (let y = 0; y < hedefH; y++) griDikey[y] = griPiksel(x, y);
        const okunan = adayKontrol(satirdanCode128Coz(griDikey, hedefH));
        if (okunan) return okunan;
      }

      // 3) Çapraz tarama çizgileri (45° ve 135° - etiket çapraz tutulduğunda!)
      const caprazUzunluk = Math.min(hedefW, hedefH);
      const griCapraz1 = new Uint8Array(caprazUzunluk);
      const griCapraz2 = new Uint8Array(caprazUzunluk);
      for (const kayma of [0, -0.15, 0.15]) {
        for (let i = 0; i < caprazUzunluk; i++) {
          const x1 = Math.min(hedefW - 1, Math.max(0, Math.floor((i / caprazUzunluk + kayma) * hedefW)));
          const x2 = Math.min(hedefW - 1, Math.max(0, hedefW - 1 - x1));
          const y = Math.min(hedefH - 1, Math.max(0, Math.floor((i / caprazUzunluk) * hedefH)));
          griCapraz1[i] = griPiksel(x1, y);
          griCapraz2[i] = griPiksel(x2, y);
        }
        const ok1 = adayKontrol(satirdanCode128Coz(griCapraz1, caprazUzunluk));
        if (ok1) return ok1;
        const ok2 = adayKontrol(satirdanCode128Coz(griCapraz2, caprazUzunluk));
        if (ok2) return ok2;
      }
    } catch (_) {}
    return '';
  }

  const disa = { DESENLER, degerler, genislikler, svg, goruntudenOku, gecerliBarkodMu, barkodSec };
  if (typeof module !== 'undefined' && module.exports) module.exports = disa;
  else kok.MezatBarkod = disa;
})(typeof window !== 'undefined' ? window : this);
