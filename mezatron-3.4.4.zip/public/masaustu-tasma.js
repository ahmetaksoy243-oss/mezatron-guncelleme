// Masaüstü ekranı üst bölümü: beş satır yerine iki satır.
//  1. satır: logo + firma adı, sekmeler, tarih, yenile ve "⚙" menüsü (Gündüz/Gece, Kılavuz, Tam Ekran)
//  2. satır: sık kullanılan düğmeler, arama, Beden/Renk ve "Diğer" menüsü (az kullanılan düğmeler)
//  Sayaçlar (Çeşit, Adet, Toplam, Yazıcı) en alttaki ince durum çubuğuna iner.
// Düğmelerin kendisi taşınır (kopyalanmaz), tıklama işlevleri aynen çalışır.
// Ekran daralırsa sığmayan öğeler de ilgili açılır menüye geçer, genişleyince geri döner.
(function () {
  'use strict';
  const $ = id => document.getElementById(id);

  function menuOlustur(etiket, baslik) {
    const kutu = document.createElement('div');
    kutu.className = 'tasma-kutu';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'tasma-btn';
    btn.textContent = etiket;
    if (baslik) btn.title = baslik;
    btn.setAttribute('aria-haspopup', 'true');
    btn.setAttribute('aria-expanded', 'false');
    const menu = document.createElement('div');
    menu.className = 'tasma-menu';
    menu.hidden = true;
    const tasanlar = document.createElement('div');   // ekrana sığmayanlar buraya gelir
    tasanlar.className = 'tasma-tasanlar';
    const ayrac = document.createElement('div');
    ayrac.className = 'tasma-ayrac';
    menu.append(tasanlar, ayrac);
    kutu.appendChild(btn);
    document.body.appendChild(menu);

    const kapat = () => { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); };
    const ac = () => {
      ayrac.style.display = tasanlar.children.length && menu.children.length > 2 ? '' : 'none';
      const r = btn.getBoundingClientRect();
      menu.hidden = false;
      menu.style.top = Math.round(r.bottom + 4) + 'px';
      menu.style.right = Math.max(8, window.innerWidth - r.right) + 'px';
      menu.style.left = 'auto';
      btn.setAttribute('aria-expanded', 'true');
    };
    btn.addEventListener('click', e => { e.stopPropagation(); menu.hidden ? ac() : kapat(); });
    document.addEventListener('click', e => { if (!menu.contains(e.target) && e.target !== btn) kapat(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') kapat(); });
    menu.addEventListener('click', e => { if (e.target.closest('button')) setTimeout(kapat, 0); });
    menu.addEventListener('change', e => { if (e.target.type === 'file') kapat(); });
    window.addEventListener('scroll', kapat, true);
    return { kutu, btn, menu, tasanlar, ac, kapat, ekle: el => el && menu.appendChild(el) };
  }

  // Satır sığmazsa adaylar sondan başlayarak menüye taşınır
  function tasmaKur(kap, adaylariBul, m) {
    const yerler = new Map();
    let calisiyor = false;
    function geriKoy() {
      for (const [oge, isaret] of yerler) { if (isaret.parentNode) isaret.parentNode.insertBefore(oge, isaret); isaret.remove(); }
      yerler.clear();
    }
    function hesapla() {
      if (calisiyor || !kap.offsetParent) return;
      calisiyor = true;
      try {
        const acikti = !m.menu.hidden;
        geriKoy();
        const adaylar = adaylariBul().filter(Boolean);
        while (kap.scrollWidth > kap.clientWidth + 1 && adaylar.length) {
          const oge = adaylar.pop();
          const isaret = document.createComment('tasma');
          oge.parentNode.insertBefore(isaret, oge);
          yerler.set(oge, isaret);
          m.tasanlar.insertBefore(oge, m.tasanlar.firstChild);
        }
        if (acikti) m.ac();
      } finally { calisiyor = false; }
    }
    let z = null;
    const sonra = () => { clearTimeout(z); z = setTimeout(hesapla, 120); };
    window.addEventListener('resize', sonra);
    if (window.ResizeObserver) new ResizeObserver(sonra).observe(kap);
    new MutationObserver(() => { if (!calisiyor) sonra(); })
      .observe(kap, { subtree: true, characterData: true, childList: true });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(sonra);
    window.addEventListener('load', sonra);
    sonra();
  }

  function basla() {
    const baslik = document.querySelector('.m365-baslik-cubuk');
    const sekmeler = document.querySelector('.m365-sekme-serit');
    const serit = $('serit-arac-cubugu');
    const formul = document.querySelector('.m365-formul-cubuk');
    if (!baslik || !sekmeler || !serit) return;
    document.body.classList.add('iki-sira');

    // ---- 1. satır: logo + firma adı | sekmeler | tarih, yenile, durum, ⚙ ----
    const marka = document.createElement('div');
    marka.className = 'iki-sira-marka';
    const rozet = document.querySelector('.m365-excel-rozet');
    const firma = $('baslik-firma-adi');
    if (rozet) marka.appendChild(rozet);
    if (firma) marka.appendChild(firma);
    sekmeler.insertBefore(marka, sekmeler.firstChild);

    const sag = document.createElement('div');
    sag.className = 'iki-sira-sag';
    const durum = document.querySelector('.m365-kayit-durum');
    [$('secili-gun'), $('hizli-yenile-btn')].forEach(e => e && sag.appendChild(e));
    const ayar = menuOlustur('⚙ ▾', 'Gündüz/Gece modu, kılavuz, tam ekran');
    ['tema-degistir-btn', 'rehber-ac-btn', 'pwa-kur-btn', 'tam-ekran-btn'].forEach(id => ayar.ekle($(id)));
    sag.appendChild(ayar.kutu);
    sekmeler.appendChild(sag);
    baslik.style.display = 'none';

    // ---- 2. satır: sık düğmeler | arama | Beden, Renk | Diğer ----
    const sik = document.createElement('div');
    sik.className = 'm365-arac-grubu iki-sira-sik';
    ['yeni-urun-btn', 'el-terminali-btn', 'toplu-etiket-btn', 'excel-indir-btn'].forEach(id => { const b = $(id); if (b) sik.appendChild(b); });

    const ara = document.createElement('div');
    ara.className = 'iki-sira-ara';
    const araGirdi = $('tablo-arama');
    if (araGirdi) ara.appendChild(araGirdi);

    const filtre = document.querySelector('.m365-filtre-kutu');
    if (filtre) filtre.classList.add('iki-sira-filtre');

    const diger = menuOlustur('Diğer ▾', 'Az kullanılan işlemler');
    const yukle = $('excel-yukle-input') && $('excel-yukle-input').closest('label');
    ['ust-cep-modu-btn', yukle, 'a4-yazdir-btn', 'serit-rapor-btn', 'ust-yonetici-btn', 'firma-profil-btn',
      'serit-canli-aktar-btn', 'yenile-btn', 'serit-guvenli-kapat-btn']
      .forEach(x => diger.ekle(typeof x === 'string' ? $(x) : x));

    const eskiGruplar = [...serit.children];
    serit.append(sik, ara);
    if (filtre) serit.appendChild(filtre);
    serit.appendChild(diger.kutu);
    eskiGruplar.forEach(g => g.remove());   // içi boşalmış eski gruplar

    // ---- Sayaçlar en alttaki durum çubuğuna ----
    const alt = document.createElement('div');
    alt.className = 'iki-sira-alt';
    if (durum) alt.appendChild(durum);   // Güncel (saat) bilgisi
    const ozet = document.querySelector('.m365-durum-ozet');
    if (ozet) alt.appendChild(ozet);
    const lisans = $('lisans-alt-yazi');
    if (lisans) alt.appendChild(lisans);
    document.body.appendChild(alt);
    if (formul) formul.style.display = 'none';

    // Dosya menüsü yeni yerinde Dosya düğmesinin altında açılsın
    const dosyaPanel = $('dosya-acilir-menu');
    if (dosyaPanel) dosyaPanel.style.left = '0';

    // ---- Dar ekranda taşma ----
    // 1. satır: sağdan sekmeler ⚙ menüsüne geçer
    tasmaKur(sekmeler, () => [...sekmeler.querySelectorAll(':scope > .m365-sekme-btn[data-serit]:not(.ana-sayfa-btn)')], ayar);
    // 2. satır: önce Beden/Renk, sonra sağdan sık düğmeler Diğer menüsüne geçer (Yeni Ürün en son)
    tasmaKur(serit, () => [...sik.children, filtre], diger);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', basla);
  else basla();
})();
