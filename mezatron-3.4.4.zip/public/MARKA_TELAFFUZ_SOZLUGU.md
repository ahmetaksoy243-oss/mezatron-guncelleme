# 🏷️ Mezatron Evrensel Marka & Telaffuz Sözlüğü (İngilizce / Yabancı Marka Algılama Kılavuzu)

Bu dosya, depoda veya canlı yayında ürünleri sesli okuyan kişinin **İngilizce, Fransızca, İtalyanca, Almanca ve İspanyolca marka adlarını**:
1. **Türkçe yazıldığı gibi (harf harf)** okuması,
2. **Türkçe aksanla / yaklaşık telaffuzla** söylemesi veya
3. **Ses tanıma motorunun (Whisper / WebSpeech)** yabancı kelimeyi Türkçe benzer sese benzeterek yanlış yazması

durumlarında sistemin markayı **%100 doğru ve orijinal yazılışıyla** tanıması için hazırlanmıştır.

> **Nasıl Çalışır?**
> Hem **Sesli Envanter Asistanı (Port 3002)** hem de **Canlı Yayın Satış Sistemi (Port 3001)** bu `.md` tablosunu otomatik olarak okur. Yeni bir marka veya yanlış telaffuz eklemek istediğinizde tabloya yeni bir satır eklemeniz veya virgülle yeni okunuş yazmanız yeterlidir; sistem yeniden başlatmaya gerek kalmadan anında öğrenir!

---

## 1. Spor Giyim, Sneaker & Sokak Modası Markaları

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Nike** | nayk, nayki, naik, naiki, nıke, naykı, nayt, naykın | Spor & Ayakkabı |
| **Adidas** | adıdas, adidaz, edidas, adiddas, adídas | Spor & Ayakkabı |
| **Puma** | pûma, pumma, puman | Spor & Ayakkabı |
| **Skechers** | skeçırs, skeçörs, sıkeçırs, sikeçırs, skecirs, skeçır, skecher, sıkeçır, şkeçırs | Spor & Ayakkabı |
| **New Balance** | niv balans, nü balans, nü belens, niv belens, nıv balans, new balans, nev balans, niu balans | Spor & Ayakkabı |
| **Under Armour** | andır armır, andır armor, under armor, under armur, andır armur, andırarmır, ander armır | Spor & Giyim |
| **Reebok** | ribok, rıbok, ribuk, reбок, reebuk, riybok, rebok | Spor & Ayakkabı |
| **Asics** | asiks, esiks, asics, asıks, aşıks, esıks | Spor & Ayakkabı |
| **Converse** | konvers, konvörs, kanvers, convers, konverz | Spor & Ayakkabı |
| **Vans** | vens, vanz, venz | Spor & Ayakkabı |
| **Fila** | fıla, filla | Spor & Giyim |
| **Champion** | çempiyın, şampiyın, çempion, çempiyon, campiyon, çampiyın | Spor & Giyim |
| **Kappa** | kapa, kapba | Spor & Giyim |
| **Lotto** | loto | Spor & Ayakkabı |
| **Diadora** | diyadora, diadora, dyadora | Spor & Ayakkabı |
| **Hummel** | hamıl, humel, hummıl, hamel, humıl | Spor & Giyim |
| **Slazenger** | sılazenger, slazıngır, slazنجer, sılazıngır, slazenger, şlazenger, silezinger | Spor & Ayakkabı |
| **Jordan** | cordın, cordin, jordin, cordan | Spor & Ayakkabı |
| **Crocs** | kroks, kıroks, kuroks, croks | Terlik & Ayakkabı |
| **Birkenstock** | birkenştok, birkınştok, birkenstok, birkınstok, bırkenştok | Terlik & Ayakkabı |

---

## 2. Outdoor, Dağcılık & Kış Giyim Markaları

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **North Face** | nort feys, nord feys, nordfalce, nortfalce, northface, nort face, nord face, nortfeys, nordfeys, nort fes, nord fes, north feys, nürt fajrı, nurt fajri, nört feys, north s, nord, nort | Outdoor |
| **Columbia** | kolumbiya, kolombiya, kolambiya, colombiya, columbiya, kalambya, kolumbia, şcolumbia, scolumbia, qcolumbia, ocolumbia, coiumoia, columbıa, colombia | Outdoor |
| **Jack Wolfskin** | cek volfskin, cak volfskin, cek vulfskin, jack volfskin, cek wolfskin, jak volfskin | Outdoor |
| **Helly Hansen** | heli hansen, helihansen, helli hansen, heli hensın, helly hansın | Outdoor |
| **Patagonia** | patagonya, pategonya | Outdoor |
| **Quechua** | keçua, keçuva, kuveçua, kueçua, keçva, queçua | Outdoor |
| **Salomon** | salamon, solomon, salımon, şalomon | Outdoor & Ayakkabı |
| **Merrell** | merel, merıl, merrel, mörıl | Outdoor & Ayakkabı |
| **Timberland** | timbırlend, timberlend, tımbırlend, timbırland, timberland, tımbırland | Outdoor & Bot |
| **Caterpillar** | katırpılar, katerpilar, katırpilar, caterpilar, ketırpılır | Outdoor & Bot |
| **Harley Davidson** | harli deyvidsın, harley davidsın, harli davidsın, harli deyvidson, harley deyvidsın | Bot & Giyim |
| **Moncler** | monklör, monkler, mongler, moncler | Lüks Kış Giyim |
| **Canada Goose** | kanada gus, kanada guz, canada gus, kanada goz | Lüks Kış Giyim |
| **Napapijri** | napapijri, napapiri, napapiyri, napapicri | Outdoor |
| **Quiksilver** | kuiksilvır, kuiksilver, kıviksilvır, quiksilvır, kuik sılvır | Outdoor & Spor |
| **Billabong** | bilabong, billabong, bılabong | Outdoor & Spor |
| **O'Neill** | onil, oneyl, o neil, oniyl | Outdoor & Spor |

---

## 3. Günlük Hazır Giyim, AVM & Fast Fashion Markaları

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Zara** | dzara, zarra | Hazır Giyim |
| **Bershka** | berşka, bırşka, berşha, berska, börşka | Hazır Giyim |
| **Pull&Bear** | pul end bir, pul en ber, pul end ber, pull and bear, pul and bir, pulenbir, pulenber, pul bir, pull bear | Hazır Giyim |
| **Stradivarius** | stradivariyus, sıtradivarius, sıtradivariyus, sitradivarius, stradivarius, istiradivarius | Hazır Giyim |
| **Massimo Dutti** | masimo dutti, masimo duti, massimo duti, mazimo dutti | Hazır Giyim |
| **Oysho** | oyşo, oişo, oyso | İç & Ev Giyim |
| **H&M** | eç end em, eç en em, haş em, he me, h ve m, eyç end em, eyç en em, haş end em | Hazır Giyim |
| **C&A** | ce a, si end ey, ce ve a | Hazır Giyim |
| **Marks & Spencer** | marks end spensır, marks en spensır, mark spensır, marks spencer, mark end spensır, marks spensır | Hazır Giyim |
| **Benetton** | beneton, benetton, benıtın | Hazır Giyim |
| **Sisley** | sisli, sısli, sisley | Hazır Giyim |
| **Esprit** | espirit, espri, esprit, ispirid | Hazır Giyim |
| **Uniqlo** | yuniklo, uniklo, üniklo, yüniklo | Hazır Giyim |
| **Forever 21** | forevır yirmi bir, forever yirmi bir, forevır 21, forevır tventi van | Hazır Giyim |
| **Primark** | praymark, primark, pıraymark, pirimark | Hazır Giyim |
| **Shein** | şiin, şeyn, şin, şiyin, sheın | Hazır Giyim |
| **Desigual** | desigüal, dezigual, desigyual, desigal | Hazır Giyim |
| **Superdry** | süpırdray, superdray, süper dray, super dry | Hazır Giyim |
| **Scotch & Soda** | skoç end soda, sikoç end soda, skoç soda, scotch soda | Hazır Giyim |
| **Gant** | gent, gant | Hazır Giyim |
| **Nautica** | navtika, notika, nautika, noutika | Hazır Giyim |
| **Paul & Shark** | pol end şark, paul şark, pol şark, paul end şark | Hazır Giyim |
| **Fred Perry** | fred peri, fıred peri, fred perry | Hazır Giyim |
| **Barbour** | barbır, barbur, barbor | Dış Giyim |
| **Ted Baker** | ted beykır, ted bekır, ted baker | Hazır Giyim |
| **XSIDE** | x side, iks sayd, iksayd, ekside, x-side, xside | Hazır Giyim |
| **Rollmann** | rollman, rolman, rolmen | Ayakkabı |

---

## 4. Denim (Kot) & Casual Markaları

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Levi's** | livays, levis, liviz, lıvays, levays, leviys, li vays | Denim & Kot |
| **Wrangler** | rangler, renglır, vırangler, vrangler, ranglır | Denim & Kot |
| **Lee Cooper** | li kupır, li kuper, lee kuper, lee kupır, likupır | Denim & Kot |
| **Diesel** | dizel, dızel, diysel | Denim & Kot |
| **G-Star Raw** | ci star rav, g star, ci star, gı star, g star raw | Denim & Kot |
| **Replay** | ripley, rıpley, repley | Denim & Kot |
| **Pepe Jeans** | pepe cins, pepe jins, pepe jeans | Denim & Kot |
| **Mavi Jeans** | mavi cins, mavi jins, mavi ceans, mavi jeans, mavi jean | Denim & Kot |
| **Colin's** | kolins, colins, kolinz, kolıns | Denim & Kot |
| **Cross Jeans** | kros cins, kıros cins, kros jins | Denim & Kot |
| **Mustang** | masteng, musteng, mustang | Denim & Kot |
| **Dockers** | dakırs, dokırs, dokers, dakers | Casual & Pantolon |
| **Jack & Jones** | cek end cons, cak end cons, cek cons, jack jones, cek jons, jak cons | Casual & Erkek |
| **Vero Moda** | veromoda, vero moda | Kadın Giyim |
| **Only** | onli, only marka | Kadın Giyim |

---

## 5. Premium, Lüks & Tasarım Markaları

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Lacoste** | lakost, lakos, lakoste, la kost | Premium Giyim |
| **Tommy Hilfiger** | tomi hilfiger, tomi hilfigır, tomi hilfıgır, tommy hilfigır, tommy hilfıgır, tomi hilfaygır, tommi hilfiger, tomi hılfıgır | Premium Giyim |
| **Calvin Klein** | kelvin klayn, kalvin klayn, kalvin kleyn, kelvin kleyn, calvin klayn, kalvın klayn | Premium Giyim |
| **Ralph Lauren** | ralf loren, ralf lauren, relf loren, polo ralf loren | Premium Giyim |
| **U.S. Polo Assn.** | us polo, yu es polo, u s polo, uspolo, amerikan polo | Premium Giyim |
| **Pierre Cardin** | piyer kardin, pier kardin, piyer gardin, pierre kardin, piyerkardin | Klasik & Giyim |
| **Cacharel** | kaşarel, kasarel, kaşerel | Klasik & Giyim |
| **Gucci** | guççi, guçi, guchi, gucci | Lüks |
| **Prada** | pırada | Lüks |
| **Louis Vuitton** | lui viton, luiz viton, luis viton, luviton, lui vuton, louis viton | Lüks |
| **Chanel** | şanel, çanel | Lüks |
| **Christian Dior** | диор, diyor, kristiyan diyor, hristiyan diyor, dior | Lüks |
| **Balenciaga** | balensiyaga, balensiaga, balenciyaga | Lüks |
| **Versace** | versaçe, versace, vörsaçe, versaci | Lüks |
| **Giorgio Armani** | corciyo armani, corco armani, jorjo armani | Lüks |
| **Emporio Armani** | emporyo armani, emporio armani | Lüks |
| **Armani Exchange** | armani eksçeync, armani ekşenj, armani iksçeync | Lüks |
| **Hugo Boss** | hugo bos, hügo bos, hugobos | Premium & Klasik |
| **Burberry** | börberi, burberi, barberi, börbıri, burberry | Lüks |
| **Dolce & Gabbana** | dolçe gabana, dolçe end gabana, dolce gabana, dolçegabana | Lüks |
| **Fendi** | fendı | Lüks |
| **Givenchy** | jivanşi, civanşi, givanşi, jivansi | Lüks |
| **Saint Laurent** | sen loran, sent loren, iv sen loran, ysl | Lüks |
| **Valentino** | valentıno | Lüks |
| **Bottega Veneta** | botega veneta, bottega venetta | Lüks |
| **Hermes** | hermes, ermez, ermes | Lüks |
| **Michael Kors** | maykıl kors, micheal kors, maykil kors, maikıl kors, maykılkors | Premium & Çanta |
| **Karl Lagerfeld** | karl lagerfeld, karl lagırfeld, lagerfeld | Premium |
| **Marc Jacobs** | mark ceykıbs, mark jakobs, marc jakobs, mark ceykobs | Premium |
| **Tory Burch** | tori börç, tori burç, tory burç | Premium |
| **Guess** | ges, gües, gues, gess | Premium |
| **Moschino** | moskino, moşkino, mosçino | Lüks |
| **Dsquared2** | diskuared, dıskuared, diskuard, d squared, diskuared iki | Lüks |
| **Off-White** | of vayt, off vayt, of white | Sokak & Lüks |
| **Palm Angels** | palm eyncıls, palm encıls, palm angels | Sokak & Lüks |
| **Stone Island** | ston aylınd, sıton aylınd, stone ayland, ston ayland | Premium |
| **Philipp Plein** | filip pilayn, filip playn, philip playn, filip pleyn | Lüks |
| **Elisabetta Franchi** | elizabetta franki, elisabetta franki, elizabet franki | Lüks Kadın |
| **Pinko** | pınko | Premium Kadın |
| **Liu Jo** | liu co, liu jo, liujo, lü co | Premium Kadın |
| **Patrizia Pepe** | patrizya pepe, patrisya pepe | Premium Kadın |
| **Max Mara** | maks mara, maksmara | Lüks Kadın |
| **Barbara** | barbara, bar bara, barbora, marmara, varvara | Kadın Giyim |

---

## 6. İç Giyim, Ev Giyim & Plaj Markaları

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Victoria's Secret** | viktorya sikrıt, viktoryas sikrıt, viktorya secret, victoria sikrıt, viktorya sıkrıt | İç Giyim |
| **Intimissimi** | intimisimi, ıntimisimi, intimissimi | İç Giyim |
| **Calzedonia** | kalzedonya, kalsedonya, calzedonya | İç & Plaj Giyim |
| **Tezenis** | tezenıs | İç Giyim |
| **Triumph** | triyumf, tırayamf, tiriyumf | İç Giyim |
| **Women'secret** | vumın sikrıt, vumen sikrıt, women sikrıt, vumınsikrıt | İç Giyim |
| **Blackspade** | blekspeyd, blakspeyd, black speyd, blek speyd | İç & Termal Giyim |

---

## 7. Ayakkabı, Çanta & Aksesuar Markaları

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Rollmann** | rolman, rollman, jolun, rolmen, rollmen, roman ayakkabı | Ayakkabı |
| **Nine West** | nayn vest, nain vest, nine vest, naynvest | Ayakkabı & Çanta |
| **Ecco** | eko, ekko | Ayakkabı |
| **Geox** | ceoks, geoks, jeoks | Ayakkabı |
| **Clarks** | klarks, kılarks | Ayakkabı |
| **Camper** | kampır, kamper, kemper, kempır | Ayakkabı |
| **Steve Madden** | stiv medın, sıtiv medın, stiv maden, steve medın | Ayakkabı & Çanta |
| **Rieker** | riker, riyker, rieker | Ayakkabı |
| **Gabor** | gabur | Ayakkabı |
| **Tamaris** | tamarıs | Ayakkabı |
| **Vagabond** | vagabont | Ayakkabı |
| **Dr. Martens** | doktor martens, doktor martins, dr martens | Bot & Ayakkabı |
| **UGG** | ag, agg, ugg bot | Bot & Ayakkabı |
| **Greyder** | gıreyder, greyder, grader, greder, crader | Ayakkabı |
| **Gezer** | gezer, bezer, ezer, cezer | Terlik & Ayakkabı |
| **Scooter** | sukutır, sıkutır, skuter, skutır | Bot & Ayakkabı |
| **Kinetix** | kinetiks, kınetiks | Spor Ayakkabı |
| **Lumberjack** | lambırcek, lambercek, lumbercek, lambırcak, lamberjak | Ayakkabı |
| **Samsonite** | semsonayt, samsonayt, samsünayt | Çanta & Valiz |
| **Eastpak** | istpek, ispek, eastpek | Çanta |
| **Herschel** | hörşıl, herşıl, hersçel | Çanta |
| **Kipling** | kıpling | Çanta |
| **Longchamp** | longşamp, lonşamp, long şamp | Çanta |

---

## 8. Türkiye Mağaza, Erkek Klasik & Mezat/İhraç Fazlası Markaları

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Bigazzi** | bigazi, bigazı, bigastim, bigasti, bigasi, bigaz, bigazzi | Erkek & Triko |
| **Sandex** | sandex, sandeks, sendeks, sendex | Hazır Giyim & Tişört |
| **Xside** | iks sayd, ikssayd, xide, x side, iks side, ekssayd, eks sayd, iksayd | LCW & Genç Giyim |
| **LC Waikiki** | el si vaykiki, elsi vaykiki, lcw, elcivaikiki, lc vaykiki, vaykiki, waikiki | Hazır Giyim |
| **Southblue** | saut blu, sautblu, south blu, sot blu | Hazır Giyim |
| **DeFacto** | defakto, de fakto, dıfakto | Hazır Giyim |
| **Kiğılı** | kığılı, kigili, kiyili, kıgılı | Erkek Klasik |
| **Altınyıldız Classics** | altınyıldız klasiks, altınyıldız klasik | Erkek Klasik |
| **Damat Tween** | damat tivin, damat tıvin, tivin, tıvin | Erkek Klasik |
| **D'S Damat** | dies damat, d s damat, ds damat | Erkek Klasik |
| **Ramsey** | ramzey, remzi, ramsey | Erkek Klasik |
| **Lufian** | lufiyan, lüfiyan, lufian | Erkek Casual |
| **Tudors** | tüdors, tudor, tudors | Gömlek & Erkek |
| **Avva** | ava, avva | Erkek Casual |
| **W Collection** | dablyu kolekşın, v kolekşın, w kolekşın | Premium |
| **Jimmy Key** | cimi key, jimi key, cimikey | Kadın Giyim |
| **Oxxo** | okso, oxxo | Kadın Giyim |
| **Adl** | adele, adl, adil ışık | Kadın Giyim |
| **Perspective** | perspektif, pörspektif | Kadın Giyim |
| **Deichmann** | dayhman, dayşman, deichman, dayhman ayakkabı | Ayakkabı |

---

## 9. Parfüm, Niş Koku & Kozmetik Markaları / Serileri

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **Sauvage** | sovaj, suvaj, savaj, sovaş, suvaş, sauvage | Parfüm |
| **Nishane Hacivat** | hacivat, hacıvat, hacep, hacıbat, nişane hacivat, nishane hacivat, nişane, nishane | Niş Parfüm |
| **Chanel Parfüm** | şanel tarıkçı, chanel tarıkçı, şanel parfüm, chanel parfum | Parfüm |
| **Chanel Chance** | şanel şans, chanel şans, şans parfüm, chance eau tendre | Parfüm |
| **Chanel Allure** | şanel alür, chanel alür, allure homme sport | Parfüm |
| **Bleu de Chanel** | blö dö şanel, blu dö şanel, blö de şanel, bleu de şanel | Parfüm |
| **Coco Mademoiselle** | koko matmazel, koko madmazel, coco matmazel | Parfüm |
| **Dior J'adore** | jador, jadore, cador, diyor jador | Parfüm |
| **Miss Dior** | mis diyor, miss diyor, mis dior | Parfüm |
| **Fahrenheit** | fahrenhayt, fahrenayt, fahrenheit | Parfüm |
| **Versace Eros** | versace eros, versaçe eros, eros parfüm | Parfüm |
| **Crystal Noir** | kristal nuar, crystal noir, kristal noir, brayt kristal, bright crystal | Parfüm |
| **Paco Rabanne** | pako raban, paco raban, pakoraban, pako rabanne | Parfüm |
| **One Million** | van milyın, van milyon, one milyon, 1 milyon parfüm | Parfüm |
| **Lady Million** | leydi milyın, leydi milyon, lady milyon | Parfüm |
| **Invictus** | inviktus, ınviktus, in viktus | Parfüm |
| **Olympea** | olimpya, olimpiya, olympea | Parfüm |
| **Carolina Herrera** | karolina herera, karolina herrera, carolina herera | Parfüm |
| **Good Girl** | gud görl, gut görl, gud girl, good görl | Parfüm |
| **Bad Boy** | bed boy, bet boy | Parfüm |
| **Jean Paul Gaultier** | jan pol gotye, can pol gotye, jan paul gotye, gotye, le male, lö mal | Parfüm |
| **Scandal** | skandal parfüm, sıkandal | Parfüm |
| **Acqua di Gio** | akua di cio, akva di jiyo, akua di jio, acqua di jio | Parfüm |
| **Stronger With You** | strongır vit yu, stronger vit yu, stronger with you | Parfüm |
| **Armani Si** | armani si, ciorcio armani si | Parfüm |
| **Armani My Way** | armani may vey, may vey parfüm, my way | Parfüm |
| **Black Opium** | blek opyum, blak opyum, black opyum, blek opiyum | Parfüm |
| **Libre** | libre parfüm, ysl libre | Parfüm |
| **Gucci Bloom** | guççi blum, gucci blum, gucci bloom, guççi flora, gucci flora, guççi gilti, gucci guilty | Parfüm |
| **L'Interdit** | linterdi, jivanşi linterdi, givenchy linterdit | Parfüm |
| **Bombshell** | bombşel, bomşel, viktorya sikrıt bombşel, bare vanilla, beyr vanilya | Parfüm & Body Mist |
| **Lattafa Khamrah** | lattafa, latafa, kamrah, hamra parfüm, lattafa asad, lattafa yara | Parfüm |
| **Club de Nuit** | armaf, klab dö nui, club de nuit intense | Parfüm |
| **Lancôme** | lankom, lancome, langom | Parfüm & Kozmetik |
| **La Vie Est Belle** | la vi e bel, lavi e bel, la vie est bel, laviebel | Parfüm |
| **Hypnôse** | hipnoz parfüm, hypnose | Parfüm |
| **Idôle** | idol parfüm, lankom idol | Parfüm |
| **Tom Ford** | tom ford, tomford, tam ford | Niş Parfüm |
| **Black Orchid** | blek orkid, blak orkid, black orkid, siyah orkide | Niş Parfüm |
| **Tobacco Vanille** | tobako vanil, tabako vanilya, tobacco vanil | Niş Parfüm |
| **Creed Aventus** | krid aventus, kırit aventus, creed aventus, aventus | Niş Parfüm |
| **Baccarat Rouge** | bakara ruj, bakarat ruj, baccarat ruj, bakara 540 | Niş Parfüm |
| **Maison Francis Kurkdjian** | mezon fransis kürkciyan, mezon fransis | Niş Parfüm |
| **Parfums de Marly** | parfüm dö marli, de marli, marli parfüm, delina, pegasus | Niş Parfüm |
| **Kirke** | kirke, tiziana terenzi, tizyana terenzi | Niş Parfüm |
| **Xerjoff** | zerjof, kserjof, erba pura | Niş Parfüm |
| **Jo Malone** | co malon, jo malon, jomalon | Niş Parfüm |
| **Narciso Rodriguez** | narsiso rodrigez, narsizo rodrigez, narciso rodrigez | Parfüm |
| **Bvlgari** | bulgari, bvlgari, bülgari | Parfüm & Lüks |
| **Chloé** | kloi, kloe, kloye | Parfüm & Lüks |
| **Mugler Alien** | mugler alyen, eliyın, alien parfüm, தियरी mugler | Parfüm |
| **Davidoff Cool Water** | davidof kul votır, davidof, kul votır, cool votır | Parfüm |
| **Euphoria** | öforya, üforya, eforya, euphoria | Parfüm |
| **Hugo Boss Bottled** | hugo bos batıld, bos batıld | Parfüm |
| **Bargello** | barjello, barcelo, bargelo | Açık Parfüm |
| **Mad Parfüm** | med parfüm, mad parfüm, med narkotik | Açık Parfüm |
| **Loris** | loris parfüm, lorıs | Açık Parfüm |
| **Parfüm Mutfağı** | parfüm mutfağı, parfum mutfagi, porfummutfagi, parfüm hutnı, parfüm muyağı, emilim mutfağı, qarfüm mutfağı, warfiim mutfağı | Açık Parfüm |
| **PM Lab** | pm lab, pmlab, pnış lab, pnis lab, extrait de clone, de clone | Açık Parfüm |
| **My Voyage** | my voyage, may voyaj, muş voyage, voyage | Parfüm |
| **Miss Giordani** | mis ciordani, miss giordani, giordani, ciordani, iordani, iordanı, ıördanl, icğrdanı, iqrdani, jicirdani, g19rdanv, 19rdani, 19rdanl, 19rdanli, ol rdani, ol rdan | Parfüm |
| **Oriflame** | orifleym, oriflame, orıflame | Kozmetik & Parfüm |
| **Estée Lauder** | este loder, este lauder, estee loder | Kozmetik & Parfüm |
| **Clinique** | klinik, kılınik, clinique | Kozmetik & Parfüm |
| **Shiseido** | şiseydo, şişeydo, shiseido | Kozmetik & Parfüm |
| **La Roche-Posay** | la roş pozey, la roş poze, laroş poze, laroşpozey | Dermokozmetik |
| **Bioderma** | biyoderma, bioderma | Dermokozmetik |
| **CeraVe** | serave, kerave, cerave | Dermokozmetik |
| **Maybelline** | meybılin, meybilin, maybeline | Kozmetik |
| **L'Oréal** | loreal, loryal, lorel | Kozmetik |
| **Garnier** | garnyer, garniye, garnier | Kozmetik |
| **Sephora** | sefora, sephora | Kozmetik |

---

## 10. Pastane, Kafe & Gurme Tatlı Sektörü (Yabancı Kökenli Ürün Adları)

| Doğru Marka Adı | Türkçe Okunuşları, Harf Harf Okunuş ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **San Sebastian** | san sebastiyan, san sebastian, sansebastiyan, sen sebastiyan | Pastane & Tatlı |
| **Cheesecake** | çizkeyk, çiz kek, çis kek, çiizkeyk, cizkeyk | Pastane & Tatlı |
| **Croissant** | kruvasan, kurvasan, kıruvasan, kruasan | Pastane & Unlu Mamul |
| **Profiterol** | pırofiterol, profüterol, profiterol | Pastane & Tatlı |
| **Tiramisu** | tiramüsü, tıramisu, tiramisu | Pastane & Tatlı |
| **Macaron** | makaron, magaron | Pastane & Tatlı |
| **Brownie** | brovni, bırovni, brauni, browni | Pastane & Tatlı |
| **Cookie** | kuki, kuuki | Pastane & Tatlı |
| **Muffin** | mafin, mufin | Pastane & Tatlı |
| **Cupcake** | kapkeyk, kap kek, kupkek | Pastane & Tatlı |
| **Donut** | donat, dounat | Pastane & Tatlı |
| **Waffle** | vafıl, vafl, wafıl | Pastane & Tatlı |
| **Pancake** | pankek, penkeyk | Pastane & Tatlı |
| **Soufflé** | sufle, süfle | Pastane & Tatlı |
| **Fondant** | fondan | Pastane & Tatlı |
| **Ganache** | ganaj, ganaş | Pastane & Tatlı |
| **Mille-Feuille** | milföy, mılföy | Pastane & Tatlı |
| **Charlotte** | şarlot, şarlotta | Pastane & Tatlı |
| **Frambuazlı** | fıramboazlı, framboazlı, fırambuazlı | Pastane & Tatlı |
| **Espresso** | ekspreso, espreso, ekpreso | Kafe & İçecek |
| **Cappuccino** | kapuçino, kapicino, kapiçino | Kafe & İçecek |
| **Latte Macchiato** | latte makyato, makiyato, makiato | Kafe & İçecek |
| **Mocha** | moka, moça | Kafe & İçecek |
| **Americano** | amerikano | Kafe & İçecek |
| **Frappuccino** | fırapuçino, frapuçino | Kafe & İçecek |

