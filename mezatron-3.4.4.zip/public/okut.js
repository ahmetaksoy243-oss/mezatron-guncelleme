// Barkod okutma ekranı: okuyucu klavye gibi yazar ve Enter'a basar. Kamera, görsel ve tek tıkla test desteklidir.
(function () {
  const $ = id => document.getElementById(id);
  const _orijinalFetch = window.fetch ? window.fetch.bind(window) : null;
  function aktifPinAl() {
    try {
      const k = String(localStorage.getItem('mezat_giris_pin') || '').replace(/\D+/g, '').slice(0, 4);
      return k.length === 4 ? k : '';
    } catch (_) {
      return '';
    }
  }
  if (_orijinalFetch) {
    window.fetch = async function (input, init) {
      const ayar = Object.assign({}, init || {});
      const basliklar = new Headers(ayar.headers || {});
      if (!basliklar.has('X-Mezat-Pin')) basliklar.set('X-Mezat-Pin', aktifPinAl());
      try {
        const jeton = localStorage.getItem('mezat_oturum_jetonu') || '';
        if (jeton && !basliklar.has('X-Mezat-Oturum')) basliklar.set('X-Mezat-Oturum', jeton);
      } catch (_) {}
      ayar.headers = basliklar;
      const yanit = await _orijinalFetch(input, ayar);
      if (yanit && yanit.status === 401) {
        const girilen = window.prompt('🔐 4 Haneli Mezatron Ağ Güvenlik PIN kodunu girin:', aktifPinAl());
        if (girilen && /^\d{4}$/.test(girilen.trim())) {
          localStorage.setItem('mezat_giris_pin', girilen.trim());
          basliklar.set('X-Mezat-Pin', girilen.trim());
          return _orijinalFetch(input, ayar);
        }
      }
      return yanit;
    };
  }
  const post = (yol, govde) => fetch(yol, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(govde || {}) }).then(r => r.json());
  const oge = (etiket, ozellik = {}, ...cocuk) => {
    const e = document.createElement(etiket);
    Object.assign(e, ozellik);
    e.append(...cocuk.filter(c => c !== null && c !== undefined && c !== ''));
    return e;
  };
  const BASLIK = {
    TAMAM: '✅ DOĞRU SİPARİŞ (POŞETE KOYUN)',
    URUN_STOK: '📦 ENVANTER ÜRÜN BARKODU DOĞRULANDI',
    IPTAL: '⛔ İPTAL EDİLDİ',
    BULUNAMADI: '⛔ BARKOD TANINMADI',
    ONAYSIZ: '⚠️ ASİSTAN ONAYLAMADI',
    KAYITSIZ: '⚠️ ETİKET KAYDI YOK'
  };
  let son = [];
  try {
    const kayitliSon = JSON.parse(localStorage.getItem('mezat_son_okutulanlar_v1') || '[]');
    if (Array.isArray(kayitliSon)) son = kayitliSon;
  } catch (_) {}
  const SOLMA_MS = 10000;
  let solmaZamani = null;

  function sonListesiniCiz() {
    const sonEl = $('son');
    if (!sonEl) return;
    const rozetSon = $('rozet-son-sayi');
    if (rozetSon) {
      rozetSon.textContent = String(son.length);
      rozetSon.style.display = son.length > 0 ? 'inline-block' : 'none';
    }
    if (!son.length) {
      sonEl.replaceChildren(oge('div', { className: 'bos', textContent: 'Henüz okutulan barkod yok. Kameraya barkod tutun veya hazır barkodlardan birine dokunun.' }));
      return;
    }
    sonEl.replaceChildren(...son.map(x => {
      const basarili = x.sonuc === 'TAMAM' || x.sonuc === 'URUN_STOK';
      const tekrarBtn = oge('button', {
        type: 'button',
        className: 'hemen-okut-btn',
        textContent: '🔎 Tekrar Doğrula'
      });
      tekrarBtn.onclick = () => koduOkut(x.kod);
      return oge('div', { className: `liste-oge${basarili ? '' : ' hata'}` },
        oge('div', { style: 'display:flex;flex-direction:column;gap:2px;min-width:0;' },
          oge('div', { style: 'display:flex;align-items:center;gap:6px;flex-wrap:wrap;' },
            oge('code', { style: 'background:#020617;color:#38bdf8;padding:2px 6px;border-radius:5px;font-weight:900;font-size:0.8rem;', textContent: x.kod }),
            oge('span', { style: 'color:#94a3b8;font-size:0.74rem;font-weight:700;', textContent: x.zaman || '' }),
            x.raf ? oge('span', { style: 'color:#6ee7b7;font-size:0.74rem;font-weight:800;', textContent: `· ${x.raf}` }) : null
          ),
          oge('span', { style: 'font-weight:800;color:#f8fafc;font-size:0.84rem;', textContent: x.ad || x.urun || 'Barkod Kaydı' })
        ),
        oge('div', { style: 'display:flex;align-items:center;gap:8px;flex-shrink:0;' },
          oge('b', { style: `font-size:0.75rem;color:${basarili ? '#34d399' : '#fca5a5'};`, textContent: basarili ? (x.sonuc === 'URUN_STOK' ? '📦 STOK' : '✅ DOĞRU') : '⛔ HATA' }),
          tekrarBtn
        )
      );
    }));
  }

  // Ana ekrana dönüş
  function istasyonGeriDon() {
    try {
      if (window.opener && !window.opener.closed) {
        try { window.opener.focus(); } catch (_) {}
        window.close();
        setTimeout(() => { window.location.href = '/'; }, 150);
        return;
      }
      window.close();
      setTimeout(() => { window.location.href = '/'; }, 150);
    } catch (e) {
      window.location.href = '/';
    }
  }
  if ($('btn-geri-don')) $('btn-geri-don').onclick = istasyonGeriDon;
  if ($('btn-sayfa-kapat')) $('btn-sayfa-kapat').onclick = istasyonGeriDon;
  window.addEventListener('keydown', e => {
    if (e.key === 'Escape' && (!document.activeElement || !document.activeElement.value)) {
      istasyonGeriDon();
    }
  });

  // Canlı saat ve kamera durumu göstergesi
  function saatiGuncelle() {
    const el = $('canli-saat');
    if (el) el.textContent = new Date().toLocaleTimeString('tr-TR');
    const odakEl = $('odak-durumu');
    if (odakEl) {
      const odakta = document.activeElement === $('kod');
      odakEl.textContent = odakta ? '⌨️ Klavye Girişi Açık' : '📷 Kamera & Tarayıcı Aktif';
    }
  }
  setInterval(saatiGuncelle, 1000);
  saatiGuncelle();

  // Gerçek Süpermarket / Depo Lazer Barkod Okuyucu Sesi (Zebra / Symbol 2730 Hz Piezo Lazer Bip)
  let ses = null;
  function bip(iyi) {
    try {
      ses = ses || new (window.AudioContext || window.webkitAudioContext)();
      if (ses.state === 'suspended') ses.resume().catch(() => {});
      const simdi = ses.currentTime;
      const sikistirici = ses.createDynamicsCompressor();
      sikistirici.threshold.setValueAtTime(-14, simdi);
      sikistirici.ratio.setValueAtTime(8, simdi);
      sikistirici.connect(ses.destination);

      if (iyi) {
        const filtre = ses.createBiquadFilter();
        filtre.type = 'peaking';
        filtre.frequency.setValueAtTime(2730, simdi);
        filtre.Q.setValueAtTime(2.2, simdi);
        filtre.gain.setValueAtTime(7, simdi);
        filtre.connect(sikistirici);

        const g = ses.createGain();
        g.gain.setValueAtTime(0.001, simdi);
        g.gain.linearRampToValueAtTime(0.92, simdi + 0.004);
        g.gain.setValueAtTime(0.92, simdi + 0.095);
        g.gain.exponentialRampToValueAtTime(0.001, simdi + 0.12);
        g.connect(filtre);

        const o1 = ses.createOscillator();
        o1.type = 'square';
        o1.frequency.setValueAtTime(2420, simdi);
        o1.frequency.setValueAtTime(2730, simdi + 0.007);
        o1.connect(g);

        const o2 = ses.createOscillator();
        o2.type = 'triangle';
        o2.frequency.setValueAtTime(2730, simdi);
        o2.connect(g);

        o1.start(simdi);
        o2.start(simdi);
        o1.stop(simdi + 0.122);
        o2.stop(simdi + 0.122);
      } else {
        [[260, 0, 0.18], [220, 0.22, 0.22]].forEach(([hz, bas, sure]) => {
          const o = ses.createOscillator();
          const g = ses.createGain();
          o.type = 'sawtooth';
          o.frequency.setValueAtTime(hz, simdi + bas);
          g.gain.setValueAtTime(0.85, simdi + bas);
          g.gain.exponentialRampToValueAtTime(0.001, simdi + bas + sure);
          o.connect(g).connect(sikistirici);
          o.start(simdi + bas);
          o.stop(simdi + bas + sure + 0.01);
        });
      }
    } catch (err) {}
    if (navigator.vibrate) {
      try { navigator.vibrate(iyi ? 85 : [90, 60, 110]); } catch (_) {}
    }
  }

  function yontemAktifYap() {}

  function gorunumDegistir(hedef) {
    const g = hedef || 'okut';
    document.body.setAttribute('data-gorunum', g);
    document.querySelectorAll('[data-gorunum-hedef]').forEach(btn => {
      btn.classList.toggle('aktif', btn.getAttribute('data-gorunum-hedef') === g);
    });
    if ($('kod') && document.activeElement === $('kod')) {
      $('kod').blur();
    }
  }
  document.querySelectorAll('[data-gorunum-hedef]').forEach(btn => {
    btn.addEventListener('click', () => {
      gorunumDegistir(btn.getAttribute('data-gorunum-hedef'));
    });
  });

  function sonucuGoster(c) {
    gorunumDegistir('okut');
    const kutu = $('sonuc');
    kutu.className = `${c.sonuc || ''}${c.arsiv ? ' arsiv' : ''}`;
    clearTimeout(solmaZamani);
    solmaZamani = setTimeout(() => kutu.classList.add('soluk'), SOLMA_MS);
    const s = c.siparis;
    const baslik = `${BASLIK[c.sonuc] || 'Sonuç'}${c.arsiv ? ' · ÖNCEKİ YAYIN' : ''}`;
    const parcalar = [oge('div', { className: 's-ust' },
      oge('span', { className: 's-baslik', textContent: baslik }),
      oge('span', { className: 's-saat', textContent: `Okutma ${new Date().toLocaleTimeString('tr-TR')}` }))];
    parcalar.push(oge('div', { className: 's-eski', textContent: 'Bu sonuç eski. Sıradaki etiketi okutun.' }));
    if (s) {
      parcalar.push(oge('div', { className: 's-musteri', textContent: s.musteri }));
      parcalar.push(oge('div', { className: 's-satir' },
        s.beden ? oge('span', { className: 's-beden', textContent: s.beden }) : null,
        oge('span', { className: 's-raf', textContent: s.raf === 'DEPO STOK' ? '📦 DEPO STOK' : `RAF ${s.raf}` }),
        oge('span', { className: 's-urun', textContent: `${s.urun} · ${s.siparisNo}` })));
    }
    if (c.musteriPoseti && c.musteriPoseti.toplam > 1) {
      const p = c.musteriPoseti;
      parcalar.push(oge('div', { className: 's-poset', textContent: `🛍️ Bu müşterinin ${p.toplam} ürünü var, ${p.okutulan}'i okutuldu.${p.okutulan < p.toplam ? ' Hepsi aynı poşete.' : ' Poşet tamam.'}` }));
    }
    parcalar.push(oge('div', { className: 's-not', textContent: c.mesaj || '' }));
    if (c.oncekiOkutma) parcalar.push(oge('div', { className: 's-not', textContent: `Bu etiket ${c.oncekiOkutma}'da da okutuldu. Aynı ürün iki kez mi poşetleniyor?` }));

    // 👤 MÜŞTERİ KAYIT KONTROLÜ KARTI (Okunan barkoddaki kişi sistemde müşteri olarak kayıtlı mı değil mi?)
    if (c.musteriKayit) {
      const mk = c.musteriKayit;
      const kayitli = Boolean(mk.kayitliMi);
      const mkKutu = oge('div', {
        id: 'musteri-kayit-kutu',
        style: `margin-top:12px; padding:14px 16px; border-radius:12px; border:2px solid ${kayitli ? '#10b981' : '#f59e0b'}; background:${kayitli ? 'rgba(6, 78, 59, 0.48)' : 'rgba(120, 53, 15, 0.48)'};`
      });

      mkKutu.append(
        oge('div', {
          style: `font-size:1.12rem; font-weight:900; color:${kayitli ? '#34d399' : '#fde047'}; margin-bottom:6px;`,
          textContent: mk.rozet || (kayitli ? '🟢 SİSTEMDE KAYITLI MÜŞTERİ' : '⛔ SİSTEMDE KAYITLI MÜŞTERİ DEĞİL!')
        }),
        oge('div', {
          style: 'font-size:0.92rem; color:#f8fafc; line-height:1.5;',
          textContent: kayitli
            ? `👤 Müşteri No: ${mk.musteriId}  ·  📞 Tel: ${mk.telefon || '—'}  ·  📍 ${mk.sehirIlce || '—'}`
            : (mk.aciklama || 'Bu kişi ana müşteri veritabanında kayıtlı değil. Kargo çıkışı için telefon ve adres bilgisi gereklidir.')
        })
      );

      if (kayitli && mk.adres) {
        mkKutu.append(oge('div', {
          style: 'font-size:0.86rem; color:#a7f3d0; margin-top:4px; font-weight:600;',
          textContent: `🏠 Kargo Adresi: ${mk.adres}`
        }));
      }

      if (!kayitli) {
        const formSatir = oge('div', {
          style: 'display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; align-items:center;'
        });
        const inpTel = oge('input', {
          type: 'text',
          placeholder: '📞 Telefon (05xx...)',
          value: mk.telefon || '',
          style: 'padding:8px 10px; border-radius:8px; border:1px solid #f59e0b; background:#020617; color:#fff; font:inherit; width:165px;'
        });
        const inpSehir = oge('input', {
          type: 'text',
          placeholder: '📍 Şehir / İlçe',
          value: mk.sehirIlce || 'İstanbul',
          style: 'padding:8px 10px; border-radius:8px; border:1px solid #f59e0b; background:#020617; color:#fff; font:inherit; width:145px;'
        });
        const inpAdres = oge('input', {
          type: 'text',
          placeholder: '🏠 Açık Kargo Adresi (Mahalle, Sokak, No)',
          value: mk.adres || '',
          style: 'flex:1; min-width:220px; padding:8px 10px; border-radius:8px; border:1px solid #f59e0b; background:#020617; color:#fff; font:inherit;'
        });
        const btnKaydet = oge('button', {
          type: 'button',
          style: 'background:#059669; border:1px solid #34d399; color:#fff; padding:8px 14px; border-radius:8px; font-weight:800;',
          textContent: '💾 Hemen Müşteri Olarak Kaydet'
        });
        btnKaydet.onclick = async () => {
          const r = await post('/api/musteri/hizli-kaydet', {
            barkod: s ? (s.siparisNo || s.barkod) : c.kod,
            adSoyad: mk.adSoyad || (s && s.musteri) || '',
            telefon: inpTel.value.trim(),
            sehir: inpSehir.value.trim(),
            adres: inpAdres.value.trim()
          });
          if (r && r.success) {
            bip(true);
            await koduOkut(s ? (s.siparisNo || s.barkod) : c.kod);
          } else {
            alert(r?.error || 'Lütfen telefon ve açık adres girin.');
          }
        };
        formSatir.append(inpTel, inpSehir, inpAdres, btnKaydet);
        mkKutu.append(formSatir);
      }

      parcalar.push(mkKutu);
    }

    if (s && (c.sonuc === 'TAMAM' || c.sonuc === 'URUN_STOK')) {
      const hedefKod = encodeURIComponent(s.siparisNo || s.barkod || c.kod || '');
      const otoFotoKutu = oge('div', {
        id: 'oto-foto-durum-kutu',
        style: 'margin-top:12px; padding:12px; border-radius:12px; background:rgba(2,6,23,0.65); border:2px solid #34d399; display:flex; align-items:center; gap:14px; flex-wrap:wrap;'
      },
        oge('span', { style: 'font-weight:800; color:#a7f3d0;', textContent: '📸 Termal barkod okundu — ürün fotoğrafı otomatik çekilip kaydediliyor…' })
      );
      parcalar.push(otoFotoKutu);
      const fotoLink = oge('a', {
        href: `/poset-foto.html?kod=${hedefKod}`,
        className: 'poset-foto-gecis-btn',
        textContent: `📸 2. SAYFA: POŞETLENEN ÜRÜN FOTOĞRAFLARI ARŞİVİNİ AÇ (${s.siparisNo || c.kod}) ➔`
      });
      parcalar.push(oge('div', {}, fotoLink));
    }
    if (s && c.sonuc === 'TAMAM') {
      const dugmeler = oge('div', { className: 's-dugmeler' }, oge('span', { textContent: 'Elinizdeki ürün tutmuyor mu?' }));
      [['KISI', 'Yanlış kişi'], ['BEDEN', 'Yanlış beden'], ['URUN', 'Yanlış ürün'], ['DIGER', 'Başka hata']].forEach(([neden, yazi]) => {
        const b = oge('button', { type: 'button', className: 'yanlis', textContent: yazi });
        b.onclick = async () => {
          const not = neden === 'DIGER' ? (prompt('Kısaca ne yanlış?') || '') : '';
          const r = await post('/api/etiket/hatali', { orderId: s.orderId, neden, not });
          kutu.querySelector('.s-dugmeler').replaceChildren(oge('span', { textContent: r.success ? '📝 Kaydedildi. Ürünü poşete koymayın, asistana gösterin.' : (r.error || 'Kaydedilemedi.') }));
          ozetiYenile();
          $('kod').focus();
        };
        dugmeler.append(b);
      });
      parcalar.push(dugmeler);
    }
    kutu.replaceChildren(...parcalar);
  }

  // Termal barkod okunduğu anda kameradan (veya görselden/otomatik kanıt şablonundan) ürün fotoğrafını çekip kaydeder
  function kanitFiligraniOlustur(kaynakEl, siparisBilgi) {
    const c = document.createElement('canvas');
    c.width = 960;
    c.height = 680;
    const ctx = c.getContext('2d');

    if (kaynakEl) {
      ctx.drawImage(kaynakEl, 0, 0, c.width, c.height);
    } else {
      const bgGrad = ctx.createLinearGradient(0, 0, 960, 680);
      bgGrad.addColorStop(0, '#1e293b');
      bgGrad.addColorStop(1, '#0f172a');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, 960, 680);

      ctx.fillStyle = '#334155';
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.roundRect(190, 75, 580, 465, 26);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#1e3a5f';
      ctx.beginPath();
      ctx.roundRect(235, 115, 490, 205, 16);
      ctx.fill();
      ctx.fillStyle = '#e2e8f0';
      ctx.font = 'bold 23px "Segoe UI", system-ui, sans-serif';
      ctx.fillText('🛍️ POŞETLENEN ÜRÜN & TERMAL ETİKET', 255, 170);
      ctx.fillStyle = '#7dd3fc';
      ctx.font = 'bold 20px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(String(siparisBilgi.urun || 'Ürün').slice(0, 42), 255, 218);
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 18px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(`✓ Beden/Raf: ${siparisBilgi.beden || 'Standart'} · RAF ${siparisBilgi.raf || 'DEPO'}`, 255, 268);

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(275, 345, 410, 170, 10);
      ctx.fill();
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 22px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(`MÜŞTERİ: ${siparisBilgi.musteri || ''}`, 295, 382);
      ctx.font = '600 16px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(String(siparisBilgi.urun || '').slice(0, 38), 295, 410);
      let bx = 295;
      for (let i = 0; i < 42; i++) {
        const w = (i % 3 === 0) ? 5 : ((i % 2 === 0) ? 3 : 2);
        ctx.fillRect(bx, 424, w, 50);
        bx += w + ((i % 4 === 0) ? 4 : 3);
      }
      ctx.font = 'bold 18px monospace';
      ctx.fillText(siparisBilgi.barkod || '', 390, 498);
    }

    // Üst sol rozet
    ctx.fillStyle = 'rgba(5, 46, 31, 0.9)';
    ctx.fillRect(16, 16, 440, 42);
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.strokeRect(16, 16, 440, 42);
    ctx.fillStyle = '#34d399';
    ctx.font = 'bold 17px "Segoe UI", system-ui, sans-serif';
    ctx.fillText('📸 TERMAL BARKOD OKUNDU · OTOMATİK POŞET KANITI', 28, 43);

    // Alt bilgi şeridi
    const seritH = 108;
    const seritY = c.height - seritH;
    ctx.fillStyle = 'rgba(2, 6, 23, 0.9)';
    ctx.fillRect(0, seritY, c.width, seritH);
    ctx.fillStyle = '#10b981';
    ctx.fillRect(0, seritY, c.width, 4);

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 24px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(`BARKOD: ${siparisBilgi.barkod}   ·   MÜŞTERİ: ${siparisBilgi.musteri}`, 22, seritY + 36);

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 19px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(`ÜRÜN: ${String(siparisBilgi.urun || '').slice(0, 56)} (${siparisBilgi.beden || 'Standart'})`, 22, seritY + 66);

    ctx.fillStyle = siparisBilgi.musteriKayitliMi === false ? '#fde047' : '#a7f3d0';
    ctx.font = 'bold 16px "Segoe UI", system-ui, sans-serif';
    const kayitEtiket = siparisBilgi.musteriKayitliMi === false
      ? '⚠️ KAYITSIZ MÜŞTERİ (ADRES EKSİK)'
      : `🟢 KAYITLI MÜŞTERİ (${siparisBilgi.telefon || 'Doğrulandı'})`;
    ctx.fillText(`📅 ${new Date().toLocaleString('tr-TR')}  |  ${kayitEtiket}  |  RAF: ${siparisBilgi.raf || 'DEPO'}`, 22, seritY + 94);

    return c.toDataURL('image/jpeg', 0.88);
  }

  async function otomatikUrunFotosuCekVeKaydet(c, gorselKaynak = null) {
    if (!c || !c.siparis || (c.sonuc !== 'TAMAM' && c.sonuc !== 'URUN_STOK')) return;
    const s = c.siparis;
    const mk = c.musteriKayit || s.musteriKayit || null;
    const barkod = s.siparisNo || s.barkod || c.kod;
    const video = $('barkod-video');
    const canliVideoHazir = video && kameraAkisi && video.readyState >= 2 && video.videoWidth > 0;
    const kaynak = gorselKaynak || (canliVideoHazir ? video : null);

    // Kamera vizörü açıksa beyaz deklanşör flaşı efekti göster
    const vizor = $('barkod-vizor');
    if (vizor && vizor.classList.contains('acik')) {
      vizor.style.boxShadow = '0 0 45px 15px rgba(255,255,255,0.95)';
      setTimeout(() => { vizor.style.boxShadow = ''; }, 260);
    }

    const dataUrl = kanitFiligraniOlustur(kaynak, {
      barkod,
      musteri: s.musteri || 'Müşteri',
      urun: s.urun || 'Ürün',
      beden: s.beden || '',
      raf: s.raf || 'DEPO',
      musteriKayitliMi: mk ? mk.kayitliMi : true,
      telefon: mk ? mk.telefon : ''
    });

    try {
      const r = await post('/api/poset-foto/kaydet', {
        barkod,
        siparisNo: barkod,
        musteri: s.musteri || '',
        urun: s.urun || '',
        beden: s.beden || '',
        raf: s.raf || 'DEPO',
        personel: localStorage.getItem('urun_girisi_ad') || 'Otomatik Kamera',
        gorselVeri: dataUrl
      });
      const kutu = $('oto-foto-durum-kutu');
      if (kutu && r && r.success && r.kayit) {
        kutu.replaceChildren(
          oge('img', {
            src: r.kayit.gorselUrl,
            alt: barkod,
            style: 'width:155px; height:108px; object-fit:cover; border-radius:8px; border:2px solid #34d399; cursor:pointer;',
            onclick: () => { window.location.href = `/poset-foto.html?kod=${encodeURIComponent(barkod)}`; }
          }),
          oge('div', { style: 'flex:1; min-width:200px;' },
            oge('div', { style: 'font-size:1.05rem; font-weight:900; color:#34d399;', textContent: '📸 ÜRÜN & POŞET FOTOĞRAFI OTOMATİK ÇEKİLDİ VE KAYDEDİLDİ!' }),
            oge('div', { style: 'font-size:0.86rem; color:#e2e8f0; margin-top:4px;', textContent: `Kayıt No: ${r.kayit.id} · Saat: ${r.kayit.tarihSaat} · 2. Sayfa (Poşet Fotoğrafları Arşivi) içine eklendi.` })
          )
        );
      }
      ozetiYenile();
    } catch (_) {}
  }

  async function koduOkut(dogrudanKod, gorselKaynak = null) {
    const kod = String(dogrudanKod !== undefined ? dogrudanKod : ($('kod') ? $('kod').value : '')).trim();
    if ($('kod')) {
      $('kod').value = '';
      if (document.activeElement === $('kod')) $('kod').blur();
    }
    if (!kod) {
      // Kutu boşsa klavyeyi AÇMA; doğrudan açık kameradan barkodu oku veya kamerayı başlat!
      const video = $('barkod-video');
      if (kameraAkisi && video && video.readyState >= 2) {
        const okundu = await kaynakGoruntudenBarkodCoz(video, true);
        if (!okundu) {
          sonucuGoster({
            sonuc: 'BULUNAMADI',
            mesaj: 'Kameradaki görüntüde barkod seçilemedi. Barkodu kırmızı çizgiye yaklaştırıp tekrar basın.'
          });
        }
      } else {
        await kamerayiAc();
      }
      return;
    }
    let c;
    try {
      c = await post('/api/etiket/okut', { kod });
    } catch (err) {
      c = { sonuc: 'BULUNAMADI', mesaj: 'Sunucuya ulaşılamadı. Tekrar okutun.' };
    }
    const basarili = (c.sonuc === 'TAMAM' || c.sonuc === 'URUN_STOK') && !c.oncekiOkutma;
    bip(basarili);
    sonucuGoster(c);
    if (c.sonuc === 'TAMAM' || c.sonuc === 'URUN_STOK') {
      otomatikUrunFotosuCekVeKaydet(c, gorselKaynak);
    }
    const yeniKayit = {
      zaman: new Date().toLocaleTimeString('tr-TR'),
      kod: c.kod || kod,
      sonuc: c.sonuc,
      ad: c.siparis ? `${c.siparis.musteri}${c.siparis.beden ? ` · ${c.siparis.beden}` : ''}` : (c.mesaj || ''),
      urun: c.siparis ? (c.siparis.urun || '') : '',
      raf: c.siparis ? (c.siparis.raf || '') : ''
    };
    son = [yeniKayit, ...son.filter(x => x.kod !== yeniKayit.kod)].slice(0, 25);
    try { localStorage.setItem('mezat_son_okutulanlar_v1', JSON.stringify(son)); } catch (_) {}
    sonListesiniCiz();
    ozetiYenile();
  }

  function okut() {
    return koduOkut();
  }

  async function ozetiYenile() {
    try {
      const o = await fetch('/api/etiket/okutma-ozeti').then(r => r.json());
      const kutu = (ad, sayi, kotu) => oge('span', { className: kotu ? 'kotu' : '' }, `${ad}: `, oge('b', { textContent: String(sayi) }));
      $('sayac').replaceChildren(
        kutu('Basılan', o.gonderilen),
        kutu('Okutulan', o.okunan),
        kutu('Poşeti Fotoğraflanan', o.fotograflanan || 0),
        kutu('Okutulmayan', o.okutulmayan.length, o.okutulmayan.length > 0),
        kutu('Yanlış bildirilen', o.hataliSayisi, o.hataliSayisi > 0));
      const bos = yazi => oge('div', { className: 'bos', textContent: yazi });

      // Sekme sayaç rozetlerini güncelle
      const bekleyenToplam = (o.okutulmayan ? o.okutulmayan.length : 0) + (o.hataliSayisi || 0);
      const rozetBekleyen = $('rozet-bekleyen-sayi');
      if (rozetBekleyen) {
        rozetBekleyen.textContent = String(bekleyenToplam);
        rozetBekleyen.style.display = bekleyenToplam > 0 ? 'inline-block' : 'none';
      }

      // Sunucudan gelen sonOkutulanlar listesini yerel geçmişle birleştir
      if (Array.isArray(o.sonOkutulanlar) && o.sonOkutulanlar.length > 0) {
        const birlesik = [...son];
        o.sonOkutulanlar.forEach(sk => {
          if (sk && sk.kod && !birlesik.some(x => x.kod === sk.kod)) {
            birlesik.push(sk);
          }
        });
        son = birlesik.slice(0, 25);
        try { localStorage.setItem('mezat_son_okutulanlar_v1', JSON.stringify(son)); } catch (_) {}
      }
      sonListesiniCiz();

      // Basıldı ama henüz okutulmadı listesi (her satırda Hemen Okut düğmesi)
      $('okutulmayan').replaceChildren(...(o.okutulmayan.length
        ? o.okutulmayan.map(v => {
            const btn = oge('button', { type: 'button', className: 'hemen-okut-btn', textContent: `🔎 Hemen Okut (${v.siparisNo})` });
            btn.onclick = () => koduOkut(v.siparisNo);
            return oge('div', { className: 'liste-oge' },
              oge('span', { textContent: `${v.siparisNo} · ${v.musteri}${v.beden ? ` · ${v.beden}` : ''} · ${v.urun || ''}` }),
              oge('div', { style: 'display:flex; align-items:center; gap:10px;' },
                oge('b', { style: 'color:#7dd3fc;', textContent: `RAF ${v.raf}` }),
                btn));
          })
        : [bos('Basılan her etiket okutuldu.')]));

      $('hatali').replaceChildren(...(o.hatali.length
        ? o.hatali.map(v => oge('div', { className: 'liste-oge hata' },
            oge('span', { textContent: `${v.siparisNo} · ${v.musteri}${v.beden ? ` · ${v.beden}` : ''}` }),
            oge('b', { textContent: v.hatalar.map(h => h.ad + (h.not ? `: ${h.not}` : '')).join(', ') })))
        : [bos('Yanlış etiket bildirilmedi.')]));

      // Hızlı Test & Canlı Barkod Kartları
      const hazirKutu = $('hazir-barkodlar');
      if (hazirKutu) {
        const cipler = [];
        // 1. Basılmış ve okutulmayı bekleyen siparişler
        (o.okutulmayan || []).forEach(v => {
          const mk = v.musteriKayit;
          const kayitYazi = mk ? (mk.kayitliMi ? '🟢 Kayıtlı Müşteri' : '⚠️ Kayıtsız Müşteri') : 'Sipariş';
          const cip = oge('button', { type: 'button', className: `barkod-cip ${mk && !mk.kayitliMi ? 'bekleyen-cip' : 'siparis-cip'}`, title: 'Tıklayarak bu sipariş etiketini hemen okutun ve müşteri kaydını kontrol edin' },
            oge('span', { textContent: `${kayitYazi}:` }),
            oge('code', { textContent: v.siparisNo }),
            oge('span', { textContent: `${v.musteri}${v.beden ? ` (${v.beden})` : ''} · RAF ${v.raf}` }));
          cip.onclick = () => koduOkut(v.siparisNo);
          cipler.push(cip);
        });
        // 2. Kuyrukta basılmayı bekleyen siparişler (Basıldı Say & Okut)
        (o.bekleyenEtiketler || []).forEach(v => {
          const cip = oge('button', { type: 'button', className: 'barkod-cip bekleyen-cip', title: 'Yazıcıya gönderildi olarak işaretleyip hemen okut' },
            oge('span', { textContent: '🖨️ Kuyrukta:' }),
            oge('code', { textContent: v.siparisNo }),
            oge('span', { textContent: `${v.musteri}${v.beden ? ` (${v.beden})` : ''} (Basıldı Say & Okut)` }));
          cip.onclick = async () => {
            await post('/api/etiket/gonderildi', { orderId: v.orderId });
            await koduOkut(v.siparisNo);
          };
          cipler.push(cip);
        });
        // 3. Envanter Ürün Barkodları (MZU-0001 vb.)
        (o.urunBarkodlari || []).forEach(u => {
          const cip = oge('button', { type: 'button', className: 'barkod-cip', title: 'Envanter ürün barkodunu okut ve doğrula' },
            oge('span', { textContent: '📦 Ürün:' }),
            oge('code', { textContent: u.barkod }),
            oge('span', { textContent: `${u.urun} (${u.fiyat} TL)` }));
          cip.onclick = () => koduOkut(u.barkod);
          cipler.push(cip);
        });
        if (cipler.length === 0) {
          ['MZU-0001', 'MZU-0002', 'MZ-2026-0001'].forEach(ornekKod => {
            const cip = oge('button', { type: 'button', className: 'barkod-cip' },
              oge('span', { textContent: '⚡ Test Barkodu:' }),
              oge('code', { textContent: ornekKod }));
            cip.onclick = () => koduOkut(ornekKod);
            cipler.push(cip);
          });
        }
        const rozetHazir = $('rozet-hazir-sayi');
        if (rozetHazir) {
          rozetHazir.textContent = String(cipler.length);
          rozetHazir.style.display = cipler.length > 0 ? 'inline-block' : 'none';
        }
        hazirKutu.replaceChildren(...cipler);
        const hazirTamKutu = $('hazir-barkodlar-tam');
        if (hazirTamKutu) {
          hazirTamKutu.replaceChildren(...cipler.map(c => {
            const kopya = c.cloneNode(true);
            kopya.onclick = c.onclick;
            return kopya;
          }));
        }
      }
    } catch (err) {}
  }

  // Kamera ile canlı barkod okutma (Sayfa açılır açılmaz otomatik başlar, klavyeyi ASLA kendiliğinden açmaz)
  let kameraAkisi = null;
  let taramaDongusu = null;
  let ocrTaramaDongusu = null;
  let ocrTaramaMesgul = false;
  let sonOkunanKod = '';
  let sonOkumaMs = 0;
  let aktifKameraYonu = 'environment';

  function kamerayiKapat() {
    if (taramaDongusu) { clearInterval(taramaDongusu); taramaDongusu = null; }
    if (ocrTaramaDongusu) { clearInterval(ocrTaramaDongusu); ocrTaramaDongusu = null; }
    if (kameraAkisi) { kameraAkisi.getTracks().forEach(t => t.stop()); kameraAkisi = null; }
    const vizor = $('barkod-vizor');
    if (vizor) vizor.classList.remove('acik');
    const btn = $('kamera-ac');
    if (btn) {
      btn.textContent = '📷 Kamerayı Aç';
      btn.classList.remove('aktif');
    }
  }

  function gecerliBarkodSec(adaylar) {
    if (window.MezatBarkod && typeof window.MezatBarkod.barkodSec === 'function') {
      return window.MezatBarkod.barkodSec(adaylar);
    }
    for (const a of (adaylar || [])) {
      const k = String(typeof a === 'string' ? a : (a && a.rawValue ? a.rawValue : '')).trim().toUpperCase();
      if (k && !/^(?:HTTPS?:\/\/|WWW\.)/i.test(k) && !/\.(?:COM|NET|ORG|TR|LINK|PAGE\.LINK)\b/i.test(k)) return k;
    }
    return '';
  }

  async function kaynakGoruntudenBarkodCoz(kaynakEl, manuelTetik = false) {
    if (!kaynakEl) return false;
    if (!manuelTetik && (Date.now() - sonOkumaMs) < 3500) return false;
    try {
      // 1) BarcodeDetector varsa dene (Web URL QR kodlarını filtrele)
      if ('BarcodeDetector' in window) {
        try {
          const okuyucu = new window.BarcodeDetector({
            formats: ['code_128', 'code_39', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'qr_code']
          });
          const bulunanlar = await okuyucu.detect(kaynakEl);
          const okunan = gecerliBarkodSec(bulunanlar);
          if (okunan) {
            const simdi = Date.now();
            if (manuelTetik || (simdi - sonOkumaMs) >= 3500 && (okunan !== sonOkunanKod || (simdi - sonOkumaMs) >= 5000)) {
              sonOkunanKod = okunan;
              sonOkumaMs = simdi;
              await koduOkut(okunan, kaynakEl);
              return true;
            }
          }
        } catch (_) {}
      }
      // 2) Saf JS Code-128 1D (360° çok açılı) tarayıcı
      if (window.MezatBarkod && typeof window.MezatBarkod.goruntudenOku === 'function') {
        const jsKod = window.MezatBarkod.goruntudenOku(kaynakEl);
        if (jsKod) {
          const simdi = Date.now();
          if (manuelTetik || (simdi - sonOkumaMs) >= 3500 && (jsKod !== sonOkunanKod || (simdi - sonOkumaMs) >= 5000)) {
            sonOkunanKod = jsKod;
            sonOkumaMs = simdi;
            await koduOkut(jsKod, kaynakEl);
            return true;
          }
        }
      }
      // 3) Sunucu OCR & Barkod çözücü (/api/kamera/barkod-ocr)
      if (ocrTaramaMesgul && !manuelTetik) return false;
      ocrTaramaMesgul = true;
      const w = kaynakEl.videoWidth || kaynakEl.width || 640;
      const h = kaynakEl.videoHeight || kaynakEl.height || 480;
      if (!w || !h) { ocrTaramaMesgul = false; return false; }
      const oran = Math.min(1, 960 / Math.max(w, h));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(w * oran));
      c.height = Math.max(1, Math.round(h * oran));
      c.getContext('2d').drawImage(kaynakEl, 0, 0, c.width, c.height);
      const gorsel = c.toDataURL('image/jpeg', 0.84);
      const r = await post('/api/kamera/barkod-ocr', { gorsel, otomatikOkut: false });
      ocrTaramaMesgul = false;
      const ocrKod = r && r.bulunanKod ? gecerliBarkodSec([r.bulunanKod]) : '';
      if (ocrKod) {
        const simdi = Date.now();
        if (manuelTetik || ocrKod !== sonOkunanKod || (simdi - sonOkumaMs) >= 3500) {
          sonOkunanKod = ocrKod;
          sonOkumaMs = simdi;
          await koduOkut(ocrKod, c);
          return true;
        }
      }
    } catch (_) {
      ocrTaramaMesgul = false;
    }
    return false;
  }

  async function kamerayiAc(zorlaAc = true) {
    if (!zorlaAc && kameraAkisi) {
      kamerayiKapat();
      return;
    }
    if (taramaDongusu) { clearInterval(taramaDongusu); taramaDongusu = null; }
    if (ocrTaramaDongusu) { clearInterval(ocrTaramaDongusu); ocrTaramaDongusu = null; }
    if (kameraAkisi) { kameraAkisi.getTracks().forEach(t => t.stop()); kameraAkisi = null; }

    gorunumDegistir('okut');
    const vizor = $('barkod-vizor');
    const video = $('barkod-video');
    const mesajEl = $('kamera-mesaj');
    const btn = $('kamera-ac');
    const rozetEl = $('vizor-durum-rozet');

    if (vizor) vizor.classList.add('acik');

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      if (vizor && mesajEl) {
        video.style.display = 'none';
        mesajEl.style.display = 'block';
        mesajEl.textContent = '📷 Kamera erişimi için üstteki "🖼️ Galeri" düğmesine basarak barkod fotoğrafı seçebilir veya hazır barkod çiplerine dokunabilirsiniz.';
      }
      return;
    }

    try {
      kameraAkisi = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: aktifKameraYonu }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      });
      video.style.display = 'block';
      if (mesajEl) mesajEl.style.display = 'none';
      video.srcObject = kameraAkisi;
      await video.play();
      if (vizor) vizor.classList.add('acik');
      if (rozetEl) {
        rozetEl.innerHTML = `<span class="canli-nokta"></span><span>${aktifKameraYonu === 'environment' ? 'ARKA KAMERA · BARKOD OKUYUCU AÇIK' : 'ÖN KAMERA · BARKOD OKUYUCU AÇIK'}</span>`;
      }
      if (btn) {
        btn.textContent = '📷 Kamera Açık';
        btn.classList.add('aktif');
      }
      let okuyucu = null;
      if ('BarcodeDetector' in window) {
        try {
          okuyucu = new window.BarcodeDetector({
            formats: ['code_128', 'code_39', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'qr_code']
          });
        } catch (_) {}
      }
      taramaDongusu = setInterval(async () => {
        if (!video || video.readyState < 2) return;
        try {
          if (okuyucu) {
            const bulunanlar = await okuyucu.detect(video);
            const okunan = gecerliBarkodSec(bulunanlar);
            if (okunan) {
              const simdi = Date.now();
              if (okunan === sonOkunanKod && (simdi - sonOkumaMs) < 3500) return;
              sonOkunanKod = okunan;
              sonOkumaMs = simdi;
              await koduOkut(okunan, video);
              return;
            }
          }
          if (window.MezatBarkod && typeof window.MezatBarkod.goruntudenOku === 'function') {
            const jsOkunan = window.MezatBarkod.goruntudenOku(video);
            if (jsOkunan) {
              const simdi = Date.now();
              if (jsOkunan === sonOkunanKod && (simdi - sonOkumaMs) < 3500) return;
              sonOkunanKod = jsOkunan;
              sonOkumaMs = simdi;
              await koduOkut(jsOkunan, video);
            }
          }
        } catch (e) {}
      }, 250);
      ocrTaramaDongusu = setInterval(() => {
        if (!video || video.readyState < 2) return;
        kaynakGoruntudenBarkodCoz(video, false);
      }, 1100);
    } catch (err) {
      if (vizor && mesajEl) {
        video.style.display = 'none';
        mesajEl.style.display = 'block';
        mesajEl.innerHTML = '';
        mesajEl.append(
          oge('div', { style: 'font-weight:800; color:#fde68a; margin-bottom:4px;', textContent: '📷 Kamera başlatılamadı veya izin bekleniyor.' }),
          oge('div', { style: 'color:#cbd5e1; font-size:0.78rem;', textContent: 'Tekrar başlatmak için "📷 Kamera" tuşuna veya galeriden seçmek için "🖼️ Galeri" tuşuna basın.' })
        );
        vizor.classList.add('acik');
        if (btn) { btn.textContent = '📷 Kamerayı Başlat'; btn.classList.remove('aktif'); }
      }
    }
  }

  async function kamerayiAcVeyaKapat() {
    if (kameraAkisi) {
      kamerayiKapat();
    } else {
      await kamerayiAc(true);
    }
  }

  // Barkod fotoğrafından / görselinden okutma (BarcodeDetector + Saf JS Code-128 + Sunucu OCR)
  async function gorseldenBarkodOkut(dosya) {
    if (!dosya) return;
    try {
      const bmp = await createImageBitmap(dosya);
      const cozuldu = await kaynakGoruntudenBarkodCoz(bmp, true);
      if (cozuldu) return;
      const adEslesme = String(dosya.name || '').toUpperCase().match(/(MZ-\d{4}-\d{4}|MZU-[A-Z0-9-]+)/);
      if (adEslesme) {
        await koduOkut(adEslesme[1], bmp);
        return;
      }
      sonucuGoster({
        sonuc: 'BULUNAMADI',
        mesaj: 'Seçilen görselde barkod tespit edilemedi. Lütfen barkodun veya sipariş numarasının net göründüğü bir fotoğraf seçin.'
      });
    } catch (err) {
      sonucuGoster({
        sonuc: 'BULUNAMADI',
        mesaj: 'Görsel okunamadı: ' + (err.message || err)
      });
    }
  }

  if ($('btn-kamera-anlik-oku')) {
    $('btn-kamera-anlik-oku').onclick = async () => {
      const video = $('barkod-video');
      if (kameraAkisi && video && video.readyState >= 2) {
        const okundu = await kaynakGoruntudenBarkodCoz(video, true);
        if (!okundu) {
          sonucuGoster({
            sonuc: 'BULUNAMADI',
            mesaj: 'Kameradaki karede barkod veya sipariş numarası seçilemedi. Etiketi kırmızı lazer çizgisine yaklaştırıp tekrar basın.'
          });
        }
      } else {
        await kamerayiAc(true);
      }
    };
  }
  if ($('btn-kamera-yon-degistir')) {
    $('btn-kamera-yon-degistir').onclick = async () => {
      aktifKameraYonu = aktifKameraYonu === 'environment' ? 'user' : 'environment';
      await kamerayiAc(true);
    };
  }
  if ($('btn-son-temizle')) {
    $('btn-son-temizle').onclick = () => ozetiYenile();
  }

  if ($('kamera-ac')) $('kamera-ac').onclick = kamerayiAcVeyaKapat;
  if ($('barkod-dosya')) {
    $('barkod-dosya').onchange = e => {
      const f = e.target.files && e.target.files[0];
      if (f) gorseldenBarkodOkut(f);
      e.target.value = '';
    };
  }

  if ($('kod')) {
    $('kod').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); okut(); } });
    $('kod').addEventListener('focus', saatiGuncelle);
    $('kod').addEventListener('blur', saatiGuncelle);
  }
  if ($('okut')) $('okut').onclick = okut;

  // Kablosuz / USB Lazer Barkod Okuyucu Desteği (Klavyeyi açmadan arka planda okur!)
  let okuyucuTamponu = '';
  let okuyucuZamanlayici = null;
  window.addEventListener('keydown', e => {
    if (document.activeElement === $('kod')) return;
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    if (e.key === 'Enter') {
      if (okuyucuTamponu.trim().length >= 3) {
        e.preventDefault();
        const okunan = okuyucuTamponu.trim();
        okuyucuTamponu = '';
        koduOkut(okunan);
      }
      return;
    }
    if (e.key && e.key.length === 1) {
      okuyucuTamponu += e.key;
      clearTimeout(okuyucuZamanlayici);
      okuyucuZamanlayici = setTimeout(() => { okuyucuTamponu = ''; }, 1200);
    }
  });

  try {
    const sse = new EventSource('/api/events');
    sse.addEventListener('etiket_kuyrugu', ozetiYenile);
    sse.onopen = () => {
      const d = $('canli-durum-metin');
      if (d) d.textContent = '📷 CANLI BARKOD KAMERASI AÇIK · Barkodu Kameraya Tutun';
    };
  } catch (err) {}

  sonListesiniCiz();
  setInterval(ozetiYenile, 4000);
  ozetiYenile();
  // Sayfa açılır açılmaz canlı barkod kamerasını otomatik başlat
  setTimeout(() => { kamerayiAc(true); }, 120);
})();
