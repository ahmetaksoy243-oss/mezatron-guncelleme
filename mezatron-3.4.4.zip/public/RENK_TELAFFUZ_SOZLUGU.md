# 🎨 Mezatron Evrensel Renk, Ton & Desen Telaffuz Sözlüğü

Bu dosya, depoda veya canlı yayında söylenen **Türkçe, İngilizce, Fransızca tekstil renklerini, ara tonları, çift renkleri ve desenleri**; konuşan kişinin aksanından veya ses tanıma motorunun (Whisper / WebSpeech) yanlış hecelemesinden etkilenmeden **%100 doğru standart renge** çevirmek için hazırlanmıştır.

> **Nasıl Çalışır?**
> Hem **Sesli Envanter Asistanı (Port 3002)** hem **Canlı Yayın Satış Sistemi (Port 3001)** hem de **Bağımsız Cep Telefonu Modu** bu `.md` tablosunu otomatik olarak okur. Uzun tamlamalar (ör. `YEŞİL ÇİZGİLİ`, `YEŞİL GRİ`, `GÜL KURUSU`, `SAKS MAVİSİ`) tek kelimeli renklerden önce eşleştirilir.

---

## 1. Ana Renkler ve Ses Motoru (Whisper) Telaffuz Yanılgıları

| Standart Renk Adı | Söylenişler, Yabancı Karşılıklar ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **SİYAH** | siyah, siyahi, siya, genç ya, genç siyah, cenk siyah, ren siyah, renk siya, black, blek, blak | Ana Renk |
| **BEYAZ** | beyaz, beyas, bayaz, bembeyaz, white, vayt | Ana Renk |
| **GRİ** | gri, gıri, giri, kriği, krigi, krii, jengri, rengri, cenk gri, ren gri, grey, gray, gırey | Ana Renk |
| **LACİVERT** | lacivert, lacivet, laci, laçivert, navy, neyvi, nevi, navy blue | Ana Renk |
| **MAVİ** | mavi, mavı, blue, blu | Ana Renk |
| **YEŞİL** | yeşil, yesil, yeşıl, green, grin, gırin | Ana Renk |
| **KIRMIZI** | kırmızı, kirmizi, kırmız, red | Ana Renk |
| **SARI** | sarı, sari, yellow, yelov | Ana Renk |
| **TURUNCU** | turuncu, oranj, orange, orınc | Ana Renk |
| **PEMBE** | pembe, penbe, pink | Ana Renk |
| **MOR** | mor, purple, pörpıl | Ana Renk |
| **KAHVERENGİ** | kahverengi, kahve rengi, kahve, kahferengi, brown, bıraun, braun | Ana Renk |

---

## 2. Tekstil Ara Tonları, Moda Renkleri ve Özel Tonlar

| Standart Renk Adı | Söylenişler, Yabancı Karşılıklar ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **EKRU** | ekru, ekrü, ecru, kırık beyaz, kirik beyaz, off white, of vayt | Açık & Doğal Tonlar |
| **KREM** | krem, kırem, cream, krim | Açık & Doğal Tonlar |
| **KEMİK** | kemik, kemik rengi, fildişi, fil dişi, ivory | Açık & Doğal Tonlar |
| **BEJ** | bej, beji, beige, beyj, kum beji, taş beji | Açık & Doğal Tonlar |
| **TAŞ RENGİ** | taş rengi, tas rengi, taş, stone | Açık & Doğal Tonlar |
| **NUDE** | nud, nüd, nude, ten rengi, cilt rengi | Açık & Doğal Tonlar |
| **ŞAMPANYA** | şampanya, sampanya, champagne | Açık & Doğal Tonlar |
| **VİZON** | vizon, vızon, vizyon, mink, taupe | Toprak & Sıcak Tonlar |
| **TABA** | taba, camel, kamel, kemıl, kemel | Toprak & Sıcak Tonlar |
| **TARÇIN** | tarçın, tarcın, tarçın rengi | Toprak & Sıcak Tonlar |
| **KİREMİT** | kiremit, kıremit, kiremit rengi, terracotta | Toprak & Sıcak Tonlar |
| **HARDAL** | hardal, hardal sarısı, mustard | Toprak & Sıcak Tonlar |
| **BORDO** | bordo, bordu, burgundy, börgındi, şarap rengi | Kırmızı & Pembe Tonları |
| **FUŞYA** | fuşya, fusya, fuşia, fuchsia, magenta, macenta | Kırmızı & Pembe Tonları |
| **PUDRA** | pudra, püdra, pudra pembesi, toz pembe | Kırmızı & Pembe Tonları |
| **GÜL KURUSU** | gül kurusu, gul kurusu, gülkurusu, dusty rose | Kırmızı & Pembe Tonları |
| **SOMON** | somon, samon, şeftali, peach, salmon | Kırmızı & Pembe Tonları |
| **MERCAN** | mercan, корал, coral, koral | Kırmızı & Pembe Tonları |
| **LİLA** | lila, lıla, leylak, lilac | Mor Tonları |
| **LAVANTA** | lavanta, lavender | Mor Tonları |
| **MÜRDÜM** | mürdüm, murdum, erik çürüğü, plum | Mor Tonları |
| **SAKS** | saks, saks mavisi, saksı mavisi, royal blue, elektrik mavisi | Mavi Tonları |
| **BEBE MAVİSİ** | bebe mavisi, bebek mavisi, baby blue | Mavi Tonları |
| **BUZ MAVİSİ** | buz mavisi, açık mavi, gök mavisi, sky blue, ice blue | Mavi Tonları |
| **İNDİGO** | indigo, ındigo, kot mavisi, denim mavisi | Mavi Tonları |
| **PETROL** | petrol, petrol mavisi, petrol yeşili, teal | Mavi & Yeşil Tonları |
| **TURKUAZ** | turkuaz, türkuaz, turkuvaz, cam göbeği, aqua | Mavi & Yeşil Tonları |
| **SU YEŞİLİ** | su yeşili, su yesili, mint, mint yeşili, nane yeşili | Yeşil Tonları |
| **HAKİ** | haki, hakı, khaki, kaki, asker yeşili | Yeşil Tonları |
| **ZEYTİN YEŞİLİ** | zeytin yeşili, zeytin yesili, yağ yeşili, yag yesili, olive | Yeşil Tonları |
| **ZÜMRÜT YEŞİLİ** | zümrüt yeşili, zumrut yesili, zümrüt, çağla yeşili, cagla yesili, fıstık yeşili | Yeşil Tonları |
| **ANTRASİT** | antrasit, antresit, antırasit, koyu gri, charcoal | Gri & Metalik Tonlar |
| **FÜME** | füme, fume, füma, duman gri, smoke | Gri & Metalik Tonlar |
| **MELANJ** | melanj, gri melanj, kırçıllı gri | Gri & Metalik Tonlar |
| **GOLD** | gold, altın, altın rengi, altın sarısı, dore | Gri & Metalik Tonlar |
| **GÜMÜŞ** | gümüş, gumus, silver, silvır, lame | Gri & Metalik Tonlar |
| **ROZE** | roze, rose gold, roz gold, bakır, bronz | Gri & Metalik Tonlar |

---

## 3. Çift Renkler, Çizgili ve Desenli Kombinasyonlar

| Standart Renk Adı | Söylenişler, Yabancı Karşılıklar ve Ses Motoru Yanılgıları | Kategori |
| :--- | :--- | :--- |
| **YEŞİL ÇİZGİLİ** | yeşil çizgili, yesil cizgili, çizgili yeşil, cizgili yesil | Çift Renk & Desen |
| **MAVİ ÇİZGİLİ** | mavi çizgili, mavi cizgili, çizgili mavi, cizgili mavi | Çift Renk & Desen |
| **SİYAH ÇİZGİLİ** | siyah çizgili, siyah cizgili, çizgili siyah, cizgili siyah | Çift Renk & Desen |
| **KIRMIZI ÇİZGİLİ** | kırmızı çizgili, kirmizi cizgili, çizgili kırmızı | Çift Renk & Desen |
| **LACİVERT ÇİZGİLİ** | lacivert çizgili, lacivert cizgili, çizgili lacivert | Çift Renk & Desen |
| **YEŞİL GRİ** | yeşil gri, yesil gri, gri yeşil, gri yesil | Çift Renk & Desen |
| **SİYAH BEYAZ** | siyah beyaz, beyaz siyah | Çift Renk & Desen |
| **SİYAH GRİ** | siyah gri, gri siyah | Çift Renk & Desen |
| **MAVİ BEYAZ** | mavi beyaz, beyaz mavi | Çift Renk & Desen |
| **LACİVERT BEYAZ** | lacivert beyaz, beyaz lacivert | Çift Renk & Desen |
| **ÇİZGİLİ** | çizgili, cizgili, şeritli, seritli, striped | Desen |
| **KARELİ** | kareli, ekose, ekoseli, pötikare, plaid | Desen |
| **LEOPAR** | leopar, leoparlı, leopar desenli, leopard | Desen |
| **ZEBRA** | zebra, zebre, zebra desenli | Desen |
| **PUANTİYELİ** | puantiyeli, puantiye, benekli, noktalı | Desen |
| **ÇİÇEKLİ** | çiçekli, cicekli, çiçek desenli, floral | Desen |
| **KAMUFLAJ** | kamuflaj, kamuflajlı, camo | Desen |
| **DESENLİ** | desenli, baskılı, baskili, batik, etnik desenli | Desen |
| **MUHTELİF** | muhtelif, karışık, karisik, çok renkli, cok renkli, rengarenk, asorti | Çoklu Renk |
