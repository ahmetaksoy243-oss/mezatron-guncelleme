// 2. Sayfa: Poşetlenen Ürün Fotoğraflama & Görsel Kanıt Arşivi
(function () {
  const $ = id => document.getElementById(id);
  const post = (yol, govde) =>
    fetch(yol, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(govde || {})
    }).then(r => r.json());

  let kameraAkisi = null;
  let barkodOtoTarama = null;
  let adayPosetListesi = [];

  // Canlı saat
  function saatiGuncelle() {
    if ($('canli-saat')) $('canli-saat').textContent = new Date().toLocaleTimeString('tr-TR');
  }
  setInterval(saatiGuncelle, 1000);
  saatiGuncelle();

  // Personel adını hatırla
  if ($('f-personel')) {
    $('f-personel').value = localStorage.getItem('urun_girisi_ad') || 'Depo Görevlisi';
    $('f-personel').addEventListener('input', () => {
      localStorage.setItem('urun_girisi_ad', $('f-personel').value.trim());
    });
  }

  // Deklanşör / onay sesi
  let sesCtx = null;
  function deklansorSesi(basarili = true) {
    try {
      sesCtx = sesCtx || new (window.AudioContext || window.webkitAudioContext)();
      const notalar = basarili ? [[880, 0, 0.08], [1318, 0.09, 0.14]] : [[220, 0, 0.22]];
      notalar.forEach(([hz, bas, sure]) => {
        const o = sesCtx.createOscillator();
        const g = sesCtx.createGain();
        o.type = basarili ? 'triangle' : 'square';
        o.frequency.value = hz;
        g.gain.setValueAtTime(0.2, sesCtx.currentTime + bas);
        g.gain.exponentialRampToValueAtTime(0.001, sesCtx.currentTime + bas + sure);
        o.connect(g).connect(sesCtx.destination);
        o.start(sesCtx.currentTime + bas);
        o.stop(sesCtx.currentTime + bas + sure);
      });
    } catch (_) {}
  }

  function durumGuncelle(metin, hata = false) {
    const el = $('durum-yazi');
    if (!el) return;
    el.textContent = metin;
    el.style.color = hata ? '#fca5a5' : '#ecfdf5';
  }

  function posetGorunumDegistir(hedef) {
    const g = hedef || 'cekim';
    document.body.setAttribute('data-gorunum', g);
    document.querySelectorAll('.alt-gorunum-btn[data-poset-gorunum]').forEach(btn => {
      btn.classList.toggle('aktif', btn.getAttribute('data-poset-gorunum') === g);
    });
  }
  document.querySelectorAll('[data-poset-gorunum]').forEach(btn => {
    btn.addEventListener('click', () => {
      posetGorunumDegistir(btn.getAttribute('data-poset-gorunum'));
    });
  });

  function posetBilgisiDoldur(p) {
    if (!p) return;
    posetGorunumDegistir('cekim');
    if ($('f-barkod')) $('f-barkod').value = p.barkod || p.siparisNo || '';
    if ($('f-musteri')) $('f-musteri').value = p.musteri || '';
    const urunTam = [p.urun, p.beden ? `(${p.beden})` : ''].filter(Boolean).join(' ');
    if ($('f-urun')) $('f-urun').value = urunTam || p.urun || '';
    durumGuncelle(`🎯 Seçili Poşet: ${p.barkod || p.siparisNo} · ${p.musteri || ''} — Şimdi poşetin fotoğrafını çekebilirsiniz.`);
  }

  // Barkod kutusunda Enter'a basılırsa veya barkod okutulursa otomatik sipariş bilgisini getir
  if ($('f-barkod')) {
    $('f-barkod').addEventListener('keydown', async e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const kod = $('f-barkod').value.trim();
        if (!kod) return;
        try {
          const c = await post('/api/etiket/okut', { kod });
          if (c && c.siparis) {
            posetBilgisiDoldur({
              barkod: c.kod || kod,
              musteri: c.siparis.musteri,
              urun: c.siparis.urun,
              beden: c.siparis.beden
            });
            deklansorSesi(true);
          }
        } catch (_) {}
      }
    });
  }

  // Fotoğrafın üzerine Tarih/Saat + Barkod + Müşteri + Ürün Kanıt Filigranı (Watermark) basar
  function kanitFiligraniBas(kaynakCanvasVeyaImg, genislik, yukseklik) {
    const c = document.createElement('canvas');
    c.width = genislik || 960;
    c.height = yukseklik || 680;
    const ctx = c.getContext('2d');

    ctx.drawImage(kaynakCanvasVeyaImg, 0, 0, c.width, c.height);

    const barkod = ($('f-barkod').value || 'GENEL-POSET').trim().toUpperCase();
    const musteri = ($('f-musteri').value || 'Depo Müşterisi').trim();
    const urun = ($('f-urun').value || 'Poşetlenen Ürün').trim();
    const personel = ($('f-personel').value || 'Depo Görevlisi').trim();
    const tarihSaat = new Date().toLocaleString('tr-TR');

    // Üst sol rozet
    ctx.fillStyle = 'rgba(5, 46, 31, 0.88)';
    ctx.fillRect(16, 16, 390, 42);
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.strokeRect(16, 16, 390, 42);
    ctx.fillStyle = '#34d399';
    ctx.font = 'bold 17px "Segoe UI", system-ui, sans-serif';
    ctx.fillText('🛡️ MEZATRON POŞET KANIT FOTOĞRAFI', 28, 43);

    // Alt bilgi şeridi
    const seritH = 108;
    const seritY = c.height - seritH;
    ctx.fillStyle = 'rgba(2, 6, 23, 0.88)';
    ctx.fillRect(0, seritY, c.width, seritH);
    ctx.fillStyle = '#10b981';
    ctx.fillRect(0, seritY, c.width, 4);

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 24px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(`BARKOD: ${barkod}   ·   MÜŞTERİ: ${musteri}`, 22, seritY + 36);

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 19px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(`ÜRÜN: ${urun.slice(0, 68)}`, 22, seritY + 66);

    ctx.fillStyle = '#a7f3d0';
    ctx.font = '600 16px "Segoe UI", system-ui, sans-serif';
    ctx.fillText(`📅 Çekim Zamanı: ${tarihSaat}   |   👤 Paketleyen: ${personel}`, 22, seritY + 94);

    return c.toDataURL('image/jpeg', 0.88);
  }

  async function fotografiSunucuyaKaydet(dataUrl) {
    const barkod = ($('f-barkod').value || 'GENEL-POSET').trim().toUpperCase();
    const musteri = ($('f-musteri').value || 'Depo Müşterisi').trim();
    const urun = ($('f-urun').value || 'Poşetlenen Ürün').trim();
    const personel = ($('f-personel').value || 'Depo Görevlisi').trim();

    durumGuncelle('⏳ Poşet fotoğrafı filigranlanıp kaydediliyor…');
    try {
      const r = await post('/api/poset-foto/kaydet', {
        barkod,
        siparisNo: barkod,
        musteri,
        urun,
        personel,
        gorselVeri: dataUrl
      });
      if (!r || !r.success) {
        deklansorSesi(false);
        durumGuncelle(r?.error || 'Fotoğraf kaydedilemedi.', true);
        return;
      }
      deklansorSesi(true);
      posetGorunumDegistir('cekim');
      const k = r.kayit;
      if ($('son-cekim-kutu') && $('son-cekim-img') && $('son-cekim-detay')) {
        $('son-cekim-img').src = k.gorselUrl;
        $('son-cekim-img').onclick = () => tamEkranAc(k);
        $('son-cekim-detay').textContent = `${k.barkod} · ${k.musteri} · ${k.urun} (${k.tarihSaat})`;
        $('son-cekim-kutu').classList.add('acik');
      }
      durumGuncelle(`✅ ${k.barkod} (${k.musteri}) poşet fotoğrafı başarıyla kaydedildi!`);
      await galeriyiYenile();
    } catch (err) {
      deklansorSesi(false);
      durumGuncelle('Sunucuya bağlanırken hata oluştu.', true);
    }
  }

  // 1. Canlı Kamera Vizörü (Termal barkodu gördüğü anda otomatik okur, ürün fotoğrafını çeker ve kaydeder!)
  let ocrOtoTarama = null;
  let ocrOtoMesgul = false;
  let sonOtoKod = '';
  let sonOtoMs = 0;

  function kamerayiKapat() {
    if (barkodOtoTarama) {
      clearInterval(barkodOtoTarama);
      barkodOtoTarama = null;
    }
    if (ocrOtoTarama) {
      clearInterval(ocrOtoTarama);
      ocrOtoTarama = null;
    }
    if (kameraAkisi) {
      kameraAkisi.getTracks().forEach(t => t.stop());
      kameraAkisi = null;
    }
    if ($('vizor-panel')) $('vizor-panel').classList.remove('acik');
  }

  function gecerliBarkodSec(adaylar) {
    if (window.MezatBarkod && typeof window.MezatBarkod.barkodSec === 'function') {
      return window.MezatBarkod.barkodSec(adaylar);
    }
    for (const a of (adaylar || [])) {
      const k = String(typeof a === 'string' ? a : (a && a.rawValue ? a.rawValue : '')).trim().toUpperCase();
      if (k && !/^(?:HTTPS?:\/\/|WWW\.)/i.test(k) && !/\.(?:COM|NET|ORG|TR|LINK|PAGE\.LINK)\b/i.test(k)) return k;
    }
    return '';
  }

  async function barkodSonucunuFormaUygula(okunan) {
    if (!okunan) return;
    try {
      const c = await post('/api/etiket/okut', { kod: okunan });
      if (c && c.siparis) {
        posetBilgisiDoldur({
          barkod: c.kod || okunan,
          musteri: c.siparis.musteri,
          urun: c.siparis.urun,
          beden: c.siparis.beden
        });
      } else {
        $('f-barkod').value = okunan;
        $('f-musteri').value = 'Sistemde Kayıtlı Değil';
        $('f-urun').value = `Okunan Barkod: ${okunan}`;
        durumGuncelle(`⚠️ ${okunan} barkodu okundu ancak sipariş/envanter listesinde kayıtlı değil.`, true);
      }
    } catch (_) {
      $('f-barkod').value = okunan;
    }
  }

  async function posetGoruntusundenBarkodDoldur(kaynakEl) {
    if (!kaynakEl) return '';
    try {
      let okunan = '';
      if ('BarcodeDetector' in window) {
        try {
          const okuyucu = new window.BarcodeDetector({
            formats: ['code_128', 'code_39', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'qr_code']
          });
          const bulunanlar = await okuyucu.detect(kaynakEl);
          okunan = gecerliBarkodSec(bulunanlar);
        } catch (_) {}
      }
      if (!okunan && window.MezatBarkod && typeof window.MezatBarkod.goruntudenOku === 'function') {
        okunan = window.MezatBarkod.goruntudenOku(kaynakEl) || '';
      }
      if (!okunan) {
        const w = kaynakEl.videoWidth || kaynakEl.width || 640;
        const h = kaynakEl.videoHeight || kaynakEl.height || 480;
        if (w && h) {
          const oran = Math.min(1, 960 / Math.max(w, h));
          const c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(w * oran));
          c.height = Math.max(1, Math.round(h * oran));
          c.getContext('2d').drawImage(kaynakEl, 0, 0, c.width, c.height);
          const r = await post('/api/kamera/barkod-ocr', { gorsel: c.toDataURL('image/jpeg', 0.84), otomatikOkut: false });
          if (r && r.bulunanKod) okunan = gecerliBarkodSec([r.bulunanKod]);
        }
      }
      if (okunan) {
        await barkodSonucunuFormaUygula(okunan);
      }
      return okunan;
    } catch (_) {
      return '';
    }
  }

  if ($('btn-canli-kamera')) {
    $('btn-canli-kamera').addEventListener('click', async () => {
      posetGorunumDegistir('cekim');
      if (kameraAkisi) {
        kamerayiKapat();
        return;
      }
      if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        durumGuncelle('📱 Fotoğraf seçmek veya çekmek için dosya penceresi açılıyor…');
        if ($('poset-dosya-input')) $('poset-dosya-input').click();
        return;
      }
      try {
        kameraAkisi = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false
        });
        const video = $('kamera-video');
        video.srcObject = kameraAkisi;
        await video.play();
        $('vizor-panel').classList.add('acik');
        durumGuncelle('🎥 Canlı kamera açık: Termal barkodu kameraya gösterdiğiniz anda barkodu okur ve ürün fotoğrafını OTOMATİK çekip kaydeder!');

        let okuyucu = null;
        if ('BarcodeDetector' in window) {
          try {
            okuyucu = new window.BarcodeDetector({
              formats: ['code_128', 'code_39', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'qr_code']
            });
          } catch (_) {}
        }
        barkodOtoTarama = setInterval(async () => {
          if (!video || video.readyState < 2) return;
          try {
            let okunan = '';
            if (okuyucu) {
              const bulunanlar = await okuyucu.detect(video);
              okunan = gecerliBarkodSec(bulunanlar);
            }
            if (!okunan && window.MezatBarkod && typeof window.MezatBarkod.goruntudenOku === 'function') {
              okunan = window.MezatBarkod.goruntudenOku(video) || '';
            }
            if (okunan) {
              const simdi = Date.now();
              if (okunan === sonOtoKod && (simdi - sonOtoMs) < 5000) return;
              sonOtoKod = okunan;
              sonOtoMs = simdi;
              await barkodSonucunuFormaUygula(okunan);
              const w = Math.min(1280, video.videoWidth || 960);
              const h = Math.round(((video.videoHeight || 680) / (video.videoWidth || 960)) * w);
              const damgaliDataUrl = kanitFiligraniBas(video, w, h);
              await fotografiSunucuyaKaydet(damgaliDataUrl);
            }
          } catch (_) {}
        }, 250);

        // Her 1.2 saniyede sunucu OCR ile termal etiketi oku
        ocrOtoTarama = setInterval(async () => {
          if (!video || video.readyState < 2 || ocrOtoMesgul) return;
          ocrOtoMesgul = true;
          try {
            const w = video.videoWidth || 640;
            const h = video.videoHeight || 480;
            const oran = Math.min(1, 960 / Math.max(w, h));
            const c = document.createElement('canvas');
            c.width = Math.max(1, Math.round(w * oran));
            c.height = Math.max(1, Math.round(h * oran));
            c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
            const r = await post('/api/kamera/barkod-ocr', { gorsel: c.toDataURL('image/jpeg', 0.82), otomatikOkut: false });
            const okunan = r && r.bulunanKod ? gecerliBarkodSec([r.bulunanKod]) : '';
            if (okunan) {
              const simdi = Date.now();
              if (okunan !== sonOtoKod || (simdi - sonOtoMs) >= 5000) {
                sonOtoKod = okunan;
                sonOtoMs = simdi;
                await barkodSonucunuFormaUygula(okunan);
                const damgaliDataUrl = kanitFiligraniBas(c, c.width, c.height);
                await fotografiSunucuyaKaydet(damgaliDataUrl);
              }
            }
          } catch (_) {}
          ocrOtoMesgul = false;
        }, 1200);
      } catch (err) {
        durumGuncelle('⚠️ Canlı kamera açılamadı; telefon/dosya kamerası penceresi açılıyor…');
        if ($('poset-dosya-input')) $('poset-dosya-input').click();
      }
    });
  }

  if ($('btn-kamera-kapat')) {
    $('btn-kamera-kapat').addEventListener('click', kamerayiKapat);
  }

  if ($('btn-deklansor')) {
    $('btn-deklansor').addEventListener('click', async () => {
      const video = $('kamera-video');
      if (!video || !video.videoWidth) return;
      const w = Math.min(1280, video.videoWidth);
      const h = Math.round((video.videoHeight / video.videoWidth) * w);
      const ham = document.createElement('canvas');
      ham.width = w;
      ham.height = h;
      ham.getContext('2d').drawImage(video, 0, 0, w, h);
      kamerayiKapat();
      durumGuncelle('🔎 Çekilen fotoğraftaki barkod/etiket kontrol ediliyor…');
      await posetGoruntusundenBarkodDoldur(ham);
      const damgaliDataUrl = kanitFiligraniBas(ham, w, h);
      await fotografiSunucuyaKaydet(damgaliDataUrl);
    });
  }

  // 2. Telefon Kamerası / Dosyadan Yükle
  if ($('btn-telefon-dosya')) {
    $('btn-telefon-dosya').addEventListener('click', () => {
      if ($('poset-dosya-input')) {
        $('poset-dosya-input').value = '';
        $('poset-dosya-input').click();
      }
    });
  }

  if ($('poset-dosya-input')) {
    $('poset-dosya-input').addEventListener('change', e => {
      const dosya = e.target.files && e.target.files[0];
      if (!dosya) return;
      const url = URL.createObjectURL(dosya);
      const img = new Image();
      img.onload = async () => {
        const maxW = 1100;
        const oran = Math.min(1, maxW / (img.width || 960));
        const w = Math.max(640, Math.round((img.width || 960) * oran));
        const h = Math.max(480, Math.round((img.height || 680) * oran));
        URL.revokeObjectURL(url);
        durumGuncelle('🔎 Fotoğraftaki barkod/etiket okunuyor…');
        await posetGoruntusundenBarkodDoldur(img);
        const damgali = kanitFiligraniBas(img, w, h);
        await fotografiSunucuyaKaydet(damgali);
      };
      img.src = url;
    });
  }

  // 3. Tek Tıkla Örnek Poşet Kanıt Fotoğrafı Oluştur & Kaydet (Canlı Test)
  if ($('btn-ornek-cekim')) {
    $('btn-ornek-cekim').addEventListener('click', async () => {
      if (!$('f-barkod').value.trim() && adayPosetListesi.length > 0) {
        posetBilgisiDoldur(adayPosetListesi[0]);
      }
      const barkod = ($('f-barkod').value || 'MZ-2026-0026').trim().toUpperCase();
      const musteri = ($('f-musteri').value || '@ayse_k').trim();
      const urun = ($('f-urun').value || 'Nike Air Spor Ayakkabı (Siyah 40)').trim();

      const hamCanvas = document.createElement('canvas');
      hamCanvas.width = 960;
      hamCanvas.height = 680;
      const ctx = hamCanvas.getContext('2d');

      // Depo tezgahı arka planı
      const bgGrad = ctx.createLinearGradient(0, 0, 960, 680);
      bgGrad.addColorStop(0, '#1e293b');
      bgGrad.addColorStop(1, '#0f172a');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, 960, 680);

      // Kargo Poşeti Gövdesi
      ctx.fillStyle = '#334155';
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.roundRect(190, 80, 580, 460, 26);
      ctx.fill();
      ctx.stroke();

      // Şeffaf poşet penceresi & katlanmış ürün görünümü
      ctx.fillStyle = '#1e3a5f';
      ctx.beginPath();
      ctx.roundRect(235, 120, 490, 210, 16);
      ctx.fill();
      ctx.fillStyle = '#e2e8f0';
      ctx.font = 'bold 24px "Segoe UI", system-ui, sans-serif';
      ctx.fillText('🛍️ ŞEFFAF KORUMALI KARGO POŞETİ', 265, 175);
      ctx.fillStyle = '#7dd3fc';
      ctx.font = 'bold 21px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(urun.slice(0, 42), 265, 225);
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 18px "Segoe UI", system-ui, sans-serif';
      ctx.fillText('✓ Beden, Renk ve Adet Kontrol Edildi', 265, 275);

      // Poşet Üzerindeki Beyaz Termal Barkod Etiketi
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(275, 350, 410, 165, 10);
      ctx.fill();

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 22px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(`MÜŞTERİ: ${musteri}`, 295, 385);
      ctx.font = '600 17px "Segoe UI", system-ui, sans-serif';
      ctx.fillText(urun.slice(0, 38), 295, 414);

      // Barkod çizgileri
      let bx = 295;
      for (let i = 0; i < 42; i++) {
        const kalinlik = (i % 3 === 0) ? 5 : ((i % 2 === 0) ? 3 : 2);
        ctx.fillRect(bx, 428, kalinlik, 52);
        bx += kalinlik + ((i % 4 === 0) ? 4 : 3);
      }
      ctx.font = 'bold 18px monospace';
      ctx.fillText(barkod, 395, 502);

      const damgaliDataUrl = kanitFiligraniBas(hamCanvas, 960, 680);
      await fotografiSunucuyaKaydet(damgaliDataUrl);
    });
  }

  function tamEkranAc(k) {
    if (!$('foto-modal')) return;
    $('modal-baslik').textContent = `📸 ${k.barkod} · ${k.musteri} · ${k.tarihSaat}`;
    $('modal-img').src = k.gorselUrl;
    $('foto-modal').classList.add('acik');
  }

  if ($('modal-kapat')) {
    $('modal-kapat').addEventListener('click', () => $('foto-modal').classList.remove('acik'));
  }
  if ($('foto-modal')) {
    $('foto-modal').addEventListener('click', e => {
      if (e.target === $('foto-modal')) $('foto-modal').classList.remove('acik');
    });
  }

  async function galeriyiYenile() {
    const q = ($('galeri-ara') && $('galeri-ara').value.trim()) || '';
    try {
      const veri = await fetch(`/api/poset-foto/liste?q=${encodeURIComponent(q)}`, { cache: 'no-store' }).then(r => r.json());
      if (!veri || !veri.success) return;

      if ($('st-toplam')) $('st-toplam').textContent = String(veri.istatistik?.toplamFoto || 0);
      if ($('st-bugun')) $('st-bugun').textContent = String(veri.istatistik?.bugunFoto || 0);
      if ($('st-bekleyen')) $('st-bekleyen').textContent = String(veri.istatistik?.bekleyenPoset || 0);

      adayPosetListesi = veri.adayPosetler || [];
      const adayKutu = $('aday-posetler');
      if (adayKutu) {
        adayKutu.innerHTML = '';
        adayPosetListesi.forEach(p => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = `aday-cip ${p.fotograflandi ? 'tamam' : 'bekleyen'}`;
          btn.innerHTML = `${p.fotograflandi ? '✅ 📸' : '⏳ 📦'} <code>${p.barkod}</code> <span>${p.musteri}${p.beden ? ` (${p.beden})` : ''}</span>`;
          btn.onclick = () => posetBilgisiDoldur(p);
          adayKutu.appendChild(btn);
        });
      }

      // İlk açılışta yalnız URL'de ?kod= varsa otomatik seç (rastgele başka müşterinin siparişini peşinen kutulara doldurma!)
      const urlParams = new URLSearchParams(window.location.search);
      const urlKod = (urlParams.get('kod') || '').trim().toUpperCase();
      if (urlKod && !$('f-barkod').dataset.ilkYuklendi) {
        $('f-barkod').dataset.ilkYuklendi = '1';
        const eslesen = adayPosetListesi.find(a => a.barkod === urlKod);
        if (eslesen) {
          posetBilgisiDoldur(eslesen);
        } else {
          await barkodSonucunuFormaUygula(urlKod);
        }
      }

      const galeri = $('galeri-liste');
      if (!galeri) return;
      const kayitlar = veri.kayitlar || [];
      if (kayitlar.length === 0) {
        galeri.innerHTML = `<div style="grid-column:1/-1;padding:18px;text-align:center;border:1px dashed #334155;border-radius:12px;color:#94a3b8">Henüz kaydedilmiş poşet kanıt fotoğrafı yok. Yukarıdaki <b>1. Canlı Kamera</b>, <b>2. Telefon Kamerası</b> veya <b>3. Tek Tıkla Canlı Poşet Kanıt Fotoğrafı Çek</b> düğmesine basarak ilk kanıt fotoğrafını kaydedebilirsiniz.</div>`;
        return;
      }

      galeri.innerHTML = '';
      kayitlar.forEach(k => {
        const kart = document.createElement('div');
        kart.className = 'foto-kart';
        const img = document.createElement('img');
        img.src = k.gorselUrl;
        img.alt = k.barkod;
        img.onclick = () => tamEkranAc(k);

        const govde = document.createElement('div');
        govde.className = 'foto-kart-govde';
        govde.innerHTML = `
          <div>
            <div class="foto-barkod">🏷️ ${k.barkod}</div>
            <div class="foto-musteri">${k.musteri}</div>
            <div class="foto-urun">${k.urun}</div>
          </div>
          <div class="foto-alt">
            <span>🕒 ${k.tarihSaat} · 👤 ${k.personel}</span>
            <span style="display:flex;gap:6px">
              <a href="${k.gorselUrl}" download="${k.barkod}-poset-kanit.jpg" style="color:#38bdf8;text-decoration:none;font-weight:800">⬇️ İndir</a>
              <button type="button" class="sil-btn" style="padding:2px 7px;font-size:0.75rem;border-color:#7f1d1d;color:#fca5a5;background:transparent">🗑️ Sil</button>
            </span>
          </div>
        `;
        govde.querySelector('.sil-btn').onclick = async () => {
          if (!confirm(`${k.barkod} poşet fotoğrafını silmek istiyor musunuz?`)) return;
          await post('/api/poset-foto/sil', { id: k.id });
          galeriyiYenile();
        };
        kart.append(img, govde);
        galeri.appendChild(kart);
      });
    } catch (_) {}
  }

  if ($('galeri-ara')) {
    $('galeri-ara').addEventListener('input', () => galeriyiYenile());
  }

  galeriyiYenile();
})();
