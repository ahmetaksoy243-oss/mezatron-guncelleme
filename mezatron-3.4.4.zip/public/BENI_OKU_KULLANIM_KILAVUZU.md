# 📖 MEZATRON AI · SESLİ ENVANTER & DEPO ASİSTANI — BENİ OKU VE KULLANIM KILAVUZU (v4.0 PRO)

Bu kılavuz; **Mezatron AI Sesli Envanter & Depo Asistanı** programının tüm menülerini, sesli ürün girişini, yaka etiketi fotoğraf okumayı (OCR), otomatik kamera barkod okuyucuyu, irsaliye aktarımını ve sıkça sorulan soruları adım adım açıklar.

---

## 1. ÜST BAR VE AÇILIR MENÜ (`☰ Menü`) NASIL KULLANILIR?

Telefon ekranının en üstünde her zaman sabit duran **4 ana öğe** bulunur:
1. **MEZATRON AI Logosu:** Programın ana kimliğidir (5 kez hızlı dokunulduğunda Kurucu/Ar-Ge araçlarını açar).
2. **`🔄 Yenile` Tuşu:** Bilgisayar ve diğer telefonlarla stok listesini anında eşitler.
3. **`⛶ Ekran` Tuşu:** Telefonun üst/alt sistem çubuklarını gizleyerek **Tam Ekran** moduna geçer.
4. **`☰ Menü` Tuşu:** Tüm yardımcı ayarların bulunduğu dikey açılır çekmece menüyü açar:
   - **👤 Kullanıcı Adı:** Ürünü hangi personelin girdiğini kaydeder (telefon hafızasında tutulur).
   - **🔄 Programı Güncelle / .APK İndir:** Program ilk kez kurulurken `.APK` indirir; kurulduktan sonra **`🔄 Programı Güncelle`** düğmesine dönüşür. Basıldığında önbelleği, marka/renk sözlüklerini ve arayüzü en son sürüme günceller.
   - **📖 Yardım / Beni Oku & SSS:** Bu kullanım kılavuzunu ve sıkça sorulan soruları ekran içinde açar.
   - **☀️ Gece / Gündüz Modu:** Güneş altında veya aydınlık depoda %100 mat ve yüksek kontrastlı gündüz temasına geçer.
   - **🔊 Sesli Okuma Aç / Kapat:** Tabloya aktarılan ürünü Türkçe sesle geri okuyarak teyit eder.
   - **🖨️ Mobil Mod & BT Yazıcı:** Bilgisayar kapalıyken çevrimdışı çalışma ve Bluetooth termal etiket yazıcısı eşleştirme panelini açar.
   - **⬇ Günlük Excel İndir:** Girilen tüm ürünleri Excel tablosu olarak indirir.
   - **⏻ Programı Güvenli Kapat (Kaydet & Çık):** Tablodaki verileri ve çevrimdışı kuyruğu kaydederek programı güvenle kapatır.

---

## 2. BEŞ ANA SAYFA VE KAYDIRARAK GEÇİŞ

Ekranı parmağınızla **sağa veya sola kaydırarak** ya da ekranın altındaki **5'li başparmak tuşlarına** dokunarak sayfalar arasında anında geçiş yapabilirsiniz:

### 🎙️ 1. Sayfa: Sesli Giriş ve Ürün Tablosu
- **`🎙️ ÜRÜN GİRİŞİ`** düğmesine bir kez basın ve ürünü doğal şekilde söyleyin:
  - *Örnek:* `"Sandex V yaka tişört siyah M beden 12 adet 350 lira"`
  - *Örnek:* `"Bigazzi triko kazak lacivert L beden 8 adet, XL beden 6 adet 750 TL"`
- Konuşmanız bittiğinde **mikrofon düğmesine dokunun**, mikrofon hemen kapanır. Dokunmazsanız **yaklaşık 4 saniye susunca** mikrofon kendiliğinden kapanır ve söylediğiniz ürün **Ürün Adı, Fiyat, Renk, Beden ve Adet** sütunlarına ayrıştırılarak tabloya yazılır.
- **`+ Yeni Renk / Beden Ekle` Tuşu Nasıl Çalışır?**
  1. Eğer tabloda **bedeni veya adedi eksik (yarım kalmış)** bir satır varsa, yeni satır açmak yerine mikrofonu açarak doğrudan o eksik satırı tamamlamanızı sağlar.
  2. Eğer mevcut satır tamamsa, üst satırın rengini koruyarak **2. satırı açar** ve tıpkı Ürün Girişi tuşuna basılmış gibi mikrofonu otomatik başlatır.
- **`✓ STOKA KAYDET` / `🏷️ KAYDET + ETİKET BAS`:** Tablodaki bilgileri kontrol ettikten sonra yeşil **`✓ STOKA KAYDET`** tuşuyla kaydedebilir veya mor **`🏷️ KAYDET + ETİKET BAS`** tuşuyla hem kaydedip hem de 50x30mm termal barkod etiketini yazdırabilirsiniz.

### 🏷️ 2. Sayfa: Yaka / Ürün Etiketi Fotoğrafından Okuma (`2. Etiket`)
- Bu sayfaya geçtiğinizde arka kamera otomatik olarak **Etiket Okuma** modunda açılır.
- İsterseniz orta kısımdaki hızlı şablon çiplerinden (**`V Yaka`**, **`Bisiklet Yaka`**, **`Polo Yaka`**, **`Tişört`**, **`Gömlek`**, **`Pantolon`** vb.) ürün cinsini tek dokunuşla seçebilirsiniz.
- Etiketi kameradaki mavi çerçeveye yaklaştırın ve başparmağınızın tam hizasındaki yeşil **`📸 ETİKETİ ÇEK & TABLOYA AKTAR`** düğmesine basın.
- **Akıllı Etiket OCR Motoru:**
  - Yıkama talimatlarını (`30°C`, `%100 Pamuk`, `Made in Turkey` vb.) otomatik temizler.
  - Yaka etiketindeki **Markayı** ve **Ana Bedeni** (`S`, `M`, `L`, `XL`, `2XL` vb.) okur.
  - Tabloda yarım kalmış bir satır varsa onu tamamlar; yoksa mevcut satıra yazar.

### 📷 3. Sayfa: Otomatik Kamera Barkod Okuyucu (`3. Barkod`)
- Bu sayfaya geçtiğinizde kamera otomatik olarak **Barkod Tarama** modunda açılır.
- Ürün barkodunu ekrandaki yeşil vizör çerçevesine tutmanız yeterlidir; hiçbir tuşa basmadan **otomatik okur**, gerçek **lazer barkod okuyucu sesi (`2730 Hz Bip`)** çalar ve ürünü tabloya ekler.
- **Çift Okuma Koruması (`3.5 Saniye`):**
  - Barkod okunduğu anda vizör çerçevesi **yeşil renge** döner ve kamera **3.5 saniye** boyunca kilitlenir.
  - Böylece ürünü kameranın önünden çekerken yanlışlıkla ikinci kez okuması kesin olarak engellenir.
  - Aynı barkod numarası kameranın önünde tutulmaya devam edilse bile **5 saniye** dolmadan tekrar tetiklenmez.
  - **Beklemeden Peş Peşe Okutma:** Aynı ürünü bilerek art arda okutmak isterseniz süreyi beklemeden alttaki mor **`📸 BARKODU YAKALA & OKU`** düğmesine basabilirsiniz.

### 📄 4. Sayfa: İrsaliye / Fatura Fotoğrafından Toplu Giriş (`4. İrsaliye`)
- Toptancıdan gelen irsaliye, fiş veya faturayı kameraya tutup alttaki yeşil **`📸 İRSALİYEYİ ÇEK & OKU`** düğmesine basın.
- Faturadaki tüm ürün kalemleri, renk, beden ve adetleriyle listelenir.
- Her kalemi seçip depoda saydıktan sonra **`✓ Depoda Saydım`** tuşuyla onaylayıp satış fiyatını girerek stoka kaydedebilirsiniz.

### 📋 5. Sayfa: Bugün Girilenler Listesi (`5. Liste`)
- Gün içinde girilen tüm ürünleri canlı olarak gösterir.
- Arama kutusundan ürün/barkod arayabilir, **`✏️ Düzelt`** ile kaydı forma geri çağırabilir, **`🏷️`** ile barkod etiketini tekrar basabilir veya **`Sil`** ile silebilirsiniz.

---

## 3. SIKÇA SORULAN SORULAR (SSS)

1. **Soru: Programdan güvenli şekilde nasıl çıkarım? Tekrar nasıl açarım?**
   - **Cevap:** `☰ Menü` en altındaki **`⏻ Programı Güvenli Kapat`** tuşuna (veya telefonun Geri tuşuna) basın. Kaydedilmemiş ürün varsa program önce sorar, ardından verileri kaydedip kırmızı **`⏻ PROGRAMI KAPAT`** komutunu gösterir. Bu komuta bastığınızda masaüstüne çıkılır. Telefon masaüstündeki **Mezatron** simgesine tekrar bastığınızda program **3B Sinematik Mezatron Açılış Animasyonu** ile sıfırdan başlar.

2. **Soru: Sesli girişte söylediğim marka veya renk yanlış yazılırsa ne yapmalıyım?**
   - **Cevap:** Tüm marka ve renk telaffuzları `MARKA_TELAFFUZ_SOZLUGU.md` ve `RENK_TELAFFUZ_SOZLUGU.md` dosyalarından dinamik okunur. Yeni bir marka telaffuzunu bu listeye eklediğinizde hem Sesli Giriş, hem Etiket OCR, hem de Çevrimdışı Mobil mod anında öğrenir.

3. **Soru: Gündüz depoda veya güneş altında yazılar silik görünürse ne yapmalıyım?**
   - **Cevap:** `☰ Menü` -> **`☀️ Gece / Gündüz Modu`** düğmesine basın. Gündüz modunda tüm saydamlıklar kaldırılır, tam beyaz zemin üzerine kalın siyah/lacivert yazılarla maksimum okunabilirlik sağlanır.

4. **Soru: Bilgisayar kapalıyken telefondan girdiğim ürünler kaybolur mu?**
   - **Cevap:** Hayır. Bilgisayar kapalıyken girilen ürünler telefonun kendi güvenli hafızasına (`Yerel Envanter Kuyruğu`) kaydedilir. Bilgisayar açıldığında otomatik olarak veya `🖨️ Mobil Mod & BT Yazıcı` panelindeki **`🔄 Şimdi Bilgisayara Aktar`** tuşuyla bilgisayara aktarılır.

5. **Soru: Sistem ve envanter verilerini ne sıklıkla yedeklemeliyim?**
   - **Cevap:**
     - **Otomatik Gölge Yedekleme:** Program arka planda her 5 dakikada bir (değişiklik olduğunda) ve her 10 işlemde bir SHA-256 imzalı anlık yedek alır.
     - **Güvenli Çıkışta Otomatik Yedekleme:** Masaüstünde veya telefonda **`⏻ Güvenli Kapat`** butonuna bastığınız anda tüm envanter, barkod bankası ve ayarların son kopyası otomatik olarak sistem arşivine mühürlenir.
     - **Kullanıcıya Tavsiye Edilen Yedekleme Disiplini:**
       - **Günlük:** Gün sonunda iş bitiminde `📁 Dosya` -> **`💾 Tam Veritabanı Yedeği Al (JSON)`** veya **`📥 Excel İndir`** yaparak dosyanızı bilgisayarınızın Belgeler klasörüne veya harici bir USB belleğe / bulut sürücünüze (Google Drive, OneDrive) kopyalamanız şiddetle tavsiye edilir.
       - **Haftalık:** Haftanın son çalışma günü sistemin toplu yedeğini alıp tarihli bir klasörde (örn: `Mezatron-Yedek-2026-Hafta45`) arşivleyiniz. Bu disiplin, bilgisayar arızalarında dahi 1 dakikada sıfır veri kaybıyla sistemi ayağa kaldırmanızı sağlar.

---

## 4. BİLGİSAYAR / MASAÜSTÜ KOMUTA MERKEZİ (365 PRO) KULLANIMI

1. **🏠 Giriş (Ana Sayfa):** Tüm envanter dökümünü Microsoft Excel arayüzü konforunda gösterir. Barkod, Adet, Fiyat, Beden ve Renk filtreleriyle arama yapabilirsiniz.
2. **📁 Dosya Menüsü:** Excel İndir / Yükle, A4 Resmi Döküm Yazdır, Tam Sistem Yedeği İndir ve Barkod İstasyonuna geçiş araçlarını sunar.
3. **🔒 Değiştirilemez Barkod Koruması:** Bir ürünü düzenlerken barkod numarası sistem ve barkod bankası bütünlüğü için kilitlidir; miktar, renk, isim ve fiyat değiştirildiğinde tüm istasyonlara anında çapraz eşitlenir.
4. **⏻ Güvenli Kapat & Yedekle:** Üst barda sağ üstte bulunan kırmızı **`⏻ Güvenli Kapat`** butonuna bastığınızda, sistem tüm verileri diske ve yedek havuzuna yazar, ardından 6 saniyelik güvenli kapanış vitriniyle programı kapatır.

