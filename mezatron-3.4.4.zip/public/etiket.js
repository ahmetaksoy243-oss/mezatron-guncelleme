// Etiket istasyonu: kuyruktaki etiketleri sırayla Windows yazıcısına gönderir.
// Etiket ölçüsü milimetre olarak sayfa boyu yapılır; böylece sürücüsü kurulu her yazıcıda aynı çıkar.
(function () {
  const $ = id => document.getElementById(id);
  // Sunucu cevap vermezse istek 8 saniyede bırakılır: istasyon sessizce takılı kalmaz, sonraki denemede yeniden sorar
  const ISTEK_SURESI_MS = 8000;
  const sureli = () => (window.AbortSignal && AbortSignal.timeout ? AbortSignal.timeout(ISTEK_SURESI_MS) : undefined);
  const post = (yol, govde) => fetch(yol, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(govde || {}), signal: sureli() }).then(r => r.json());
  // Bu pencerenin kimliği (her açılışta yeni): iki istasyon penceresi açıksa aynı etiketi ikisi birden basmaz
  const ISTASYON = `ist-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  const mesaj = metin => { $('mesaj').textContent = metin || ''; };

  const HAZIR_BOYLAR = [[30, 20], [40, 30], [50, 25], [50, 30], [58, 40], [60, 40], [70, 50], [100, 50], [100, 100], [100, 150]];
  const ALAN_ADLARI = { musteri: 'Müşteri adı', raf: 'Raf', beden: 'Beden', urun: 'Ürün', fiyat: 'Fiyat', siparisNo: 'Sipariş no', barkod: 'Barkod', tarih: 'Tarih' };
  const ORNEK = { orderId: 'ornek', siparisNo: 'MZ-2026-0001', barkod: 'MZ-2026-0001', musteri: 'Fatma Aktaş', raf: 'Y-012', beden: '42', urun: 'Adidas Beyaz Ayakkabı', adet: 1, fiyat: 1500 };

  let ayar = null;
  let kuyruk = { bekleyen: [], gonderilen: [], iptalUyarilari: [] };
  let basiyor = false;

  // ===== Etiket çizimi =====
  function etiketOgesi(veri, a) {
    const e = document.createElement('div');
    e.className = 'etiket';
    const icGen = a.genislikMm - a.kenarMm * 2;
    const icYuk = a.yukseklikMm - a.kenarMm * 2;
    e.style.width = `${a.genislikMm}mm`;
    e.style.height = `${a.yukseklikMm}mm`;
    e.style.padding = `${a.kenarMm}mm`;
    // Yazı boyu etiketin küçük kenarına göre: 30 mm yükseklikte yaklaşık 4,8 mm
    e.style.fontSize = `${Math.max(2.2, Math.min(icYuk * 0.17, icGen * 0.11)).toFixed(2)}mm`;
    const kucuk = icYuk < 24;
    const al = a.alanlar;
    const div = (sinif, metin) => { const d = document.createElement('div'); d.className = sinif; d.textContent = metin; return d; };

    const ust = document.createElement('div');
    ust.className = 'e-ust';
    if (al.musteri) ust.append(div('e-musteri', veri.musteri));
    const bedenRenk = [veri.renk, veri.beden].filter(Boolean).join(' / ');
    if (al.beden && bedenRenk) ust.append(div('e-beden', bedenRenk));
    else if (al.beden && veri.beden) ust.append(div('e-beden', veri.beden));
    if (ust.childNodes.length) e.append(ust);
    if (al.urun && !kucuk) {
      const parcaBilgi = veri.parcaSayisi && veri.parcaSayisi > 1 ? ` (${veri.parcaSayisi} parça konsolide)` : '';
      e.append(div('e-urun', `${veri.adet > 1 && !/^\d+ adet /u.test(veri.urun) ? `${veri.adet} adet ` : ''}${veri.urun}${parcaBilgi}`));
    }
    if (veri.hediye && !kucuk) {
      e.append(div('e-urun', `🎁 HEDİYE: ${veri.hediye}`));
    }
    const orta = document.createElement('div');
    orta.className = 'e-orta';
    if (al.raf && veri.raf) orta.append(div('e-raf', `RAF ${veri.raf}`));
    if (al.fiyat && veri.fiyat && !kucuk) orta.append(div('e-fiyat', `${Number(veri.fiyat).toLocaleString('tr-TR')} TL`));
    if (orta.childNodes.length) e.append(orta);
    if (al.barkod) {
      const b = document.createElement('div');
      b.className = 'e-barkod';
      try {
        b.innerHTML = window.MezatBarkod.svg(veri.barkod);
      } catch (err) {
        b.append(div('e-no', 'Barkod çizilemedi'));
      }
      if (al.siparisNo) b.append(div('e-no', veri.siparisNo));
      e.append(b);
    } else if (al.siparisNo) {
      e.append(div('e-no', veri.siparisNo));
    }
    if (al.tarih) e.append(div('e-tarih', new Date().toLocaleString('tr-TR')));
    return e;
  }

  // Ad kesilmez: sığmazsa yazı küçülür (en fazla yarıya kadar). Ürün adı da aynı.
  function sigdir(kok) {
    kok.querySelectorAll('.e-musteri, .e-urun, .e-raf').forEach(el => {
      el.style.fontSize = '';
      let boy = parseFloat(getComputedStyle(el).fontSize);
      const enAz = boy * 0.5;
      el.classList.remove('iki-satir');
      for (let i = 0; i < 40 && el.scrollWidth > el.clientWidth + 0.5 && boy > enAz; i++) {
        boy *= 0.94;
        el.style.fontSize = `${boy}px`;
      }
      // Yarıya küçülse de sığmayan ad iki satıra iner, hiçbir harfi kesilmez
      if (el.classList.contains('e-musteri') && el.scrollWidth > el.clientWidth + 0.5) el.classList.add('iki-satir');
    });
  }

  function sayfaBoyunuAyarla(a) {
    $('sayfa-boyu').textContent = `@page { size: ${a.genislikMm}mm ${a.yukseklikMm}mm; margin: 0; }`;
  }

  // ===== Ayar formu =====
  function formdanAyar() {
    const alanlar = {};
    Object.keys(ALAN_ADLARI).forEach(k => { alanlar[k] = $(`alan-${k}`).checked; });
    return {
      ...ayar,
      genislikMm: Number($('genislik').value),
      yukseklikMm: Number($('yukseklik').value),
      kenarMm: Number($('kenar').value),
      kopya: Number($('kopya').value),
      alanlar
    };
  }

  function formuDoldur(a) {
    $('genislik').value = a.genislikMm;
    $('yukseklik').value = a.yukseklikMm;
    $('kenar').value = a.kenarMm;
    $('kopya').value = a.kopya;
    Object.keys(ALAN_ADLARI).forEach(k => { $(`alan-${k}`).checked = Boolean(a.alanlar[k]); });
    hazirBoylariIsaretle();
  }

  function hazirBoylariIsaretle() {
    const g = Number($('genislik').value), y = Number($('yukseklik').value);
    $('hazir-boy').querySelectorAll('button').forEach(b => b.classList.toggle('secili', b.dataset.g == g && b.dataset.y == y));
  }

  function onizle() {
    const a = formdanAyar();
    $('onizleme').replaceChildren(etiketOgesi(ORNEK, a));
    sigdir($('onizleme'));
    hazirBoylariIsaretle();
  }

  function yaziciDurumu() {
    const acik = ayar && ayar.yaziciAcik;
    $('yazici-durum').textContent = acik ? '🖨️ Yazıcı açık: etiketler basılıyor' : '⏸️ Yazıcı kapalı: etiketler kuyrukta bekliyor';
    $('yazici-durum').className = `durum ${acik ? 'acik' : 'kapali'}`;
    $('yazici-dugme').textContent = acik ? 'Yazıcıyı kapat' : 'Yazıcıyı aç';
  }

  // ===== Kuyruk =====
  function listeOgesi(veri, dugmeYazi, dugmeIs) {
    const d = document.createElement('div');
    d.className = 'liste-oge';
    const sol = document.createElement('span');
    const ad = document.createElement('b');
    ad.textContent = `${veri.musteri}${veri.beden ? ` · ${veri.beden}` : ''}`;
    sol.append(ad, ` · ${veri.siparisNo} · RAF ${veri.raf}`);
    d.append(sol);
    if (dugmeYazi) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = dugmeYazi;
      b.onclick = dugmeIs;
      d.append(b);
    }
    return d;
  }

  function kuyruguGoster() {
    $('bekleyen-sayi').textContent = `Kuyrukta ${kuyruk.bekleyen.length} etiket`;
    const bos = yazi => Object.assign(document.createElement('div'), { className: 'bos', textContent: yazi });
    $('bekleyenler').replaceChildren(...(kuyruk.bekleyen.length ? kuyruk.bekleyen.map(v => listeOgesi(v)) : [bos('Kuyruk boş.')]));
    $('gonderilenler').replaceChildren(...(kuyruk.gonderilen.length
      ? kuyruk.gonderilen.slice(0, 10).map(v => listeOgesi(v, 'Yeniden bas', async () => {
        const c = await post('/api/etiket/yeniden', { orderId: v.orderId });
        mesaj(c.success ? '' : c.error);
        yenile();
      }))
      : [bos('Henüz etiket gönderilmedi.')]));
    // Basıldıktan sonra iptal edilen sipariş: poşetleyen görsün
    $('iptal-uyarilari').replaceChildren(...kuyruk.iptalUyarilari.map(v => {
      const d = document.createElement('div');
      d.className = 'iptal-uyari';
      const b = document.createElement('b');
      b.textContent = `⛔ ${v.siparisNo} · ${v.musteri}${v.beden ? ` · ${v.beden}` : ''} · RAF ${v.raf}`;
      const gordum = document.createElement('button');
      gordum.type = 'button';
      gordum.textContent = 'Gördüm, ayırdım';
      gordum.style.marginLeft = '10px';
      gordum.onclick = async () => { await post('/api/etiket/iptal-goruldu', { orderId: v.orderId }); yenile(); };
      d.append(b, document.createElement('br'), 'Bu siparişin etiketi basıldı ama sipariş İPTAL edildi. Etiketi ve ürünü poşete koymayın.', gordum);
      return d;
    }));
  }

  // Tek etiket (kopya sayısı kadar) yazıcıya gider. Yazıcı penceresi sorarsa kullanıcı "Yazdır" der;
  // etiket_istasyonu.bat ile açıldıysa sormadan varsayılan yazıcıya gider.
  function bas(veriler, a) {
    sayfaBoyunuAyarla(a);
    const ogeler = [];
    veriler.forEach(v => { for (let i = 0; i < a.kopya; i++) ogeler.push(etiketOgesi(v, a)); });
    $('baski').replaceChildren(...ogeler);
    $('baski').style.display = 'block';
    sigdir($('baski'));
    $('baski').style.display = '';
    window.print();
  }

  async function siradakiniBas() {
    if (basiyor || !ayar || !ayar.yaziciAcik || !kuyruk.bekleyen.length || new URLSearchParams(location.search).has('ornek')) return;
    basiyor = true;
    try {
      // Sıradaki etiket sunucudan "alınır": başka istasyonun bastığı etiket buraya gelmez
      const alinan = await post('/api/etiket/al', { istasyon: ISTASYON });
      const veri = alinan && alinan.etiket;
      if (!veri) return;
      bas([veri], ayar);
      const c = await post('/api/etiket/gonderildi', { orderId: veri.orderId, istasyon: ISTASYON });
      if (!c.success) mesaj(c.error || 'Etiket kaydedilemedi.');
      else mesaj('');
    } catch (err) {
      mesaj('Sunucuya ulaşılamadı. Etiket kuyrukta kaldı, bağlantı gelince yeniden denenecek.');
    } finally {
      basiyor = false;
      await yenile();
    }
  }

  let yenileniyor = false;
  async function yenile() {
    if (yenileniyor) return;
    yenileniyor = true;
    try {
      kuyruk = await fetch('/api/etiket/kuyruk', { signal: sureli() }).then(r => r.json());
      const ilk = !ayar;
      ayar = kuyruk.ayar;
      if (ilk) { formuDoldur(ayar); onizle(); ornekBaskiyiHazirla(); }
      $('baglanti').textContent = '🟢 Bağlı';
      yaziciDurumu();
      kuyruguGoster();
    } catch (err) {
      $('baglanti').textContent = '🔴 Sunucuya ulaşılamıyor';
    } finally {
      yenileniyor = false;
    }
    setTimeout(siradakiniBas, 200);
  }

  // Kurulum denemesi: etiket.html?ornek=1&g=58&y=40 sayfası yazdırılınca (ya da PDF'e alınınca) örnek etiket çıkar
  function ornekBaskiyiHazirla() {
    const p = new URLSearchParams(location.search);
    if (!p.has('ornek')) return;
    const a = { ...ayar, genislikMm: Number(p.get('g')) || ayar.genislikMm, yukseklikMm: Number(p.get('y')) || ayar.yukseklikMm, yaziciAcik: false };
    ayar = { ...ayar, yaziciAcik: false };
    sayfaBoyunuAyarla(a);
    $('baski').replaceChildren(etiketOgesi(p.get('ad') ? { ...ORNEK, musteri: p.get('ad') } : ORNEK, a));
    $('baski').style.display = 'block';
    sigdir($('baski'));
    $('baski').style.display = '';
  }

  // ===== Kurulum =====
  HAZIR_BOYLAR.forEach(([g, y]) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.dataset.g = g;
    b.dataset.y = y;
    b.textContent = `${g} × ${y}`;
    b.onclick = () => { $('genislik').value = g; $('yukseklik').value = y; onizle(); };
    $('hazir-boy').append(b);
  });
  Object.entries(ALAN_ADLARI).forEach(([k, ad]) => {
    const l = document.createElement('label');
    const c = document.createElement('input');
    c.type = 'checkbox';
    c.id = `alan-${k}`;
    c.onchange = onizle;
    l.append(c, ad);
    $('alanlar').append(l);
  });
  ['genislik', 'yukseklik', 'kenar', 'kopya'].forEach(id => { $(id).oninput = onizle; });

  $('kaydet').onclick = async () => {
    const c = await post('/api/etiket/ayar', formdanAyar());
    if (c.success) { ayar = c.ayar; formuDoldur(ayar); onizle(); mesaj('Ayar kaydedildi.'); }
    else mesaj(c.error || 'Ayar kaydedilemedi.');
  };
  $('deneme').onclick = () => bas([ORNEK], formdanAyar());
  $('yazici-dugme').onclick = async () => {
    const c = await post('/api/etiket/ayar', { yaziciAcik: !(ayar && ayar.yaziciAcik) });
    if (c.success) ayar = c.ayar;
    yaziciDurumu();
    yenile();
  };

  // Canlı bağlantı: kuyruk değişince hemen yenile; bağlantı koparsa 3 saniyede bir sorulur
  try {
    const kaynak = new EventSource('/api/events');
    kaynak.addEventListener('etiket_kuyrugu', yenile);
    kaynak.addEventListener('etiket_ayari', yenile);
  } catch (err) {}
  setInterval(yenile, 3000);
  yenile();
})();
