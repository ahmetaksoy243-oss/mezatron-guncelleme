// ============================================================================
// MEZATRON İLK KURULUM, SES MODELLERİ VE EKLENTİ YÖNETİCİSİ (kurulum_sihirbazi.js)
// - Yeni kurulan bir bilgisayarda sistemin tam kapasite çalışması için gereken
//   ses motorlarını (Whisper C++/CUDA/Vulkan), Türkçe ses modellerini
//   (Large-v3-Turbo, Base, Silero VAD), Yayıncı Ses İzi (3D-Speaker ONNX +
//   Sherpa-ONNX eklentisi) ve Windows C++ çalışma zamanı bileşenlerini denetler.
// - Bilgisayarın donanımına (RAM, CPU, Ekran Kartı) göre hangi paketin
//   kurulması gerektiğini tavsiye eder.
// - Kullanıcı arayüzden izin verip tıkladığında ilgili dosyayı resmi kaynağından
//   (veya bilgisayardaki ortak önbellekten) canlı ilerleme çubuğuyla indirip kurar.
// ============================================================================

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile, spawn } = require('child_process');

function donanimProfiliniCikar() {
  const toplamRamGB = Math.round((os.totalmem() / (1024 ** 3)) * 10) / 10;
  const bosRamGB = Math.round((os.freemem() / (1024 ** 3)) * 10) / 10;
  const cekirdekSayisi = (os.cpus() || []).length || 2;
  const islemciModeli = (os.cpus() && os.cpus()[0] && os.cpus()[0].model) ? os.cpus()[0].model.trim() : 'Standart İşlemci';
  return { toplamRamGB, bosRamGB, cekirdekSayisi, islemciModeli };
}

function nvidiaKartTespiti() {
  return new Promise(resolve => {
    execFile('nvidia-smi', ['--query-gpu=name,memory.total', '--format=csv,noheader,nounits'], { timeout: 4000, windowsHide: true }, (err, out) => {
      if (err || !out) return resolve(null);
      const satir = String(out).trim().split(/\r?\n/)[0] || '';
      const [ad, bellek] = satir.split(',').map(s => s.trim());
      if (!ad) return resolve(null);
      resolve({ ad, vramMB: Number(bellek) || 0, vramGB: Math.round(((Number(bellek) || 0) / 1024) * 10) / 10 });
    });
  });
}

function kurulumSihirbaziOlustur({ projeKlasoru, motorKlasoru, kurulumSonrasiTetikle } = {}) {
  const anaKlasor = path.resolve(projeKlasoru || __dirname);
  const motorDir = path.resolve(motorKlasoru || path.join(anaKlasor, 'motor'));
  const indirilenDir = path.join(motorDir, 'indirilen');
  const releaseDir = path.join(motorDir, 'bin', 'Release');
  const vulkanDir = path.join(motorDir, 'vulkan');
  const sesTanimaDir = path.join(motorDir, 'ses-tanima');

  // Bilgisayardaki olası kardeş proje klasörleri (yerel önbellekten 1 saniyede kurulum için)
  const ustKlasor = path.dirname(anaKlasor);
  const kardesMotorKlasorleri = [
    path.join(ustKlasor, 'live-commerce-demo-claude', 'motor'),
    path.join(ustKlasor, 'live-commerce-demo', 'motor'),
    path.join(ustKlasor, 'live-commerce-demo-claude-evrensel', 'motor'),
    path.join(ustKlasor, 'sesli-envanter-asistani', 'motor')
  ].filter(p => path.resolve(p) !== motorDir);

  // Aktif indirme/kurulum görevlerinin canlı ilerleme durumu
  const aktifGorevler = new Map();

  function bilesenTanimlari() {
    return [
      {
        id: 'vcredist_x64',
        ad: 'Microsoft Visual C++ Çalışma Zamanı (x64)',
        kategori: 'Sistem Eklentisi',
        zorunlu: true,
        tahminiBoyutMB: 24,
        hedefYol: path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'vcruntime140.dll'),
        indirmeDosyaYolu: path.join(indirilenDir, 'vc_redist.x64.exe'),
        resmiUrl: 'https://aka.ms/vs/17/release/vc_redist.x64.exe',
        resmiSayfaUrl: 'https://learn.microsoft.com/tr-tr/cpp/windows/latest-supported-vc-redist',
        tavsiyeNedeni: 'Windows bilgisayarlarda yerel C++ ses motorlarının (whisper-server.exe ve ONNX) hata vermeden açılması için temel sistem eklentisidir.',
        kontrolEt: () => {
          const sys32 = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'vcruntime140.dll');
          return fs.existsSync(sys32);
        },
        yerelKopyaYolu: () => null
      },
      {
        id: 'whisper_server_bin',
        ad: 'Whisper C++ Yerel Ses Sunucusu (CUDA / CPU)',
        kategori: 'Ses Motoru Çekirdeği',
        zorunlu: true,
        tahminiBoyutMB: 45,
        hedefYol: path.join(releaseDir, 'whisper-server.exe'),
        indirmeDosyaYolu: path.join(indirilenDir, 'whisper-cublas-12.4.0-bin-x64.zip'),
        resmiUrl: 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.7.4/whisper-cublas-12.4.0-bin-x64.zip',
        resmiSayfaUrl: 'https://github.com/ggml-org/whisper.cpp/releases',
        tavsiyeNedeni: 'Mikrofon sesini internet bağlantısına ihtiyaç duymadan bilgisayarın kendi işlemcisi veya Nvidia ekran kartı üzerinde işleyen ana ses motorudur.',
        kontrolEt: () => fs.existsSync(path.join(releaseDir, 'whisper-server.exe')),
        yerelKopyaYolu: () => {
          for (const k of kardesMotorKlasorleri) {
            const p = path.join(k, 'bin', 'Release', 'whisper-server.exe');
            if (fs.existsSync(p)) return path.join(k, 'bin', 'Release');
          }
          return null;
        }
      },
      {
        id: 'whisper_vulkan_bin',
        ad: 'Evrensel GPU Ses Hızlandırıcı (AMD / Intel Vulkan)',
        kategori: 'Ses Motoru Çekirdeği',
        zorunlu: false,
        tahminiBoyutMB: 3.5,
        hedefYol: path.join(vulkanDir, 'whisper-server.exe'),
        indirmeDosyaYolu: path.join(indirilenDir, 'whisper-vulkan-bin-x64.zip'),
        resmiUrl: 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.7.4/whisper-bin-x64.zip',
        resmiSayfaUrl: 'https://github.com/ggml-org/whisper.cpp/releases',
        tavsiyeNedeni: 'Nvidia ekran kartı olmayan dizüstü/masaüstü bilgisayarlarda AMD Radeon veya Intel Iris/UHD dahili grafik işlemcisini kullanarak ses tanımayı hızlandırır.',
        kontrolEt: () => fs.existsSync(path.join(vulkanDir, 'whisper-server.exe')),
        yerelKopyaYolu: () => {
          for (const k of kardesMotorKlasorleri) {
            const p = path.join(k, 'vulkan', 'whisper-server.exe');
            if (fs.existsSync(p)) return path.join(k, 'vulkan');
          }
          return null;
        }
      },
      {
        id: 'model_silero_vad',
        ad: 'Silero VAD v6.2 Gürültü & Sessizlik Süzgeci',
        kategori: 'Ses Modeli (VAD)',
        zorunlu: true,
        tahminiBoyutMB: 0.9,
        hedefYol: path.join(indirilenDir, 'ggml-silero-v6.2.0.bin'),
        indirmeDosyaYolu: path.join(indirilenDir, 'ggml-silero-v6.2.0.bin'),
        resmiUrl: 'https://huggingface.co/ggml-org/whisper-vad/resolve/main/ggml-silero-v6.2.0.bin',
        resmiSayfaUrl: 'https://huggingface.co/ggml-org/whisper-vad/tree/main',
        tavsiyeNedeni: 'Ortam gürültüsünü ve konuşma dışı sessizlikleri süzer; yayında konuşulmadığı anlarda ses motorunun yanlış metin üretmesini engeller.',
        kontrolEt: () => {
          const p = path.join(indirilenDir, 'ggml-silero-v6.2.0.bin');
          return fs.existsSync(p) && fs.statSync(p).size > 100000;
        },
        yerelKopyaYolu: () => {
          for (const k of kardesMotorKlasorleri) {
            const p = path.join(k, 'indirilen', 'ggml-silero-v6.2.0.bin');
            if (fs.existsSync(p) && fs.statSync(p).size > 100000) return p;
          }
          return null;
        }
      },
      {
        id: 'model_whisper_turbo',
        ad: 'Whisper Large-v3-Turbo Türkçe Ana Ses Modeli (Q5_0)',
        kategori: 'Türkçe Yapay Zeka Ses Modeli',
        zorunlu: true,
        tahminiBoyutMB: 547,
        hedefYol: path.join(indirilenDir, 'ggml-large-v3-turbo-q5_0.bin'),
        indirmeDosyaYolu: path.join(indirilenDir, 'ggml-large-v3-turbo-q5_0.bin'),
        resmiUrl: 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin',
        resmiSayfaUrl: 'https://huggingface.co/ggerganov/whisper.cpp/blob/main/ggml-large-v3-turbo-q5_0.bin',
        tavsiyeNedeni: 'Mezat şivesi, müşteri isimleri, renk/beden ve fiyatları en yüksek doğrulukla tanıyan ana Türkçe ses modelidir.',
        kontrolEt: () => {
          const p = path.join(indirilenDir, 'ggml-large-v3-turbo-q5_0.bin');
          return fs.existsSync(p) && fs.statSync(p).size > 100 * 1024 * 1024;
        },
        yerelKopyaYolu: () => {
          for (const k of kardesMotorKlasorleri) {
            const p = path.join(k, 'indirilen', 'ggml-large-v3-turbo-q5_0.bin');
            if (fs.existsSync(p) && fs.statSync(p).size > 100 * 1024 * 1024) return p;
          }
          return null;
        }
      },
      {
        id: 'model_whisper_base',
        ad: 'Whisper Base Hafif Türkçe Ses Modeli (Düşük RAM / Eski PC)',
        kategori: 'Türkçe Yapay Zeka Ses Modeli',
        zorunlu: false,
        tahminiBoyutMB: 57,
        hedefYol: path.join(indirilenDir, 'ggml-base-q5_1.bin'),
        indirmeDosyaYolu: path.join(indirilenDir, 'ggml-base-q5_1.bin'),
        resmiUrl: 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base-q5_1.bin',
        resmiSayfaUrl: 'https://huggingface.co/ggerganov/whisper.cpp/blob/main/ggml-base-q5_1.bin',
        tavsiyeNedeni: 'Ekran kartı olmayan 4-8 GB RAM\'li eski dizüstü bilgisayarlarda işlemciyi yormadan 0.6 saniyede hızlı yanıt almak için tavsiye edilen hafif modeldir.',
        kontrolEt: () => {
          const p = path.join(indirilenDir, 'ggml-base-q5_1.bin');
          return fs.existsSync(p) && fs.statSync(p).size > 20 * 1024 * 1024;
        },
        yerelKopyaYolu: () => {
          for (const k of kardesMotorKlasorleri) {
            const p = path.join(k, 'indirilen', 'ggml-base-q5_1.bin');
            if (fs.existsSync(p) && fs.statSync(p).size > 20 * 1024 * 1024) return p;
          }
          return null;
        }
      },
      {
        id: 'model_speaker_onnx',
        ad: '3D-Speaker Yayıncı Ses İzi Doğrulama Modeli (ONNX)',
        kategori: 'Yayıncı Ses Tanıma (Speaker ID)',
        zorunlu: true,
        tahminiBoyutMB: 27,
        hedefYol: path.join(sesTanimaDir, '3dspeaker_speech_campplus_sv_zh_en_16k-common_advanced.onnx'),
        indirmeDosyaYolu: path.join(sesTanimaDir, '3dspeaker_speech_campplus_sv_zh_en_16k-common_advanced.onnx'),
        resmiUrl: 'https://github.com/k2-fsa/sherpa-onnx/releases/download/speaker-recog-models/3dspeaker_speech_campplus_sv_zh_en_16k-common_advanced.onnx',
        resmiSayfaUrl: 'https://github.com/k2-fsa/sherpa-onnx/releases/tag/speaker-recog-models',
        tavsiyeNedeni: 'Yayıncının sesini yanındaki kişilerden ve arka plan seslerinden ayırt ederek yabancı seslerin sipariş açmasını engeller.',
        kontrolEt: () => {
          const p = path.join(sesTanimaDir, '3dspeaker_speech_campplus_sv_zh_en_16k-common_advanced.onnx');
          return fs.existsSync(p) && fs.statSync(p).size > 5 * 1024 * 1024;
        },
        yerelKopyaYolu: () => {
          for (const k of kardesMotorKlasorleri) {
            const p = path.join(k, 'ses-tanima', '3dspeaker_speech_campplus_sv_zh_en_16k-common_advanced.onnx');
            if (fs.existsSync(p) && fs.statSync(p).size > 5 * 1024 * 1024) return p;
          }
          return null;
        }
      },
      {
        id: 'plugin_sherpa_onnx',
        ad: 'Sherpa-ONNX Yerel Ses İzi Eklentisi (Node.js Modülü)',
        kategori: 'Yayıncı Ses Tanıma (Speaker ID)',
        zorunlu: true,
        tahminiBoyutMB: 32,
        hedefYol: path.join(sesTanimaDir, 'node_modules', 'sherpa-onnx-node'),
        indirmeDosyaYolu: path.join(sesTanimaDir, 'node_modules', 'sherpa-onnx-node'),
        resmiUrl: 'https://registry.npmjs.org/sherpa-onnx-node',
        resmiSayfaUrl: 'https://www.npmjs.com/package/sherpa-onnx-node',
        tavsiyeNedeni: '3D-Speaker ses izi modelini çalıştıran yerel biyometrik ses analizi eklentisidir.',
        kontrolEt: () => fs.existsSync(path.join(sesTanimaDir, 'node_modules', 'sherpa-onnx-node')),
        yerelKopyaYolu: () => {
          for (const k of kardesMotorKlasorleri) {
            const p = path.join(k, 'ses-tanima', 'node_modules', 'sherpa-onnx-node');
            if (fs.existsSync(p)) return path.join(k, 'ses-tanima');
          }
          return null;
        }
      }
    ];
  }

  function klasorKopyalaRecursive(kaynak, hedef) {
    fs.mkdirSync(hedef, { recursive: true });
    const girdiler = fs.readdirSync(kaynak, { withFileTypes: true });
    for (const g of girdiler) {
      const kYol = path.join(kaynak, g.name);
      const hYol = path.join(hedef, g.name);
      if (g.isDirectory()) {
        klasorKopyalaRecursive(kYol, hYol);
      } else if (g.isFile()) {
        fs.copyFileSync(kYol, hYol);
      }
    }
  }

  async function urlDenDosyaIndir(urlStr, hedefDosya, gorev) {
    fs.mkdirSync(path.dirname(hedefDosya), { recursive: true });
    const geciciDosya = hedefDosya + '.indiriliyor.part';
    const res = await fetch(urlStr, { redirect: 'follow' });
    if (!res.ok || !res.body) {
      throw new Error(`İndirme sunucusu yanıt vermedi (HTTP ${res.status})`);
    }
    const toplamBayt = Number(res.headers.get('content-length')) || Math.round((gorev.tahminiBoyutMB || 10) * 1024 * 1024);
    gorev.toplamBayt = toplamBayt;
    gorev.indirilenBayt = 0;

    const yazici = fs.createWriteStream(geciciDosya);
    const okuyucu = res.body.getReader();
    const baslangicMs = Date.now();

    try {
      while (true) {
        const { done, value } = await okuyucu.read();
        if (done) break;
        if (value) {
          yazici.write(Buffer.from(value));
          gorev.indirilenBayt += value.byteLength;
          gorev.yuzde = Math.min(99, Math.round((gorev.indirilenBayt / Math.max(1, toplamBayt)) * 100));
          const gecenSn = Math.max(0.2, (Date.now() - baslangicMs) / 1000);
          gorev.hizMBsn = Math.round(((gorev.indirilenBayt / (1024 * 1024)) / gecenSn) * 10) / 10;
          gorev.mesaj = `İndiriliyor: ${(gorev.indirilenBayt / (1024 * 1024)).toFixed(1)} MB / ${(toplamBayt / (1024 * 1024)).toFixed(1)} MB (%${gorev.yuzde})`;
        }
      }
      await new Promise((resolve, reject) => {
        yazici.end(() => resolve());
        yazici.on('error', reject);
      });
      if (fs.existsSync(hedefDosya)) {
        try { fs.unlinkSync(hedefDosya); } catch (_) {}
      }
      fs.renameSync(geciciDosya, hedefDosya);
    } catch (err) {
      try { yazici.destroy(); } catch (_) {}
      try { if (fs.existsSync(geciciDosya)) fs.unlinkSync(geciciDosya); } catch (_) {}
      throw err;
    }
  }

  async function bilesenKur(bilesenId) {
    const tanimlar = bilesenTanimlari();
    const b = tanimlar.find(x => x.id === bilesenId);
    if (!b) return { success: false, error: `Bilinmeyen bileşen: ${bilesenId}` };

    if (b.kontrolEt()) {
      return { success: true, zatenKurulu: true, id: b.id, ad: b.ad, mesaj: `${b.ad} zaten kurulu ve hazır.` };
    }

    if (aktifGorevler.has(b.id) && aktifGorevler.get(b.id).durum === 'calisiyor') {
      return { success: true, devamEdiyor: true, gorev: aktifGorevler.get(b.id) };
    }

    const gorev = {
      id: b.id,
      ad: b.ad,
      durum: 'calisiyor',
      yuzde: 5,
      indirilenBayt: 0,
      toplamBayt: Math.round((b.tahminiBoyutMB || 1) * 1024 * 1024),
      hizMBsn: 0,
      kaynak: 'kontrol_ediliyor',
      mesaj: `${b.ad} hazırlanıyor...`,
      baslangicZamani: new Date().toISOString()
    };
    aktifGorevler.set(b.id, gorev);

    const yerelKaynak = b.yerelKopyaYolu ? b.yerelKopyaYolu() : null;
    if (yerelKaynak && fs.existsSync(yerelKaynak)) {
      try {
        gorev.kaynak = 'yerel_onbellek';
        gorev.durum = 'kopyalaniyor';
        gorev.yuzde = 50;
        gorev.mesaj = `Bilgisayardaki yerel Mezatron önbelleğinden kopyalanıyor...`;
        if (b.id === 'whisper_server_bin') {
          klasorKopyalaRecursive(yerelKaynak, releaseDir);
        } else if (b.id === 'whisper_vulkan_bin') {
          klasorKopyalaRecursive(yerelKaynak, vulkanDir);
        } else if (b.id === 'plugin_sherpa_onnx') {
          klasorKopyalaRecursive(yerelKaynak, sesTanimaDir);
        } else {
          fs.mkdirSync(path.dirname(b.hedefYol), { recursive: true });
          fs.copyFileSync(yerelKaynak, b.hedefYol);
        }
        gorev.yuzde = 100;
        gorev.durum = 'tamamlandi';
        gorev.mesaj = `✓ ${b.ad} yerel önbellekten 1 saniyede kuruldu!`;
        if (typeof kurulumSonrasiTetikle === 'function') {
          try { kurulumSonrasiTetikle(b.id); } catch (_) {}
        }
        return { success: true, tamamlandi: true, kaynak: 'yerel_onbellek', gorev };
      } catch (err) {
        gorev.durum = 'hata';
        gorev.hata = err.message;
        gorev.mesaj = `⚠️ Yerel kopyalama hatası: ${err.message}`;
        return { success: false, error: err.message, gorev };
      }
    }

    // Arka planda asenkron indirme ve kurulum başlat
    (async () => {
      try {
        gorev.durum = 'indiriliyor';
        if (b.id === 'plugin_sherpa_onnx') {
          gorev.kaynak = 'npm_resmi';
          gorev.yuzde = 25;
          gorev.mesaj = 'Resmi NPM paket deposundan sherpa-onnx-node indiriliyor ve kuruluyor...';
          fs.mkdirSync(sesTanimaDir, { recursive: true });
          const pkgYol = path.join(sesTanimaDir, 'package.json');
          if (!fs.existsSync(pkgYol)) {
            fs.writeFileSync(pkgYol, JSON.stringify({
              name: 'ses-tanima',
              version: '1.0.0',
              commonjs: true,
              dependencies: { 'sherpa-onnx-node': '^2.0.1' }
            }, null, 2), 'utf8');
          }
          await new Promise((resolve, reject) => {
            const p = spawn('cmd.exe', ['/c', 'npm', 'install', 'sherpa-onnx-node', '--no-audit', '--no-fund'], {
              cwd: sesTanimaDir,
              windowsHide: true
            });
            p.on('close', code => code === 0 ? resolve() : reject(new Error(`npm install çıkış kodu: ${code}`)));
            p.on('error', reject);
          });
          gorev.yuzde = 100;
          gorev.durum = 'tamamlandi';
          gorev.mesaj = `✓ ${b.ad} başarıyla indirildi ve kuruldu!`;
        } else {
          // Resmi HTTPS adresinden doğrudan indir
          gorev.kaynak = 'resmi_indirici';
          await urlDenDosyaIndir(b.resmiUrl, b.indirmeDosyaYolu, gorev);

          if (b.id === 'whisper_server_bin' || b.id === 'whisper_vulkan_bin') {
            gorev.durum = 'cikariliyor';
            gorev.yuzde = 95;
            gorev.mesaj = 'İndirilen ZIP paketi klasöre çıkartılıyor...';
            const hedefCikarmaKlasoru = b.id === 'whisper_vulkan_bin' ? vulkanDir : releaseDir;
            fs.mkdirSync(hedefCikarmaKlasoru, { recursive: true });
            await new Promise((resolve, reject) => {
              execFile('powershell.exe', [
                '-NoProfile',
                '-Command',
                `Expand-Archive -Path '${b.indirmeDosyaYolu.replace(/'/g, "''")}' -DestinationPath '${hedefCikarmaKlasoru.replace(/'/g, "''")}' -Force`
              ], { timeout: 60000, windowsHide: true }, err => err ? reject(err) : resolve());
            });
          } else if (b.id === 'vcredist_x64') {
            gorev.durum = 'kuruluyor';
            gorev.yuzde = 95;
            gorev.mesaj = 'Microsoft Visual C++ Redistributable kuruluyor...';
            await new Promise(resolve => {
              execFile(b.indirmeDosyaYolu, ['/install', '/passive', '/norestart'], { timeout: 120000, windowsHide: true }, () => resolve());
            });
          }

          gorev.yuzde = 100;
          gorev.durum = 'tamamlandi';
          gorev.mesaj = `✓ ${b.ad} resmi kaynağından indirildi ve kuruldu!`;
        }

        if (typeof kurulumSonrasiTetikle === 'function') {
          try { kurulumSonrasiTetikle(b.id); } catch (_) {}
        }
      } catch (err) {
        gorev.durum = 'hata';
        gorev.hata = err.message;
        gorev.mesaj = `⚠️ Kurulum hatası: ${err.message}. Resmi indirme bağlantısını kullanarak da indirebilirsiniz.`;
      }
    })();

    return { success: true, baslatildi: true, kaynak: 'resmi_indirici', gorev };
  }

  async function tumEksikleriKur() {
    const durum = await durumRaporu();
    const eksikler = durum.bilesenler.filter(b => !b.kurulu);
    const baslatilanlar = [];
    for (const b of eksikler) {
      const r = await bilesenKur(b.id);
      baslatilanlar.push({ id: b.id, ad: b.ad, sonuc: r });
    }
    return {
      success: true,
      baslatilanSayisi: baslatilanlar.length,
      baslatilanlar
    };
  }

  async function durumRaporu() {
    const donanim = donanimProfiliniCikar();
    const nvidia = await nvidiaKartTespiti();
    const tanimlar = bilesenTanimlari();

    // Donanıma göre akıllı tavsiye belirleme
    let sistemTavsiyesi = '';
    let tavsiyeProfil = 'Evrensel Hibrit Kip';
    if (nvidia && nvidia.vramMB >= 2000) {
      tavsiyeProfil = `Tam GPU Hızlandırmalı Kip (${nvidia.ad})`;
      sistemTavsiyesi = `Bilgisayarınızda ${nvidia.ad} (${nvidia.vramGB} GB VRAM) tespit edildi. "Whisper Large-v3-Turbo", "Silero VAD" ve "3D-Speaker Ses İzi" paketleriyle en üst düzey GPU hızında (0.3 sn) çalıştırmanız tavsiye edilir.`;
    } else if (donanim.toplamRamGB >= 8) {
      tavsiyeProfil = 'Evrensel Vulkan / Çok Çekirdek CPU Kipi';
      sistemTavsiyesi = `Bilgisayarınızda ${donanim.toplamRamGB} GB RAM ve ${donanim.cekirdekSayisi} çekirdekli işlemci tespit edildi. Dahili ekran kartı için "Evrensel GPU (Vulkan)" + "Whisper Large-v3-Turbo" ve "3D-Speaker Ses İzi" paketlerini kurmanız tavsiye edilir.`;
    } else {
      tavsiyeProfil = 'Hafif Ekonomi Kipi (Whisper Base + WebSpeech)';
      sistemTavsiyesi = `Bilgisayarınızda ${donanim.toplamRamGB} GB RAM tespit edildi. İşlemciyi hiç yormadan akıcı çalışması için "Whisper Base Hafif Model (57 MB)" veya "Tarayıcı WebSpeech (0 MB)" kipini kullanmanız tavsiye edilir.`;
    }

    const bilesenler = tanimlar.map(b => {
      const kurulu = Boolean(b.kontrolEt());
      const yerelHazir = !kurulu && Boolean(b.yerelKopyaYolu && b.yerelKopyaYolu());
      const aktifGorev = aktifGorevler.get(b.id) || null;
      let buBilgisayarIcinOnerilen = b.zorunlu;
      if (b.id === 'whisper_vulkan_bin' && !nvidia) buBilgisayarIcinOnerilen = true;
      if (b.id === 'model_whisper_base' && !nvidia && donanim.toplamRamGB < 10) buBilgisayarIcinOnerilen = true;

      let dosyaBoyutuMB = null;
      if (kurulu && fs.existsSync(b.hedefYol)) {
        try {
          const st = fs.statSync(b.hedefYol);
          if (st.isFile()) dosyaBoyutuMB = Math.round((st.size / (1024 * 1024)) * 10) / 10;
        } catch (_) {}
      }

      return {
        id: b.id,
        ad: b.ad,
        kategori: b.kategori,
        zorunlu: b.zorunlu,
        buBilgisayarIcinOnerilen,
        kurulu,
        yerelOnbellekteVar: yerelHazir,
        tahminiBoyutMB: b.tahminiBoyutMB,
        tahminiBoyutMb: b.tahminiBoyutMB,
        kuruluBoyutMB: dosyaBoyutuMB,
        boyutMb: dosyaBoyutuMB || b.tahminiBoyutMB,
        hedefYol: b.hedefYol,
        resmiUrl: b.resmiUrl,
        indirmeUrl: b.resmiUrl,
        resmiSayfaUrl: b.resmiSayfaUrl,
        tavsiyeNedeni: b.tavsiyeNedeni,
        aciklama: `${b.kategori} — Hedef: ${path.basename(b.hedefYol)}`,
        tavsiye: b.tavsiyeNedeni,
        gorev: aktifGorev,
        aktifIslem: aktifGorev
      };
    });

    const zorunluEksikSayisi = bilesenler.filter(b => b.zorunlu && !b.kurulu).length;
    const onerilenEksikSayisi = bilesenler.filter(b => b.buBilgisayarIcinOnerilen && !b.kurulu).length;
    const eksikSayisi = bilesenler.filter(b => !b.kurulu).length;
    const kuruluSayisi = bilesenler.filter(b => b.kurulu).length;

    const tavsiyeler = [
      {
        seviye: zorunluEksikSayisi === 0 ? 'tamam' : 'uyari',
        baslik: zorunluEksikSayisi === 0
          ? '✅ Temel Ses Motoru ve Modeller Hazır'
          : `⚠️ İlk Kurulum Tavsiyesi: ${zorunluEksikSayisi} Önerilen Ses Bileşeni Eksik`,
        mesaj: sistemTavsiyesi
      }
    ];

    return {
      success: true,
      tamHazir: zorunluEksikSayisi === 0,
      zorunluEksikSayisi,
      onerilenEksikSayisi,
      toplamBilesen: bilesenler.length,
      kuruluBilesen: kuruluSayisi,
      ozet: {
        ilkKurulumTamam: zorunluEksikSayisi === 0,
        zorunluEksikSayisi,
        onerilenEksikSayisi,
        eksikSayisi,
        kuruluSayisi,
        toplamBilesen: bilesenler.length
      },
      donanim: {
        ...donanim,
        cpuModel: donanim.islemciModeli,
        cpuCekirdek: donanim.cekirdekSayisi,
        toplamRamGb: donanim.toplamRamGB,
        ekranKartlari: nvidia ? [`${nvidia.ad} (${nvidia.vramGB} GB VRAM)`] : ['Dahili GPU (Intel / AMD)'],
        tavsiyeProfil,
        nvidia
      },
      sistemTavsiyesi,
      tavsiyeler,
      bilesenler
    };
  }

  return {
    durumRaporu,
    bilesenKur,
    tumEksikleriKur
  };
}

module.exports = { kurulumSihirbaziOlustur };
