/**
 * Mezatron AI - Ticari Lisans, 14 Günlük Deneme ve Demo Motoru
 * Geliştirici: Ahmet Aksoy (ahmetaksoy243@gmail.com)
 * 
 * Özellikler:
 * - 14 Günlük Kartlı Tam Sürüm Deneme
 * - 14 Günlük Kartsız Kısıtlı Demo (Maks. 50 Ürün, Excel/Yedek Kapalı)
 * - Saat geri alma (anti-tamper) koruması
 * - AR-GE Şalteri (Ahmet Aksoy onay verene kadar tüm kısıtlamalar pasiftir)
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class TicariDenemeMotoru {
  constructor({ veriKlasoru }) {
    this.veriKlasoru = veriKlasoru;
    this.durumDosyasi = path.join(veriKlasoru, '.ticari_durum.json');
    
    // ⚠️ AR-GE & ÜR-GE ŞALTERİ:
    // Ahmet Aksoy onay verene kadar 'false' kalır.
    // 'false' iken hiçbir süre kısıtlaması, ürün limiti veya kilit devreye girmez!
    this.TICARI_MOD_AKTIF = false;

    this.DENEME_SURESI_GUN = 14;
    this.DEMO_MAKS_URUN = 50;
    this.DESTEK_EPOSTA = 'ahmetaksoy243@gmail.com';
    this.YAPIMCI = 'Ahmet Aksoy';

    this.durum = this.durumYukle();
  }

  durumYukle() {
    try {
      if (fs.existsSync(this.durumDosyasi)) {
        const j = JSON.parse(fs.readFileSync(this.durumDosyasi, 'utf8'));
        return j;
      }
    } catch (_) {}

    // İlk kurulum durumu
    const simdi = new Date().toISOString();
    const baslangic = {
      ilkKurulumTarihi: simdi,
      sonGorulenZaman: Date.now(),
      mod: 'demo', // 'demo' | 'kartli_deneme' | 'abone' | 'omurboyu'
      kartTanimli: false,
      kartMaskeli: '',
      sonOdemeTarihi: null,
      abonelikDurumu: 'aktif',
      saatHilesiTespitEdildi: false,
      argeModu: !this.TICARI_MOD_AKTIF
    };
    this.durumKaydet(baslangic);
    return baslangic;
  }

  durumKaydet(veri) {
    try {
      fs.writeFileSync(this.durumDosyasi, JSON.stringify(veri, null, 2), 'utf8');
      this.durum = veri;
    } catch (_) {}
  }

  // Bilgisayar saatini geri alma kontrolü (Anti-Tamper)
  saatKontrolu() {
    const simdi = Date.now();
    if (this.durum.sonGorulenZaman && simdi < (this.durum.sonGorulenZaman - 3600000)) {
      // 1 saatten fazla geriye gidilmişse hile bayrağı koy
      this.durum.saatHilesiTespitEdildi = true;
      this.durumKaydet(this.durum);
      return false;
    }
    if (simdi > (this.durum.sonGorulenZaman || 0)) {
      this.durum.sonGorulenZaman = simdi;
      this.durumKaydet(this.durum);
    }
    return true;
  }

  durumRaporu(toplamUrunSayisi = 0) {
    this.saatKontrolu();

    // 1) Eğer AR-GE Şalteri kapalıysa (Şu anki geliştirme aşaması):
    if (!this.TICARI_MOD_AKTIF) {
      return {
        ticariModAktif: false,
        argeModu: true,
        kilitli: false,
        kalanGun: 999,
        mod: 'arge_sinirsiz',
        mesaj: '🔬 AR-GE / ÜR-GE Modu (Tüm özellikler sınırsız ve açıktır)',
        krediKartiGerekli: false,
        yapimci: this.YAPIMCI,
        destekEposta: this.DESTEK_EPOSTA
      };
    }

    // 2) Ticari Mod Açıldığında çalışacak mantık:
    const simdi = Date.now();
    const baslangicMs = new Date(this.durum.ilkKurulumTarihi).getTime();
    const gecenGun = Math.floor((simdi - baslangicMs) / (1000 * 60 * 60 * 24));
    const kalanGun = Math.max(0, this.DENEME_SURESI_GUN - gecenGun);

    // Saat hilesi yapılmışsa doğrudan kilitle
    if (this.durum.saatHilesiTespitEdildi) {
      return {
        ticariModAktif: true,
        kilitli: true,
        hataKodu: 'SAAT_HILESI',
        mesaj: 'Sistem saati tahrif edildiği için deneme süresi durduruldu. Lütfen desteğe başvurun.',
        yapimci: this.YAPIMCI,
        destekEposta: this.DESTEK_EPOSTA
      };
    }

    // Abone veya Ömür boyu lisanslı ise
    if (this.durum.mod === 'abone' || this.durum.mod === 'omurboyu') {
      return {
        ticariModAktif: true,
        kilitli: false,
        mod: this.durum.mod,
        kartMaskeli: this.durum.kartMaskeli,
        kalanGun: 30, // abonelik dönemi
        mesaj: '✅ Lisanslı Ticari Sürüm',
        yapimci: this.YAPIMCI,
        destekEposta: this.DESTEK_EPOSTA
      };
    }

    // Kartlı 14 Günlük Tam Sürüm Denemesi
    if (this.durum.mod === 'kartli_deneme') {
      if (kalanGun <= 0) {
        return {
          ticariModAktif: true,
          kilitli: true,
          sureBitti: true,
          mesaj: '14 Günlük tam sürüm deneme süreniz dolmuştur. Aboneliğinizi başlatmak için ödemeyi onaylayın.',
          kartTanimli: true,
          kartMaskeli: this.durum.kartMaskeli,
          yapimci: this.YAPIMCI,
          destekEposta: this.DESTEK_EPOSTA
        };
      }
      return {
        ticariModAktif: true,
        kilitli: false,
        mod: 'kartli_deneme',
        kalanGun,
        mesaj: `⭐ 14 Günlük Tam Sürüm Deneme (Kalan: ${kalanGun} Gün)`,
        tumOzelliklerAcik: true,
        yapimci: this.YAPIMCI,
        destekEposta: this.DESTEK_EPOSTA
      };
    }

    // Kartsız Demo Modu (14 Gün + 50 Ürün Sınırı)
    const urunSiniriDoldu = toplamUrunSayisi >= this.DEMO_MAKS_URUN;
    if (kalanGun <= 0 || urunSiniriDoldu) {
      return {
        ticariModAktif: true,
        kilitli: true,
        sureBitti: kalanGun <= 0,
        urunSiniriDoldu,
        mesaj: kalanGun <= 0 
          ? '14 Günlük ücretsiz demo süreniz doldu.' 
          : `Demo sürüm için ${this.DEMO_MAKS_URUN} ürün limitine ulaştınız.`,
        krediKartiGerekli: true,
        yapimci: this.YAPIMCI,
        destekEposta: this.DESTEK_EPOSTA
      };
    }

    return {
      ticariModAktif: true,
      kilitli: false,
      mod: 'demo',
      kalanGun,
      mevcutUrun: toplamUrunSayisi,
      maksUrun: this.DEMO_MAKS_URUN,
      excelIzni: false,
      cokluTerminalIzni: false,
      mesaj: `🎁 Ücretsiz Demo: ${kalanGun} Gün Kaldı (${toplamUrunSayisi}/${this.DEMO_MAKS_URUN} Ürün)`,
      yapimci: this.YAPIMCI,
      destekEposta: this.DESTEK_EPOSTA
    };
  }

  // Ahmet Aksoy tarafından şalteri açma / kapama
  salterAyarla(aktifMi) {
    this.TICARI_MOD_AKTIF = Boolean(aktifMi);
    this.durum.argeModu = !this.TICARI_MOD_AKTIF;
    this.durumKaydet(this.durum);
    return { success: true, ticariModAktif: this.TICARI_MOD_AKTIF };
  }
}

module.exports = { TicariDenemeMotoru };
