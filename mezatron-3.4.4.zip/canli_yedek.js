// ============================================================================
// CANLI SİSTEM YEDEĞİ VE OTOMATİK ÇÖKME / ELEKTRİK KESİNTİSİ KURTARMA MOTORU
// - Her 5 dakikada bir (veri değiştiyse) ve her 10 yeni siparişte/üründe bir
//   data/yedekler/ altına SHA-256 doğrulamalı canlı gölge yedek (snapshot) alır.
// - Sunucu açılışında elektrik kesintisinden dolayı bozulmuş/yarım kalmış JSON
//   dosyalarını tespit ederse en son sağlam yedekten otomatik onarır; yeniden
//   kurulum gerektirmez.
// - Disk şişmesini önlemek için yalnız son 30 canlı yedeği tutar.
// ============================================================================

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MAKS_YEDEK_SAYISI = 30;
const OTOMATIK_YEDEK_SURESI_MS = 5 * 60 * 1000; // 5 dakika
const ISLEM_SAYACI_ESIGI = 10; // Her 10 siparişte/kayıtta otomatik yedek

function sha256Buffer(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function zamanDamgasi() {
  const d = new Date();
  const pad = (n, l = 2) => String(n).padStart(l, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}_${pad(d.getMilliseconds(), 3)}`;
}

function canliYedekOlustur({ veriKlasoru, dataDir, veriDizin, ekDosyalar = [], projeAdi = 'Mezatron', geriYuklemeSonrasi = null } = {}) {
  const anaKlasor = path.resolve(veriKlasoru || dataDir || veriDizin || path.join(__dirname, 'data'));
  const yedekKlasoru = path.join(anaKlasor, 'yedekler');
  fs.mkdirSync(yedekKlasoru, { recursive: true });

  function yedekAdindanHedefYol(ad, disDosya = false) {
    if (disDosya) {
      return ekDosyalar.find(e => path.basename(e) === ad) || path.join(anaKlasor, ad);
    }
    if (ad.startsWith('envanter__')) {
      const envKlasor = path.join(anaKlasor, 'envanter');
      fs.mkdirSync(envKlasor, { recursive: true });
      return path.join(envKlasor, ad.slice('envanter__'.length));
    }
    return path.join(anaKlasor, ad);
  }

  let sonBilesikImza = '';
  let sonYedekZamani = null;
  let sonYedekAdi = '';
  let islemSayaci = 0;
  const otomatikOnarilanDosyalar = [];

  function izlenenDosyalariBul() {
    const liste = [];
    const taranacakKlasorler = [
      { klasor: anaKlasor, onEk: '' },
      { klasor: path.join(anaKlasor, 'envanter'), onEk: 'envanter__' }
    ];
    for (const { klasor, onEk } of taranacakKlasorler) {
      if (!fs.existsSync(klasor)) continue;
      const adlar = fs.readdirSync(klasor);
      for (const ad of adlar) {
        if (ad === 'yedekler') continue;
        if (ad.endsWith('.tmp') || ad.endsWith('-shm') || ad.endsWith('-wal')) continue;
        if (ad.endsWith('.json') || ad.endsWith('.sqlite') || ad.endsWith('.db') || ad.endsWith('.jsonl')) {
          const tamYol = path.join(klasor, ad);
          try {
            const st = fs.statSync(tamYol);
            if (st.isFile()) liste.push({ ad: onEk + ad, tamYol, boyut: st.size, altKlasor: onEk ? 'envanter' : '' });
          } catch (_) {}
        }
      }
    }
    for (const ekYol of ekDosyalar) {
      if (!ekYol || !fs.existsSync(ekYol)) continue;
      try {
        const st = fs.statSync(ekYol);
        if (st.isFile()) {
          liste.push({ ad: path.basename(ekYol), tamYol: ekYol, boyut: st.size, disDosya: true });
        }
      } catch (_) {}
    }
    return liste;
  }

  function yedekleriListele() {
    if (!fs.existsSync(yedekKlasoru)) return [];
    const klasorler = fs.readdirSync(yedekKlasoru)
      .filter(ad => ad.startsWith('yedek_'))
      .sort()
      .reverse();
    const sonuc = [];
    for (const ad of klasorler) {
      const manifestYolu = path.join(yedekKlasoru, ad, 'manifest.json');
      try {
        if (fs.existsSync(manifestYolu)) {
          const m = JSON.parse(fs.readFileSync(manifestYolu, 'utf8'));
          sonuc.push(m);
        }
      } catch (_) {}
    }
    return sonuc;
  }

  function eskiYedekleriTemizle() {
    try {
      if (!fs.existsSync(yedekKlasoru)) return;
      const klasorler = fs.readdirSync(yedekKlasoru)
        .filter(ad => ad.startsWith('yedek_'))
        .sort()
        .reverse();
      const silinecekler = klasorler.slice(MAKS_YEDEK_SAYISI);
      for (const ad of silinecekler) {
        fs.rmSync(path.join(yedekKlasoru, ad), { recursive: true, force: true });
      }
    } catch (_) {}
  }

  // Sunucu açılışında bozuk JSON veya yarım kalmış .tmp dosyalarını en son sağlam yedekten onarır
  function baslangictaOnarVeDogrula() {
    try {
      if (!fs.existsSync(anaKlasor)) return { onarilan: [] };
      const mevcutYedekler = yedekleriListele();
      if (mevcutYedekler.length > 0) {
        sonYedekZamani = mevcutYedekler[0].tarih;
        sonYedekAdi = mevcutYedekler[0].id;
        sonBilesikImza = mevcutYedekler[0].bilesikImza || '';
      }

      const onarilacakKlasorler = [
        { klasor: anaKlasor, onEk: '' },
        { klasor: path.join(anaKlasor, 'envanter'), onEk: 'envanter__' }
      ];

      for (const { klasor, onEk } of onarilacakKlasorler) {
        if (!fs.existsSync(klasor)) continue;
        const adlar = fs.readdirSync(klasor);
        // 1. Yarım kalmış .tmp dosyası varsa ve asıl dosya yoksa/0 baytsa kontrol et
        for (const ad of adlar) {
          if (!ad.endsWith('.json.tmp')) continue;
          const tmpYol = path.join(klasor, ad);
          const asilAd = ad.slice(0, -4);
          const asilYol = path.join(klasor, asilAd);
          try {
            const tmpIcerik = fs.readFileSync(tmpYol, 'utf8');
            JSON.parse(tmpIcerik);
            let asilSaglam = false;
            if (fs.existsSync(asilYol)) {
              try {
                const asilIcerik = fs.readFileSync(asilYol, 'utf8');
                if (asilIcerik.trim().length > 0) {
                  JSON.parse(asilIcerik);
                  asilSaglam = true;
                }
              } catch (_) {}
            }
            if (!asilSaglam) {
              fs.renameSync(tmpYol, asilYol);
              otomatikOnarilanDosyalar.push({ dosya: onEk + asilAd, kaynak: 'gecici_tmp_kurtarma', tarih: new Date().toISOString() });
            } else {
              fs.unlinkSync(tmpYol);
            }
          } catch (_) {
            try { fs.unlinkSync(tmpYol); } catch (_e) {}
          }
        }

        // 2. JSON dosyalarının bütünlüğünü denetle, bozuksa son sağlam yedekten geri yükle
        const guncelAdlar = fs.readdirSync(klasor).filter(a => a.endsWith('.json'));
        for (const ad of guncelAdlar) {
          const tamYol = path.join(klasor, ad);
          const yedekAdi = onEk + ad;
          let bozuk = false;
          try {
            const icerik = fs.readFileSync(tamYol, 'utf8');
            if (!icerik.trim()) bozuk = true;
            else JSON.parse(icerik);
          } catch (_) {
            bozuk = true;
          }
          if (bozuk && mevcutYedekler.length > 0) {
            for (const yedek of mevcutYedekler) {
              const yedekDosyaYolu = path.join(yedekKlasoru, yedek.id, yedekAdi);
              if (!fs.existsSync(yedekDosyaYolu)) continue;
              try {
                const yedekBuf = fs.readFileSync(yedekDosyaYolu);
                JSON.parse(yedekBuf.toString('utf8'));
                const tmp = tamYol + '.onarim.tmp';
                fs.writeFileSync(tmp, yedekBuf);
                fs.renameSync(tmp, tamYol);
                otomatikOnarilanDosyalar.push({ dosya: yedekAdi, kaynak: yedek.id, tarih: new Date().toISOString() });
                console.log(`[CANLI YEDEK ONARIM] Bozuk ${yedekAdi} dosyası ${yedek.id} yedeğinden otomatik kurtarıldı.`);
                break;
              } catch (_) {}
            }
          }
        }
      }
    } catch (err) {
      console.error('[CANLI YEDEK] Başlangıç doğrulama uyarısı:', err.message);
    }
    return { onarilan: otomatikOnarilanDosyalar };
  }

  function yedekAl({ sebep = 'periyodik', zorla = false } = {}) {
    try {
      const dosyalar = izlenenDosyalariBul();
      if (dosyalar.length === 0 && !zorla) return { success: true, atlandi: true, message: 'Yedeklenecek veri dosyası henüz yok.' };

      const parcalar = [];
      const dosyaBilgileri = [];
      const tamponlar = new Map();

      for (const d of dosyalar) {
        try {
          const buf = fs.readFileSync(d.tamYol);
          const sha256 = sha256Buffer(buf);
          parcalar.push(`${d.ad}:${sha256}`);
          tamponlar.set(d.ad, { buf, disDosya: Boolean(d.disDosya), tamYol: d.tamYol });
          dosyaBilgileri.push({ ad: d.ad, boyut: buf.length, sha256, disDosya: Boolean(d.disDosya) });
        } catch (_) {}
      }

      const bilesikImza = sha256Buffer(Buffer.from(parcalar.sort().join('|'), 'utf8'));
      if (!zorla && sonBilesikImza && bilesikImza === sonBilesikImza) {
        return { success: true, atlandi: true, id: sonYedekAdi, tarih: sonYedekZamani, message: 'Veri değişmediği için mevcut yedek güncel.' };
      }

      let id = `yedek_${zamanDamgasi()}`;
      let hedefKlasor = path.join(yedekKlasoru, id);
      let sira = 1;
      while (fs.existsSync(hedefKlasor)) {
        id = `yedek_${zamanDamgasi()}_${sira++}`;
        hedefKlasor = path.join(yedekKlasoru, id);
      }
      fs.mkdirSync(hedefKlasor, { recursive: true });

      for (const [ad, veri] of tamponlar.entries()) {
        fs.writeFileSync(path.join(hedefKlasor, ad), veri.buf);
      }

      const manifest = {
        id,
        projeAdi,
        tarih: new Date().toISOString(),
        sebep,
        bilesikImza,
        dosyaSayisi: dosyaBilgileri.length,
        toplamBoyutBayt: dosyaBilgileri.reduce((t, d) => t + d.boyut, 0),
        dosyalar: dosyaBilgileri
      };

      const manifestTmp = path.join(hedefKlasor, 'manifest.json.tmp');
      fs.writeFileSync(manifestTmp, JSON.stringify(manifest, null, 2), 'utf8');
      fs.renameSync(manifestTmp, path.join(hedefKlasor, 'manifest.json'));

      sonBilesikImza = bilesikImza;
      sonYedekZamani = manifest.tarih;
      sonYedekAdi = id;
      islemSayaci = 0;

      eskiYedekleriTemizle();
      return { success: true, atlandi: false, ...manifest };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  function yedektenYukle(yedekId) {
    const liste = yedekleriListele();
    const secilen = yedekId ? liste.find(y => y.id === yedekId) : liste[0];
    if (!secilen) return { success: false, error: 'Geri yüklenecek yedek bulunamadı.' };

    // Geri yüklemeden önce mevcut durumun güvenlik yedeğini al
    yedekAl({ sebep: 'geri_yukleme_oncesi', zorla: true });

    const kaynakKlasor = path.join(yedekKlasoru, secilen.id);
    const yuklenenDosyalar = [];
    for (const d of (secilen.dosyalar || [])) {
      if (!d.ad.endsWith('.json')) continue;
      const kaynakYol = path.join(kaynakKlasor, d.ad);
      if (!fs.existsSync(kaynakYol)) continue;
      const hedefYol = yedekAdindanHedefYol(d.ad, Boolean(d.disDosya));
      try {
        const buf = fs.readFileSync(kaynakYol);
        JSON.parse(buf.toString('utf8'));
        const tmp = hedefYol + '.geri.tmp';
        fs.writeFileSync(tmp, buf);
        fs.renameSync(tmp, hedefYol);
        yuklenenDosyalar.push(d.ad);
      } catch (_) {}
    }
    if (typeof geriYuklemeSonrasi === 'function') {
      try { geriYuklemeSonrasi(yuklenenDosyalar); } catch (_) {}
    }
    return {
      success: true,
      yuklenenYedek: secilen.id,
      yedekTarihi: secilen.tarih,
      yuklenenDosyalar
    };
  }

  function islemBildir(sebep = '10_islem_otomatik') {
    islemSayaci += 1;
    if (islemSayaci >= ISLEM_SAYACI_ESIGI) {
      islemSayaci = 0;
      setImmediate(() => yedekAl({ sebep, zorla: false }));
    }
  }

  function durum() {
    const yedekler = yedekleriListele();
    return {
      aktif: true,
      projeAdi,
      yedekKlasoru,
      otomatikPeriyotDakika: OTOMATIK_YEDEK_SURESI_MS / 60000,
      islemEsigi: ISLEM_SAYACI_ESIGI,
      maksYedekSayisi: MAKS_YEDEK_SAYISI,
      toplamYedekSayisi: yedekler.length,
      sonYedekZamani: sonYedekZamani || (yedekler[0] ? yedekler[0].tarih : null),
      sonYedekAdi: sonYedekAdi || (yedekler[0] ? yedekler[0].id : null),
      otomatikOnarilanDosyalar,
      sonYedekler: yedekler.slice(0, 10).map(y => ({
        id: y.id,
        tarih: y.tarih,
        sebep: y.sebep,
        dosyaSayisi: y.dosyaSayisi,
        toplamBoyutKB: Math.round((y.toplamBoyutBayt || 0) / 1024)
      }))
    };
  }

  baslangictaOnarVeDogrula();
  setImmediate(() => yedekAl({ sebep: 'acilis_kontrolu', zorla: false }));

  const zamanlayici = setInterval(() => {
    yedekAl({ sebep: '5dk_periyodik', zorla: false });
  }, OTOMATIK_YEDEK_SURESI_MS);
  if (typeof zamanlayici.unref === 'function') zamanlayici.unref();

  return {
    baslangictaOnarVeDogrula,
    yedekAl,
    yedektenYukle,
    islemBildir,
    durum
  };
}

module.exports = { canliYedekOlustur };
