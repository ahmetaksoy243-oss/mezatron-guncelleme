'use strict';
// Excel dosyasını (xlsx, csv, programın kendi .xls'i) satır satır düz yazıya çevirir.
// Ek paket gerekmez: xlsx bir zip paketidir, Node'un zlib'i ile açılır.

const zlib = require('zlib');

const EN_FAZLA_ACIK = 60 * 1024 * 1024; // açılmış içerik sınırı

function zipDosyalari(buf) {
  // Merkez dizin sonunu bul
  let son = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { son = i; break; }
  }
  if (son < 0) throw new Error('zip-bozuk');
  const adet = buf.readUInt16LE(son + 10);
  let p = buf.readUInt32LE(son + 16);
  const dosyalar = new Map();
  for (let n = 0; n < adet; n++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip-bozuk');
    const yontem = buf.readUInt16LE(p + 10);
    const sikisik = buf.readUInt32LE(p + 20);
    const adUz = buf.readUInt16LE(p + 28);
    const ekUz = buf.readUInt16LE(p + 30);
    const notUz = buf.readUInt16LE(p + 32);
    const yerel = buf.readUInt32LE(p + 42);
    const ad = buf.toString('utf8', p + 46, p + 46 + adUz);
    dosyalar.set(ad, { yontem, sikisik, yerel });
    p += 46 + adUz + ekUz + notUz;
  }
  let toplam = 0;
  return function oku(ad) {
    const d = dosyalar.get(ad);
    if (!d) return null;
    if (buf.readUInt32LE(d.yerel) !== 0x04034b50) throw new Error('zip-bozuk');
    const bas = d.yerel + 30 + buf.readUInt16LE(d.yerel + 26) + buf.readUInt16LE(d.yerel + 28);
    const ham = buf.subarray(bas, bas + d.sikisik);
    const acik = d.yontem === 0 ? ham : (d.yontem === 8 ? zlib.inflateRawSync(ham, { maxOutputLength: EN_FAZLA_ACIK }) : null);
    if (!acik) throw new Error('zip-yontem');
    toplam += acik.length;
    if (toplam > EN_FAZLA_ACIK) throw new Error('cok-buyuk');
    return acik.toString('utf8');
  };
}

function xmlCoz(s) {
  return String(s)
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&amp;/g, '&');
}

function metinParcalari(xml) {
  // <t>..</t> parçalarını birleştir (zengin yazıda birden çok olur)
  return (String(xml).match(/<t(?:\s[^>]*)?>[\s\S]*?<\/t>|<t\s*\/>/g) || [])
    .map(t => xmlCoz(t.replace(/^<t[^>]*>|<\/t>$/g, '').replace(/^<t\s*\/>$/, ''))).join('');
}

function sutunNo(ref) {
  const harf = String(ref || '').replace(/\d+/g, '').toUpperCase();
  let n = 0;
  for (const c of harf) n = n * 26 + (c.charCodeAt(0) - 64);
  return n - 1;
}

function xlsxMetneCevir(buf) {
  const oku = zipDosyalari(buf);
  const ortak = [];
  const ss = oku('xl/sharedStrings.xml');
  if (ss) for (const si of ss.match(/<si>[\s\S]*?<\/si>|<si\/>/g) || []) ortak.push(metinParcalari(si));

  // İlk sayfanın yolu: workbook.xml + rels; olmazsa sheet1.xml
  let sayfaYolu = 'xl/worksheets/sheet1.xml';
  try {
    const wb = oku('xl/workbook.xml') || '';
    const rels = oku('xl/_rels/workbook.xml.rels') || '';
    const ilk = wb.match(/<sheet\b[^>]*r:id="([^"]+)"/);
    if (ilk) {
      const rel = rels.match(new RegExp(`<Relationship\\b[^>]*Id="${ilk[1]}"[^>]*>`));
      const hedef = rel && rel[0].match(/Target="([^"]+)"/);
      if (hedef) sayfaYolu = hedef[1].startsWith('/') ? hedef[1].slice(1) : 'xl/' + hedef[1].replace(/^\.\//, '');
    }
  } catch (_) {}
  const sayfa = oku(sayfaYolu);
  if (!sayfa) throw new Error('sayfa-yok');

  const satirlar = [];
  for (const row of sayfa.match(/<row\b[\s\S]*?<\/row>/g) || []) {
    const hucreler = [];
    let sira = 0;
    for (const c of row.match(/<c\b[^>]*\/>|<c\b[^>]*>[\s\S]*?<\/c>/g) || []) {
      const bas = c.match(/^<c\b[^>]*>/)[0];
      const ref = (bas.match(/\br="([A-Z]+\d+)"/) || [])[1];
      const tur = (bas.match(/\bt="([^"]+)"/) || [])[1] || 'n';
      const idx = ref ? sutunNo(ref) : sira;
      sira = idx + 1;
      const v = (c.match(/<v>([\s\S]*?)<\/v>/) || [])[1];
      let deger = '';
      if (tur === 's') deger = v != null ? (ortak[Number(v)] ?? '') : '';
      else if (tur === 'inlineStr') deger = metinParcalari((c.match(/<is>[\s\S]*?<\/is>/) || [''])[0]);
      else if (tur === 'b') deger = v === '1' ? 'DOĞRU' : (v === '0' ? 'YANLIŞ' : '');
      else if (tur === 'e') deger = '';
      else deger = v != null ? xmlCoz(v) : '';
      hucreler[idx] = String(deger).replace(/[\t\r\n]+/g, ' ').trim();
    }
    for (let i = 0; i < hucreler.length; i++) if (hucreler[i] == null) hucreler[i] = '';
    if (hucreler.some(h => h !== '')) satirlar.push(hucreler.join('\t'));
  }
  return satirlar.join('\n');
}

function yaziMi(metin) {
  if (!metin) return false;
  const ornek = metin.slice(0, 20000);
  let kontrol = 0;
  for (let i = 0; i < ornek.length; i++) {
    const k = ornek.charCodeAt(i);
    if ((k < 32 && k !== 9 && k !== 10 && k !== 13) || k === 0xFFFD) kontrol++;
  }
  return kontrol / ornek.length < 0.01;
}

// buf: dosyanın baytları. Dönüş: { metin } ya da { hata }
function dosyayiMetneCevir(buf) {
  if (!Buffer.isBuffer(buf) || buf.length === 0) return { hata: 'Dosya boş.' };
  if (buf.length > 25 * 1024 * 1024) return { hata: 'Dosya çok büyük (en çok 25 MB).' };
  if (buf.readUInt32LE(0) === 0x04034b50) {
    try {
      const metin = xlsxMetneCevir(buf);
      return metin.trim() ? { metin } : { hata: 'Excel dosyasının ilk sayfası boş.' };
    } catch (e) {
      return { hata: 'Excel dosyası okunamadı. Dosyayı Excel\'de açıp "Farklı Kaydet → Excel Çalışma Kitabı (.xlsx)" ile yeniden kaydedin.' };
    }
  }
  if (buf.length >= 8 && buf.readUInt32BE(0) === 0xD0CF11E0) {
    return { hata: 'Bu eski .xls biçimi okunamıyor. Dosyayı Excel\'de açıp "Farklı Kaydet → Excel Çalışma Kitabı (.xlsx)" ile kaydedip yeniden yükleyin.' };
  }
  let metin = buf.toString('utf8');
  if (metin.includes('�')) {
    try { metin = new TextDecoder('windows-1254').decode(buf); } catch (_) {}
  }
  if (!yaziMi(metin)) return { hata: 'Dosya okunamadı: Excel (.xlsx) ya da CSV dosyası seçin.' };
  return { metin };
}

module.exports = { dosyayiMetneCevir, xlsxMetneCevir, yaziMi };
