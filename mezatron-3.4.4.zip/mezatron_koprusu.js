// Mezatron Entegrasyon Köprüsü
// Sesli Envanter Asistanı bağımsız çalışır; aynı zamanda açık olan Mezatron sunucularına
// (örn. Port 3000 Tıklamalı Sürüm ve Port 3001 Sesli Evrensel Sürüm) envanter, barkod ve canlı ürün aktarabilir.

const fs = require('fs');
const path = require('path');

const VARSAYILAN_HEDEFLER = [
  { ad: 'Mezatron Sürüm 2 (Asistan Tıklamalı - Port 3000)', url: 'http://127.0.0.1:3000', otomatikAktar: true },
  { ad: 'Mezatron Claude Evrensel (Sesli Sürüm - Port 3001)', url: 'http://127.0.0.1:3001', otomatikAktar: true }
];

function kopruOlustur(veriKlasoru) {
  const ayarYolu = path.join(veriKlasoru, 'mezatron-kopru-ayar.json');
  let ayar = { otomatikSenkron: true, hedefler: VARSAYILAN_HEDEFLER, sonAktarimlar: [] };
  try {
    if (fs.existsSync(ayarYolu)) {
      const okunan = JSON.parse(fs.readFileSync(ayarYolu, 'utf8'));
      if (okunan && Array.isArray(okunan.hedefler)) ayar = { ...ayar, ...okunan };
    }
  } catch (_) {}

  function kaydet() {
    try {
      const tmp = ayarYolu + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(ayar, null, 2), 'utf8');
      fs.renameSync(tmp, ayarYolu);
    } catch (_) {}
  }

  async function hedefDurumu(hedef) {
    const temizUrl = String(hedef.url || '').replace(/\/+$/, '');
    const basladi = Date.now();
    try {
      const [urunRes, envRes] = await Promise.all([
        fetch(`${temizUrl}/api/active-product`, { signal: AbortSignal.timeout(1800) }),
        fetch(`${temizUrl}/api/envanter`, { signal: AbortSignal.timeout(1800) })
      ]);
      if (!urunRes.ok) return { ...hedef, acik: false, gecikmeMs: null };
      const aktifUrun = await urunRes.json();
      const envanter = envRes.ok ? await envRes.json() : { kayitlar: [] };
      return {
        ...hedef,
        url: temizUrl,
        acik: true,
        gecikmeMs: Date.now() - basladi,
        aktifUrun: aktifUrun && aktifUrun.isAnnounced ? aktifUrun.itemTitle : null,
        aktifBarkod: (aktifUrun && aktifUrun.barkod) || null,
        envanterUrunSayisi: Array.isArray(envanter.kayitlar) ? envanter.kayitlar.length : 0
      };
    } catch (_) {
      return { ...hedef, url: temizUrl, acik: false, gecikmeMs: null };
    }
  }

  async function durum() {
    const sonuclar = await Promise.all(ayar.hedefler.map(hedefDurumu));
    return {
      otomatikSenkron: Boolean(ayar.otomatikSenkron),
      hedefler: sonuclar,
      acikSunucuSayisi: sonuclar.filter(s => s.acik).length,
      sonAktarimlar: (ayar.sonAktarimlar || []).slice(0, 15)
    };
  }

  async function kaydiHedefeGonder(hedefUrl, kayit, girenOverride) {
    const temizUrl = String(hedefUrl || '').replace(/\/+$/, '');
    const gonderilecek = {
      giren: girenOverride || kayit.giren || 'Sesli Envanter Asistanı',
      urun: kayit.urun,
      fiyat: kayit.fiyat,
      barkod: kayit.barkod || '',
      satirlar: (kayit.satirlar || []).map(s => ({
        renk: s.renk || '',
        beden: s.beden || '',
        adet: Number(s.adet) || 1,
        barkod: s.barkod || ''
      })),
      soz: kayit.soz || '',
      ekle: true
    };
    const res = await fetch(`${temizUrl}/api/envanter/kaydet`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(gonderilecek),
      signal: AbortSignal.timeout(4000)
    });
    const yanit = await res.json();
    // Eğer aynı ürün zaten varsa üstüne ekleme / güncelleme yap
    if (res.status === 409 && yanit && yanit.cift && yanit.mevcut) {
      const res2 = await fetch(`${temizUrl}/api/envanter/kaydet`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...gonderilecek,
          id: yanit.mevcut.id,
          surum: yanit.mevcut.surum,
          ekle: false
        }),
        signal: AbortSignal.timeout(4000)
      });
      return await res2.json();
    }
    return yanit;
  }

  async function kaydiMezatronaAktar(kayit, { zorla = false } = {}) {
    if (!kayit || (!ayar.otomatikSenkron && !zorla)) return { aktarildi: false, sonuclar: [] };
    const sonuclar = [];
    for (const hedef of ayar.hedefler) {
      if (!hedef.otomatikAktar && !zorla) continue;
      try {
        const y = await kaydiHedefeGonder(hedef.url, kayit);
        sonuclar.push({ ad: hedef.ad, url: hedef.url, basarili: Boolean(y && y.success), urun: kayit.urun });
      } catch (err) {
        sonuclar.push({ ad: hedef.ad, url: hedef.url, basarili: false, hata: err.message });
      }
    }
    const basariliSayisi = sonuclar.filter(s => s.basarili).length;
    if (basariliSayisi > 0) {
      ayar.sonAktarimlar = [
        { zaman: new Date().toLocaleTimeString('tr-TR'), urun: kayit.urun, barkod: kayit.barkod || '', basariliSayisi, hedefler: sonuclar },
        ...(ayar.sonAktarimlar || [])
      ].slice(0, 20);
      kaydet();
    }
    return { aktarildi: basariliSayisi > 0, basariliSayisi, sonuclar };
  }

  async function tumEnvanteriSenkronizeEt(kayitlar) {
    const liste = Array.isArray(kayitlar) ? kayitlar : [];
    const rapor = [];
    for (const k of liste) {
      const r = await kaydiMezatronaAktar(k, { zorla: true });
      rapor.push({ urun: k.urun, barkod: k.barkod, ...r });
    }
    return { success: true, urunSayisi: liste.length, rapor };
  }

  async function canliYayinaUrunAc(barkod, hedefUrl) {
    const seciliHedefler = hedefUrl
      ? ayar.hedefler.filter(h => h.url === hedefUrl)
      : ayar.hedefler;
    const sonuclar = [];
    for (const h of seciliHedefler) {
      try {
        const temizUrl = String(h.url || '').replace(/\/+$/, '');
        const res = await fetch(`${temizUrl}/api/active-product/barkod`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ barkod }),
          signal: AbortSignal.timeout(4000)
        });
        const veri = await res.json();
        sonuclar.push({ ad: h.ad, url: temizUrl, basarili: Boolean(veri && veri.success), mesaj: veri.message || veri.error || '' });
      } catch (err) {
        sonuclar.push({ ad: h.ad, url: h.url, basarili: false, mesaj: 'Sunucu kapalı veya ulaşılamadı' });
      }
    }
    return {
      success: sonuclar.some(s => s.basarili),
      barkod,
      sonuclar
    };
  }

  function ayarGuncelle(yeni) {
    if (typeof yeni.otomatikSenkron === 'boolean') ayar.otomatikSenkron = yeni.otomatikSenkron;
    if (Array.isArray(yeni.hedefler)) ayar.hedefler = yeni.hedefler;
    kaydet();
    return ayar;
  }

  return {
    durum,
    kaydiMezatronaAktar,
    tumEnvanteriSenkronizeEt,
    canliYayinaUrunAc,
    ayarGuncelle
  };
}

module.exports = { kopruOlustur };
