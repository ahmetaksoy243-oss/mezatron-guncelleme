// Renk sözlüğü: söz ve yazıdaki renkleri tam kelime olarak bulur. Panel (sipariş rengi) ve ürün girişi (envanter) kullanır.
// Görünen ad -> söyleniş ve yazılışları (Türkçe harfsiz yazım ve sık yazım hataları dahil)
const COLOR_LEXICON = [
  ['SİYAH', ['siyah', 'siyahi', 'siya']],
  ['BEYAZ', ['beyaz', 'beyas', 'bayaz']],
  ['EKRU', ['ekru', 'kırık beyaz', 'kirik beyaz']],
  ['KREM', ['krem']],
  ['BEJ', ['bej']],
  ['VİZON', ['vizon']],
  ['TABA', ['taba', 'camel']],
  ['KAHVERENGİ', ['kahverengi', 'kahve rengi', 'kahve', 'kahferengi']],
  ['LACİVERT', ['lacivert', 'lacivet', 'laci']],
  ['MAVİ', ['mavi']],
  ['BEBE MAVİSİ', ['bebe mavisi']],
  ['SAKS', ['saks', 'saks mavisi']],
  ['İNDİGO', ['indigo']],
  ['PETROL', ['petrol', 'petrol mavisi', 'petrol yeşili']],
  ['YEŞİL', ['yeşil', 'yesil']],
  ['SU YEŞİLİ', ['su yeşili', 'su yesili', 'mint']],
  ['HAKİ', ['haki']],
  ['ZEYTİN YEŞİLİ', ['zeytin yeşili', 'zeytin yesili']],
  ['KIRMIZI', ['kırmızı', 'kirmizi']],
  ['BORDO', ['bordo']],
  ['KİREMİT', ['kiremit']],
  ['PEMBE', ['pembe']],
  ['PUDRA', ['pudra']],
  ['GÜL KURUSU', ['gül kurusu', 'gul kurusu']],
  ['FUŞYA', ['fuşya', 'fusya']],
  ['LİLA', ['lila']],
  ['MOR', ['mor']],
  ['SARI', ['sarı', 'sari']],
  ['HARDAL', ['hardal']],
  ['TURUNCU', ['turuncu', 'oranj']],
  ['SOMON', ['somon']],
  ['GRİ', ['gri']],
  ['ANTRASİT', ['antrasit']],
  ['FÜME', ['füme', 'fume']],
  ['GOLD', ['gold', 'altın rengi']],
  ['GÜMÜŞ', ['gümüş', 'gumus']],
  ['MUHTELİF', ['muhtelif', 'karışık', 'karisik', 'çok renkli', 'cok renkli', 'rengarenk']],
  ['ÇİZGİLİ', ['çizgili', 'cizgili']],
  ['KARELİ', ['kareli', 'ekose', 'ekoseli']],
  ['DESENLİ', ['desenli', 'çiçekli', 'cicekli', 'puantiyeli', 'benekli', 'leopar']]
];
const fs = require('fs');
const path = require('path');

// Rengin ardından gelebilen ekler: "siyahı", "siyahtan", "siyahını", "beyazlardan", "lacivertten", "kırmızıyı"
const COLOR_SUFFIX = /^(?:['’])?(?:lar|ler)?(?:[ıiuü]|y[ıiuü]|n[ıiuü]|[ıiuü]n[ıiuü]|n[ıiuü]n|[ıiuü]n|[ae]|y[ae]|n[ae]|d[ae]|t[ae]|nd[ae]|nd[ae]n|d[ae]n|t[ae]n|s[ıiuü]|s[ıiuü]n[ıiuü]|l[ıiuü])?(?:d[ae]n|t[ae]n|d[ae]|t[ae])?$/u;
const COLOR_VARIANTS = COLOR_LEXICON.flatMap(([ad, yazilislar]) => yazilislar.map(y => ({ ad, y })))
  .sort((a, b) => b.y.length - a.y.length);

const kacir = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// ===== 🎨 RENK_TELAFFUZ_SOZLUGU.md Otomatik Yükleyici & Sıcak Güncelleyici =====
const RENK_SOZLUK_YOLLARI = [
  path.join(__dirname, '..', 'RENK_TELAFFUZ_SOZLUGU.md'),
  path.join(__dirname, 'RENK_TELAFFUZ_SOZLUGU.md'),
  path.join(__dirname, 'public', 'RENK_TELAFFUZ_SOZLUGU.md')
];
let __renkSozlukOnbellek = { mtimeMs: 0, varyantlar: COLOR_VARIANTS };

function guncelRenkVaryantlari() {
  const dosyaYolu = RENK_SOZLUK_YOLLARI.find(p => { try { return fs.existsSync(p); } catch (_) { return false; } });
  if (!dosyaYolu) return __renkSozlukOnbellek.varyantlar;
  try {
    const stat = fs.statSync(dosyaYolu);
    if (stat.mtimeMs === __renkSozlukOnbellek.mtimeMs && __renkSozlukOnbellek.varyantlar.length > 0) {
      return __renkSozlukOnbellek.varyantlar;
    }
    const md = fs.readFileSync(dosyaYolu, 'utf8');
    const birlesikHarita = new Map();
    for (const [ad, yazilislar] of COLOR_LEXICON) {
      birlesikHarita.set(ad, new Set(yazilislar.map(y => y.toLocaleLowerCase('tr-TR').trim())));
    }
    for (const satir of md.split(/\r?\n/)) {
      const m = satir.match(/^\|\s*\*\*(.+?)\*\*\s*\|\s*([^|]+)\|/);
      if (!m) continue;
      const ad = m[1].trim().toLocaleUpperCase('tr-TR');
      if (!birlesikHarita.has(ad)) birlesikHarita.set(ad, new Set());
      const kume = birlesikHarita.get(ad);
      for (const v of m[2].split(',')) {
        const temiz = v.trim().toLocaleLowerCase('tr-TR').replace(/\s+/g, ' ');
        if (temiz.length >= 2) kume.add(temiz);
      }
    }
    const varyantlar = [];
    for (const [ad, kume] of birlesikHarita.entries()) {
      for (const y of kume) varyantlar.push({ ad, y });
    }
    varyantlar.sort((a, b) => b.y.length - a.y.length);
    __renkSozlukOnbellek = { mtimeMs: stat.mtimeMs, varyantlar };
  } catch (_) {}
  return __renkSozlukOnbellek.varyantlar;
}

// Metindeki renkler yerleriyle: [{ ad, bas, son }]. Yerler, harf ve rakam dışındakileri boşluğa çevrilmiş küçük harfli
// metne göredir (normalMetin). haric: renk sanılmaması gereken sözler (ör. sözde geçen müşteri adı: "Pembe Hanım")
function normalMetin(text) {
  return String(text || '').toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}'’]+/gu, ' ');
}

function colorSpans(text, haric = []) {
  let lower = ` ${normalMetin(text)} `;
  for (const ad of haric) {
    for (const w of String(ad || '').toLocaleLowerCase('tr-TR').split(/\s+/u).filter(Boolean)) {
      lower = lower.replace(new RegExp(`(?<=\\s)${kacir(w)}[\\p{L}'’]*(?=\\s)`, 'gu'), m => ' '.repeat(m.length));
    }
  }
  const found = [];
  for (const { ad, y } of guncelRenkVaryantlari()) {
    const desen = new RegExp(`(?<=\\s)${y.replace(/ /g, '\\s+')}([\\p{L}'’]*)(?=\\s)`, 'gu');
    lower = lower.replace(desen, (tum, ek, konum) => {
      if (!COLOR_SUFFIX.test(ek)) return tum;
      found.push({ ad, bas: konum - 1, son: konum - 1 + tum.length });
      return ' '.repeat(tum.length);
    });
  }
  return found.sort((a, b) => a.bas - b.bas);
}

// Metindeki renkler, geçiş sırasıyla, görünen adlarıyla. Tam kelime aranır: "Hakime" HAKİ, "Pembegül" PEMBE değildir.
function colorsInText(text, haric = []) {
  return [...new Set(colorSpans(text, haric).map(f => f.ad))];
}

module.exports = { COLOR_LEXICON, COLOR_SUFFIX, COLOR_VARIANTS, normalMetin, colorSpans, colorsInText };
