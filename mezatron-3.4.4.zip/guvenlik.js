// Sunucu kapısı: kim bağlanabilir, hangi istek kabul edilir.
// Varsayılan: yalnız bu bilgisayar. Ağa açmak için MEZAT_ADRES ve MEZAT_PAROLA birlikte verilir.
const crypto = require('crypto');

const YEREL_ADRESLER = new Set(['127.0.0.1', 'localhost', '::1']);
const YANLIS_DENEME_SINIRI = 10;
const YANLIS_DENEME_SURESI_MS = 60000;

const GUVENLIK_CSP = [
  "default-src 'self' http://127.0.0.1:* http://localhost:* ws://127.0.0.1:* ws://localhost:* data: blob:",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://unpkg.com",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com data:",
  "img-src 'self' data: blob: https: http:",
  "media-src 'self' data: blob: mediastream:",
  "connect-src 'self' http://127.0.0.1:* http://localhost:* ws://127.0.0.1:* ws://localhost:* https:",
  "object-src 'none'",
  "base-uri 'self'",
  "frame-ancestors 'self'"
].join('; ');

function korumaBasliklariniUygula(res) {
  if (!res || typeof res.setHeader !== 'function') return;
  try {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Permissions-Policy', 'microphone=(self), camera=(self), geolocation=()');
    res.setHeader('Content-Security-Policy', GUVENLIK_CSP);
    res.setHeader('X-Mezat-Zirh', 'Aktif-v2.5');
  } catch (_) {}
}

function dinlemeAdresi(ortam = process.env) {
  const istenen = String(ortam.MEZAT_ADRES || '').trim();
  const parola = String(ortam.MEZAT_PAROLA || '');
  if (!istenen || YEREL_ADRESLER.has(istenen)) return { adres: '127.0.0.1', parola, uyari: '' };
  if (!parola) {
    return { adres: '127.0.0.1', parola: '', uyari: `MEZAT_ADRES=${istenen} istendi ama MEZAT_PAROLA yok. Parolasız ağa açılmaz, yalnız bu bilgisayar bağlanabilir.` };
  }
  return { adres: istenen, parola, uyari: '' };
}

function sunucuAdi(hostBasligi) {
  const metin = String(hostBasligi || '').toLowerCase();
  if (metin.startsWith('[')) return metin.slice(1, metin.indexOf(']'));
  return metin.split(':')[0];
}

function ayniParola(gelen, beklenen) {
  const a = crypto.createHash('sha256').update(String(gelen)).digest();
  const b = crypto.createHash('sha256').update(String(beklenen)).digest();
  return crypto.timingSafeEqual(a, b);
}

function kapiOlustur({ adres, parola }) {
  const yanlislar = new Map();

  function baskaSitedenMi(req) {
    const origin = req.headers.origin;
    if (origin === undefined) return req.headers['sec-fetch-site'] === 'cross-site';
    try {
      return new URL(origin).host.toLowerCase() !== String(req.headers.host || '').toLowerCase();
    } catch (err) {
      return true;
    }
  }

  function adresGecerli(req) {
    if (parola) return true;
    return YEREL_ADRESLER.has(sunucuAdi(req.headers.host));
  }

  function parolaKontrol(req) {
    if (!parola) return 'tamam';
    const ip = req.socket.remoteAddress || '';
    const simdi = Date.now();
    const kayit = yanlislar.get(ip);
    if (kayit && simdi - kayit.ilk > YANLIS_DENEME_SURESI_MS) yanlislar.delete(ip);
    if (yanlislar.has(ip) && yanlislar.get(ip).sayi >= YANLIS_DENEME_SINIRI) return 'bekle';
    const baslik = String(req.headers.authorization || '');
    if (!baslik) return 'sor';
    const cozulmus = baslik.startsWith('Basic ') ? Buffer.from(baslik.slice(6), 'base64').toString('utf8') : '';
    if (ayniParola(cozulmus.slice(cozulmus.indexOf(':') + 1), parola)) {
      yanlislar.delete(ip);
      return 'tamam';
    }
    const yeni = yanlislar.get(ip) || { sayi: 0, ilk: simdi };
    yeni.sayi++;
    yanlislar.set(ip, yeni);
    return 'sor';
  }

  function reddet(req, res) {
    const bitir = (kod, mesaj, basliklar = {}) => {
      res.writeHead(kod, { 'Content-Type': 'application/json; charset=utf-8', ...basliklar });
      res.end(JSON.stringify({ success: false, error: mesaj }));
      return true;
    };
    if (!adresGecerli(req)) return bitir(403, 'Bu adres kabul edilmiyor.');
    const durum = parolaKontrol(req);
    if (durum === 'bekle') return bitir(429, 'Çok fazla yanlış parola. Bir dakika sonra deneyin.');
    if (durum === 'sor') return bitir(401, 'Parola gerekli.', { 'WWW-Authenticate': 'Basic realm="Canli Mezat", charset="UTF-8"' });
    if (req.method !== 'GET' && req.method !== 'HEAD' && baskaSitedenMi(req)) return bitir(403, 'Başka siteden gelen istek reddedildi.');
    korumaBasliklariniUygula(res);
    return false;
  }

  return Object.freeze({ adres, parolali: Boolean(parola), reddet, korumaBasliklariniUygula });
}

module.exports = Object.freeze({ dinlemeAdresi, kapiOlustur, sunucuAdi, korumaBasliklariniUygula });
