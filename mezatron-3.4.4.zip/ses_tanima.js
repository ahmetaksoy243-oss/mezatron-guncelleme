// Yayıncının sesini tanıma: yalnız yayıncının sözü sipariş açsın, yanındaki kişi ya da arka plan sesi açmasın.
// Her şey bu bilgisayarda çalışır. Ses saklanmaz; yalnız sesten çıkarılan sayı dizisi (ses izi) veri klasöründe tutulur.
const fs = require('fs');
const path = require('path');
const { ensureAsciiPathBridge, optimalCpuThreads } = require('./evrensel_motor');

const MODEL_DIR = path.join(__dirname, 'motor', 'ses-tanima');
const MODEL_FILE = '3dspeaker_speech_campplus_sv_zh_en_16k-common_advanced.onnx';
const PROFILE_FILE = 'yayinci-ses-izi.json';
const MIN_ENROLL_SECONDS = 4;
const ENROLL_WINDOW_SECONDS = 3;
const MIN_ENROLL_LOUDNESS = 0.003;
// Gerçek mikrofon ölçümü: yayıncı 0,43-0,81, telefondan çalınan video sesleri en çok 0,37
const DEFAULT_THRESHOLD = 0.42;
const MODES = ['engelle', 'isaretle'];

// Kurulu modeli yükler. Kurulu değilse null döner, program ses tanımasız çalışmaya devam eder.
// Türkçe karakterli / boşluklu yollarda C++ fopen çökmemesi için ASCII köprüsü kullanılır.
function loadRealEngine() {
  const safeModelDir = ensureAsciiPathBridge(MODEL_DIR, 'ses_tanima');
  const modelPath = path.join(safeModelDir, MODEL_FILE);
  if (!fs.existsSync(modelPath)) return null;
  try {
    const sherpa = require(path.join(safeModelDir, 'node_modules', 'sherpa-onnx-node'));
    const numThreads = Math.min(4, optimalCpuThreads());
    const extractor = new sherpa.SpeakerEmbeddingExtractor({ model: modelPath, numThreads, provider: 'cpu', debug: 0 });
    return (samples, sampleRate) => {
      const stream = extractor.createStream();
      stream.acceptWaveform({ samples, sampleRate });
      stream.inputFinished();
      if (!extractor.isReady(stream)) return null;
      return Array.from(extractor.compute(stream));
    };
  } catch (err) {
    console.error('[SES-TANIMA] Model yüklenemedi:', err.message);
    return null;
  }
}

function readWav(buffer) {
  if (!buffer || buffer.length < 44 || buffer.toString('latin1', 0, 4) !== 'RIFF' || buffer.toString('latin1', 8, 12) !== 'WAVE') return null;
  let offset = 12;
  let sampleRate = 0;
  while (offset + 8 <= buffer.length) {
    const id = buffer.toString('latin1', offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    const start = offset + 8;
    if (id === 'fmt ') {
      if (buffer.readUInt16LE(start + 2) !== 1 || buffer.readUInt16LE(start + 14) !== 16) return null;
      sampleRate = buffer.readUInt32LE(start + 4);
    } else if (id === 'data' && sampleRate) {
      const count = Math.floor(Math.min(size, buffer.length - start) / 2);
      const samples = new Float32Array(count);
      for (let i = 0; i < count; i++) samples[i] = buffer.readInt16LE(start + i * 2) / 32768;
      return { samples, sampleRate };
    }
    offset = start + size + (size % 2);
  }
  return null;
}

function similarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0;
  let sizeA = 0;
  let sizeB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    sizeA += a[i] * a[i];
    sizeB += b[i] * b[i];
  }
  return sizeA && sizeB ? dot / Math.sqrt(sizeA * sizeB) : 0;
}

function loudness(samples) {
  let sum = 0;
  for (let i = 0; i < samples.length; i++) sum += samples[i] * samples[i];
  return samples.length ? Math.sqrt(sum / samples.length) : 0;
}

function createVoiceIdentity({ dataDir, engine }) {
  const profilePath = path.join(dataDir, PROFILE_FILE);
  let profile = null;
  try {
    if (fs.existsSync(profilePath)) profile = JSON.parse(fs.readFileSync(profilePath, 'utf8'));
  } catch (err) {
    console.error('[SES-TANIMA] Ses izi okunamadı:', err.message);
  }

  const save = () => {
    const temp = profilePath + '.tmp';
    fs.writeFileSync(temp, JSON.stringify(profile), 'utf8');
    fs.renameSync(temp, profilePath);
  };

  function status() {
    return {
      available: Boolean(engine),
      enrolled: Boolean(profile),
      mode: profile ? profile.mode : 'engelle',
      threshold: profile ? profile.threshold : DEFAULT_THRESHOLD,
      enrolledAt: profile ? profile.enrolledAt : null,
      selfScore: profile ? profile.selfScore : null
    };
  }

  function enroll(wavBuffer) {
    if (!engine) return { success: false, action: 'NOT_INSTALLED', message: 'Ses tanıma kurulu değil.' };
    const wav = readWav(wavBuffer);
    if (!wav) return { success: false, action: 'BAD_AUDIO', message: 'Ses kaydı okunamadı.' };
    const seconds = wav.samples.length / wav.sampleRate;
    if (seconds < MIN_ENROLL_SECONDS) return { success: false, action: 'TOO_SHORT', message: `Ses kaydı kısa: en az ${MIN_ENROLL_SECONDS} saniye gerekli.` };
    if (loudness(wav.samples) < MIN_ENROLL_LOUDNESS) return { success: false, action: 'TOO_QUIET', message: 'Ses duyulmadı. Mikrofonu kontrol edip yeniden okuyun.' };

    const windowSize = Math.round(ENROLL_WINDOW_SECONDS * wav.sampleRate);
    const parts = [];
    for (let start = 0; start + windowSize <= wav.samples.length; start += windowSize) {
      const part = engine(wav.samples.subarray(start, start + windowSize), wav.sampleRate);
      if (part) parts.push(part);
    }
    if (parts.length === 0) return { success: false, action: 'BAD_AUDIO', message: 'Sesten ses izi çıkarılamadı.' };

    const vector = parts[0].map((_, i) => parts.reduce((sum, part) => sum + part[i], 0) / parts.length);
    const selfScore = Math.min(...parts.map(part => similarity(part, vector)));
    profile = {
      vector,
      selfScore: Number(selfScore.toFixed(3)),
      enrolledAt: new Date().toISOString(),
      mode: profile ? profile.mode : 'engelle',
      threshold: profile ? profile.threshold : DEFAULT_THRESHOLD
    };
    save();
    return { success: true, action: 'ENROLLED', message: 'Sesiniz tanıtıldı.', identity: status() };
  }

  // Emin olunamayan ses tanınmamış sayılır
  function check(wavBuffer) {
    if (!engine || !profile) return { status: 'KAPALI', blocked: false, flagged: false, score: null };
    let score = 0;
    let seconds = 0;
    try {
      const wav = readWav(wavBuffer);
      if (wav) {
        seconds = wav.samples.length / wav.sampleRate;
        score = similarity(engine(wav.samples, wav.sampleRate), profile.vector);
      }
    } catch (err) {
      console.error('[SES-TANIMA] Ses karşılaştırılamadı:', err.message);
    }
    const recognized = score >= profile.threshold;
    return {
      status: recognized ? 'TANINDI' : 'TANINMADI',
      blocked: !recognized && profile.mode === 'engelle',
      flagged: !recognized && profile.mode === 'isaretle',
      score: Number(score.toFixed(3)),
      seconds: Number(seconds.toFixed(1))
    };
  }

  function update({ mode, threshold, forget }) {
    if (forget) {
      profile = null;
      fs.rmSync(profilePath, { force: true });
      return { success: true, identity: status() };
    }
    if (!profile) return { success: false, message: 'Önce sesinizi tanıtın.', identity: status() };
    if (mode !== undefined) {
      if (!MODES.includes(mode)) return { success: false, message: 'Geçersiz seçim.', identity: status() };
      profile.mode = mode;
    }
    if (threshold !== undefined) {
      const value = Number(threshold);
      if (!(value >= 0.1 && value <= 0.95)) return { success: false, message: 'Benzerlik sınırı 0,1 ile 0,95 arasında olmalı.', identity: status() };
      profile.threshold = value;
    }
    save();
    return { success: true, identity: status() };
  }

  return { status, enroll, check, update };
}

module.exports = { createVoiceIdentity, loadRealEngine, readWav, similarity };
