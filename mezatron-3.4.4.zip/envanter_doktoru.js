// Sesli Envanter & Depo Doktoru
// Depoda söylenen ses kayıtlarının gürültü oranını (SNR dB), ses tanıma güvenini,
// eksik fiyat/beden/ürün adlarını ve irsaliye-sayım farklarını denetler.

const fs = require('fs');
const path = require('path');

function envanterDoktoruOlustur({ veriKlasoru, raporKlasoru, urunDeposu }) {
  const gunlukYolu = path.join(veriKlasoru, 'envanter-ses-gunlugu.jsonl');
  fs.mkdirSync(veriKlasoru, { recursive: true });
  if (raporKlasoru) fs.mkdirSync(raporKlasoru, { recursive: true });

  function olayKaydet(olay) {
    try {
      const kayit = {
        id: 'ESD-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 5).toUpperCase(),
        zaman: new Date().toISOString(),
        saat: new Date().toLocaleTimeString('tr-TR'),
        ...olay
      };
      fs.appendFileSync(gunlukYolu, JSON.stringify(kayit) + '\n', 'utf8');
      return kayit;
    } catch (_) {
      return null;
    }
  }

  function olaylariOku(limit = 200) {
    try {
      if (!fs.existsSync(gunlukYolu)) return [];
      const satirlar = fs.readFileSync(gunlukYolu, 'utf8').split(/\r?\n/).filter(Boolean);
      return satirlar.slice(-limit).map(s => {
        try { return JSON.parse(s); } catch (_) { return null; }
      }).filter(Boolean).reverse();
    } catch (_) {
      return [];
    }
  }

  function analizEt(gun) {
    const hedefGun = gun || urunDeposu.gunAdi();
    const olaylar = olaylariOku(300);
    const envanterKayitlari = urunDeposu.oku(hedefGun) || [];

    const sesOlaylari = olaylar.filter(o => o.tur === 'ses_cozum');
    const gurultuluKayitlar = sesOlaylari.filter(o => o.sesAnalizi && (o.sesAnalizi.gurultuluMu || o.sesAnalizi.snrDb < 12));
    const dusukGuvenliKayitlar = sesOlaylari.filter(o => o.guven && o.guven.enDusukOlasilik != null && o.guven.enDusukOlasilik < 0.65);
    const eksikBilgiliSesler = sesOlaylari.filter(o => !o.urun || !o.satirSayisi);

    const ortSnr = sesOlaylari.length > 0
      ? Number((sesOlaylari.reduce((t, o) => t + ((o.sesAnalizi && o.sesAnalizi.snrDb) || 18), 0) / sesOlaylari.length).toFixed(1))
      : null;
    const ortMotorMs = sesOlaylari.length > 0
      ? Math.round(sesOlaylari.reduce((t, o) => t + (Number(o.motorMs) || 0), 0) / sesOlaylari.length)
      : null;

    const fiyatsizUrunler = envanterKayitlari.filter(k => !k.fiyat || Number(k.fiyat) <= 0);
    const barkodsuzUrunler = envanterKayitlari.filter(k => !k.barkod);
    const irsaliyeFarklari = [];
    envanterKayitlari.forEach(k => {
      (k.satirlar || []).forEach(s => {
        if (s.irsaliyeAdet != null && Number(s.irsaliyeAdet) !== Number(s.adet)) {
          irsaliyeFarklari.push({
            urun: k.urun,
            renk: s.renk || 'Standart',
            beden: s.beden || 'Standart',
            irsaliyeAdet: Number(s.irsaliyeAdet),
            sayilanAdet: Number(s.adet),
            fark: Number(s.adet) - Number(s.irsaliyeAdet)
          });
        }
      });
    });

    const bulgular = [];
    if (gurultuluKayitlar.length > 0) {
      bulgular.push({
        seviye: 'UYARI',
        kategori: 'GÜRÜLTÜLÜ_ORTAM',
        baslik: `${gurultuluKayitlar.length} ses kaydında yüksek depo gürültüsü algılandı`,
        cozum: 'DSP Gürültü Kapısı ve 85-4000 Hz insan sesi filtresi devreye girerek sesi temizledi. Çok gürültülü anlarda telefonu ağza 15-20 cm yaklaştırın.'
      });
    }
    if (dusukGuvenliKayitlar.length > 0) {
      bulgular.push({
        seviye: 'UYARI',
        kategori: 'DUSUK_SES_GUVENI',
        baslik: `${dusukGuvenliKayitlar.length} ses kaydında bazı kelimeler düşük olasılıkla okundu`,
        ornekler: dusukGuvenliKayitlar.slice(0, 5).map(d => ({ metin: d.metin, dusukKelimeler: d.guven && d.guven.dusukKelimeler })),
        cozum: 'Tablodaki ürün adı ve bedenleri kaydetmeden önce gözle kontrol edin.'
      });
    }
    if (fiyatsizUrunler.length > 0) {
      bulgular.push({
        seviye: 'DIKKAT',
        kategori: 'FIYATSIZ_URUN',
        baslik: `${fiyatsizUrunler.length} üründe satış fiyatı henüz girilmemiş`,
        urunler: fiyatsizUrunler.map(u => u.urun),
        cozum: 'Canlı yayında otomatik sipariş açılabilmesi için bu ürünlerin fiyatını tamamlayın.'
      });
    }
    if (irsaliyeFarklari.length > 0) {
      bulgular.push({
        seviye: 'KRITIK',
        kategori: 'IRSALIYE_SAYIM_FARKI',
        baslik: `${irsaliyeFarklari.length} varyantta irsaliye adedi ile depo sayımı uyuşmuyor`,
        farklar: irsaliyeFarklari,
        cozum: 'Tedarikçi irsaliyesi ile fiziki teslimat arasındaki eksik/fazla adetleri tedarikçiye bildirin.'
      });
    }

    const saglikPuani = Math.max(40, 100 - (gurultuluKayitlar.length * 2) - (dusukGuvenliKayitlar.length * 3) - (fiyatsizUrunler.length * 5) - (irsaliyeFarklari.length * 4));

    return {
      gun: hedefGun,
      saglikPuani,
      ozet: {
        toplamSesKaydi: sesOlaylari.length,
        gurultuluKayitSayisi: gurultuluKayitlar.length,
        dusukGuvenSayisi: dusukGuvenliKayitlar.length,
        eksikBilgiliSesSayisi: eksikBilgiliSesler.length,
        ortalamaSnrDb: ortSnr,
        ortalamaMotorMs: ortMotorMs,
        envanterUrunSayisi: envanterKayitlari.length,
        fiyatsizUrunSayisi: fiyatsizUrunler.length,
        barkodsuzUrunSayisi: barkodsuzUrunler.length,
        irsaliyeFarkSayisi: irsaliyeFarklari.length
      },
      bulgular,
      irsaliyeFarklari,
      sonSesKayitlari: sesOlaylari.slice(0, 15)
    };
  }

  function raporYaz(gun) {
    const sonuc = analizEt(gun);
    if (!raporKlasoru) return { sonuc, dosya: null };
    const simdi = new Date();
    const iki = n => String(n).padStart(2, '0');
    const dosyaAdi = `Envanter doktoru ${simdi.getFullYear()}-${iki(simdi.getMonth() + 1)}-${iki(simdi.getDate())} ${iki(simdi.getHours())}-${iki(simdi.getMinutes())}.md`;
    const tamYol = path.join(raporKlasoru, dosyaAdi);

    const md = [
      `# Sesli Envanter & Depo Doktoru Raporu (${sonuc.gun})`,
      ``,
      `- **Depo & Ses Sağlık Puanı:** ${sonuc.saglikPuani} / 100`,
      `- **Toplam Sesli Komut:** ${sonuc.ozet.toplamSesKaydi}`,
      `- **Ortalama Sinyal-Gürültü Oranı (SNR):** ${sonuc.ozet.ortalamaSnrDb != null ? `${sonuc.ozet.ortalamaSnrDb} dB` : 'Veri yok'}`,
      `- **Ortalama Ses Çözümleme Süresi:** ${sonuc.ozet.ortalamaMotorMs != null ? `${sonuc.ozet.ortalamaMotorMs} ms` : 'Veri yok'}`,
      `- **Envanterdeki Ürün Sayısı:** ${sonuc.ozet.envanterUrunSayisi}`,
      ``,
      `## Bulgular ve Öneriler`,
      sonuc.bulgular.length === 0
        ? `- Herhangi bir sorun veya eksiklik tespit edilmedi.`
        : sonuc.bulgular.map(b => `- **[${b.seviye}] ${b.baslik}**\n  - Çözüm: ${b.cozum}`).join('\n'),
      ``
    ].join('\n');

    try { fs.writeFileSync(tamYol, md, 'utf8'); } catch (_) {}
    return { sonuc, dosya: tamYol };
  }

  return {
    olayKaydet,
    olaylariOku,
    analizEt,
    raporYaz
  };
}

module.exports = { envanterDoktoruOlustur };
