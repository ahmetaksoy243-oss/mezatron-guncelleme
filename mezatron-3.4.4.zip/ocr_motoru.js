// ============================================================================
// YEREL GÖRSEL & KAMERA OCR MOTORU (Windows.Media.Ocr + 4-Yönlü Rotasyon + Barkod / Etiket / İrsaliye Okuyucu)
// Cep telefonundan veya bilgisayar kamerasından gelen fotoğraflardaki:
// 1) Barkod numaralarını (MZ-2026-xxxx, MZU-xxxx, CUST-xxx, EAN-13 869...)
// 2) Ürün / Yaka Etiketi yazılarını (Marka, Model, Renk, Beden, Fiyat)
// 3) Sevk İrsaliyesi / Fatura satırlarını
// telefon dikey/yatay/ters tutulsa bile (0°, 90°, 270°, 180° otomatik yön bulma ile)
// internet gerektirmeden doğrudan Windows Yerel Türkçe OCR motoruyla okur.
// ============================================================================

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');

// Kalıcı PowerShell OCR betiği (Çok katmanlı kontrast/ölçek + merkez bant + 4-yönlü rotasyon)
const OCR_PS1_PATH = path.join(os.tmpdir(), 'mezatron_win_ocr_v3.ps1');

const OCR_PS1_CONTENT = `
param([string]$ImagePath)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName System.Drawing
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Foundation.IAsyncOperation\`1, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime]

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1'
})[0]

function Await($WinRtTask, $ResultType) {
  $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  $netTask.Wait(-1) | Out-Null
  return $netTask.Result
}

$lang = New-Object Windows.Globalization.Language('tr')
if (-not [Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($lang)) {
  $ocrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
} else {
  $ocrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
}

function RunOcrOnFile([string]$PathToRead) {
  $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($PathToRead)) ([Windows.Storage.StorageFile])
  $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $ocrResult = Await ($ocrEngine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
  $lines = @()
  foreach ($line in $ocrResult.Lines) {
    $lines += $line.Text
  }
  $stream.Dispose()
  return ($lines -join "\`n")
}

function RenderVariant([System.Drawing.Bitmap]$Src, [int]$X, [int]$Y, [int]$W, [int]$H, [double]$Scale, [double]$Contrast, [string]$Suffix) {
  $dw = [Math]::Max(80, [int]($W * $Scale))
  $dh = [Math]::Max(80, [int]($H * $Scale))
  $dst = New-Object System.Drawing.Bitmap($dw, $dh)
  $grp = [System.Drawing.Graphics]::FromImage($dst)
  $grp.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $rectDst = New-Object System.Drawing.Rectangle(0, 0, $dw, $dh)
  if ($Contrast -gt 1.01) {
    $ia = New-Object System.Drawing.Imaging.ImageAttributes
    $t = [single]((1.0 - $Contrast) / 2.0)
    $c = [single]$Contrast
    $cm = New-Object System.Drawing.Imaging.ColorMatrix
    $cm.Matrix00 = [single](0.30 * $c); $cm.Matrix01 = [single](0.30 * $c); $cm.Matrix02 = [single](0.30 * $c)
    $cm.Matrix10 = [single](0.59 * $c); $cm.Matrix11 = [single](0.59 * $c); $cm.Matrix12 = [single](0.59 * $c)
    $cm.Matrix20 = [single](0.11 * $c); $cm.Matrix21 = [single](0.11 * $c); $cm.Matrix22 = [single](0.11 * $c)
    $cm.Matrix40 = $t; $cm.Matrix41 = $t; $cm.Matrix42 = $t
    $ia.SetColorMatrix($cm)
    $grp.DrawImage($Src, $rectDst, $X, $Y, $W, $H, [System.Drawing.GraphicsUnit]::Pixel, $ia)
    $ia.Dispose()
  } else {
    $grp.DrawImage($Src, $rectDst, $X, $Y, $W, $H, [System.Drawing.GraphicsUnit]::Pixel)
  }
  $grp.Dispose()
  $tmpPath = "$ImagePath.$Suffix.jpg"
  $dst.Save($tmpPath, [System.Drawing.Imaging.ImageFormat]::Jpeg)
  $dst.Dispose()
  try {
    return (RunOcrOnFile $tmpPath)
  } finally {
    try { if ([System.IO.File]::Exists($tmpPath)) { [System.IO.File]::Delete($tmpPath) } } catch {}
  }
}

$text0 = RunOcrOnFile $ImagePath
[Console]::WriteLine("===ROT:0===")
[Console]::WriteLine($text0)

# Çok katmanlı hassas okuma: İri/parlak etiketler için 0.6x yüksek kontrast + Cam şişe orta bant + Küçük yaka etiketi 1.8x
if ($text0 -notmatch '(MZ-\d{4}-\d{3,6}|MZU-[A-Z0-9-]+|IRS-|İRS-)') {
  $srcBmp = $null
  try {
    $srcBmp = [System.Drawing.Bitmap]::FromFile($ImagePath)
    $sw = $srcBmp.Width
    $sh = $srcBmp.Height

    # 1) 0.60x ölçek + dengeli kontrast (yakın çekim parfüm kutuları ve açık renk etiketleri beyazlatmadan okumak için)
    $tEnh = RenderVariant $srcBmp 0 0 $sw $sh 0.60 1.25 'enh'
    [Console]::WriteLine("===ROT:Enh===")
    [Console]::WriteLine($tEnh)

    # 2) Orta yatay bant + orta kontrast (şeffaf/buzlu cam şişe yazıları ve el/masa arka planını ayıklamak için)
    $bx = [int]($sw * 0.08); $by = [int]($sh * 0.24)
    $bw = [int]($sw * 0.84); $bh = [int]($sh * 0.52)
    $tBand = RenderVariant $srcBmp $bx $by $bw $bh 0.75 1.38 'band'
    [Console]::WriteLine("===ROT:Band===")
    [Console]::WriteLine($tBand)

    # 3) Uzak/küçük yaka etiketi için merkez 1.8x büyütme
    if (($text0.Length + $tEnh.Length + $tBand.Length) -lt 40) {
      $cw = [Math]::Max(80, [int]($sw * 0.68))
      $ch = [Math]::Max(80, [int]($sh * 0.68))
      $cx = [int](($sw - $cw) / 2)
      $cy = [int](($sh - $ch) / 2)
      $tCrop = RenderVariant $srcBmp $cx $cy $cw $ch 1.80 1.0 'crop2x'
      [Console]::WriteLine("===ROT:Crop2x===")
      [Console]::WriteLine($tCrop)
    }
  } catch {} finally {
    if ($srcBmp -ne $null) { $srcBmp.Dispose() }
  }

  # 4) Yalnızca düz açılarda anlamlı metin çıkmadıysa 90° ve 270° yan yönleri dene
  $uprightCombined = "$text0 $tEnh $tBand $tCrop".Trim()
  if ($uprightCombined.Length -lt 10) {
    foreach ($rot in @('Rotate90FlipNone', 'Rotate270FlipNone')) {
      $bmp = [System.Drawing.Bitmap]::FromFile($ImagePath)
      $bmp.RotateFlip([System.Drawing.RotateFlipType]::$rot)
      $tmpRot = "$ImagePath.$rot.jpg"
      $bmp.Save($tmpRot, [System.Drawing.Imaging.ImageFormat]::Jpeg)
      $bmp.Dispose()
      try {
        $tRot = RunOcrOnFile $tmpRot
        [Console]::WriteLine("===ROT:$rot===")
        [Console]::WriteLine($tRot)
      } finally {
        try { if ([System.IO.File]::Exists($tmpRot)) { [System.IO.File]::Delete($tmpRot) } } catch {}
      }
    }
  }
}
`;

try {
  fs.writeFileSync(OCR_PS1_PATH, OCR_PS1_CONTENT, 'utf8');
} catch (_) {}

function filigranSatirlariniTemizle(metin) {
  return String(metin || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(s => {
      if (!s) return false;
      if (/MEZATRON\s+PO[ŞS]ET\s+KANIT\s+FOTO[ĞG]RAFI/i.test(s)) return false;
      if (/^[📅🕒]?\s*[ÇC]ekim\s+Zaman[ıi]\s*:/i.test(s)) return false;
      if (/Paketleyen\s*:/i.test(s)) return false;
      return true;
    })
    .join('\n');
}

function ocrMetniniNormalizeEt(hamMetin) {
  return filigranSatirlariniTemizle(hamMetin)
    // "XXI-" -> "XXL", "XI-" -> "XL", "2XI-" -> "2XL", "3XI-" -> "3XL", "zxu-2Xü" -> "2XL", "ZXk-2XL" -> "2XL"
    .replace(/\b(?:zx[ul1iük]|2x[l1iük]|zxl)\b/giu, '2XL')
    .replace(/\b(XX|X|2X|3X|4X)[Iİ1l]\s*[-]?(?=\s|$|[,;:.])/giu, (_, onEk) => `${onEk.toUpperCase()}L`)
    // Barkod başındaki "5" rakamının "S" harfi okunmasını ("S 412345695971", "s 699971") düzelt ki "S" beden sanılmasın
    .replace(/\b[sS]\s+(?=\d{4,14}\b)/g, '5 ')
    // İrsaliye satırında "1-:4" veya "I-:4" olarak okunan "L:4" bedenini düzelt
    .replace(/(?<=\s|^)[1Iİl]\s*-\s*:\s*(\d{1,4})\b/gu, 'L:$1')
    // "İRS-2026-884" -> "IRS-2026-884"
    .replace(/(?<![\p{L}\p{N}])[İIıi]RS\s*-\s*([A-Z0-9\-]+)/gu, 'IRS-$1')
    // Pembe My Voyage kutusundaki "VOYAGIE", "VOYAG", "VOYAGE" ve Parfüm Mutfağı / Columbia OCR varyasyonlarını düzelt
    .replace(/\b(?:my\s+)?voyag[a-zıiİ]*\b/giu, 'My Voyage')
    .replace(/\b(?:for|far)\s+w[o0a-zıiİ.•\-]{2,9}\b/giu, ' ')
    .replace(/\b(?:[şsçq]?c[o0n][l1iı]?umb[iı1l]a)\b/giu, 'Columbia')
    .replace(/\S*(?:parf[uü]mmutfa|porfummutfa|ummutf|r[ıi]utf)\S*/giu, 'Parfüm Mutfağı')
    // Buzlu/şeffaf cam şişedeki "Miss GIORDANI" OCR yanılgılarını ("IORDANI", "ıÖRDANl", "ICğRDANı", "JICİRDANI", "19RDANl", "ol RDANI", "O DANI", "ı DANI", "Iordfxp") düzelt
    .replace(/(?:^|\b)(?:j[üu]bb\s+)?(?:g?19\s*r\s*da[iınlv1]+|jic[iı]rdan[iı]|ic[ğg\?]?rdan[iıv1l]|[iıIİ1][oöq0]rd\p{L}*|(?:ol|dl|[ıiI1oO])\s+i?rdan[iıt1l]?|[oOıiI1]\s+dan[iı]:?|rdan[iı1l]\b)/giu, 'Miss Giordani Parfüm')
    // ÖNCE fl.oz / ml hacim kalıplarını normalize et ki "1.69" parfüm kodu sanılmasın:
    // "100de338f10z", "IOOmıe338fLoz", "DOmıe3.38floz", "100mlffi8fLoz", "mrie338floz", "3.38 fi.", "338floz" -> 100ml
    .replace(/\b(?:1[0oO]{2}|[iI1l][oO0]{2}|d[oO0])\s*(?:m[lI1ıu!e]{1,3}|de|rıe|rne)\s*3[.,]?38\s*f[lI1i!]\.?\s*[o0]?z\.?/giu, '100ml')
    .replace(/\S*3[.,]?38\s*f[lI1i!]\.?\s*(?:[o0a]z\.?)?/giu, ' 100ml ')
    // "50 mLe 1.69 fi.oz", "50 mue", "50 mLeL69fLoz", "1.69 fi", "10 1.69", "11TL e 1.69 fi" -> 50ml
    .replace(/\b(?:5[0oO]|11?tl)\s*(?:m[lI1ıu!e\-]{1,4}\s*)?(?:e\s*)?l?[1I]?[.,]?69\s*(?:f[lI1i!]\.?\s*(?:[o0a]z\.?|w\.?|u\.?)?)?/giu, '50ml')
    .replace(/\b1[.,]69(?:\s*f[lI1i!]\.?\s*(?:[o0a]z\.?|w\.?|u\.?)?|\b)/giu, '50ml')
    // Parfüm kutularındaki "1.182" / "6.182" (E-182 etiketinin uzaktan okunuşu) kalıbını düzelt (3 haneli kodlar)
    .replace(/(?<=\b(?:fl\.?\s*oz\.?|fi\.?\s*oz\.?|parf[uü]m|clone|50ml|100ml|m[lI1ıe]{1,3})\s*[\r\n\s]+)[16I][.,\-](\d{3})\b/giu, 'E-$1');
}

function metinKalitePuani(metin) {
  const s = ocrMetniniNormalizeEt(metin);
  if (!s) return 0;
  let puan = 0;
  const barkodlar = metindenBarkodlariAyikla(s);
  puan += barkodlar.length * 50;
  // Ünlü ve ünsüz harf dengesi olan gerçek kelimeleri puanla; ters dönmüş (180°) sessiz harf yığınlarını ("WfHMVd", "ııvuıxg") cezalandır
  const kelimeler = s.match(/\p{L}{3,}/gu) || [];
  for (const k of kelimeler) {
    const unluVar = /[aeıioöuüAEIİOÖUÜ]/.test(k);
    const unsuzYigini = /[bcçdfgğhjklmnprsştvyzqxw]{4,}/iu.test(k);
    if (unluVar && !unsuzYigini) puan += 6;
    else puan -= 5;
  }
  // Bilinen tekstil / kozmetik / parfüm / irsaliye / etiket anahtar kelimeleri
  const anahtarlar = s.match(/(?:beden|adet|fiyat|lira|tl|irsaliye|sevk|toplam|siyah|beyaz|mavi|kırmızı|yeşil|sarı|pamuk|keten|ipek|gömlek|kazak|tişört|pantolon|ceket|mont|ayakkabı|elbise|parf[uü]m|mutfa[ğg][ıi]|voyage|night|giordani|extrait|clone|lab|100ml|50ml|\b[ekmuw]-\d{2,4}\b)/giu) || [];
  puan += anahtarlar.length * 28;
  // Rakam grupları
  const rakamlar = s.match(/\d{2,}/g) || [];
  puan += rakamlar.length * 4;
  return puan;
}

function enIyiRotasyonuSec(hamCikti) {
  const ham = String(hamCikti || '');
  const bolumEslesmeleri = [...ham.matchAll(/===ROT:([^=]+)===\r?\n?([\s\S]*?)(?====ROT:|$)/g)];
  if (bolumEslesmeleri.length === 0) return ocrMetniniNormalizeEt(ham);

  const duzSatirlar = [];
  const duzGorulen = new Set();
  const yanAdaylar = [];

  for (const m of bolumEslesmeleri) {
    const etiket = String(m[1] || '').trim();
    const icerik = ocrMetniniNormalizeEt(String(m[2] || '').trim());
    if (!icerik) continue;
    if (etiket === '0' || etiket === 'Enh' || etiket === 'Band' || etiket === 'Crop2x') {
      for (const satir of icerik.split(/\r?\n/)) {
        const temiz = satir.trim();
        if (!temiz) continue;
        const anahtar = temiz.toLocaleLowerCase('tr-TR').replace(/\s+/g, ' ');
        if (!duzGorulen.has(anahtar)) {
          duzGorulen.add(anahtar);
          duzSatirlar.push(temiz);
        }
      }
    } else {
      yanAdaylar.push(icerik);
    }
  }

  const birlesikDuz = duzSatirlar.join('\n').trim();
  const duzPuan = metinKalitePuani(birlesikDuz);

  let enIyiMetin = birlesikDuz;
  let enIyiPuan = duzPuan + (birlesikDuz ? 30 : 0); // Düz yöne öncelik bonusu

  for (const yan of yanAdaylar) {
    const p = metinKalitePuani(yan);
    if (p > enIyiPuan) {
      enIyiPuan = p;
      enIyiMetin = yan;
    }
  }
  return enIyiMetin;
}

function gorseldenMetinOku(dataUrlVeyaBuffer) {
  return new Promise(resolve => {
    try {
      let buf = null;
      if (Buffer.isBuffer(dataUrlVeyaBuffer)) {
        buf = dataUrlVeyaBuffer;
      } else if (typeof dataUrlVeyaBuffer === 'string') {
        const m = dataUrlVeyaBuffer.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/i);
        if (m) buf = Buffer.from(m[2], 'base64');
      }
      if (!buf || buf.length < 64) {
        return resolve({ success: false, metin: '', satirlar: [], barkodlar: [] });
      }

      const geciciDosya = path.join(os.tmpdir(), `mz_ocr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}.jpg`);
      fs.writeFileSync(geciciDosya, buf);

      execFile(
        'powershell.exe',
        ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', OCR_PS1_PATH, '-ImagePath', geciciDosya],
        { timeout: 10000, windowsHide: true, encoding: 'utf8' },
        (err, stdout) => {
          try { fs.unlinkSync(geciciDosya); } catch (_) {}
          const hamCikti = String(stdout || '').trim();
          if (err && !hamCikti.includes('===ROT:')) {
            return resolve({ success: false, metin: '', satirlar: [], barkodlar: [], error: err.message });
          }
          const ham = enIyiRotasyonuSec(hamCikti);
          const satirlar = ham.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
          const barkodlar = metindenBarkodlariAyikla(ham);
          resolve({
            success: true,
            metin: ham,
            satirlar,
            barkodlar,
            ilkBarkod: barkodlar[0] || ''
          });
        }
      );
    } catch (e) {
      resolve({ success: false, metin: '', satirlar: [], barkodlar: [], error: e.message });
    }
  });
}

function metindenBarkodlariAyikla(metin) {
  if (!metin) return [];
  // Web URL'lerini (QR kod reklam linkleri vb.) temizle ki barkod sanılmasın
  const arinmis = filigranSatirlariniTemizle(metin)
    .replace(/https?:\/\/\S+/gi, ' ')
    .replace(/\bwww\.\S+/gi, ' ')
    .replace(/\b\S+\.(?:com|net|org|tr|link|io)\b\S*/gi, ' ');

  const ust = String(arinmis)
    .toUpperCase()
    // OCR'ın 0 yerine O/B/D, 1 yerine I/l, 5 yerine S okuduğu barkod kalıplarını normalize et
    .replace(/\bMZ[\s\-_]*2[0OBD]2[6G][\s\-_]*([0-9OIBDS]{3,5})\b/g, (_, d) =>
      `MZ-2026-${d.replace(/[OBD]/g, '0').replace(/I/g, '1').replace(/S/g, '5')}`
    )
    .replace(/\bMZU[\s\-_]+([A-Z0-9]+)(?:[\s\-_]+([0-9OIBDS]{3,4}))?\b/g, (tam, a, b) =>
      b ? `MZU-${a}-${b.replace(/[OBD]/g, '0').replace(/I/g, '1').replace(/S/g, '5')}` : `MZU-${a}`
    );

  const bulunan = [];
  const ekle = k => {
    const temiz = String(k || '').trim().replace(/\s+/g, '');
    if (!temiz || /^HTTPS?:/i.test(temiz)) return;
    if (temiz && !bulunan.includes(temiz)) bulunan.push(temiz);
  };

  // 1) MZ-2026-xxxx sipariş barkodları
  const mzEslesme = ust.match(/\bMZ-\d{4}-\d{3,5}\b/g) || [];
  mzEslesme.forEach(ekle);

  // 2) MZU-xxxx ürün barkodları
  const mzuEslesme = ust.match(/\bMZU-[A-Z0-9]{2,10}(?:-[A-Z0-9]{1,6})*\b/g) || [];
  mzuEslesme.forEach(ekle);

  // 3) CUST-xxx müşteri kartı barkodları
  const custEslesme = ust.match(/\bCUST-[A-Z0-9]{2,8}\b/g) || [];
  custEslesme.forEach(ekle);

  // 4) EAN-8 / EAN-13 / UPC / SIM seri no sayısal barkodlar (boşluklu "8 684407 640070" veya "684407 645556" dahil)
  const eanMetin = ust
    .replace(/\b(\d)\s+(\d{6})\s+(\d{6})\b/g, '$1$2$3')
    .replace(/\b(6[89]\d{4})\s+(\d{6})\b/g, '8$1$2')
    .replace(/\b(\d)\s+(\d{5})\s+(\d{5})\s+(\d)\b/g, '$1$2$3$4')
    .replace(/\b(\d{4})\s+(\d{4})\b/g, '$1$2');
  const eanEslesme = eanMetin.match(/\b\d{8,16}\b/g) || [];
  eanEslesme.forEach(ekle);

  return bulunan;
}

module.exports = {
  gorseldenMetinOku,
  metindenBarkodlariAyikla
};
