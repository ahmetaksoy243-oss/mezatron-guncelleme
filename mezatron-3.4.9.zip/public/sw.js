// Mezatron Çevrimdışı (Bilgisayarsız) Mobil PWA Service Worker
const CACHE_NAME = 'mezatron-mobil-v20261111_v156';
const ASSETS = [
  '/',
  '/urun-girisi.html',
  '/masaustu.html',
  '/masaustu.js',
  '/masaustu-iki-sira.css',
  '/masaustu-yazi.css',
  '/masaustu-tasma.js',
  '/lisanslar.html',
  '/masaustu.webmanifest',
  '/okut.html',
  '/mezatron-tanitim.html',
  '/urun-girisi.js',
  '/okut.js',
  '/envanter-cozucu.js',
  '/mobil-hibrit.js',
  '/barkod.js',
  '/mic-worklet.js',
  '/MARKA_TELAFFUZ_SOZLUGU.md',
  '/RENK_TELAFFUZ_SOZLUGU.md',
  '/BENI_OKU_KULLANIM_KILAVUZU.md',
  '/assets/mezatron-icon.svg',
  '/assets/mezatron-logo.svg',
  '/assets/mezatron-ai-icon.jpg',
  '/assets/mezatron-ai-horizontal-logo.jpg',
  '/assets/logo-3d/mezatron-3d-amblem.svg',
  '/assets/logo-3d/mezatron-3d-amblem.png',
  '/assets/logo-3d/mezatron-3d-baslik.svg',
  '/assets/logo-3d/mezatron-3d-yazi.svg',
  '/poset-foto.html',
  '/poset-foto.js',
  '/etiket.html',
  '/etiket.js',
  '/urun-girisi.webmanifest'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async cache => {
      for (const url of ASSETS) {
        try {
          const res = await fetch(url, { cache: 'no-store' });
          if (res && res.ok) await cache.put(url, res);
        } catch (_) {}
      }
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || req.url.includes('/api/') || req.url.toLowerCase().includes('.apk')) return;
  // ÖNEMLİ: req.mode === 'navigate' iken fetch(req, { cache: 'no-store' }) Chromium'da TypeError fırlatır
  // ve eski önbelleğe düşmesine sebep olur! Bu yüzden req.url üzerinden ağ öncelikli (network-first) çekiyoruz.
  event.respondWith(
    fetch(req.url, { cache: 'no-store', credentials: 'same-origin' })
      .then(res => {
        if (res && res.ok) {
          const copy1 = res.clone();
          const copy2 = res.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(req, copy1).catch(() => {});
            try {
              const u = new URL(req.url);
              cache.put(u.pathname, copy2).catch(() => {});
            } catch (_) {}
          }).catch(() => {});
        }
        return res;
      })
      .catch(() => caches.match(req, { ignoreSearch: true }))
  );
});
