'use strict';
/**
 * Mezatron — imzalı güncelleme motoru (Şube Asistanı'ndaki yöntemin Mezatron'a uyarlanmışı).
 *
 * Güncelleme = imzalı bir program paketi (zip) + surum.json. İkisi herkese açık güncelleme deposunda durur;
 * asıl kod deposu gizli kalır. Program yalnız bizim gizli anahtarımızla imzalanmış paketi kurar.
 *
 * Yöntem (yerinde güncelleme):
 *   1. surum.json indirilir, imzası açık anahtarla doğrulanır, sürüm karşılaştırılır.
 *   2. Zip indirilir; boyutu ve SHA-256 parmak izi surum.json'dakiyle aynı olmalı.
 *   3. Zip geçici klasöre açılır; içinde server.js ve aynı sürüm numarası olmalı.
 *   4. Değişecek her program dosyasının eski hali guncelleme/onceki/ klasörüne yedeklenir, yeni dosyalar yerine konur.
 *   5. Program yeniden açılır; 90 sn içinde açılmazsa yedek geri konur ve o sürüm bir daha kurulmaz.
 * Dokunulmayanlar: data/ (müşteri verisi), motor/ (ses motorları, Python), node/, reports/, veri/, .apk dosyaları.
 *
 * İmza metni: "mezatron-envanter\n<surum>\n<sha256>\n<boyut>"  (ed25519)
 */
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

const IMZA_ONEKI = 'mezatron-envanter';
const SURUM_DESENI = /^\d{1,4}\.\d{1,4}\.\d{1,5}$/;
// Güncellemenin asla dokunmayacağı yerler (paketin içinde olsalar bile atlanır)
const KORUNAN = [/^data(\/|$)/i, /^motor(\/|$)/i, /^node(\/|$)/i, /^reports(\/|$)/i, /^veri(\/|$)/i, /^guncelleme(\/|$)/i,
  /\.apk$/i, /^Kaldir\.exe$/i, /^Mezatron\.exe$/i, /(^|\/)\.\.(\/|$)/, /^\//, /^[a-z]:/i];

function surumKarsilastir(a, b) {
  const x = String(a || '0').split('.').map(Number); const y = String(b || '0').split('.').map(Number);
  for (let i = 0; i < 3; i += 1) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0) ? 1 : -1; }
  return 0;
}
function imzaMetni(b) { return `${IMZA_ONEKI}\n${b.surum}\n${b.sha256}\n${b.boyut}`; }

function bildirimDogrula(b, acikAnahtarPem) {
  if (!b || typeof b !== 'object') throw new Error('Güncelleme bilgisi okunamadı.');
  if (!SURUM_DESENI.test(String(b.surum || ''))) throw new Error('Güncelleme sürüm numarası geçersiz.');
  if (!/^[a-f0-9]{64}$/.test(String(b.sha256 || ''))) throw new Error('Güncelleme dosyasının parmak izi geçersiz.');
  if (!Number.isInteger(b.boyut) || b.boyut <= 0 || b.boyut > 400 * 1024 * 1024) throw new Error('Güncelleme dosyasının boyutu geçersiz.');
  if (!/^[A-Za-z0-9._-]{1,120}\.zip$/.test(String(b.dosya || ''))) throw new Error('Güncelleme dosya adı geçersiz.');
  let gecerli = false;
  try { gecerli = crypto.verify(null, Buffer.from(imzaMetni(b)), crypto.createPublicKey(acikAnahtarPem), Buffer.from(String(b.imza || ''), 'base64')); } catch (_) { gecerli = false; }
  if (!gecerli) throw new Error('Güncelleme imzası tutmadı. Bu paket Mezatron tarafından hazırlanmamış ya da bozulmuş; kurulmadı.');
  return true;
}

function dosyaSha256(yol) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash('sha256');
    fs.createReadStream(yol).on('error', reject).on('data', d => h.update(d)).on('end', () => resolve(h.digest('hex')));
  });
}

function zipAc(zip, hedef) {
  return new Promise((resolve, reject) => {
    const tar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
    execFile(tar, ['-xf', zip, '-C', hedef], { windowsHide: true, timeout: 10 * 60 * 1000 },
      (e, _o, he) => (e ? reject(new Error(`Paket açılamadı: ${String(he || e.message).slice(0, 300)}`)) : resolve()));
  });
}

function dosyalar(kok, alt = '', liste = []) {
  for (const g of fs.readdirSync(path.join(kok, alt), { withFileTypes: true })) {
    const rel = alt ? `${alt}/${g.name}` : g.name;
    if (g.isDirectory()) dosyalar(kok, rel, liste); else if (g.isFile()) liste.push(rel);
  }
  return liste;
}

const korunuyor = rel => KORUNAN.some(d => d.test(rel));

async function getirMetin(url) {
  const r = await fetch(url, { redirect: 'follow', cache: 'no-store', headers: { 'User-Agent': 'Mezatron-Guncelleme' }, signal: AbortSignal.timeout(20000) });
  if (r.status !== 200) throw new Error(`Güncelleme sunucusu ${r.status} döndü.`);
  const t = await r.text();
  if (t.length > 1e6) throw new Error('Güncelleme bilgisi beklenenden büyük.');
  return t;
}

async function indirDosya(url, hedef) {
  const r = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': 'Mezatron-Guncelleme' }, signal: AbortSignal.timeout(15 * 60 * 1000) });
  if (r.status !== 200) throw new Error(`İndirme ${r.status} döndü.`);
  const gecici = `${hedef}.indiriliyor`;
  await fsp.writeFile(gecici, Buffer.from(await r.arrayBuffer()));
  await fsp.rename(gecici, hedef);
}

class Guncelleyici {
  /**
   * programKlasoru: kurulum klasörü (server.js'nin olduğu yer)
   * acikAnahtar: PEM metni
   */
  constructor({ programKlasoru, acikAnahtar, gunluk, getir = getirMetin, indir = indirDosya }) {
    Object.assign(this, { programKlasoru, acikAnahtar, getir, indir });
    this.gunluk = gunluk || (() => {});
    this.isKlasoru = path.join(programKlasoru, 'guncelleme');
    this.durumDosyasi = path.join(this.isKlasoru, 'durum.json');
  }

  simdikiSurum() {
    try { return JSON.parse(fs.readFileSync(path.join(this.programKlasoru, 'surum.json'), 'utf8')).surum || '0.0.0'; } catch (_) { return '0.0.0'; }
  }

  async durum() { try { return JSON.parse(await fsp.readFile(this.durumDosyasi, 'utf8')); } catch (_) { return {}; } }
  async durumYaz(o) {
    await fsp.mkdir(this.isKlasoru, { recursive: true });
    await fsp.writeFile(`${this.durumDosyasi}.tmp`, JSON.stringify(o, null, 2));
    await fsp.rename(`${this.durumDosyasi}.tmp`, this.durumDosyasi);
  }

  /** Döner: { var, bildirim, simdi } */
  async denetle(bildirimAdresi) {
    const b = JSON.parse(await this.getir(bildirimAdresi));
    bildirimDogrula(b, this.acikAnahtar);
    const simdi = this.simdikiSurum();
    const kotu = (await this.durum()).kotuSurumler || [];
    return { var: surumKarsilastir(b.surum, simdi) > 0 && !kotu.includes(b.surum), bildirim: b, simdi };
  }

  /** İnternetten indirir ve hazırlar (dosyalar henüz değişmez). */
  async indirVeHazirla(bildirimAdresi, b) {
    bildirimDogrula(b, this.acikAnahtar);
    const klasor = path.join(this.isKlasoru, 'indirilen');
    await fsp.mkdir(klasor, { recursive: true });
    const zip = path.join(klasor, b.dosya);
    await this.indir(new URL(b.dosya, bildirimAdresi).toString(), zip);
    return this.hazirla(zip, b);
  }

  /** USB ile gelen paket: zip ve yanındaki surum.json (ya da <zip>.json). */
  async elleHazirla(zipYolu) {
    const adaylar = [`${zipYolu}.json`, zipYolu.replace(/\.zip$/i, '.json'), path.join(path.dirname(zipYolu), 'surum.json')];
    const bd = adaylar.find(y => fs.existsSync(y));
    if (!bd) throw new Error('Paketin yanında imza bilgisi (surum.json) bulunamadı. Zip ile birlikte surum.json dosyasını da aynı klasöre koyun.');
    const b = JSON.parse(await fsp.readFile(bd, 'utf8'));
    bildirimDogrula(b, this.acikAnahtar);
    return this.hazirla(zipYolu, b);
  }

  async hazirla(zip, b) {
    const st = await fsp.stat(zip);
    if (st.size !== b.boyut) throw new Error(`Paket boyutu tutmadı (beklenen ${b.boyut}, gelen ${st.size}). İndirme yarım kalmış olabilir.`);
    if (await dosyaSha256(zip) !== b.sha256) throw new Error('Paketin parmak izi tutmadı; dosya bozuk ya da değiştirilmiş. Kurulmadı.');
    const acik = path.join(this.isKlasoru, 'yeni');
    await fsp.rm(acik, { recursive: true, force: true });
    await fsp.mkdir(acik, { recursive: true });
    await zipAc(zip, acik);
    if (!fs.existsSync(path.join(acik, 'server.js'))) throw new Error('Paketin içinde program (server.js) yok; kurulmadı.');
    let icSurum = '';
    try { icSurum = JSON.parse(fs.readFileSync(path.join(acik, 'surum.json'), 'utf8')).surum; } catch (_) {}
    if (icSurum !== b.surum) throw new Error(`Paketin içindeki sürüm (${icSurum || 'yok'}) imzalı bilgiyle (${b.surum}) aynı değil; kurulmadı.`);
    return { surum: b.surum, notlar: b.notlar || '', klasor: acik };
  }

  /** Hazırlanan dosyaları yerine koyar. Program bu sırada KAPALI olmalı. */
  async uygula(hazir) {
    const kok = this.programKlasoru;
    const yedek = path.join(this.isKlasoru, 'onceki');
    await fsp.rm(yedek, { recursive: true, force: true });
    await fsp.mkdir(yedek, { recursive: true });
    const liste = dosyalar(hazir.klasor).filter(rel => !korunuyor(rel));
    const eklenen = [];
    // Önce hepsinin yedeği (yarıda kalırsa geri alınabilsin)
    for (const rel of liste) {
      const eski = path.join(kok, rel);
      if (fs.existsSync(eski)) { await fsp.mkdir(path.dirname(path.join(yedek, rel)), { recursive: true }); await fsp.copyFile(eski, path.join(yedek, rel)); } else eklenen.push(rel);
    }
    const onceki = this.simdikiSurum();
    const d = await this.durum();
    await this.durumYaz({ ...d, bekleyen: { surum: hazir.surum, onceki, eklenen, zaman: new Date().toISOString() } });
    for (const rel of liste) {
      await fsp.mkdir(path.dirname(path.join(kok, rel)), { recursive: true });
      await fsp.copyFile(path.join(hazir.klasor, rel), path.join(kok, rel));
    }
    this.gunluk(`güncelleme dosyaları yerine kondu: ${onceki} → ${hazir.surum} (${liste.length} dosya)`);
    return { surum: hazir.surum, onceki };
  }

  /** Yeni sürüm açıldı: bekleyen kaydını kapat, geçici klasörleri temizle (yedek bir sonrakine kadar kalır). */
  async onayla() {
    const d = await this.durum();
    if (!d.bekleyen) return;
    await this.durumYaz({ ...d, son: { surum: d.bekleyen.surum, onceki: d.bekleyen.onceki, zaman: new Date().toISOString() }, bekleyen: null });
    await fsp.rm(path.join(this.isKlasoru, 'yeni'), { recursive: true, force: true });
    await fsp.rm(path.join(this.isKlasoru, 'indirilen'), { recursive: true, force: true });
  }

  /** Yeni sürüm açılmadı: yedeği geri koy, eklenen dosyaları sil, sürümü kötü say. */
  async geriAl(sebep) {
    const d = await this.durum();
    const b = d.bekleyen;
    if (!b) return null;
    const kok = this.programKlasoru;
    const yedek = path.join(this.isKlasoru, 'onceki');
    if (fs.existsSync(yedek)) for (const rel of dosyalar(yedek)) {
      await fsp.mkdir(path.dirname(path.join(kok, rel)), { recursive: true });
      await fsp.copyFile(path.join(yedek, rel), path.join(kok, rel));
    }
    for (const rel of b.eklenen || []) if (!korunuyor(rel)) await fsp.rm(path.join(kok, rel), { force: true });
    const kotuSurumler = [...new Set([...(d.kotuSurumler || []), b.surum])].slice(-20);
    await this.durumYaz({ ...d, bekleyen: null, kotuSurumler, geriAlma: { surum: b.surum, onceki: b.onceki, zaman: new Date().toISOString(), sebep: String(sebep || '').slice(0, 300) } });
    this.gunluk(`geri alındı: ${b.surum} → ${b.onceki} (${sebep})`);
    return b.onceki;
  }
}

module.exports = { Guncelleyici, bildirimDogrula, imzaMetni, surumKarsilastir, dosyaSha256, korunuyor, IMZA_ONEKI };
