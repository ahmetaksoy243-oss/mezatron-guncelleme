'use strict';
/**
 * Mezatron kabuğu: tepsi simgesi (Mezatron.exe) bunu penceresiz çalıştırır.
 *  - Programı (server.js) ayrı süreç olarak açar, çökerse artan beklemeyle yeniden açar.
 *  - Güncellemeyi denetler/kurar (guncelleme_motoru.js), yeni sürüm açılmazsa geri alır.
 *  - Tepsi ile satır satır JSON konuşur: tepsi stdin'e komut yazar, kabuk stdout'a olay yazar.
 *    Komutlar: {komut:"denetle",elle}, {komut:"kur"}, {komut:"elle-kur",yol}, {komut:"yeniden"}, {komut:"cik"}
 *    Olaylar:  {tur:"surum"}, {tur:"hazir"}, {tur:"denetim"}, {tur:"guncelleme-var"}, {tur:"bilgi"}, {tur:"kuruldu"},
 *              {tur:"geri-alindi"}, {tur:"hata"}
 *  - Tepsi kapanırsa (stdin biter) program da kapatılır.
 * Geliştirme kopyasında (.git varsa) güncelleme kapalıdır; o klasör git ile güncellenir.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');
const readline = require('readline');
const { Guncelleyici } = require('./guncelleme_motoru');

const KOK = __dirname;
const PORT = Number(process.env.PORT) || 3002;
const GELISTIRME = fs.existsSync(path.join(KOK, '.git'));
const VARSAYILAN_ADRES = 'https://raw.githubusercontent.com/ahmetaksoy243-oss/mezatron-guncelleme/main/surum.json';
const KAYIT = path.join(KOK, 'data', 'kayitlar', 'kabuk.log');

function gunluk(m) {
  try { fs.mkdirSync(path.dirname(KAYIT), { recursive: true }); fs.appendFileSync(KAYIT, `${new Date().toISOString()} ${m}\n`); } catch (_) {}
}
function yolla(o) { try { process.stdout.write(JSON.stringify(o) + '\n'); } catch (_) {} }
// Güncelleme adresi: ortam değişkeni → bu bilgisayara özel ayar (data/guncelleme-ayar.json, güncelleme dokunmaz)
// → surum.json → herkese açık Mezatron güncelleme deposu
function adres() {
  if (process.env.MEZATRON_GUNCELLEME_ADRESI) return process.env.MEZATRON_GUNCELLEME_ADRESI;
  for (const dosya of [path.join(KOK, 'data', 'guncelleme-ayar.json'), path.join(KOK, 'surum.json')]) {
    try { const s = JSON.parse(fs.readFileSync(dosya, 'utf8')); if (s.guncellemeAdresi) return s.guncellemeAdresi; } catch (_) {}
  }
  return VARSAYILAN_ADRES;
}

// ── Program süreci ──
let surec = null; let durdurulsun = false; let cokmeler = []; let disSunucu = false;

function sagMi(sure = 2500) {
  return new Promise(resolve => {
    const r = http.get({ host: '127.0.0.1', port: PORT, path: '/masaustu', timeout: sure }, y => { y.resume(); resolve(y.statusCode === 200); });
    r.on('error', () => resolve(false)); r.on('timeout', () => { r.destroy(); resolve(false); });
  });
}
async function hazirBekle(ms) {
  const bitis = Date.now() + ms;
  while (Date.now() < bitis) { if (await sagMi()) return true; await new Promise(r => setTimeout(r, 1000)); }
  return false;
}

function baslat() {
  durdurulsun = false;
  const logYolu = path.join(KOK, 'data', 'kayitlar', 'sunucu.log');
  fs.mkdirSync(path.dirname(logYolu), { recursive: true });
  try { if (fs.statSync(logYolu).size > 5 * 1024 * 1024) fs.renameSync(logYolu, `${logYolu}.eski`); } catch (_) {}
  const log = fs.openSync(logYolu, 'a');
  fs.writeSync(log, `\n==== ${new Date().toISOString()} program başlıyor\n`);
  surec = spawn(process.execPath, [path.join(KOK, 'server.js')], { cwd: KOK, env: { ...process.env, MEZATRON_KABUK: '1' }, stdio: ['ignore', log, log], windowsHide: true });
  surec.on('exit', kod => {
    try { fs.closeSync(log); } catch (_) {}
    surec = null;
    if (durdurulsun) return;
    const simdi = Date.now();
    cokmeler = [...cokmeler.filter(t => simdi - t < 10 * 60 * 1000), simdi];
    const bekle = Math.min(60000, 2000 * cokmeler.length);
    gunluk(`program kapandı (kod ${kod}); ${bekle / 1000} sn sonra yeniden açılıyor`);
    setTimeout(() => { if (!durdurulsun && !surec) baslat(); }, bekle);
  });
}

function durdur() {
  durdurulsun = true;
  return new Promise(resolve => {
    if (!surec) return resolve();
    const s = surec;
    const zaman = setTimeout(() => { try { s.kill('SIGKILL'); } catch (_) {} resolve(); }, 8000);
    s.once('exit', () => { clearTimeout(zaman); resolve(); });
    try { s.kill(); } catch (_) { resolve(); }
  });
}
async function yenidenBaslat() { await durdur(); cokmeler = []; baslat(); }

// ── Güncelleme ──
const g = new Guncelleyici({ programKlasoru: KOK, acikAnahtar: require('./guncelleme_anahtar'), gunluk });
let mesgul = false; let sonBulunan = null;

async function denetle(elle) {
  if (GELISTIRME) { if (elle) yolla({ tur: 'denetim', var: false, simdi: g.simdikiSurum(), not: 'Bu bir geliştirme kopyası; güncelleme git ile yapılır.' }); return; }
  if (mesgul) { if (elle) yolla({ tur: 'bilgi', baslik: 'Güncelleme', metin: 'Bir güncelleme işi zaten sürüyor.' }); return; }
  try {
    const d = await g.denetle(adres());
    sonBulunan = d.var ? d.bildirim : null;
    if (d.var) yolla({ tur: 'guncelleme-var', surum: d.bildirim.surum, simdi: d.simdi, notlar: d.bildirim.notlar || '', elle: Boolean(elle) });
    else if (elle) yolla({ tur: 'denetim', var: false, simdi: d.simdi });
  } catch (e) {
    gunluk(`denetim hatası: ${e.message}`);
    if (elle) yolla({ tur: 'hata', baslik: 'Güncelleme denetlenemedi', metin: `${e.message}\n\nİnternet yoksa paketi "Güncelleme dosyası yükle (USB)" ile kurabilirsiniz.` });
  }
}

async function kurVeAc(hazirlayici) {
  if (GELISTIRME) { yolla({ tur: 'hata', baslik: 'Güncelleme', metin: 'Bu bir geliştirme kopyası; güncelleme git ile yapılır.' }); return; }
  if (mesgul) return;
  mesgul = true;
  try {
    yolla({ tur: 'bilgi', baslik: 'Güncelleme', metin: 'Güncelleme indiriliyor ve doğrulanıyor…' });
    const hazir = await hazirlayici();
    yolla({ tur: 'bilgi', baslik: 'Güncelleme', metin: `${hazir.surum} kuruluyor; program kısa süre kapanıp açılacak.` });
    await durdur();
    const k = await g.uygula(hazir);
    baslat();
    if (await hazirBekle(90000)) {
      await g.onayla();
      sonBulunan = null;
      yolla({ tur: 'kuruldu', surum: k.surum, onceki: k.onceki });
      yolla({ tur: 'surum', surum: g.simdikiSurum() });
    } else {
      await durdur();
      const onceki = await g.geriAl('yeni sürüm 90 sn içinde açılmadı');
      baslat();
      yolla({ tur: 'geri-alindi', surum: k.surum, onceki });
    }
  } catch (e) {
    gunluk(`kurulum hatası: ${e.message}`);
    yolla({ tur: 'hata', baslik: 'Güncelleme kurulamadı', metin: e.message });
    if (!surec && !disSunucu) baslat();
  } finally { mesgul = false; }
}

async function kur() {
  if (!sonBulunan) { await denetle(false); }
  if (!sonBulunan) { yolla({ tur: 'denetim', var: false, simdi: g.simdikiSurum() }); return; }
  const b = sonBulunan;
  await kurVeAc(() => g.indirVeHazirla(adres(), b));
}

// ── Açılış ──
async function ac() {
  yolla({ tur: 'surum', surum: g.simdikiSurum(), gelistirme: GELISTIRME });
  // Bilgisayar açılmadan önce güncelleme yarıda kaldıysa: açılıyorsa onayla, açılmıyorsa geri al
  const d = await g.durum();
  if (await sagMi()) {
    disSunucu = true;
    gunluk('program zaten açık (dışarıdan başlatılmış); kabuk yalnız izliyor');
  } else {
    baslat();
  }
  const hazir = await hazirBekle(120000);
  if (d.bekleyen && !disSunucu) {
    if (hazir) await g.onayla();
    else { await durdur(); await g.geriAl('yarıda kalan güncelleme açılmadı'); baslat(); }
  }
  yolla({ tur: 'hazir', basarili: hazir, port: PORT });
  gunluk(`kabuk açıldı: sürüm ${g.simdikiSurum()}, ${disSunucu ? 'dış program' : 'program başlatıldı'}, hazır=${hazir}`);
  if (!GELISTIRME) {
    setTimeout(() => denetle(false), 3 * 60 * 1000);
    setInterval(() => denetle(false), 6 * 60 * 60 * 1000);
  }
}

async function kapan() {
  if (!disSunucu) await durdur();
  gunluk('kabuk kapandı');
  process.exit(0);
}

const satirlar = readline.createInterface({ input: process.stdin });
satirlar.on('line', async satir => {
  let k; try { k = JSON.parse(satir); } catch (_) { return; }
  if (k.komut === 'denetle') await denetle(Boolean(k.elle));
  else if (k.komut === 'kur') await kur();
  else if (k.komut === 'elle-kur' && k.yol) await kurVeAc(() => g.elleHazirla(String(k.yol)));
  else if (k.komut === 'yeniden') { if (disSunucu) yolla({ tur: 'bilgi', baslik: 'Mezatron', metin: 'Program bu kabuk dışından açılmış; onu açtığınız yerden yeniden başlatın.' }); else { await yenidenBaslat(); yolla({ tur: 'hazir', basarili: await hazirBekle(90000), port: PORT }); } }
  else if (k.komut === 'cik') await kapan();
});
satirlar.on('close', kapan);
process.on('SIGTERM', kapan);

if (require.main === module) ac();
module.exports = { denetle, kur };
