'use strict';
// Mezatron güncelleme paketlerini doğrulayan AÇIK anahtar (gizli değildir).
// Gizli eşi yalnız paket hazırlayan kişinin flash diskindedir.
module.exports = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAgKJeNTE6MB1f0DTbXWixQ1hVOq5TVidhxUpL3MYBXuk=\n-----END PUBLIC KEY-----\n";
