// ============================================================================
// DÖRTLÜ KONSEY TÜRKÇE/ÇOK DİLLİ ASR MOTORLARI (2026 Yeni Nesil Mimari):
// Whisper large-v3-turbo (Port 3100) ile paralel çalışarak:
//   1. Whisper large-v3-turbo (809M) -> Küresel/yabancı markaları ve rakamları yakalar.
//   2. balbal-v2-manas (313M, Port 3101) -> 2026 Mu-Bench #1 (%8.20 WER) Türkçe+İngilizce FastConformer-CTC + C++ HotwordLM.
//   3. Mihu-STT-v2 (66M, Sherpa C++) -> 2026 Mu-Bench #3 (%10.91 WER) Noktalamalı Zipformer2 Transducer (~190 ms).
//   4. Seda-v0.2 (Sherpa C++) -> İkinci bağımsız Türkçe Zipformer2 Transducer doğrulaması (~170 ms).
// ============================================================================

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const os = require('os');
const { optimalCpuThreads, ensureAsciiPathBridge } = require('./evrensel_motor');

function locateWavPcm(buffer) {
  if (!buffer || buffer.length < 44) return null;
  if (buffer.toString('latin1', 0, 4) !== 'RIFF' || buffer.toString('latin1', 8, 12) !== 'WAVE') return null;
  let offset = 12;
  let sampleRate = 16000;
  let channels = 1;
  let bitsPerSample = 16;
  while (offset + 8 <= buffer.length) {
    const id = buffer.toString('latin1', offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    const start = offset + 8;
    if (id === 'fmt ') {
      const audioFormat = buffer.readUInt16LE(start);
      channels = buffer.readUInt16LE(start + 2);
      sampleRate = buffer.readUInt32LE(start + 4);
      bitsPerSample = buffer.readUInt16LE(start + 14);
      if (audioFormat !== 1 || bitsPerSample !== 16) return null;
    } else if (id === 'data') {
      const validBytes = Math.min(size, buffer.length - start);
      const sampleCount = Math.floor(validBytes / 2);
      return { start, sampleCount, sampleRate, channels };
    }
    offset = start + size + (size % 2);
  }
  return null;
}

// Kurulum paketinde Türkçe motorlar programın kendi klasöründedir (motor/turkce, motor/python).
// C++ motorları boşluklu / Türkçe karakterli yolları açamadığı için ASCII köprüsüyle bağlanır.
// Paket klasörü yoksa (geliştirme bilgisayarı) eskisi gibi ortak klasöre bakılır.
const ESKI_MOTOR_KOKU = 'C:\\Users\\Public\\mezatron_ascii';
const PAKET_TURKCE = path.join(__dirname, 'motor', 'turkce');
const PAKETLI = fs.existsSync(PAKET_TURKCE);
const TURKCE_KOK = PAKETLI ? ensureAsciiPathBridge(PAKET_TURKCE, 'turkce') : ESKI_MOTOR_KOKU;
const SEDA_DIR = path.join(TURKCE_KOK, 'seda_v02');
const MIHU_DIR = path.join(TURKCE_KOK, 'mihu_v2');
const SHERPA_MODULE_PATH = PAKETLI
  ? path.join(ensureAsciiPathBridge(path.join(__dirname, 'motor', 'ses-tanima'), 'ses_tanima'), 'node_modules', 'sherpa-onnx-node')
  : path.join(ESKI_MOTOR_KOKU, 'ses_tanima', 'node_modules', 'sherpa-onnx-node');
const BALBAL_MANAS_DIR = path.join(TURKCE_KOK, 'balbal_v2_manas');
const BALBAL_V2_DIR = path.join(TURKCE_KOK, 'balbal_v2');
const BALBAL_PORT = Number(process.env.BALBAL_PORT) || 3101;
const BALBAL_URL = `http://127.0.0.1:${BALBAL_PORT}`;

const PYTHON_ADAYLARI = [
  path.join(__dirname, 'motor', 'python', 'python.exe'),
  path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Python', 'Python311', 'python.exe'),
  'python'
];

// Türkçe Sözlü Sayı -> Rakam (ITN) Dönüştürücü (Seda-v0.2 ve Mihu-v2 çıktıları için)
const BIRLER = { bir: 1, iki: 2, üç: 3, dört: 4, dörd: 4, beş: 5, altı: 6, yedi: 7, sekiz: 8, dokuz: 9 };
const ONLAR = { on: 10, yirmi: 20, otuz: 30, kırk: 40, elli: 50, altmış: 60, yetmiş: 70, seksen: 80, doksan: 90 };
const SAYI_KELIMELERI = { ...BIRLER, ...ONLAR, yüz: 100, bin: 1000 };
const CAPA_ONCEKI = new Set(['fiyat', 'fiyatı', 'beden', 'bedeni', 'adet', 'adedi', 'tane', 'numara']);

function turkceSayiItn(metin) {
  if (!metin) return '';
  const parcalar = String(metin).trim().split(/\s+/);
  const sonuc = [];
  let i = 0;
  while (i < parcalar.length) {
    const ham = parcalar[i];
    const temiz = ham.replace(/[.,!?;:]+$/g, '').toLocaleLowerCase('tr-TR');
    if (Object.prototype.hasOwnProperty.call(SAYI_KELIMELERI, temiz)) {
      let j = i;
      const kelimeler = [];
      let sonNoktalama = '';
      while (j < parcalar.length) {
        const tHam = parcalar[j];
        const tTemiz = tHam.replace(/[.,!?;:]+$/g, '').toLocaleLowerCase('tr-TR');
        if (Object.prototype.hasOwnProperty.call(SAYI_KELIMELERI, tTemiz)) {
          kelimeler.push(tTemiz);
          sonNoktalama = tHam.slice(tTemiz.length);
          j++;
        } else {
          break;
        }
      }
      const onceki = sonuc.length ? sonuc[sonuc.length - 1].replace(/[.,!?;:]+$/g, '').toLocaleLowerCase('tr-TR') : '';
      const sonraki = j < parcalar.length ? parcalar[j].replace(/[.,!?;:]+$/g, '').toLocaleLowerCase('tr-TR') : '';
      const envanterSayisiMi =
        kelimeler.length >= 2 ||
        Object.prototype.hasOwnProperty.call(ONLAR, kelimeler[0]) ||
        kelimeler[0] === 'yüz' ||
        kelimeler[0] === 'bin' ||
        CAPA_ONCEKI.has(onceki) ||
        ['lira', 'tl', 'adet', 'tane', 'beden', 'numara'].includes(sonraki);

      const belirsizBirMi = kelimeler.length === 1 && kelimeler[0] === 'bir' && !CAPA_ONCEKI.has(onceki) && !['adet', 'tane'].includes(sonraki);
      if (envanterSayisiMi && !belirsizBirMi) {
        const sayilar = [];
        let toplam = 0;
        let grup = 0;
        let yuzVar = false;
        let onVar = false;
        let birVar = false;
        for (const k of kelimeler) {
          if (k === 'bin') {
            if (onVar || birVar || yuzVar) {
              toplam += (grup || 1) * 1000;
              grup = 0;
              yuzVar = false;
              onVar = false;
              birVar = false;
            } else if (toplam > 0) {
              sayilar.push(toplam + grup);
              toplam = 1000;
              grup = 0;
            } else {
              toplam = 1000;
            }
          } else if (k === 'yüz') {
            if (yuzVar || onVar) {
              sayilar.push(toplam + grup);
              toplam = 0;
              grup = 100;
              yuzVar = true;
              onVar = false;
              birVar = false;
            } else {
              grup = (grup || 1) * 100;
              yuzVar = true;
              birVar = false;
            }
          } else if (Object.prototype.hasOwnProperty.call(ONLAR, k)) {
            if (onVar || birVar) {
              sayilar.push(toplam + grup);
              toplam = 0;
              grup = ONLAR[k];
              yuzVar = false;
              onVar = true;
              birVar = false;
            } else {
              grup += ONLAR[k];
              onVar = true;
            }
          } else if (Object.prototype.hasOwnProperty.call(BIRLER, k)) {
            if (birVar) {
              sayilar.push(toplam + grup);
              toplam = 0;
              grup = BIRLER[k];
              yuzVar = false;
              onVar = false;
              birVar = true;
            } else {
              grup += BIRLER[k];
              birVar = true;
            }
          }
        }
        if (toplam + grup > 0) sayilar.push(toplam + grup);
        if (sayilar.length > 0) {
          sonuc.push(`${sayilar.join(', ')}${sonNoktalama}`);
          i = j;
          continue;
        }
      }
    }
    sonuc.push(ham);
    i++;
  }
  return sonuc.join(' ');
}

let sedaRecognizer = null;
let sedaHata = null;
let mihuRecognizer = null;
let mihuHata = null;
let balbalSurec = null;
let balbalHazir = false;

function sedaMotorunuHazirla() {
  if (motorlarKapali) return null;
  if (sedaRecognizer) return sedaRecognizer;
  if (sedaHata) return null;
  try {
    const encoderPath = path.join(SEDA_DIR, 'encoder.int8.onnx');
    const decoderPath = path.join(SEDA_DIR, 'decoder.onnx');
    const joinerPath = path.join(SEDA_DIR, 'joiner.int8.onnx');
    const tokensPath = path.join(SEDA_DIR, 'tokens.txt');
    if (!fs.existsSync(encoderPath) || !fs.existsSync(SHERPA_MODULE_PATH)) {
      sedaHata = 'Seda-v0.2 model dosyaları bulunamadı';
      return null;
    }
    const sherpa = require(SHERPA_MODULE_PATH);
    const numThreads = Math.min(4, optimalCpuThreads());
    sedaRecognizer = new sherpa.OnlineRecognizer({
      featConfig: { sampleRate: 16000, featureDim: 80 },
      modelConfig: {
        transducer: {
          encoder: encoderPath,
          decoder: decoderPath,
          joiner: joinerPath
        },
        tokens: tokensPath,
        numThreads,
        provider: 'cpu',
        debug: 0,
        modelType: 'zipformer2'
      },
      decodingMethod: 'modified_beam_search',
      maxActivePaths: 8
    });
    console.log('[SEDA-V0.2] Sherpa-ONNX Zipformer2 Türkçe motoru belleğe yüklendi.');
    return sedaRecognizer;
  } catch (err) {
    sedaHata = err.message;
    console.warn('[SEDA-V0.2] Yüklenemedi:', err.message);
    return null;
  }
}

function mihuMotorunuHazirla() {
  if (motorlarKapali) return null;
  if (mihuRecognizer) return mihuRecognizer;
  if (mihuHata) return null;
  try {
    const encoderPath = path.join(MIHU_DIR, 'encoder.int8.onnx');
    const decoderPath = path.join(MIHU_DIR, 'decoder.int8.onnx');
    const joinerPath = path.join(MIHU_DIR, 'joiner.int8.onnx');
    const tokensPath = path.join(MIHU_DIR, 'tokens.txt');
    if (!fs.existsSync(encoderPath) || !fs.existsSync(SHERPA_MODULE_PATH)) {
      mihuHata = 'Mihu-STT-v2 model dosyaları bulunamadı';
      return null;
    }
    const sherpa = require(SHERPA_MODULE_PATH);
    const numThreads = Math.min(4, optimalCpuThreads());
    mihuRecognizer = new sherpa.OnlineRecognizer({
      featConfig: { sampleRate: 16000, featureDim: 80 },
      modelConfig: {
        transducer: {
          encoder: encoderPath,
          decoder: decoderPath,
          joiner: joinerPath
        },
        tokens: tokensPath,
        numThreads,
        provider: 'cpu',
        debug: 0,
        modelType: 'zipformer2'
      },
      decodingMethod: 'modified_beam_search',
      maxActivePaths: 8
    });
    console.log('[MIHU-V2] Sherpa-ONNX Mihu-STT-66M-v2 Türkçe motoru belleğe yüklendi.');
    return mihuRecognizer;
  } catch (err) {
    mihuHata = err.message;
    console.warn('[MIHU-V2] Yüklenemedi:', err.message);
    return null;
  }
}

// Bilgisayarda ses tanıma kapatılabilir (az bellekli bilgisayarlar): telefon uygulaması sesi kendisi çözer,
// tarayıcıdan bağlanan telefonlar da telefonun kendi ses tanımasını kullanır.
let motorlarKapali = false;
function motorlarKapaliMi() { return motorlarKapali; }
function motorlariKapat() {
  motorlarKapali = true;
  sedaRecognizer = null;
  mihuRecognizer = null;
  if (balbalSurec) { try { balbalSurec.kill(); } catch (_) {} }
  balbalSurec = null;
  balbalHazir = false;
}
function motorlariAc() {
  motorlarKapali = false;
  sedaHata = null;
  mihuHata = null;
}

function sedaIleCoz(wavBuffer) {
  const rec = sedaMotorunuHazirla();
  if (!rec || !wavBuffer) return { text: '', sureMs: 0 };
  const t0 = Date.now();
  try {
    const info = locateWavPcm(wavBuffer);
    if (!info || info.sampleCount < 800) return { text: '', sureMs: 0 };
    const chunkSamples = Math.round(5.12 * 16000);
    const marginSamples = Math.round(0.5 * 16000);
    const rem = info.sampleCount % chunkSamples;
    const padToChunk = rem ? (chunkSamples - rem) : 0;
    const floatSamples = new Float32Array(info.sampleCount + padToChunk + marginSamples);
    const pcmStart = info.start != null ? info.start : 44;
    for (let i = 0; i < info.sampleCount; i++) {
      floatSamples[i] = wavBuffer.readInt16LE(pcmStart + i * 2) / 32768.0;
    }
    const stream = rec.createStream();
    stream.acceptWaveform({ samples: floatSamples, sampleRate: info.sampleRate || 16000 });
    stream.inputFinished();
    while (rec.isReady(stream)) {
      rec.decode(stream);
    }
    const res = rec.getResult(stream);
    const hamMetin = String((res && res.text) || '').trim();
    const itnMetin = turkceSayiItn(hamMetin);
    return { text: itnMetin, hamText: hamMetin, sureMs: Date.now() - t0 };
  } catch (err) {
    return { text: '', sureMs: Date.now() - t0, error: err.message };
  }
}

function mihuIleCoz(wavBuffer) {
  const rec = mihuMotorunuHazirla();
  if (!rec || !wavBuffer) return { text: '', sureMs: 0 };
  const t0 = Date.now();
  try {
    const info = locateWavPcm(wavBuffer);
    if (!info || info.sampleCount < 800) return { text: '', sureMs: 0 };
    const padSamples = Math.round(0.75 * 16000);
    const floatSamples = new Float32Array(info.sampleCount + padSamples);
    const pcmStart = info.start != null ? info.start : 44;
    for (let i = 0; i < info.sampleCount; i++) {
      floatSamples[i] = wavBuffer.readInt16LE(pcmStart + i * 2) / 32768.0;
    }
    const stream = rec.createStream();
    stream.acceptWaveform({ samples: floatSamples, sampleRate: info.sampleRate || 16000 });
    stream.inputFinished();
    while (rec.isReady(stream)) {
      rec.decode(stream);
    }
    const res = rec.getResult(stream);
    const hamMetin = String((res && res.text) || '').trim();
    const itnMetin = turkceSayiItn(hamMetin);
    return { text: itnMetin, hamText: hamMetin, sureMs: Date.now() - t0 };
  } catch (err) {
    return { text: '', sureMs: Date.now() - t0, error: err.message };
  }
}

async function balbalHazirMi() {
  if (motorlarKapali) return false;
  try {
    const r = await fetch(`${BALBAL_URL}/health`, { signal: AbortSignal.timeout(800) });
    if (r.ok) {
      balbalHazir = true;
      return true;
    }
  } catch (_) {}
  return false;
}

async function balbalMotorunuBaslat() {
  if (motorlarKapali) return false;
  if (await balbalHazirMi()) return true;
  if (balbalSurec) return false;
  const manasPath = path.join(BALBAL_MANAS_DIR, 'model-plain.onnx');
  const v2Path = path.join(BALBAL_V2_DIR, 'model-plain.onnx');
  const scriptPath = path.join(__dirname, 'balbal_server.py');
  if ((!fs.existsSync(manasPath) && !fs.existsSync(v2Path)) || !fs.existsSync(scriptPath)) return false;

  const pythonExe = PYTHON_ADAYLARI.find(p => p === 'python' || fs.existsSync(p)) || 'python';
  try {
    balbalSurec = spawn(pythonExe, [scriptPath], {
      cwd: __dirname,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: {
        ...process.env, PYTHONIOENCODING: 'utf-8', BALBAL_PORT: String(BALBAL_PORT),
        BALBAL_MODEL_DIR: fs.existsSync(manasPath) ? BALBAL_MANAS_DIR : BALBAL_V2_DIR
      }
    });
    // Python bulunamazsa program çökmesin, Balbal'sız devam etsin
    balbalSurec.on('error', err => {
      console.warn('[BALBAL-MANAS] Python başlatılamadı:', err.message);
      balbalSurec = null;
    });
    balbalSurec.stdout.on('data', d => {
      const s = String(d).trim();
      if (s) console.log(s);
    });
    balbalSurec.on('exit', () => {
      balbalSurec = null;
      balbalHazir = false;
    });
    for (let i = 0; i < 24; i++) {
      await new Promise(r => setTimeout(r, 250));
      if (await balbalHazirMi()) return true;
    }
  } catch (err) {
    console.warn('[BALBAL-MANAS] Başlatılamadı:', err.message);
  }
  return false;
}

async function balbalIleCoz(wavBuffer) {
  if (!wavBuffer || motorlarKapali) return { text: '', sureMs: 0 };
  const t0 = Date.now();
  try {
    if (!balbalHazir && !(await balbalHazirMi())) {
      await balbalMotorunuBaslat();
    }
    const r = await fetch(`${BALBAL_URL}/inference`, {
      method: 'POST',
      headers: { 'Content-Type': 'audio/wav' },
      body: wavBuffer,
      signal: AbortSignal.timeout(3500)
    });
    if (!r.ok) return { text: '', sureMs: Date.now() - t0 };
    const j = await r.json();
    return {
      text: String((j && j.text) || '').trim(),
      model: (j && j.model) || 'balbal-v2-manas',
      sureMs: Number(j && j.sureMs) || (Date.now() - t0)
    };
  } catch (err) {
    return { text: '', sureMs: Date.now() - t0, error: err.message };
  }
}

async function paralelTurkceAsrCalistir(wavBuffer) {
  const t0 = Date.now();
  // Hızlı İkili Yerel Ses Motoru: Balbal-v2-Manas (Port 3101) + Seda-v0.2 (Sherpa C++)
  // (Yavaşlatan 3. motor Mihu-v2 devre dışı bırakıldı -> ~300-450 ms anlık yanıt)
  const [balbalSonuc, sedaSonuc] = await Promise.all([
    balbalIleCoz(wavBuffer),
    Promise.resolve().then(() => sedaIleCoz(wavBuffer))
  ]);
  return {
    balbalMetin: (balbalSonuc && balbalSonuc.text) || '',
    balbalModel: (balbalSonuc && balbalSonuc.model) || 'balbal-v2-manas',
    balbalSureMs: (balbalSonuc && balbalSonuc.sureMs) || 0,
    mihuMetin: '',
    mihuSureMs: 0,
    sedaMetin: (sedaSonuc && sedaSonuc.text) || '',
    sedaSureMs: (sedaSonuc && sedaSonuc.sureMs) || 0,
    toplamSureMs: Date.now() - t0
  };
}

function tumTurkceMotorlariIsit() {
  if (motorlarKapali) return;
  setTimeout(() => {
    sedaMotorunuHazirla();
    balbalMotorunuBaslat().catch(() => {});
  }, 50);
}

module.exports = {
  sedaMotorunuHazirla,
  sedaIleCoz,
  mihuMotorunuHazirla,
  mihuIleCoz,
  balbalMotorunuBaslat,
  balbalIleCoz,
  paralelTurkceAsrCalistir,
  tumTurkceMotorlariIsit,
  motorlariKapat,
  motorlariAc,
  motorlarKapaliMi,
  turkceSayiItn
};
