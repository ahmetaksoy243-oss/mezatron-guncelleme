// ============================================================================
// BAĞIMSIZ SESLİ ENVANTER & DEPO ASİSTANI (Mezatron Entegrasyon Köprülü)
// Claude'un yerel ses tanıma (Whisper GPU/CPU + Sherpa-ONNX Ses İzi) ve
// Gürültülü Ortam DSP Ses Analizi (85-4000 Hz Filtre + Gürültü Kapısı + SNR)
// mimarisiyle güçlendirilmiş bağımsız depo/envanter sunucusu.
// ============================================================================

const http = require('http');
// Fabrika barkodu (EAN-8, UPC-12, EAN-13, GTIN-14): hane sayısı ve son rakamdaki kontrol hesabı tutmalı
function gecerliFabrikaBarkodu(kod) {
  const k = String(kod || '').trim();
  if (!/^(?:\d{8}|\d{12,14})$/.test(k)) return false;
  let toplam = 0;
  for (let i = k.length - 2, kat = 3; i >= 0; i--, kat = kat === 3 ? 1 : 3) toplam += Number(k[i]) * kat;
  return (10 - (toplam % 10)) % 10 === Number(k[k.length - 1]);
}

const https = require('https');
const os = require('os');
const fs = require('fs');
const excelOkuyucu = require('./excel_okuyucu');
const path = require('path');
const url = require('url');
const { spawn, execFile, execFileSync } = require('child_process');

const evrenselMotor = require('./evrensel_motor');
const turkceAsrMotorlari = require('./turkce_asr_motorlari');
const urunGirisi = require('./envanter');
const ocrMotoru = require('./ocr_motoru');
const voiceIdentityModule = require('./ses_tanima');
const { guvenOzeti } = require('./olcum');
const { kopruOlustur } = require('./mezatron_koprusu');
const { envanterDoktoruOlustur } = require('./envanter_doktoru');
const { canliYedekOlustur } = require('./canli_yedek');
const { kurulumSihirbaziOlustur } = require('./kurulum_sihirbazi');
const { guncellemeKontroluOlustur } = require('./guncelleme_kontrolu');
const { zirhMotoruOlustur } = require('./zirh_koruma');

const PORT = process.env.PORT !== undefined ? Number(process.env.PORT) : 3002;
const HTTPS_PORT = process.env.HTTPS_PORT !== undefined ? Number(process.env.HTTPS_PORT) : 3442;
const DATA_DIR = process.env.ENVANTER_VERI_KLASORU ? path.resolve(process.env.ENVANTER_VERI_KLASORU) : path.join(__dirname, 'data');
const REPORT_DIR = path.join(__dirname, 'reports', 'envanter doktoru');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(REPORT_DIR, { recursive: true });

function yerelAgAdresleriBul() {
  const sonuc = [];
  try {
    const aglar = os.networkInterfaces() || {};
    for (const [ad, liste] of Object.entries(aglar)) {
      for (const net of (liste || [])) {
        if (net && net.family === 'IPv4' && !net.internal) {
          sonuc.push({ arayuz: ad, ip: net.address });
        }
      }
    }
  } catch (_) {}
  sonuc.sort((a, b) => (/wi-?fi|wlan/i.test(b.arayuz) ? 1 : 0) - (/wi-?fi|wlan/i.test(a.arayuz) ? 1 : 0));
  return sonuc;
}

// Telefon uygulaması (public/Mezatron-Envanter.apk) sürümü: yanındaki .json'dan (derleme betiği yazar);
// boyut ve SHA-256 dosyadan hesaplanır, dosya değişmedikçe yeniden hesaplanmaz.
let apkBilgiOnbellek = null;
function mobilApkBilgisi() {
  const apk = path.join(__dirname, 'public', 'Mezatron-Envanter.apk');
  try {
    const st = fs.statSync(apk);
    const anahtar = `${st.size}:${st.mtimeMs}`;
    if (apkBilgiOnbellek && apkBilgiOnbellek.anahtar === anahtar) return apkBilgiOnbellek.bilgi;
    const ek = JSON.parse(fs.readFileSync(`${apk}.json`, 'utf8'));
    const bilgi = {
      success: true, var: true,
      surumKodu: Number(ek.versionCode) || 0, surumAdi: String(ek.versionName || ''),
      boyut: st.size, sha256: require('crypto').createHash('sha256').update(fs.readFileSync(apk)).digest('hex'),
      adres: '/Mezatron-Envanter.apk'
    };
    apkBilgiOnbellek = { anahtar, bilgi };
    return bilgi;
  } catch (_) {
    return { success: true, var: false };
  }
}

// Telefon uygulaması bu parmak iziyle yalnız bu bilgisayara bağlanır (kare kodla eşlenir)
function tlsParmakIziOku() {
  try { return new crypto.X509Certificate(fs.readFileSync(path.join(DATA_DIR, 'mobil-tls-cert.pem'))).fingerprint256; } catch (_) { return ''; }
}
let httpsAktif = false;
function mobilTlsSertifikasiHazirla() {
  const keyPath = path.join(DATA_DIR, 'mobil-tls-key.pem');
  const certPath = path.join(DATA_DIR, 'mobil-tls-cert.pem');
  try {
    if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
      // Dışarıdan araç (openssl) gerekmez: müşteri bilgisayarında da ilk açılışta kendiliğinden üretilir
      const { sertifikaUret } = require('./tls_sertifika');
      const s = sertifikaUret({ ipler: ['127.0.0.1', ...yerelAgAdresleriBul().map(x => x.ip)] });
      fs.writeFileSync(keyPath, s.key, { mode: 0o600 });
      fs.writeFileSync(certPath, s.cert);
    }
    return { key: fs.readFileSync(keyPath), cert: fs.readFileSync(certPath) };
  } catch (_) {
    return null;
  }
}

const zirhKoruma = zirhMotoruOlustur({
  kokKlasor: __dirname,
  veriKlasoru: DATA_DIR,
  projeAdi: 'Sesli Envanter ve Depo Asistanı (Port 3002)',
  kritikDosyalar: ['server.js', 'guvenlik.js', 'zirh_koruma.js', 'evrensel_motor.js', 'envanter.js', 'mezatron_koprusu.js', 'ses_tanima.js', 'public/urun-girisi.js']
});
setInterval(() => { try { zirhKoruma.butunlukDenetle({ otomatikOlustur: false }); } catch (_) {} }, 60 * 1000).unref();

const canliYedek = canliYedekOlustur({
  veriKlasoru: DATA_DIR,
  projeAdi: 'Sesli Envanter ve Depo Asistanı (Port 3002)',
  geriYuklemeSonrasi: () => {
    try { if (typeof urunDeposu !== 'undefined' && urunDeposu && urunDeposu.yenidenYukle) urunDeposu.yenidenYukle(); } catch (_) {}
  }
});
const kurulumSihirbazi = kurulumSihirbaziOlustur({
  projeKlasoru: __dirname,
  motorKlasoru: process.env.MOTOR_KLASORU ? path.resolve(process.env.MOTOR_KLASORU) : path.join(__dirname, 'motor'),
  kurulumSonrasiTetikle: () => {
    try { if (typeof ensureVoiceEngine === 'function') ensureVoiceEngine(); } catch (_) {}
  }
});
const guncellemeKontrolu = guncellemeKontroluOlustur({
  kokKlasor: __dirname,
  canliYedek
});
const urunDeposu = urunGirisi.deposuKur(DATA_DIR);
const mezatronKoprusu = kopruOlustur(DATA_DIR);
const envanterDoktoru = envanterDoktoruOlustur({ veriKlasoru: DATA_DIR, raporKlasoru: REPORT_DIR, urunDeposu });
const { TicariDenemeMotoru } = require('./ticari_deneme.js');
const ticariMotor = new TicariDenemeMotoru({ veriKlasoru: DATA_DIR });

// ============================================================================
// 4 HANELİ AĞ / MOBİL GÜVENLİK PIN KAPISI (10 Kasım 2026 Raporu Güvenlik Zırhı)
// - Mağaza bilgisayarı (127.0.0.1 / ::1) doğrudan yetkilidir.
// - Wi-Fi / LAN üzerinden bağlanan telefon ve tabletler 4 haneli PIN ile doğrulanır.
// ============================================================================
const crypto = require('crypto');
const PIN_DOSYA_YOLU = path.join(DATA_DIR, 'guvenlik-pin.json');
const ESKI_VARSAYILAN_PIN = '1453'; // Kodda yazılı, herkesin bildiği eski şifre: artık kabul edilmez
const pinHataSayaci = new Map();
const PIN_KILIT_PENCERE_MS = 15 * 60 * 1000;
const PIN_KISI_SINIRI = 5;   // Bir cihazdan 15 dakikada denenebilecek farklı yanlış şifre
const PIN_GENEL_SINIRI = 30; // Bütün cihazlardan 15 dakikada denenebilecek farklı yanlış şifre
let bellekPin = null;

function gecerliPinOku() {
  const envPin = String(process.env.MEZAT_PIN || process.env.MEZAT_ADMIN_PIN || '').trim();
  if (/^\d{4,8}$/.test(envPin)) return envPin;
  try {
    if (fs.existsSync(PIN_DOSYA_YOLU)) {
      const j = JSON.parse(fs.readFileSync(PIN_DOSYA_YOLU, 'utf8'));
      const kayitli = String((j && j.pin) || '').trim();
      if (/^\d{4,8}$/.test(kayitli) && kayitli !== ESKI_VARSAYILAN_PIN) return kayitli;
    }
  } catch (_) {}
  // Yeni kurulum ya da eski varsayılan şifre: tahmin edilemeyen bir şifre üretilir, bilgisayar ekranındaki panelde görünür
  if (!bellekPin) {
    do { bellekPin = String(crypto.randomInt(100000, 1000000)); } while (bellekPin === ESKI_VARSAYILAN_PIN);
  }
  try { fs.writeFileSync(PIN_DOSYA_YOLU, JSON.stringify({ pin: bellekPin, guncelleme: new Date().toISOString() }, null, 2), 'utf8'); bellekPin = null; return JSON.parse(fs.readFileSync(PIN_DOSYA_YOLU, 'utf8')).pin; } catch (_) {}
  return bellekPin;
}

function istekIpAl(req) {
  // Sahte adres başlığı yalnız otomatik testlerde dikkate alınır; aksi halde deneme sınırı bu başlıkla aşılabilirdi
  const testIp = process.env.MEZAT_TEST_MODU === '1' ? req.headers['x-test-uzak-ip'] : '';
  return String(testIp || (req.socket && req.socket.remoteAddress) || 'bilinmiyor').replace(/^::ffff:/, '');
}
const GUN_MS = 24 * 60 * 60 * 1000;
const PIN_GUNLUK_SINIRI = 100; // Bütün cihazlardan bir günde denenebilecek farklı yanlış şifre: 4 rakamın hepsini denemek aylar sürer
function pinSayaciAl(anahtar, simdi, pencere = PIN_KILIT_PENCERE_MS) {
  const k = pinHataSayaci.get(anahtar);
  if (!k) return null;
  if (simdi - k.ilkMs >= pencere) { pinHataSayaci.delete(anahtar); return null; }
  return k;
}
function pinKilitliMi(req) {
  const simdi = Date.now();
  const kisi = pinSayaciAl(istekIpAl(req), simdi);
  const genel = pinSayaciAl('*', simdi);
  const gunluk = pinSayaciAl('*gun', simdi, GUN_MS);
  return Boolean((kisi && kisi.sayi >= PIN_KISI_SINIRI) || (genel && genel.sayi >= PIN_GENEL_SINIRI) || (gunluk && gunluk.sayi >= PIN_GUNLUK_SINIRI));
}
// Telefonda kalmış eski şifre aynı değerle tekrar tekrar gelir; kendini kilitlemesin diye yalnız farklı yanlış değerler sayılır
function pinHatasiYaz(req, deger) {
  const simdi = Date.now();
  const ozet = crypto.createHash('sha256').update(String(deger)).digest('hex').slice(0, 16);
  for (const [anahtar, pencere] of [[istekIpAl(req), PIN_KILIT_PENCERE_MS], ['*', PIN_KILIT_PENCERE_MS], ['*gun', GUN_MS]]) {
    const k = pinSayaciAl(anahtar, simdi, pencere) || { sayi: 0, ilkMs: simdi, denenen: new Set() };
    if (!k.denenen.has(ozet)) { k.denenen.add(ozet); k.sayi += 1; }
    pinHataSayaci.set(anahtar, k);
  }
}

function pinKaydet(yeniPin) {
  const temiz = String(yeniPin || '').trim();
  if (!/^\d{4,6}$/.test(temiz)) return { success: false, error: 'Şifre 4, 5 ya da 6 rakam olmalı. 6 rakam daha güvenlidir.' };
  if (temiz === ESKI_VARSAYILAN_PIN) return { success: false, error: 'Bu şifre herkesçe bilindiği için kullanılamaz. Başka bir şifre seçin.' };
  try {
    fs.writeFileSync(PIN_DOSYA_YOLU, JSON.stringify({ pin: temiz, guncelleme: new Date().toISOString() }, null, 2), 'utf8');
    return { success: true, pin: temiz };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

function pinTokenUret(pin) {
  return crypto.createHmac('sha256', oturumAnahtari()).update(String(pin)).digest('hex').slice(0, 32);
}

function istekYerelMi(req) {
  if (req.headers['x-test-uzak-ip']) return false;
  const ip = String(req.socket && req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  return ip === '127.0.0.1' || ip === '::1' || ip === 'localhost';
}

// Dükkan bilgisayarında açılan yabancı bir sayfa yerel güveni kullanarak işlem yaptıramasın
function istekKaynagiGuvenliMi(req) {
  const ozelAg = h => /^(?:192\.168\.|10\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(h);
  const kendisi = h => h === 'localhost' || h === '127.0.0.1' || h === '::1' || yerelAgAdresleriBul().some(a => a.ip === h);
  const hostAdi = String(req.headers.host || '').replace(/:\d+$/, '').replace(/^\[|\]$/g, '').toLowerCase();
  if (hostAdi && !kendisi(hostAdi) && !ozelAg(hostAdi)) return false;
  if (!istekYerelMi(req)) return true; // Ağdan gelen istek zaten şifre kapısından geçer
  if (String(req.headers['sec-fetch-site'] || '') === 'cross-site') return false;
  const kaynak = String(req.headers.origin || '');
  if (!kaynak) return true;
  try { return kendisi(new URL(kaynak).hostname.replace(/^\[|\]$/g, '').toLowerCase()); } catch (_) { return false; }
}

function istekPinYetkiliMi(req, query = {}) {
  if (istekYerelMi(req)) return true;
  if (kullaniciOturumuCoz(req)) return true;
  if (pinKilitliMi(req)) return false; // Kilitliyken doğru şifre de kabul edilmez, yoksa deneme sürerdi
  const dogruPin = gecerliPinOku();
  const dogruToken = pinTokenUret(dogruPin);
  const baslikPin = String(req.headers['x-mezat-pin'] || '').trim();
  const eslesme = String(req.headers.cookie || '').match(/(?:^|;\s*)mezat_pin_oturum=([^;]+)/);
  const adaylar = [baslikPin, eslesme ? eslesme[1] : ''].filter(Boolean);
  if (adaylar.some(a => a === dogruPin || a === dogruToken)) return true;
  adaylar.forEach(a => pinHatasiYaz(req, a));
  return false;
}

// ============================================================================
// v116: YÖNETİCİ (GELİŞTİRİCİ) KONSOLU
// - Şifre data/.yonetici.json içinde scrypt özetiyle saklanır (düz metin yok).
// - Şifre henüz yoksa YALNIZCA bilgisayarın kendisinden (localhost) ilk kez belirlenebilir.
// - Oturum jetonu 2 saat geçerlidir; log dosyaları yalnız izinli klasörlerden okunur.
// ============================================================================
const YONETICI_DOSYA = path.join(DATA_DIR, '.yonetici.json');

// ============================================================================
// v117: KİŞİSEL KULLANICI HESAPLARI (Ad + kişisel 4 haneli şifre)
// - Bir ad ilk kez giriş yaptığında kendi şifresini belirler; sonraki girişlerde o şifre sorulur.
// - Şifreler scrypt özetiyle saklanır. Oturum jetonu imzalıdır (30 gün) ve kaydın "Giren" adını belirler.
// ============================================================================
const KULLANICI_DOSYA = path.join(DATA_DIR, 'kullanicilar.json');
const OTURUM_ANAHTAR_DOSYA = path.join(DATA_DIR, '.oturum-anahtari');
const KULLANICI_OTURUM_MS = 30 * 24 * 60 * 60 * 1000;
const GIRIS_HESAP_CIHAZ_SINIRI = 5; // Bir cihazdan bir hesaba 15 dakikada farklı yanlış şifre
const GIRIS_CIHAZ_SINIRI = 20;      // Bir cihazdan bütün hesaplara 15 dakikada farklı yanlış şifre
const GIRIS_HESAP_SINIRI = 30;      // Bütün cihazlardan bir hesaba 15 dakikada farklı yanlış şifre
function kullaniciGirisKilitliMi(req, ip, anahtar, simdi) {
  const asti = (k, sinir) => { const s = pinSayaciAl(k, simdi); return Boolean(s && s.sayi >= sinir); };
  if (asti(`giris:${anahtar}|${ip}`, GIRIS_HESAP_CIHAZ_SINIRI) || asti(`giris-cihaz:${ip}`, GIRIS_CIHAZ_SINIRI)) return true;
  // Ağdan biri hesabı kilitlese de sahibi dükkan bilgisayarından girebilsin
  if (istekYerelMi(req)) return false;
  const gunluk = pinSayaciAl(`giris-hesap-gun:${anahtar}`, simdi, GUN_MS);
  return asti(`giris-hesap:${anahtar}`, GIRIS_HESAP_SINIRI) || Boolean(gunluk && gunluk.sayi >= PIN_GUNLUK_SINIRI);
}
function kullaniciGirisHatasiYaz(ip, anahtar, pin, simdi) {
  const ozet = crypto.createHash('sha256').update(`${anahtar}|${pin}`).digest('hex').slice(0, 16);
  for (const k of [`giris:${anahtar}|${ip}`, `giris-cihaz:${ip}`, `giris-hesap:${anahtar}`, `giris-hesap-gun:${anahtar}`]) {
    const s = pinSayaciAl(k, simdi, k.startsWith('giris-hesap-gun:') ? GUN_MS : PIN_KILIT_PENCERE_MS) || { sayi: 0, ilkMs: simdi, denenen: new Set() };
    if (!s.denenen.has(ozet)) { s.denenen.add(ozet); s.sayi += 1; }
    pinHataSayaci.set(k, s);
  }
}
// v119-v120: Ed25519 Dijital İmzalı Lisans Sistemi (Tahrif Edilemez)
// - Varsayılan limit: 3 kullanıcı (Lisans Sahibi + 2 Eleman)
// - Ek kullanıcılar için Ahmet Aksoy'un özel anahtarı (private key) ile imzalanmış MZL-... lisans kodu gerekir.
// - Dosya elle değiştirilse bile imza uyuşmazlığından anında 3'e düşer.
const LISANS_DOSYA = path.join(DATA_DIR, '.lisans.json');
const VARSAYILAN_KULLANICI_LIMITI = 3;
const BEKLEYEN_UST_SINIR = 10;
const LISANS_PUBLIC_KEY = '-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAAneKDvpTKq29FvHH6CR/+8PdeQ2nnkoP2FziyIq+jeM=\n-----END PUBLIC KEY-----\n';

function lisansKoduDogrula(kod) {
  try {
    const ham = String(kod || '').trim();
    if (!ham.startsWith('MZL-')) return { gecerli: false, error: 'Lisans kodu MZL- ile başlamalıdır.' };
    const govde = ham.slice(4);
    const noktaIdx = govde.indexOf('.');
    if (noktaIdx <= 0) return { gecerli: false, error: 'Geçersiz lisans kodu formatı.' };
    const payloadB64 = govde.slice(0, noktaIdx);
    const imzaB64 = govde.slice(noktaIdx + 1);
    const imza = Buffer.from(imzaB64, 'base64url');
    const veri = Buffer.from(payloadB64, 'utf8');
    const dogru = crypto.verify(null, veri, LISANS_PUBLIC_KEY, imza);
    if (!dogru) return { gecerli: false, error: 'Lisans imzası geçersiz veya lisans kodu hatalı/tahrif edilmiş!' };
    const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8'));
    const limit = Number(payload.limit);
    if (!Number.isInteger(limit) || limit < 1) return { gecerli: false, error: 'Lisans limiti geçersiz.' };
    if (payload.sonTarih && Date.now() > Date.parse(payload.sonTarih)) {
      return { gecerli: false, error: 'Bu lisans kodunun geçerlilik süresi dolmuş (' + payload.sonTarih + ').' };
    }
    return { gecerli: true, payload, lisansKodu: ham };
  } catch (err) {
    return { gecerli: false, error: 'Lisans doğrulama hatası: ' + err.message };
  }
}

function lisansOku() {
  try {
    if (!fs.existsSync(LISANS_DOSYA)) {
      return { kullaniciLimiti: VARSAYILAN_KULLANICI_LIMITI, musteri: 'Standart Lisans (3 Kullanıcı)', lisansli: false, sonTarih: null };
    }
    const j = JSON.parse(fs.readFileSync(LISANS_DOSYA, 'utf8'));
    if (!j || !j.lisansKodu) {
      return { kullaniciLimiti: VARSAYILAN_KULLANICI_LIMITI, musteri: 'Standart Lisans (3 Kullanıcı)', lisansli: false, sonTarih: null };
    }
    const dogrulama = lisansKoduDogrula(j.lisansKodu);
    if (!dogrulama.gecerli) {
      return { kullaniciLimiti: VARSAYILAN_KULLANICI_LIMITI, musteri: 'Standart Lisans (Geçersiz İmza)', lisansli: false, sonTarih: null, hata: dogrulama.error };
    }
    const p = dogrulama.payload;
    return {
      kullaniciLimiti: p.limit,
      musteri: p.musteri || 'Lisanslı Müşteri',
      sonTarih: p.sonTarih || null,
      olusturma: p.olusturma,
      lisansli: true,
      lisansKodu: j.lisansKodu
    };
  } catch (_) {
    return { kullaniciLimiti: VARSAYILAN_KULLANICI_LIMITI, musteri: 'Standart Lisans (3 Kullanıcı)', lisansli: false, sonTarih: null };
  }
}

function lisansKaydet(lisansKodu) {
  const dogrulama = lisansKoduDogrula(lisansKodu);
  if (!dogrulama.gecerli) return { success: false, error: dogrulama.error };
  const p = dogrulama.payload;
  const kayit = {
    lisansKodu: dogrulama.lisansKodu,
    musteri: p.musteri,
    kullaniciLimiti: p.limit,
    olusturma: p.olusturma,
    sonTarih: p.sonTarih || null,
    kayitTarihi: new Date().toISOString()
  };
  fs.writeFileSync(LISANS_DOSYA, JSON.stringify(kayit, null, 2), 'utf8');
  return { success: true, lisans: Object.assign({ lisansli: true }, kayit) };
}

function onayliKullaniciSayisi(tum) { return Object.values(tum).filter(k => k.onayli !== false).length; }
let __oturumAnahtari = null;
function oturumAnahtari() {
  if (__oturumAnahtari) return __oturumAnahtari;
  try { __oturumAnahtari = fs.readFileSync(OTURUM_ANAHTAR_DOSYA, 'utf8').trim(); } catch (_) {}
  if (!__oturumAnahtari || __oturumAnahtari.length < 32) {
    __oturumAnahtari = crypto.randomBytes(32).toString('hex');
    try { fs.writeFileSync(OTURUM_ANAHTAR_DOSYA, __oturumAnahtari, 'utf8'); } catch (_) {}
  }
  return __oturumAnahtari;
}
function kullaniciAnahtar(ad) { return String(ad || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase('tr-TR'); }
function kullanicilariOku() { try { return JSON.parse(fs.readFileSync(KULLANICI_DOSYA, 'utf8')) || {}; } catch (_) { return {}; } }
// Yarım kalan yazma hesapları boş gösterip sonraki kişiyi "ilk hesap" yapmasın
function kullanicilariYaz(v) {
  const gecici = `${KULLANICI_DOSYA}.${process.pid}.yeni`;
  fs.writeFileSync(gecici, JSON.stringify(v, null, 2), 'utf8');
  fs.renameSync(gecici, KULLANICI_DOSYA);
}
function kullaniciJetonUret(ad) {
  const govde = Buffer.from(JSON.stringify({ ad, bitis: Date.now() + KULLANICI_OTURUM_MS })).toString('base64url');
  const imza = crypto.createHmac('sha256', oturumAnahtari()).update(govde).digest('base64url');
  return `${govde}.${imza}`;
}
function kullaniciOturumuCoz(req) {
  const j = String(req.headers['x-mezat-oturum'] || '').trim();
  if (!j || !j.includes('.')) return null;
  const [govde, imza] = j.split('.');
  const dogru = crypto.createHmac('sha256', oturumAnahtari()).update(govde).digest('base64url');
  if (!imza || imza.length !== dogru.length || !crypto.timingSafeEqual(Buffer.from(imza), Buffer.from(dogru))) return null;
  try {
    const v = JSON.parse(Buffer.from(govde, 'base64url').toString('utf8'));
    if (!v.ad || Date.now() > v.bitis) return null;
    const kayit = kullanicilariOku()[kullaniciAnahtar(v.ad)];
    if (!kayit || kayit.onayli === false) return null; // hesap silindi / onay kaldırıldı → oturum geçersiz
    if (kayit.sifreYenilenecek) return null;
    if (kayit.sifreYenileme && v.bitis - KULLANICI_OTURUM_MS < Date.parse(kayit.sifreYenileme)) return null;
    return { ad: kayit.ad, rol: kayit.rol || 'kullanici' };
  } catch (_) { return null; }
}
function kullaniciIstegiIsle(req, pathname, query, gonder) {
  const ip = istekIpAl(req);
  if (req.method === 'GET' && pathname === '/api/kullanici/durum') {
    const k = kullanicilariOku()[kullaniciAnahtar(query.ad)];
    return gonder(200, { success: true, hesapVar: Boolean(k && !k.sifreYenilenecek) });
  }
  if (req.method === 'POST' && pathname === '/api/kullanici/giris') {
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 4096) req.destroy(); });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      const ad = String(v.ad || '').replace(/[<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 40);
      const pin = String(v.pin || '').trim();
      if (ad.length < 3) return gonder(400, { success: false, error: 'Lütfen adınızı yazın (en az 3 harf).' });
      if (!/^\d{4}$/.test(pin)) return gonder(400, { success: false, error: 'Şifre tam 4 rakam olmalı.' });
      const simdi = Date.now();
      const anahtar = kullaniciAnahtar(ad);
      if (kullaniciGirisKilitliMi(req, ip, anahtar, simdi)) return gonder(429, { success: false, error: 'Çok fazla hatalı deneme. 15 dakika bekleyin.' });
      const tum = kullanicilariOku();
      let yeniHesap = false;
      if (!tum[anahtar]) {
        const tuz = crypto.randomBytes(16).toString('hex');
        // İlk hesap = Lisans Sahibi (otomatik onaylı); sonrakiler lisans sahibinin onayını bekler
        const ilkHesap = !Object.values(tum).some(x => x.rol === 'sahip');
        if (ilkHesap && !istekYerelMi(req)) return gonder(403, { success: false, error: 'İlk hesap (lisans sahibi) yalnız dükkan bilgisayarından açılır.' });
        if (!ilkHesap && Object.values(tum).filter(x => x.onayli === false).length >= BEKLEYEN_UST_SINIR) {
          return gonder(429, { success: false, error: 'Onay bekleyen çok fazla başvuru var. Lisans sahibine başvurun.' });
        }
        tum[anahtar] = { ad, tuz, ozet: crypto.scryptSync(pin, tuz, 32).toString('hex'), olusturma: new Date().toISOString(), ip, rol: ilkHesap ? 'sahip' : 'kullanici', onayli: ilkHesap };
        kullanicilariYaz(tum);
        yeniHesap = true;
      } else if (tum[anahtar].sifreYenilenecek) {
        const tuz = crypto.randomBytes(16).toString('hex');
        // Ağdan yenilenen şifre sahibinin onayını bekler; yoksa adı bilen herkes hesabı alırdı
        Object.assign(tum[anahtar], { tuz, ozet: crypto.scryptSync(pin, tuz, 32).toString('hex'), sifreYenilenecek: false, sifreYenileme: new Date().toISOString() }, istekYerelMi(req) ? {} : { onayli: false });
        kullanicilariYaz(tum);
        yeniHesap = true;
      } else {
        const k = tum[anahtar];
        const a = Buffer.from(crypto.scryptSync(pin, k.tuz, 32).toString('hex'), 'hex');
        const b = Buffer.from(k.ozet, 'hex');
        if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
          kullaniciGirisHatasiYaz(ip, anahtar, pin, simdi);
          return gonder(401, { success: false, error: 'Şifre hatalı.' });
        }
      }
      // Yalnız bu hesabın bu cihazdaki sayacı silinir; başka hesabın doğru şifresi denemeleri sıfırlayamaz
      pinHataSayaci.delete(`giris:${anahtar}|${ip}`);
      if (tum[anahtar].onayli === false) {
        return gonder(403, { success: false, onayBekliyor: true, yeniHesap, error: yeniHesap
          ? 'Şifreniz oluşturuldu. Lisans sahibi (yönetici) onayladığında giriş yapabilirsiniz.'
          : 'Hesabınız henüz yönetici tarafından onaylanmadı.' });
      }
      tum[anahtar].sonGiris = new Date().toISOString();
      try { kullanicilariYaz(tum); } catch (_) {}
      return gonder(200, { success: true, ad: tum[anahtar].ad, rol: tum[anahtar].rol || 'kullanici', jeton: kullaniciJetonUret(tum[anahtar].ad), yeniHesap });
    });
    return;
  }
  // ---- Lisans Sahibi (veya mağaza bilgisayarı) kullanıcı yönetimi ----
  const yetkili = istekYerelMi(req) || ((kullaniciOturumuCoz(req) || {}).rol === 'sahip');
  if (!yetkili) return gonder(403, { success: false, error: 'Bu işlem yalnız lisans sahibi (yönetici) içindir.' });
  if (req.method === 'GET' && pathname === '/api/kullanici/liste') {
    const tum = kullanicilariOku();
    const l = lisansOku();
    return gonder(200, {
      success: true,
      lisans: {
        kullaniciLimiti: l.kullaniciLimiti,
        onayliSayisi: onayliKullaniciSayisi(tum),
        musteri: l.musteri,
        lisansli: l.lisansli,
        sonTarih: l.sonTarih
      },
      kullanicilar: Object.values(tum).map(k => ({ ad: k.ad, rol: k.rol || 'kullanici', onayli: k.onayli !== false, olusturma: k.olusturma, sonGiris: k.sonGiris || '' }))
    });
  }
  if (req.method === 'POST' && pathname === '/api/kullanici/lisans-yukle') {
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 8192) req.destroy(); });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      const sonuc = lisansKaydet(v.lisansKodu);
      if (!sonuc.success) return gonder(400, sonuc);
      return gonder(200, { success: true, lisans: sonuc.lisans, message: 'Lisans kodu başarıyla aktifleştirildi.' });
    });
    return;
  }
  if (req.method === 'POST' && ['/api/kullanici/onayla', '/api/kullanici/reddet', '/api/kullanici/sifre-sifirla', '/api/kullanici/sahip-yap'].includes(pathname)) {
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 4096) req.destroy(); });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      const tum = kullanicilariOku();
      const a = kullaniciAnahtar(v.ad);
      const k = tum[a];
      if (!k) return gonder(404, { success: false, error: 'Kullanıcı bulunamadı.' });
      const sahipSayisi = Object.values(tum).filter(x => x.rol === 'sahip').length;
      if (pathname === '/api/kullanici/onayla') {
        const { kullaniciLimiti } = lisansOku();
        if (k.onayli === false && onayliKullaniciSayisi(tum) >= kullaniciLimiti) {
          return gonder(402, { success: false, lisansDolu: true, error: 'Lisansınız ' + kullaniciLimiti + ' kullanıcı ile sınırlıdır (' + onayliKullaniciSayisi(tum) + '/' + kullaniciLimiti + ' dolu). Ek kullanıcı için ek lisans satın almanız gerekir. Ya da mevcut bir kullanıcının erişimini kaldırın.' });
        }
        k.onayli = true; k.onaylanma = new Date().toISOString();
      }
      else if (pathname === '/api/kullanici/reddet') {
        if (k.rol === 'sahip' && sahipSayisi <= 1) return gonder(400, { success: false, error: 'Tek lisans sahibi kaldırılamaz.' });
        delete tum[a];
      } else if (pathname === '/api/kullanici/sifre-sifirla') {
        if (k.rol === 'sahip' && !istekYerelMi(req) && (kullaniciOturumuCoz(req) || {}).ad !== k.ad) return gonder(403, { success: false, error: 'Başka bir lisans sahibinin şifresi sıfırlanamaz.' });
        const rol = k.rol; const onayli = k.onayli;
        delete tum[a];
        // Kayıt "şifresiz" bekletilir: kişi aynı adla girince yeni şifresini belirler, rol/onay korunur
        tum[a] = { ad: k.ad, rol, onayli, sifreYenilenecek: true, olusturma: k.olusturma };
      } else if (pathname === '/api/kullanici/sahip-yap') { k.rol = 'sahip'; k.onayli = true; }
      kullanicilariYaz(tum);
      return gonder(200, { success: true });
    });
    return;
  }
  return gonder(404, { success: false, error: 'Bilinmeyen kullanıcı isteği.' });
}
const YONETICI_OTURUM_MS = 2 * 60 * 60 * 1000;
const yoneticiOturumlari = new Map();
const yoneticiHataSayaci = new Map();
const SISTEM_HATA_LOG = path.join(DATA_DIR, 'sistem-hata.log');

function sistemHataYaz(tur, hata) {
  try {
    const satir = `[${new Date().toISOString()}] ${tur}: ${hata && hata.stack ? hata.stack : String(hata)}\n`;
    fs.appendFileSync(SISTEM_HATA_LOG, satir, 'utf8');
  } catch (_) {}
}
process.on('uncaughtException', e => { sistemHataYaz('uncaughtException', e); console.error(e); });
process.on('unhandledRejection', e => { sistemHataYaz('unhandledRejection', e); });

function yoneticiKaydiOku() {
  try { return JSON.parse(fs.readFileSync(YONETICI_DOSYA, 'utf8')); } catch (_) { return null; }
}
function yoneticiOzet(sifre, tuz) {
  return crypto.scryptSync(String(sifre), tuz, 32).toString('hex');
}
function yoneticiSifreDogruMu(sifre) {
  const k = yoneticiKaydiOku();
  if (!k || !k.tuz || !k.ozet) return false;
  const a = Buffer.from(yoneticiOzet(sifre, k.tuz), 'hex');
  const b = Buffer.from(k.ozet, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function yoneticiJetonGecerliMi(req, query) {
  const j = String(req.headers['x-yonetici-jeton'] || query.jeton || '').trim();
  const o = j && yoneticiOturumlari.get(j);
  if (!o) return false;
  if (Date.now() - o.zaman > YONETICI_OTURUM_MS) { yoneticiOturumlari.delete(j); return false; }
  return true;
}
const YONETICI_LOG_KLASORLERI = { 'veri': DATA_DIR, 'envanter': path.join(DATA_DIR, 'envanter'), 'raporlar': REPORT_DIR };
function yoneticiLogListesi() {
  const liste = [];
  for (const [klasorKodu, klasor] of Object.entries(YONETICI_LOG_KLASORLERI)) {
    try {
      for (const ad of fs.readdirSync(klasor)) {
        if (!/\.(log|jsonl|json|md|txt)$/i.test(ad) || ad === '.yonetici.json') continue;
        const st = fs.statSync(path.join(klasor, ad));
        if (st.isFile()) liste.push({ klasor: klasorKodu, ad, boyut: st.size, degisim: st.mtime.toISOString() });
      }
    } catch (_) {}
  }
  return liste.sort((x, y) => y.degisim.localeCompare(x.degisim));
}
function yoneticiIstegiIsle(req, pathname, query, gonder) {
  const ip = istekIpAl(req);
  if (req.method === 'GET' && pathname === '/api/yonetici/durum') {
    return gonder(200, { success: true, sifreTanimli: Boolean(yoneticiKaydiOku()), yerel: istekYerelMi(req) });
  }
  if (req.method === 'POST' && pathname === '/api/yonetici/giris') {
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 4096) req.destroy(); });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      const sifre = String(v.sifre || '');
      const simdi = Date.now();
      const h = yoneticiHataSayaci.get(ip);
      if (h && simdi - h.ilk < 5 * 60000 && h.sayi >= 5) {
        return gonder(429, { success: false, error: 'Çok fazla hatalı deneme. 5 dakika bekleyin.' });
      }
      if (!yoneticiKaydiOku()) {
        if (!istekYerelMi(req)) return gonder(403, { success: false, error: 'Yönetici şifresi henüz belirlenmemiş. İlk kurulum yalnız bilgisayarın kendisinden yapılabilir.' });
        if (sifre.length < 6) return gonder(400, { success: false, error: 'Yönetici şifresi en az 6 karakter olmalı.' });
        const tuz = crypto.randomBytes(16).toString('hex');
        fs.writeFileSync(YONETICI_DOSYA, JSON.stringify({ tuz, ozet: yoneticiOzet(sifre, tuz), olusturma: new Date().toISOString() }, null, 2), 'utf8');
      } else if (!yoneticiSifreDogruMu(sifre)) {
        yoneticiHataSayaci.set(ip, { sayi: (h && simdi - h.ilk < 5 * 60000 ? h.sayi : 0) + 1, ilk: (h && simdi - h.ilk < 5 * 60000) ? h.ilk : simdi });
        sistemHataYaz('yonetici-hatali-giris', ip);
        return gonder(401, { success: false, error: 'Yönetici şifresi hatalı.' });
      }
      yoneticiHataSayaci.delete(ip);
      const jeton = crypto.randomBytes(24).toString('hex');
      yoneticiOturumlari.set(jeton, { zaman: simdi, ip });
      return gonder(200, { success: true, jeton });
    });
    return;
  }
  if (!yoneticiJetonGecerliMi(req, query)) return gonder(401, { success: false, oturumGerekli: true, error: 'Yönetici oturumu yok veya süresi doldu.' });
  if (req.method === 'GET' && pathname === '/api/yonetici/loglar') {
    return gonder(200, { success: true, dosyalar: yoneticiLogListesi() });
  }
  if (req.method === 'GET' && pathname === '/api/yonetici/log') {
    const klasor = YONETICI_LOG_KLASORLERI[String(query.klasor || '')];
    const ad = path.basename(String(query.ad || ''));
    if (!klasor || !ad || ad === '.yonetici.json' || !/\.(log|jsonl|json|md|txt)$/i.test(ad)) return gonder(400, { success: false, error: 'Geçersiz dosya.' });
    const yol = path.join(klasor, ad);
    try {
      const st = fs.statSync(yol);
      const okunacak = Math.min(st.size, 300 * 1024);
      const fd = fs.openSync(yol, 'r');
      const buf = Buffer.alloc(okunacak);
      fs.readSync(fd, buf, 0, okunacak, st.size - okunacak);
      fs.closeSync(fd);
      return gonder(200, { success: true, ad, boyut: st.size, kirpildi: st.size > okunacak, icerik: buf.toString('utf8') });
    } catch (e) {
      return gonder(404, { success: false, error: 'Dosya okunamadı.' });
    }
  }
  if (req.method === 'POST' && pathname === '/api/yonetici/hata-log-temizle') {
    try { fs.writeFileSync(SISTEM_HATA_LOG, `[${new Date().toISOString()}] Log yönetici tarafından temizlendi.\n`, 'utf8'); } catch (_) {}
    return gonder(200, { success: true });
  }
  if (req.method === 'GET' && pathname === '/api/yonetici/sistem') {
    return gonder(200, {
      success: true,
      node: process.version,
      calismaSuresiSn: Math.round(process.uptime()),
      bellekMb: Math.round(process.memoryUsage().rss / 1048576),
      pinTanimli: Boolean(gecerliPinOku()),
      zaman: new Date().toISOString()
    });
  }
  if (pathname === '/api/yonetici/lisans') {
    if (req.method === 'GET') return gonder(200, Object.assign({ success: true, onayliSayisi: onayliKullaniciSayisi(kullanicilariOku()) }, lisansOku()));
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 8192) req.destroy(); });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      if (v.lisansKodu) {
        const sonuc = lisansKaydet(v.lisansKodu);
        if (!sonuc.success) return gonder(400, sonuc);
        return gonder(200, Object.assign({ success: true, onayliSayisi: onayliKullaniciSayisi(kullanicilariOku()) }, sonuc.lisans));
      }
      return gonder(400, { success: false, error: 'Lütfen dijital imzalı MZL-... lisans kodunu girin.' });
    });
    return;
  }
  if (req.method === 'GET' && pathname === '/api/yonetici/kullanicilar') {
    const tum = kullanicilariOku();
    return gonder(200, { success: true, kullanicilar: Object.values(tum).map(k => ({ ad: k.ad, olusturma: k.olusturma, sonGiris: k.sonGiris || '' })) });
  }
  if (req.method === 'POST' && pathname === '/api/yonetici/kullanici-sifirla') {
    let govde = '';
    req.on('data', p => { govde += p; });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      const tum = kullanicilariOku();
      const a = kullaniciAnahtar(v.ad);
      if (!tum[a]) return gonder(404, { success: false, error: 'Kullanıcı bulunamadı.' });
      delete tum[a];
      kullanicilariYaz(tum);
      return gonder(200, { success: true, message: 'Şifre sıfırlandı. Kişi bir sonraki girişte yeni şifresini belirleyecek.' });
    });
    return;
  }
  if (pathname === '/api/yonetici/ticari-salter') {
    if (req.method === 'GET') {
      const toplamUrun = (urunDeposu.listele(urunDeposu.gunAdi()) || []).length;
      return gonder(200, { success: true, rapor: ticariMotor.durumRaporu(toplamUrun), salter: ticariMotor.TICARI_MOD_AKTIF });
    }
    let govde = '';
    req.on('data', p => { govde += p; });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      const r = ticariMotor.salterAyarla(Boolean(v.aktif));
      const toplamUrun = (urunDeposu.listele(urunDeposu.gunAdi()) || []).length;
      return gonder(200, { success: true, salter: r.ticariModAktif, rapor: ticariMotor.durumRaporu(toplamUrun) });
    });
    return;
  }
  return gonder(404, { success: false, error: 'Bilinmeyen yönetici isteği.' });
}

// Depo Etiket Kuyruğu ve Barkod Doğrulama Durumu (etiket.html ve okut.html için)
const LABEL_SETTINGS_PATH = path.join(DATA_DIR, 'etiket-ayar.json');
let labelSettings = {
  yaziciAcik: false,
  genislikMm: 50,
  yukseklikMm: 30,
  kenarMm: 2,
  kopya: 1,
  alanlar: { musteri: true, raf: true, beden: true, urun: true, fiyat: true, siparisNo: true, barkod: true, tarih: false }
};
try {
  if (fs.existsSync(LABEL_SETTINGS_PATH)) {
    labelSettings = { ...labelSettings, ...JSON.parse(fs.readFileSync(LABEL_SETTINGS_PATH, 'utf8')) };
  }
} catch (_) {}
let productLabelQueue = [];
let nextProductLabelSeq = 1;
const sseClients = new Set();

function broadcastSSE(event, data) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of sseClients) {
    try { res.write(payload); } catch (_) { sseClients.delete(res); }
  }
}

function enqueueProductLabels(kayit, { kip = 'varyant', satirIndeks = null } = {}) {
  if (!kayit || !kayit.urun) return { success: false, error: 'Ürün bilgisi bulunamadı.' };
  const satirlar = Array.isArray(kayit.satirlar) && kayit.satirlar.length
    ? kayit.satirlar
    : [{ renk: '', beden: '', adet: 1, barkod: kayit.barkod || urunGirisi.otomatikBarkodUret(kayit.urun) }];
  const seciliSatirlar = satirIndeks !== null && satirIndeks !== undefined && satirlar[Number(satirIndeks)]
    ? [satirlar[Number(satirIndeks)]]
    : satirlar;
  const anaBarkod = kayit.barkod || urunGirisi.otomatikBarkodUret(kayit.urun);
  const eklenen = [];
  const zaman = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

  seciliSatirlar.forEach((s, idx) => {
    const vBarkod = s.barkod || urunGirisi.otomatikBarkodUret(kayit.urun, s.renk, s.beden);
    const kopyaSayisi = kip === 'tum-adetler' ? Math.min(50, Math.max(1, Number(s.adet) || 1)) : 1;
    const varyantAciklama = [s.renk, s.beden].filter(Boolean).join(' / ') || 'Standart';
    for (let k = 0; k < kopyaSayisi; k++) {
      const seq = nextProductLabelSeq++;
      const etiketObj = {
        orderId: `URUN-ETK-${kayit.id || 'BARKOD'}-${idx + 1}-${k + 1}-${seq}`,
        tur: 'URUN_BARKOD',
        siparisNo: vBarkod,
        barkod: vBarkod,
        anaBarkod,
        musteri: kayit.urun,
        raf: 'DEPO STOK',
        beden: s.beden || '',
        renk: s.renk || '',
        urun: kip === 'tum-adetler'
          ? `${varyantAciklama} (${k + 1}/${kopyaSayisi})`
          : `${varyantAciklama} · Stok: ${Number(s.adet) || 1} Adet`,
        adet: kip === 'tum-adetler' ? 1 : (Number(s.adet) || 1),
        fiyat: Number(kayit.fiyat) || 0,
        hediye: '',
        parcaSayisi: 1,
        parcalar: [],
        zaman,
        etiket: {
          durum: 'BEKLIYOR',
          kuyrukMs: Date.now() + eklenen.length,
          gonderimSayisi: 0,
          ilkGonderimMs: null,
          sonGonderimMs: null,
          okunduMs: null,
          hatalar: []
        }
      };
      productLabelQueue.push(etiketObj);
      eklenen.push(etiketObj);
    }
  });
  broadcastSSE('etiket_kuyrugu', { bekleyen: productLabelQueue.filter(p => p.etiket.durum === 'BEKLIYOR').length, iptalUyarisi: 0, yaziciAcik: labelSettings.yaziciAcik });
  return { success: true, urun: kayit.urun, anaBarkod, kip, eklenenSayisi: eklenen.length, etiketler: eklenen };
}

// Mezatron Müşteri & Sipariş Veritabanı Bağlantısı (Barkod okunduğunda kişinin sistemde kayıtlı müşteri olup olmadığını kontrol eder)
const MEZATRON_DATA_DIR = path.resolve(__dirname, '..', 'live-commerce-demo', 'data');
const CUSTOMERS_PATH = fs.existsSync(path.join(MEZATRON_DATA_DIR, 'customers.json'))
  ? path.join(MEZATRON_DATA_DIR, 'customers.json')
  : path.join(DATA_DIR, 'customers.json');
const NEW_CUSTOMERS_PATH = fs.existsSync(path.join(MEZATRON_DATA_DIR, 'yeni-musteriler.json'))
  ? path.join(MEZATRON_DATA_DIR, 'yeni-musteriler.json')
  : path.join(DATA_DIR, 'yeni-musteriler.json');
const MEZATRON_ORDERS_PATH = path.join(MEZATRON_DATA_DIR, 'orders.json');

function jsonDosyaOku(dosyaYolu, varsayilan = []) {
  try {
    if (fs.existsSync(dosyaYolu)) return JSON.parse(fs.readFileSync(dosyaYolu, 'utf8'));
  } catch (_) {}
  return varsayilan;
}

function normMusteriAd(s) {
  return String(s || '')
    .toLocaleLowerCase('tr-TR')
    .replace(/^@+/, '')
    .replace(/[^a-z0-9çğıöşü\s]/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function musteriKayitKontrolEt(aday = {}) {
  const kayitliMusteriler = jsonDosyaOku(CUSTOMERS_PATH, []);
  const yeniMusteriler = jsonDosyaOku(NEW_CUSTOMERS_PATH, []);

  const arananId = String(aday.musteriId || aday.id || '').trim().toUpperCase();
  const arananAd = normMusteriAd(aday.musteri || aday.name || '');
  const arananTel = String(aday.telefon || aday.phone || '').replace(/\D+/g, '');

  // 1. Ana Müşteri Veritabanında (customers.json) Ara
  let bulunanKayitli = kayitliMusteriler.find(c => {
    if (arananId && String(c.id || '').toUpperCase() === arananId) return true;
    if (arananTel && arananTel.length >= 10 && String(c.phone || '').replace(/\D+/g, '').endsWith(arananTel.slice(-10))) return true;
    const cAd = normMusteriAd(c.name);
    const fbAd = normMusteriAd(c.facebookId);
    const tgAd = normMusteriAd(c.telegramUsername);
    return arananAd && (cAd === arananAd || fbAd === arananAd || tgAd === arananAd);
  });

  if (bulunanKayitli) {
    const tel = String(bulunanKayitli.phone || '').trim();
    const adres = String(bulunanKayitli.address || '').trim();
    const sehir = [bulunanKayitli.city, bulunanKayitli.district].filter(Boolean).join(' / ');
    const eksikler = [];
    if (!tel) eksikler.push('Telefon Numarası');
    if (!adres) eksikler.push('Açık Kargo Adresi');
    const tamKayitli = eksikler.length === 0 && !bulunanKayitli.yeniMusteri;
    return {
      kayitliMi: tamKayitli,
      durumKodu: tamKayitli ? 'KAYITLI_MUSTERI' : 'EKSIK_BILGILI_MUSTERI',
      rozet: tamKayitli
        ? '🟢 SİSTEMDE KAYITLI MÜŞTERİ (Adres & Telefon Doğrulandı)'
        : '⚠️ KAYITLI FAKAT ADRES / TELEFON EKSİK',
      musteriId: bulunanKayitli.id || 'CUST',
      adSoyad: bulunanKayitli.name || aday.musteri || '',
      telefon: tel,
      sehirIlce: sehir,
      adres,
      raf: String(bulunanKayitli.binNumber || aday.raf || '').replace(/^RAF:\s*/i, ''),
      eksikler,
      aciklama: tamKayitli
        ? `✅ ${bulunanKayitli.name} (${bulunanKayitli.id}) sistemde kayıtlı müşteridir. Kargo adresi ve telefonu tamdır.`
        : `⚠️ ${bulunanKayitli.name} müşteri listesinde var ancak ${eksikler.join(' ve ')} eksik!`
    };
  }

  // 2. Yeni / Kayıtsız Müşteriler Listesinde (yeni-musteriler.json) Ara
  const bulunanYeni = yeniMusteriler.find(c => {
    if (arananId && String(c.id || '').toUpperCase() === arananId) return true;
    return arananAd && normMusteriAd(c.name) === arananAd;
  });

  const hamTel = String(aday.telefon || aday.phone || (bulunanYeni && bulunanYeni.phone) || '').trim();
  const hamAdres = String(aday.adres || aday.address || (bulunanYeni && bulunanYeni.address) || '').trim();
  const eksikler = [];
  if (!hamTel) eksikler.push('Telefon Numarası');
  if (!hamAdres) eksikler.push('Açık Kargo Adresi');

  return {
    kayitliMi: false,
    durumKodu: 'KAYITSIZ_MUSTERI',
    rozet: '⛔ SİSTEMDE KAYITLI MÜŞTERİ DEĞİL! (Yeni İzleyici / Adres & Telefon Yok)',
    musteriId: (bulunanYeni && bulunanYeni.id) || arananId || 'KAYITSIZ',
    adSoyad: (bulunanYeni && bulunanYeni.name) || aday.musteri || aday.name || 'Bilinmeyen Müşteri',
    telefon: hamTel,
    sehirIlce: [aday.city || (bulunanYeni && bulunanYeni.city), aday.district || (bulunanYeni && bulunanYeni.district)].filter(Boolean).join(' / '),
    adres: hamAdres,
    raf: String((bulunanYeni && bulunanYeni.binNumber) || aday.raf || 'Y-001').replace(/^RAF:\s*/i, ''),
    eksikler,
    aciklama: `⛔ DİKKAT: "${(bulunanYeni && bulunanYeni.name) || aday.musteri || 'Bu kişi'}" ana müşteri veritabanında (customers.json) KAYITLI DEĞİL! Kargo çıkışı için telefon ve adres kaydı yapılmalıdır.`
  };
}

function mezatronSiparisleriniKuyrugaSenkronla() {
  try {
    // 1. Örnek Kayıtlı Müşteri Siparişi (CUST-003 Ayşe Yılmaz — Sistemde Kayıtlı Müşteri kontrolünü anında test etmek için)
    if (!productLabelQueue.some(p => p.siparisNo === 'MZ-2026-0025')) {
      const mKayitli = musteriKayitKontrolEt({ id: 'CUST-003', name: 'Ayşe Yılmaz' });
      productLabelQueue.unshift({
        orderId: 'SIP-KAYITLI-0025',
        siparisNo: 'MZ-2026-0025',
        barkod: 'MZ-2026-0025',
        musteri: 'Ayşe Yılmaz',
        musteriId: 'CUST-003',
        telefon: mKayitli.telefon,
        sehir: mKayitli.sehirIlce,
        adres: mKayitli.adres,
        raf: mKayitli.raf || 'A-01',
        beden: '38',
        renk: 'Zümrüt Yeşili',
        urun: 'İpek Saten Abiye Elbise (Zümrüt / 38)',
        adet: 1,
        fiyat: 1450,
        musteriKayit: mKayitli,
        zaman: '22:15:00',
        etiket: {
          durum: 'GONDERILDI',
          kuyrukMs: Date.now() - 60000,
          gonderimSayisi: 1,
          ilkGonderimMs: Date.now() - 60000,
          sonGonderimMs: Date.now() - 60000,
          okunduMs: null,
          hatalar: []
        }
      });
    }
    const orders = jsonDosyaOku(MEZATRON_ORDERS_PATH, []);
    orders.forEach(o => {
      const sipNo = String(o.orderNumber || (o.item && o.item.stickerBarcode) || '').trim().toUpperCase();
      if (!sipNo) return;
      const c = o.customer || {};
      const mKontrol = musteriKayitKontrolEt({
        id: c.id,
        name: c.name,
        phone: c.phone,
        city: c.city,
        district: c.district,
        address: c.address,
        raf: c.binNumber
      });
      const mevcut = productLabelQueue.find(p => p.siparisNo === sipNo || p.barkod === sipNo);
      if (mevcut) {
        mevcut.musteri = c.name || mevcut.musteri;
        mevcut.musteriId = c.id || mevcut.musteriId;
        mevcut.musteriKayit = mKontrol;
        return;
      }
      productLabelQueue.unshift({
        orderId: o.id || sipNo,
        siparisNo: sipNo,
        barkod: sipNo,
        musteri: c.name || 'Müşteri',
        musteriId: c.id || '',
        telefon: mKontrol.telefon || c.phone || '',
        sehir: mKontrol.sehirIlce || '',
        adres: mKontrol.adres || c.address || '',
        raf: String(c.binNumber || 'DEPO').replace(/^RAF:\s*/i, ''),
        beden: (o.item && o.item.size) || 'Standart',
        renk: (o.item && o.item.color) || '',
        urun: (o.item && o.item.itemLabel) || 'Sipariş Ürünü',
        adet: (o.item && o.item.quantity) || 1,
        fiyat: (o.item && o.item.price) || 0,
        musteriKayit: mKontrol,
        zaman: o.timestamp || new Date().toLocaleTimeString('tr-TR'),
        etiket: {
          durum: 'GONDERILDI',
          kuyrukMs: o.createdAtMs || Date.now(),
          gonderimSayisi: 1,
          ilkGonderimMs: o.createdAtMs || Date.now(),
          sonGonderimMs: o.createdAtMs || Date.now(),
          okunduMs: null,
          hatalar: []
        }
      });
    });
  } catch (_) {}
}

function hizliMusteriKaydet(veri = {}) {
  const adSoyad = String(veri.adSoyad || veri.musteri || '').trim();
  const telefon = String(veri.telefon || '').trim();
  const sehir = String(veri.sehir || 'İstanbul').trim();
  const ilce = String(veri.ilce || 'Merkez').trim();
  const adres = String(veri.adres || '').trim();
  const barkod = String(veri.barkod || veri.siparisNo || '').trim().toUpperCase();

  if (!adSoyad || !telefon || !adres) {
    return { success: false, error: 'Müşteri kaydı için Ad Soyad, Telefon ve Açık Adres zorunludur.' };
  }

  const kayitliMusteriler = jsonDosyaOku(CUSTOMERS_PATH, []);
  const yeniId = `CUST-${String(kayitliMusteriler.length + 1).padStart(3, '0')}`;
  const rafHarf = adSoyad.charAt(0).toLocaleUpperCase('tr-TR') || 'M';
  const yeniMusteriObj = {
    id: yeniId,
    name: adSoyad,
    phone: telefon,
    city: sehir,
    district: ilce,
    address: adres,
    facebookId: normMusteriAd(adSoyad).replace(/\s+/g, '_'),
    telegramUsername: normMusteriAd(adSoyad).replace(/\s+/g, ''),
    binNumber: `RAF: ${rafHarf}-${String((kayitliMusteriler.length % 20) + 1).padStart(2, '0')}`,
    totalOrders: 1,
    cancelledOrders: 0,
    returnedOrders: 0,
    isOnline: true,
    onlinePlatform: 'facebook',
    joinedAt: new Date().toISOString(),
    yeniMusteri: false
  };
  kayitliMusteriler.push(yeniMusteriObj);
  try {
    fs.writeFileSync(CUSTOMERS_PATH, JSON.stringify(kayitliMusteriler, null, 2), 'utf8');
  } catch (_) {}

  // İlgili siparişi de güncelle
  try {
    const orders = jsonDosyaOku(MEZATRON_ORDERS_PATH, []);
    let degisti = false;
    orders.forEach(o => {
      if ((barkod && o.orderNumber === barkod) || normMusteriAd(o.customer?.name) === normMusteriAd(adSoyad)) {
        o.customer = { ...o.customer, ...yeniMusteriObj };
        degisti = true;
      }
    });
    if (degisti) fs.writeFileSync(MEZATRON_ORDERS_PATH, JSON.stringify(orders, null, 2), 'utf8');
  } catch (_) {}

  // Kuyruktaki etiketi güncelle
  productLabelQueue.forEach(p => {
    if ((barkod && (p.siparisNo === barkod || p.barkod === barkod)) || normMusteriAd(p.musteri) === normMusteriAd(adSoyad)) {
      p.musteri = adSoyad;
      p.musteriId = yeniId;
      p.telefon = telefon;
      p.adres = adres;
      p.raf = yeniMusteriObj.binNumber.replace(/^RAF:\s*/i, '');
      p.musteriKayit = musteriKayitKontrolEt({ id: yeniId, name: adSoyad, phone: telefon, address: adres });
    }
  });

  return {
    success: true,
    musteri: yeniMusteriObj,
    musteriKayit: musteriKayitKontrolEt({ id: yeniId, name: adSoyad, phone: telefon, address: adres })
  };
}

const SON_OKUTULAN_JSON = path.join(DATA_DIR, 'son-okutulan-barkodlar.json');

function sonOkutulanlariOku() {
  try {
    if (fs.existsSync(SON_OKUTULAN_JSON)) {
      const veri = JSON.parse(fs.readFileSync(SON_OKUTULAN_JSON, 'utf8'));
      if (Array.isArray(veri)) return veri;
    }
  } catch (_) {}
  return [];
}

function sonOkutulanKaydet(kayit) {
  try {
    const liste = sonOkutulanlariOku();
    const yeni = {
      zaman: kayit.zaman || new Date().toLocaleTimeString('tr-TR'),
      zamanMs: Date.now(),
      kod: String(kayit.kod || '').trim().toUpperCase(),
      sonuc: kayit.sonuc || 'TAMAM',
      ad: kayit.ad || '',
      urun: kayit.urun || '',
      raf: kayit.raf || ''
    };
    const filtreli = liste.filter(x => !(x.kod === yeni.kod && (Date.now() - (x.zamanMs || 0)) < 3000));
    filtreli.unshift(yeni);
    if (filtreli.length > 50) filtreli.length = 50;
    fs.writeFileSync(SON_OKUTULAN_JSON, JSON.stringify(filtreli, null, 2), 'utf8');
    return filtreli;
  } catch (_) {
    return [];
  }
}

function musteriHassasBilgiMaskele(item) {
  if (!item || typeof item !== 'object') return item;
  const tel = String(item.telefon || '');
  const maskeliTel = tel.length >= 7 ? `${tel.slice(0, 4)} *** ** ${tel.slice(-2)}` : (tel ? '***' : '');
  const adr = String(item.adres || '');
  const maskeliAdr = adr.length > 18 ? `${adr.slice(0, 12)}...` : adr;
  return {
    ...item,
    telefon: maskeliTel,
    adres: maskeliAdr,
    ...(item.musteriKayit ? {
      musteriKayit: {
        ...item.musteriKayit,
        telefon: maskeliTel,
        acikAdres: maskeliAdr
      }
    } : {})
  };
}

function depoScanSummary({ tamYetki = false } = {}) {
  mezatronSiparisleriniKuyrugaSenkronla();
  const maskeleyici = tamYetki ? (x => x) : musteriHassasBilgiMaskele;
  const sent = productLabelQueue.filter(p => p.etiket && p.etiket.gonderimSayisi > 0).map(maskeleyici);
  const okutulmayan = sent.filter(p => !p.etiket.okunduMs);
  const hatali = sent.filter(p => (p.etiket.hatalar || []).length > 0);
  const bekleyenEtiketler = productLabelQueue.filter(p => p.etiket && p.etiket.durum === 'BEKLIYOR').map(maskeleyici);
  let urunBarkodlari = [];
  try {
    const banka = urunDeposu.barkodBankasiListesi('', urunDeposu.gunAdi());
    urunBarkodlari = (banka && Array.isArray(banka.urunler) ? banka.urunler : []).slice(0, 12).map(u => ({
      barkod: u.anaBarkod || u.barkod,
      urun: u.urun,
      fiyat: u.fiyat || 0
    }));
  } catch (_) {}

  let sonOkutulanlar = sonOkutulanlariOku();
  if (sonOkutulanlar.length === 0) {
    // Henüz okutma geçmişi yoksa okutulmuş etiketleri ve bugünkü envanter barkodlarını başlangıç geçmişi olarak hazırla
    const okunanEtiketler = sent.filter(p => p.etiket && p.etiket.okunduMs).map(p => ({
      zaman: new Date(p.etiket.okunduMs).toLocaleTimeString('tr-TR'),
      zamanMs: p.etiket.okunduMs,
      kod: p.siparisNo || p.barkod,
      sonuc: 'TAMAM',
      ad: `${p.musteri || ''}${p.beden ? ` · ${p.beden}` : ''}`,
      urun: p.urun || '',
      raf: p.raf || 'DEPO'
    }));
    const envanterGecmis = urunBarkodlari.slice(0, 6).map(u => ({
      zaman: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
      zamanMs: Date.now(),
      kod: u.barkod,
      sonuc: 'URUN_STOK',
      ad: `${u.urun} (${u.fiyat || 0} TL)`,
      urun: u.urun,
      raf: 'DEPO STOK'
    }));
    sonOkutulanlar = [...okunanEtiketler, ...envanterGecmis].slice(0, 20);
  }

  return {
    tamYetki: Boolean(tamYetki),
    gonderilen: sent.length,
    okunan: sent.filter(p => p.etiket.okunduMs).length,
    fotograflanan: posetFotolariniOku().length,
    okutulmayan,
    hatali,
    hataliSayisi: hatali.length,
    bekleyenEtiketler,
    urunBarkodlari,
    sonOkutulanlar
  };
}

// Poşetlenen Ürün Fotoğraflama (Kanıt Arşivi) Deposu
const POSET_FOTO_DIR = path.join(DATA_DIR, 'poset-fotograflari');
const POSET_FOTO_JSON = path.join(DATA_DIR, 'poset-fotograflari.json');
fs.mkdirSync(POSET_FOTO_DIR, { recursive: true });

function posetFotolariniOku() {
  try {
    if (fs.existsSync(POSET_FOTO_JSON)) {
      const veri = JSON.parse(fs.readFileSync(POSET_FOTO_JSON, 'utf8'));
      return Array.isArray(veri) ? veri : [];
    }
  } catch (_) {}
  return [];
}

function posetFotolariniYaz(liste) {
  try {
    fs.writeFileSync(POSET_FOTO_JSON, JSON.stringify(liste, null, 2), 'utf8');
  } catch (_) {}
}

function posetFotoKaydet(veri = {}) {
  const hamGorsel = String(veri.gorselVeri || veri.image || '');
  const eslesme = hamGorsel.match(/^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/i);
  if (!eslesme) {
    return { success: false, error: 'Geçerli bir fotoğraf verisi gönderilmedi.' };
  }
  const uzanti = eslesme[1].toLowerCase() === 'png' ? 'png' : 'jpg';
  const buf = Buffer.from(eslesme[2], 'base64');
  if (buf.length < 100 || buf.length > 14 * 1024 * 1024) {
    return { success: false, error: 'Fotoğraf boyutu geçersiz (maksimum 14 MB).' };
  }
  const simdi = new Date();
  const id = `PF-${simdi.getFullYear()}${String(simdi.getMonth() + 1).padStart(2, '0')}${String(simdi.getDate()).padStart(2, '0')}-${Date.now().toString(36).toUpperCase()}`;
  const dosyaAdi = `${id}.${uzanti}`;
  const dosyaYolu = path.join(POSET_FOTO_DIR, dosyaAdi);
  fs.writeFileSync(dosyaYolu, buf);

  let barkod = String(veri.barkod || veri.siparisNo || 'GENEL-POSET').trim().toUpperCase();
  if (/^(?:HTTPS?:\/\/|WWW\.)/i.test(barkod) || /\.(?:COM|NET|ORG|TR|LINK|PAGE\.LINK)\b/i.test(barkod)) {
    barkod = 'GENEL-POSET';
  }
  const qItem = productLabelQueue.find(p => p.barkod === barkod || p.siparisNo === barkod || p.orderId === barkod);
  const bKayit = !qItem ? urunDeposu.barkodBul(barkod) : null;
  const baskaSipariseAitMusteriMi = !qItem && veri.musteri && productLabelQueue.some(p => p.musteri === veri.musteri);

  const kayit = {
    id,
    dosyaAdi,
    barkod,
    siparisNo: String((qItem && qItem.siparisNo) || barkod),
    musteri: String((qItem && qItem.musteri) || (bKayit && bKayit.bulundu ? bKayit.urun : (!baskaSipariseAitMusteriMi && veri.musteri ? veri.musteri : 'Depo Poşeti'))),
    urun: String((qItem && qItem.urun) || (bKayit && bKayit.bulundu ? `${bKayit.urun} (${bKayit.fiyat || 0} TL)` : (!baskaSipariseAitMusteriMi && veri.urun ? veri.urun : 'Poşetlenen Ürün'))),
    beden: String(veri.beden || (qItem && qItem.beden) || (bKayit && bKayit.bulundu ? [bKayit.renk, bKayit.beden].filter(Boolean).join(' ') : '')),
    raf: String(veri.raf || (qItem && qItem.raf) || 'DEPO'),
    personel: String(veri.personel || 'Depo Görevlisi').slice(0, 60),
    not: String(veri.not || '').slice(0, 240),
    tarihIso: simdi.toISOString(),
    tarihSaat: simdi.toLocaleString('tr-TR'),
    boyutKb: Math.round(buf.length / 1024),
    gorselUrl: `/api/poset-foto/gorsel/${id}`
  };

  if (qItem && qItem.etiket) {
    qItem.etiket.okunduMs = qItem.etiket.okunduMs || Date.now();
    qItem.etiket.posetFotoId = id;
    qItem.etiket.posetFotoUrl = kayit.gorselUrl;
    qItem.etiket.posetFotoSaat = kayit.tarihSaat;
  }

  const liste = posetFotolariniOku();
  liste.unshift(kayit);
  if (liste.length > 500) liste.length = 500;
  posetFotolariniYaz(liste);

  return { success: true, kayit };
}

function posetFotoListeHazirla(arama = '') {
  const q = String(arama || '').trim().toLocaleLowerCase('tr-TR');
  const tumu = posetFotolariniOku();
  const filtreli = q
    ? tumu.filter(k =>
        String(k.barkod || '').toLocaleLowerCase('tr-TR').includes(q) ||
        String(k.musteri || '').toLocaleLowerCase('tr-TR').includes(q) ||
        String(k.urun || '').toLocaleLowerCase('tr-TR').includes(q) ||
        String(k.personel || '').toLocaleLowerCase('tr-TR').includes(q))
    : tumu;

  const fotograflananBarkodlar = new Set(tumu.map(k => k.barkod));
  const adayPosetler = [];

  productLabelQueue.forEach(p => {
    const kod = p.siparisNo || p.barkod;
    adayPosetler.push({
      barkod: kod,
      siparisNo: kod,
      musteri: p.musteri,
      urun: p.urun,
      beden: p.beden || '',
      raf: p.raf || 'DEPO',
      okutuldu: Boolean(p.etiket && p.etiket.okunduMs),
      fotograflandi: fotograflananBarkodlar.has(kod) || Boolean(p.etiket && p.etiket.posetFotoId)
    });
  });

  try {
    const banka = urunDeposu.barkodBankasiListesi('', urunDeposu.gunAdi());
    (banka && Array.isArray(banka.urunler) ? banka.urunler : []).slice(0, 8).forEach(u => {
      const kod = u.anaBarkod || u.barkod;
      if (!adayPosetler.some(a => a.barkod === kod)) {
        adayPosetler.push({
          barkod: kod,
          siparisNo: kod,
          musteri: u.urun,
          urun: `${u.urun} (${u.fiyat || 0} TL)`,
          beden: (u.varyantlar && u.varyantlar[0] ? [u.varyantlar[0].renk, u.varyantlar[0].beden].filter(Boolean).join(' ') : 'STOK'),
          raf: 'DEPO STOK',
          okutuldu: true,
          fotograflandi: fotograflananBarkodlar.has(kod)
        });
      }
    });
  } catch (_) {}

  const bugunStr = new Date().toLocaleDateString('tr-TR');
  const bugunSayisi = tumu.filter(k => String(k.tarihSaat || '').startsWith(bugunStr)).length;

  return {
    success: true,
    kayitlar: filtreli,
    adayPosetler,
    istatistik: {
      toplamFoto: tumu.length,
      bugunFoto: bugunSayisi,
      bekleyenPoset: adayPosetler.filter(a => !a.fotograflandi).length
    }
  };
}

function depoScanLabel(kod) {
  mezatronSiparisleriniKuyrugaSenkronla();
  const hamStr = String(kod || '').trim();
  if (/^(?:https?:\/\/|www\.)/i.test(hamStr) || /\.(?:com|net|org|tr|link|page\.link)\b/i.test(hamStr)) {
    return { success: false, sonuc: 'BULUNAMADI', kod: '', mesaj: 'Okunan QR kod bir web sitesi bağlantısıdır; ürün veya sipariş barkodu değildir.' };
  }
  const bZirh = zirhKoruma.barkodZirhiDenetle(kod);
  if (!bZirh.gecerli && String(kod || '').trim()) {
    return { success: false, sonuc: 'ENGELLENDI', kod: '', mesaj: bZirh.hata || 'Geçersiz barkod engellendi.' };
  }
  const no = String(bZirh.temizBarkod || kod || '').trim().toUpperCase();
  if (!no) return { success: false, sonuc: 'BOS', mesaj: 'Barkod okunmadı.' };

  const qItem = productLabelQueue.find(p => p.barkod === no || p.siparisNo === no || p.orderId === no);
  if (qItem) {
    const now = Date.now();
    const onceki = qItem.etiket.okunduMs;
    qItem.etiket.okunduMs = qItem.etiket.okunduMs || now;
    qItem.etiket.gonderimSayisi = Math.max(1, qItem.etiket.gonderimSayisi || 0);
    qItem.etiket.durum = 'GONDERILDI';
    const musteriKayit = musteriKayitKontrolEt({
      id: qItem.musteriId,
      musteri: qItem.musteri,
      telefon: qItem.telefon,
      adres: qItem.adres,
      raf: qItem.raf
    });
    qItem.musteriKayit = musteriKayit;
    sonOkutulanKaydet({
      kod: no,
      sonuc: 'TAMAM',
      ad: `${qItem.musteri || ''}${qItem.beden ? ` · ${qItem.beden}` : ''}`,
      urun: qItem.urun || '',
      raf: qItem.raf || 'DEPO'
    });
    return {
      success: true,
      sonuc: 'TAMAM',
      kod: no,
      siparis: qItem,
      musteriKayit,
      mesaj: musteriKayit.kayitliMi
        ? `✅ Sipariş ve Müşteri Doğrulandı (${qItem.musteri} · Sistemde Kayıtlı Müşteri).`
        : `⚠️ Sipariş Doğrulandı ANCAK "${qItem.musteri}" Sistemde Kayıtlı Müşteri Değil (Adres/Telefon Eksik)!`,
      oncekiOkutma: onceki ? new Date(onceki).toLocaleTimeString('tr-TR') : null
    };
  }

  // Doğrudan Müşteri Barkodu / ID'si (CUST-001 vb.) okutulduysa
  if (/^CUST-/i.test(no)) {
    const musteriKayit = musteriKayitKontrolEt({ id: no });
    if (musteriKayit && musteriKayit.adSoyad && musteriKayit.adSoyad !== 'Bilinmeyen Müşteri') {
      sonOkutulanKaydet({
        kod: no,
        sonuc: 'TAMAM',
        ad: `${musteriKayit.adSoyad} · MÜŞTERİ KARTI`,
        urun: musteriKayit.sehirIlce || 'Adres Kontrolü',
        raf: musteriKayit.raf || 'DEPO'
      });
      return {
        success: true,
        sonuc: 'TAMAM',
        kod: no,
        siparis: {
          orderId: no,
          siparisNo: no,
          barkod: no,
          musteri: musteriKayit.adSoyad,
          musteriId: musteriKayit.musteriId,
          raf: musteriKayit.raf || 'DEPO',
          beden: 'MÜŞTERİ KARTI',
          urun: `Kayıt Kontrolü · ${musteriKayit.sehirIlce || 'Adres Kontrolü'}`,
          adet: 1,
          fiyat: 0
        },
        musteriKayit,
        mesaj: musteriKayit.aciklama
      };
    }
  }

  const bKayit = urunDeposu.barkodBul(no);
  if (bKayit && bKayit.bulundu) {
    const varyantMetin = [bKayit.renk, bKayit.beden].filter(Boolean).join(' / ') ||
      (Array.isArray(bKayit.varyantlar) && bKayit.varyantlar.length
        ? bKayit.varyantlar.map(v => `${[v.renk, v.beden].filter(Boolean).join(' ')} (${v.sonAdet || 1})`).slice(0, 5).join(', ')
        : 'Standart');
    sonOkutulanKaydet({
      kod: bKayit.barkod || no,
      sonuc: 'URUN_STOK',
      ad: `${bKayit.urun} (${bKayit.fiyat || 0} TL)`,
      urun: varyantMetin,
      raf: 'DEPO STOK'
    });
    return {
      success: true,
      sonuc: 'URUN_STOK',
      kod: bKayit.barkod || no,
      siparis: {
        orderId: `ENV-${bKayit.barkod || no}`,
        siparisNo: bKayit.barkod || no,
        barkod: bKayit.barkod || no,
        musteri: bKayit.urun,
        raf: 'DEPO STOK',
        beden: [bKayit.renk, bKayit.beden].filter(Boolean).join(' ') || 'STOK',
        urun: `Varyant: ${varyantMetin} · Fiyat: ${bKayit.fiyat || 0} TL`,
        adet: 1,
        fiyat: bKayit.fiyat || 0
      },
      mesaj: `📦 Envanter ürünü doğrulandı (${bKayit.urun} · ${bKayit.fiyat || 0} TL).`
    };
  }
  sonOkutulanKaydet({
    kod: no,
    sonuc: 'BULUNAMADI',
    ad: 'Bilinmeyen Barkod',
    urun: 'Kuyrukta veya stokta yok',
    raf: '-'
  });
  return { success: false, sonuc: 'BULUNAMADI', kod: no, mesaj: `${no}: Bu barkod envanterde veya etiket kuyruğunda bulunamadı.` };
}

// Depo görevlisi ses izi doğrulama motoru (Sherpa-ONNX 3D-Speaker)
const voiceIdentity = voiceIdentityModule.createVoiceIdentity({
  dataDir: DATA_DIR,
  engine: voiceIdentityModule.loadRealEngine()
});

// Konuşma motoru (Paylaşımlı 3100 portu veya kendi başlattığı motor)
const RAW_ENGINE_DIR = process.env.MOTOR_KLASORU ? path.resolve(process.env.MOTOR_KLASORU) : path.join(__dirname, 'motor');
const ENGINE_DIR = evrenselMotor.ensureAsciiPathBridge(RAW_ENGINE_DIR, 'envanter_whisper');
const ENGINE_EXE = path.join(ENGINE_DIR, 'bin', 'Release', 'whisper-server.exe');
const ENGINE_FILES_DIR = path.join(ENGINE_DIR, 'indirilen');
const ENGINE_PORT = Number(process.env.MOTOR_PORT) || 3100;
const ENGINE_URL = process.env.UZAK_MOTOR_URL ? String(process.env.UZAK_MOTOR_URL).replace(/\/+$/, '') : `http://127.0.0.1:${ENGINE_PORT}`;
const ENGINE_TIMEOUT_MS = 20000;
const MAX_VOICE_BODY_BYTES = 8 * 1024 * 1024;
const ENGINE_HALLUCINATION = /altyazı|izlediğiniz için|abone ol|iyi seyirler|hoşça kal|görüşmek üzere|devam edecek|kanalımıza|^\s*(?:teşekkür\p{L}*|teşekkür\s+ederim|sağ\s*ol\p{L}*|thank\s*you)[.!?,;\s]*$|^\s*[\[(].*[\])]\s*$|^[\s.,!?♪-]*$/iu;

const URUN_GIRISI_IPUCU = "Ürün Versace mont, fiyat 1000, beden S, adet 15, renk beyaz. Ürün Barbara çizgili gömlek, fiyat 500, beden XXL, adet 5, renk sarı. Ürün keten gömlek, fiyat 450, beden M, adet 10, renk siyah. Ürün Chanel parfüm 100 ml, fiyat 1500, adet 5.";

function magazaUrunIsimleriGetir() {
  try {
    const listeObj = urunDeposu.barkodBankasiListesi ? urunDeposu.barkodBankasiListesi() : [];
    const liste = Array.isArray(listeObj) ? listeObj : (Array.isArray(listeObj && listeObj.kayitlar) ? listeObj.kayitlar : []);
    const tekil = [];
    const gorulen = new Set();
    for (const k of liste) {
      const ad = String(k && k.urun || '').trim();
      if (!ad || ad.length < 3 || /[ðþæøßñáéíóúýãõåäâîû]/i.test(ad)) continue;
      const aLow = ad.toLocaleLowerCase('tr-TR');
      if (gorulen.has(aLow)) continue;
      gorulen.add(aLow);
      tekil.push({ urun: ad, fiyat: k.fiyat || null, barkod: k.anaBarkod || k.barkod || null });
      if (tekil.length >= 60) break;
    }
    return tekil;
  } catch (_) {
    return [];
  }
}

function dinamikWhisperIpucuUret() {
  const magazaUrunleri = magazaUrunIsimleriGetir().slice(0, 6).map(x => typeof x === 'string' ? x : x.urun);
  if (!magazaUrunleri.length) return URUN_GIRISI_IPUCU;
  const ornekCumleler = magazaUrunleri.slice(0, 3).map(u => `Ürün ${u}, fiyat 500, beden L, adet 5, renk siyah.`).join(' ');
  return `${URUN_GIRISI_IPUCU} ${ornekCumleler}`.slice(0, 380);
}

let engineState = { kip: 'hazirlaniyor', kart: null, kartAdi: '', sebep: '', webspeechDestegi: true };
let engineProcess = null;

// Bilgisayarda ses tanıma açık/kapalı (panelde tek tuş). Kapalıyken Balbal ve Seda belleğe yüklenmez.
const SES_MOTORU_AYAR_DOSYA = path.join(DATA_DIR, 'ses-motoru-ayar.json');
function sesMotoruKapaliMi() {
  try { return JSON.parse(fs.readFileSync(SES_MOTORU_AYAR_DOSYA, 'utf8')).bilgisayardaKapali === true; } catch (_) { return false; }
}
const KAPALI_MOTOR_DURUMU = { kip: 'webspeech', kart: 'webspeech', kartAdi: 'Bilgisayarda ses tanıma kapalı (telefon sesi kendisi çözer)', sebep: 'Ayarlardan kapatıldı', webspeechDestegi: true };
if (sesMotoruKapaliMi()) turkceAsrMotorlari.motorlariKapat();

async function isEngineReady() {
  if (turkceAsrMotorlari.motorlarKapaliMi()) return false;
  try {
    const r = await fetch(`http://127.0.0.1:${Number(process.env.BALBAL_PORT) || 3101}/health`, { signal: AbortSignal.timeout(800) });
    if (r.ok) return true;
  } catch (_) {}
  return Boolean(turkceAsrMotorlari.sedaMotorunuHazirla() || turkceAsrMotorlari.mihuMotorunuHazirla());
}

function detectNvidia() {
  return new Promise(resolve => {
    execFile('nvidia-smi', ['--query-gpu=name,memory.total', '--format=csv,noheader,nounits'], { timeout: 5000, windowsHide: true }, (err, out) => {
      if (err) return resolve(null);
      const [name, mem] = String(out).trim().split(/\r?\n/)[0].split(',').map(s => s.trim());
      resolve(name ? { ad: name, vramMB: Number(mem) || 0 } : null);
    });
  });
}

async function ensureVoiceEngine() {
  if (turkceAsrMotorlari.motorlarKapaliMi()) { engineState = { ...KAPALI_MOTOR_DURUMU }; return false; }
  turkceAsrMotorlari.tumTurkceMotorlariIsit();
  const hazir = await turkceAsrMotorlari.balbalMotorunuBaslat();
  if (hazir || (await isEngineReady())) {
    engineState = {
      kip: 'ses',
      kart: 'balbal_manas',
      kartAdi: 'İkili Türkçe/İngilizce Hızlı Ses Motoru (Balbal-v2-Manas 313M + Seda-v0.2)',
      sebep: '',
      webspeechDestegi: true
    };
    return true;
  }
  engineState = { kip: 'webspeech', kart: 'webspeech', kartAdi: 'Tarayıcı Ses Tanıma (WebSpeech - 0 MB RAM)', sebep: 'Yerel ses motoru açık değil, tarayıcı sesi aktif', webspeechDestegi: true };
  return false;
}

ensureVoiceEngine();
process.on('exit', () => { if (engineProcess) engineProcess.kill(); });

async function transcribeInventoryVoice(wavBuffer) {
  // 1. Gürültülü depo ortamı için sinyali analiz et; Türkçe sessiz harfleri (s, ş, ç, t, k, v) bozmamak için 75-7600 Hz geniş bant ve yumuşak kapı uygula
  const islenmis = evrenselMotor.temizleVeGuclendirWav(wavBuffer, { highpassHz: 75, lowpassHz: 7600, gateCarpani: 1.12 });
  const temizWav = islenmis.buffer;
  const audioCtx = evrenselMotor.calculateDynamicAudioCtx(temizWav);

  // 2. Depo görevlisi ses izi (tanıtılmışsa arka plandaki yabancı sesleri denetler)
  const konusmaci = voiceIdentity.check(temizWav);

  // 3. ÜÇLÜ SAF TÜRKÇE/İNGİLİZCE KONSEY MOTORU (Whisper Devre Dışı - ~200 ms Anlık Yanıt):
  //    a) balbal-v2-manas (313M, Port 3101 - Türkçe+İngilizce FastConformer-CTC + C++ HotwordLM, ~90 ms)
  //    b) Mihu-STT-v2 (66M, Sherpa-ONNX C++ - Noktalamalı Türkçe Zipformer2 Transducer, ~200 ms)
  //    c) Seda-v0.2 (Sherpa-ONNX C++ - Türkçe Zipformer2 Transducer, ~170 ms)
  const startedAt = Date.now();
  const turkceMotorlar = await turkceAsrMotorlari.paralelTurkceAsrCalistir(temizWav).catch(() => ({
    balbalMetin: '', mihuMetin: '', sedaMetin: '', balbalSureMs: 0, mihuSureMs: 0, sedaSureMs: 0
  }));
  const motorMs = Date.now() - startedAt;
  const balbalText = String((turkceMotorlar && turkceMotorlar.balbalMetin) || '').trim();
  const mihuText = String((turkceMotorlar && turkceMotorlar.mihuMetin) || '').trim();
  const sedaText = String((turkceMotorlar && turkceMotorlar.sedaMetin) || '').trim();
  const text = balbalText || mihuText || sedaText;
  const confidence = { seviye: text ? 'yuksek' : 'dusuk', neden: 'Balbal-v2-Manas + Mihu-v2 + Seda-v0.2 Konseyi' };

  return {
    text,
    rawText: text,
    whisperText: '',
    balbalText,
    mihuText,
    sedaText,
    balbalModel: (turkceMotorlar && turkceMotorlar.balbalModel) || 'balbal-v2-manas',
    balbalMs: (turkceMotorlar && turkceMotorlar.balbalSureMs) || 0,
    mihuMs: (turkceMotorlar && turkceMotorlar.mihuSureMs) || 0,
    sedaMs: (turkceMotorlar && turkceMotorlar.sedaSureMs) || 0,
    motorMs,
    confidence,
    konusmaci,
    sesAnalizi: {
      ...islenmis.analiz,
      oncekiSnrDb: islenmis.oncekiAnaliz ? islenmis.oncekiAnaliz.snrDb : null,
      uygulananKazanc: islenmis.uygulananKazanc,
      temizlendi: islenmis.temizlendi,
      audioCtx
    }
  };
}

function deepseekAnahtariYukle() {
  if (process.env.HAKEM_KAPALI) return null;
  if (process.env.DEEPSEEK_API_KEY) return String(process.env.DEEPSEEK_API_KEY).trim();
  const adayYollar = [
    path.join(__dirname, '.env'),
    path.resolve(__dirname, '..', 'live-commerce-demo', '.env')
  ];
  for (const p of adayYollar) {
    try {
      if (fs.existsSync(p)) {
        const m = fs.readFileSync(p, 'utf8').match(/^DEEPSEEK_API_KEY=(\S+)/m);
        if (m && m[1]) return m[1].trim();
      }
    } catch (_) {}
  }
  return null;
}

const DEEPSEEK_KEY = deepseekAnahtariYukle();
const DEEPSEEK_URL = 'https://api.deepseek.com/chat/completions';
const HAKEM_PROMPT = `Sen bir giyim, ayakkabı, parfüm/kozmetik ve tekstil deposunun "Anahtar Kelime Çapalı (Ürün / Fiyat / Beden / Adet / Renk)" Kolektif Ses ve Envanter Konsensüs Konseyisin.
Kullanıcı ürünleri sesle girerken alanları şu ANAHTAR KELİMELERLE belirterek söyler:
- "ÜRÜN <Marka + Ürün Cinsi>" (Whisper bazen "Ünlü ...", "Günün ...", "Ürünün ...", "Marmara gömlek -> Barbara Gömlek", "para gömlek -> Barbara Gömlek" diye yazabilir) -> "urun" alanı
- "FİYAT <Sayı>" (Whisper bazen "fiyahtı", "yat", "fırat" diye yazabilir) -> "fiyat" alanı
- "BEDEN <Beden/Numara>" (Whisper bazen "meden", "ve den", "be den", "neden", "bedense/sebeden/sebebeden/sebebden/sebedin -> beden S", "bedenle/lebeden/elbeden -> beden L", "bedenem/mebeden/embeden -> beden M" diye yazabilir) -> "beden" alanı
- "ADET <Sayı>" (Whisper bazen "alet", "aded", "at et", "tane", "adet O5 -> adet 5" diye yazabilir) -> "adet" alanı
- "RENK <Renk>" (Whisper bazen "reyni", "rengi", "genç", "cenk", "ren", "kahveringi/kafirengi -> kahverengi" diye yazabilir) -> "renk" alanı

Görevin:
1) ANAHTAR KELİME ÇAPALI ÇÖZÜMLEME: Sana verilen "anahtar_kelime_dilimleri", "son_soz" (Whisper düz yazısı), "webspeech_yedek" (Google WebSpeech düz yazısı), "fonetik_barkod_bankasi_adaylari" ve "yerel_kural_cozumu" verilerini birlikte incele:
   - "Ürün" anahtar kelimesinden sonra (veya ilk anahtar kelimeden önce) söylenen marka ve ürün cinsi bölümünü analiz et; markayı resmi yazılışıyla (örn: Versace, Barbara, Mavi Jeans, Gezer, Greyder, Beymen, Chanel, Dior Sauvage, Nishane Hacivat, Bigazzi, Xside, Rimoldi, Street One, Mona Lisa, Marima, Rollmann, North Face, Tekbir, Hermes, Zara, Columbia, Moncler, Reebok) ve ürün cinsini (Mont, Gömlek, Pantolon, Kot Pantolon, Kot Ceket, Tişört, Kazak, Elbise, Ceket, Eşarp, Çorap, Terlik, Ayakkabı, Bot, Parfüm vb.) doğru şekilde birleştirip "urun" alanına yaz.
   - "Fiyat" anahtar kelimesinden sonra gelen sayıyı "fiyat" alanına yaz.
   - "Beden" anahtar kelimesinden sonra gelen ifadeyi "beden" alanına ("S", "M", "L", "XL", "XXL", "2XL", "38", "40", "42", "44", "46", "50ML", "100ML", "STD") yaz.
   - "Adet" anahtar kelimesinden sonra gelen sayıyı "adet" alanına (tam sayı) yaz.
   - "Renk" anahtar kelimesinden sonra gelen rengi (çift renk söylendiyse ör: "siyah beyaz" -> "SİYAH BEYAZ", "yeşil sarı" -> "YEŞİL SARI", "yeşil gri" -> "YEŞİL GRİ" olarak birlikte) "renk" alanına yaz.
2) HALÜSİNASYON FİLTRESİ (ÇOK KRİTİK): Bir ifadenin "urun" olabilmesi için içinde MUTLAKA gerçek bir giyim/ayakkabı/kozmetik/aksesuar/ev tekstili ürün cinsi VEYA bilinen bir mağaza markası VEYA "fonetik_barkod_bankasi_adaylari" eşleşmesi bulunmalıdır! İçinde ne ürün cinsi ne marka olan uydurma/anlamsız/yabancı kelimeleri (ör: "Meriç Mâş Düzal", "Sefðin Aðeimt Ondís", "Benîn", "Genç", "O5", "Şarkiði mælum") ASLA "urun" alanına yazma ("urun": "" bırak; eğer cümlede renk/beden/adet/fiyat da yoksa "halusinasyon": true döndür)!
3) DEVAM KAYITLARI ("ÜRÜN" DENMEDEN SÖYLENEN BEDEN/ADET/RENK): Eğer cümlede "Ürün ..." anahtar kelimesi veya yeni bir ürün cinsi/markası SÖYLENMEDİYSE (örneğin kullanıcı açık ürüne devam ederek sadece "beden XXL adet 5 renk sarı", "renk kahverengi", "beden M adet 10", "fiyat 1000 lira" dediyse), "urun" alanını KESİNLİKLE "" (boş) bırak ki ekrandaki mevcut ürüne eklensin!
4) ÜÇLÜ MOTOR KONSENSÜSÜ (Whisper large-v3-turbo + balbal-v2 + Seda-v0.2):
   - "son_soz" (Whisper large-v3-turbo) yabancı giyim markalarını (North Face, Versace, Pierre Cardin, Columbia, Fashion, Zara vb.) ve rakamları en iyi yakalayan motordur.
   - "balbal_v2_turkce" ve "seda_v02_turkce" ise Bluetooth/telefon sesinde Türkçe anahtar kelimeleri ("ürün", "fiyat", "beden", "adet", "renk"), Türkçe giyim kategorilerini ("erkek el çantası", "keten gömlek", "çizgili gömlek", "ayakkabı") ve renkleri en iyi yakalayan saf Türkçe motorlardır.
   - Bu üç motorun çıktılarını birleştirerek markayı Whisper'dan, Türkçe kelimeleri ve eksik kalan beden/adet/renk/kategori bilgilerini balbal-v2 ve Seda-v0.2'den tamamla! Parfümlerde ml bilgisini ("50 ML", "100 ML" vb.) hem ürün adının sonuna hem de satırın "beden" alanına ("50ML", "100ML") yaz.
5) "temiz_soz" alanına, halüsinasyonlardan ve yazım hatalarından arındırılmış temiz Türkçe envanter cümlesini yaz (ör: "Ürün Barbara Çizgili Gömlek, fiyat 500 TL, beden XXL, adet 5, renk sarı" veya "Beden XXL, adet 5, renk sarı").

Yanıtı SADECE şu JSON şemasıyla ver:
{"urun":"Ürün Adı","fiyat":300,"satirlar":[{"renk":"SİYAH","beden":"46","adet":5}],"temiz_soz":"Temizlenmiş Türkçe cümle","halusinasyon":false,"aciklama":"Kısa kolektif konsey notu"}`;

function temizEnvanterMetniUret(hamMetin, cozum) {
  if (!cozum || typeof cozum !== 'object') return hamMetin;
  const parcalar = [];
  if (cozum.urun) parcalar.push(cozum.urun);
  if (cozum.fiyat && Number(cozum.fiyat) > 0) parcalar.push(`${cozum.fiyat} TL`);
  if (Array.isArray(cozum.satirlar)) {
    for (const s of cozum.satirlar) {
      const sp = [];
      if (s.renk) sp.push(s.renk);
      if (s.beden) sp.push(`Beden ${s.beden}`);
      if (s.adet != null && Number(s.adet) > 0) sp.push(`${s.adet} Adet`);
      if (sp.length > 0) parcalar.push(sp.join(' '));
    }
  }
  const sentez = parcalar.join(', ');
  if (sentez) return sentez;
  if (cozum.temizSoz && !/[ðþæøßñáéíóúýãõåäâîû]/i.test(cozum.temizSoz)) {
    return cozum.temizSoz;
  }
  return hamMetin;
}

// İki ses motoru ürün adını farklı anladıysa (boşluk ve noktalama sayılmaz) yanlış ad kaydedilmesin diye hakeme sorulur
function motorlarUrundeAyriliyorMu(duyulan) {
  if (!duyulan || !duyulan.balbalText || !duyulan.sedaText) return false;
  const ad = metin => String(urunGirisi.coz(metin).urun || '').toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]/gu, '');
  const a = ad(duyulan.balbalText), b = ad(duyulan.sedaText);
  return Boolean(a && b && a !== b);
}

// Hakem ürün adını bulamadıysa yerelde bulunan ad silinmez
function hakemSonucuKullanilsinMi(yerelCozum, hakemCozum) {
  return Boolean(hakemCozum && (hakemCozum.urun || !yerelCozum.urun));
}

function hakemGerekliMi(cozum, duyulan, mevcutDurum) {
  if (!DEEPSEEK_KEY) return false;
  if (!cozum) return true;
  const urunVar = Boolean(cozum.urun && cozum.urun.trim().length >= 2);
  const fiyatVar = Boolean(cozum.fiyat && Number(cozum.fiyat) > 0);
  const anlamliSatirVar = Array.isArray(cozum.satirlar) && cozum.satirlar.some(
    s => s && (s.renk || s.beden || (s.adet != null && Number(s.adet) > 0))
  );
  const acikUrunVar = Boolean(mevcutDurum && mevcutDurum.urun && String(mevcutDurum.urun).trim().length >= 2);
  const birlesikSes = [
    duyulan && duyulan.text,
    duyulan && duyulan.balbalText,
    duyulan && duyulan.sedaText
  ].filter(Boolean).join(' ');
  const urunAnahtariSoylendi = /\b(?:ürün|urun|ürünü|urunu)\b/iu.test(birlesikSes);

  // 1. İki yerel motor hiçbir ürün, fiyat veya beden/adet/renk çıkaramadıysa hakeme sor
  if (!urunVar && !fiyatVar && !anlamliSatirVar) return true;

  // 2. Kullanıcı açıkça "Ürün ..." dediği halde yerel motorlar ürün adını çıkaramadıysa hakeme sor
  if (urunAnahtariSoylendi && !urunVar) return true;

  // 3. Ekranda açık bir ürün yokken yeni kayıt giriliyor ama ürün adı hiç bulunamadıysa hakeme sor
  if (!acikUrunVar && !urunVar) return true;

  // 4. İki ses motoru ürün adında ayrıldıysa hakeme sor
  if (motorlarUrundeAyriliyorMu(duyulan)) return true;

  // Yerel ikili motor (Balbal-v2 + Seda-v0.2 + Sözlük) ürünü ve/veya sayıları bulduysa DeepSeek'i ÇAĞIRMA (0 ms bekleme!)
  return false;
}

function ucluMotorYerelBirlestir(cWhisper, cBalbal, cMihu, cSeda) {
  const ana = cWhisper ? { ...cWhisper, satirlar: Array.isArray(cWhisper.satirlar) ? cWhisper.satirlar.map(s => ({ ...s })) : [] } : { urun: '', fiyat: null, satirlar: [], uyarilar: [] };
  const yardimcilar = [cBalbal, cMihu, cSeda].filter(Boolean);
  for (const y of yardimcilar) {
    if (!ana.urun && y.urun) {
      ana.urun = y.urun;
    } else if (ana.urun && y.urun && ana.urun.split(/\s+/).length === 1 && y.urun.split(/\s+/).length >= 2) {
      // Whisper sadece markayı ("North Face" veya "Fashion") yakalayıp Türkçe ürün cinsini ("Erkek El Çantası") kaçırdıysa birleştir
      const aLow = ana.urun.toLocaleLowerCase('tr-TR');
      const yLow = y.urun.toLocaleLowerCase('tr-TR');
      if (!yLow.includes(aLow)) {
        ana.urun = `${ana.urun} ${y.urun}`.replace(/\s+/g, ' ').trim();
      } else {
        ana.urun = y.urun;
      }
    }
    if (!ana.fiyat && y.fiyat) ana.fiyat = y.fiyat;
    if (Array.isArray(y.satirlar) && y.satirlar.length > 0) {
      if (ana.satirlar.length === 0) {
        ana.satirlar = y.satirlar.map(s => ({ ...s }));
      } else {
        const s0 = ana.satirlar[0];
        const ys0 = y.satirlar[0];
        if (s0 && ys0) {
          if (!s0.beden && ys0.beden) s0.beden = ys0.beden;
          if ((s0.adet == null || s0.adet <= 0) && ys0.adet > 0) s0.adet = ys0.adet;
          if (!s0.renk && ys0.renk) s0.renk = ys0.renk;
          else if (s0.renk && ys0.renk && ys0.renk.length > s0.renk.length && ys0.renk.includes(s0.renk)) s0.renk = ys0.renk;
        }
      }
    }
  }
  return ana;
}

async function envanterHakemineSor({ metin, yedekMetin, balbalMetin, mihuMetin, sedaMetin, yerelCozum, mevcutDurum }) {
  const baslangic = Date.now();
  const magazaUrunleri = magazaUrunIsimleriGetir();
  const birlesikHam = [metin, balbalMetin, mihuMetin, sedaMetin, yedekMetin].filter(Boolean).join(' | ');
  const anahtarDilimleri = urunGirisi.anahtarKelimeCapaliAyristir
    ? urunGirisi.anahtarKelimeCapaliAyristir(metin || balbalMetin || mihuMetin || sedaMetin || yedekMetin || '')
    : null;
  const adayAramaMetni = (anahtarDilimleri && anahtarDilimleri.capaliMi)
    ? (anahtarDilimleri.urunAnahtariVar ? `${anahtarDilimleri.urunDilimi} ${balbalMetin || ''} ${mihuMetin || ''} ${sedaMetin || ''} ${yedekMetin || ''}` : '')
    : `${yerelCozum && yerelCozum.urun ? yerelCozum.urun : ''} ${birlesikHam}`;
  const fonetikAdaylar = adayAramaMetni
    ? urunGirisi.kolektifUrunAdaylariBul(adayAramaMetni, magazaUrunleri)
    : [];

  // Eğer DeepSeek anahtarı yoksa bile Fonetik İkiz Motoru yüksek güvenli (>= 0.80) eşleşme bulduysa kolektif düzeltme uygula
  if (!DEEPSEEK_KEY) {
    if (yerelCozum && yerelCozum.urun && fonetikAdaylar.length > 0 && fonetikAdaylar[0].skor >= 0.80) {
      return {
        ...yerelCozum,
        urun: fonetikAdaylar[0].urun,
        hakemOnayli: true,
        hakemNotu: `Fonetik İkiz Motoru (${Math.round(fonetikAdaylar[0].skor * 100)}%)`,
        hakemSureMs: Date.now() - baslangic
      };
    }
    return null;
  }

  try {
    const izoleMetin = zirhKoruma.aiVeriKutusuSar(metin || '', 'depo_gorevlisi_sesi').izoleMetin;
    const temizMevcut = zirhKoruma.istekVerisiDenetle(mevcutDurum || {}, 'hakem_mevcut_durum').veri;
    const res = await fetch(DEEPSEEK_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${DEEPSEEK_KEY}`,
        'Content-Type': 'application/json'
      },
      signal: AbortSignal.timeout(4500),
      body: JSON.stringify({
        model: 'deepseek-chat',
        temperature: 0,
        max_tokens: 300,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: HAKEM_PROMPT },
          {
            role: 'user',
            content: JSON.stringify({
              anahtar_kelime_dilimleri: anahtarDilimleri,
              son_soz: izoleMetin,
              balbal_v2_turkce: balbalMetin || '',
              mihu_v2_turkce: mihuMetin || '',
              seda_v02_turkce: sedaMetin || '',
              webspeech_yedek: yedekMetin || '',
              fonetik_barkod_bankasi_adaylari: fonetikAdaylar,
              yerel_kural_cozumu: {
                urun: yerelCozum.urun || '',
                fiyat: yerelCozum.fiyat || null,
                satirlar: yerelCozum.satirlar || []
              },
              ekrandaki_mevcut_tablo: temizMevcut
            })
          }
        ]
      })
    });
    if (!res.ok) return null;
    const data = await res.json();
    const icerik = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (!icerik) return null;
    const parsed = JSON.parse(icerik);
    if (parsed.halusinasyon === true && !parsed.fiyat && (!Array.isArray(parsed.satirlar) || parsed.satirlar.length === 0)) {
      return {
        urun: '',
        fiyat: null,
        satirlar: [],
        halusinasyon: true,
        hakemOnayli: true,
        hakemNotu: String(parsed.aciklama || 'Halüsinasyon engellendi').slice(0, 120),
        hakemSureMs: Date.now() - baslangic
      };
    }
    const parsedUrunVar = parsed.urun !== undefined || parsed['ürün'] !== undefined;
    let urun = String((parsedUrunVar ? (parsed.urun ?? parsed['ürün']) : yerelCozum.urun) || '').trim();
    // Yabancı karakter halüsinasyonlarını ve ürün sonuna sızan tek harfli beden kırıntılarını ("Versace Mont C") temizle
    urun = urun.replace(/\b\S*[ðþæøßñáéíóúýãõåäâîû]\S*\b/giu, ' ').replace(/\s+/g, ' ').trim();
    if (urun.split(/\s+/).length >= 2) {
      urun = urun.replace(/\s+[bcçdfgğhjklmnprsştvyzqxw]$/iu, '').trim();
    }
    // Renk/desen veya bağlaç/"aynısından"/"yat"/"fiyat" kelimelerinin ürün adına sızmasını engelle
    if (/^(?:ayn[ıi]\p{L}*|bunun|bundan|bir\s*de|devam\p{L}*|ilave|çizgili|kareli|desenli|yeşil|gri|siyah|beyaz|mavi|kırmızı|sarı|kahverengi|kahveringi|muhtelif|ise|beden|yat|fiyat\p{L}*|seymiştir|seymistir|adet|tane|alet|genç|o\d+)$/iu.test(urun)) {
      urun = '';
    }
    // KATİ HALÜSİNASYON KALKANI: Hakemin döndürdüğü "urun" gerçek bir giyim/ayakkabı/kozmetik/aksesuar kategorisi, resmi marka veya mağaza barkod bankası eşleşmesi DEĞİLSE ("Meriç Mâş Düzal", "Benîn", "Sefðin" vb.), asla ürün adı kabul etme!
    if (urun && urunGirisi.gecerliUrunAdiMi && !urunGirisi.gecerliUrunAdiMi(urun, magazaUrunleri)) {
      if (fonetikAdaylar.length > 0 && fonetikAdaylar[0].skor >= 0.74) {
        urun = fonetikAdaylar[0].urun;
      } else {
        urun = '';
      }
    }
    // Hakem, yerel motorun sözlükten bulduğu resmi MARKA adını ("Bigazzi", "Versace", "Chanel" vb.) düşürdüyse, sadece o durumda yerel ürün adını koru.
    if (yerelCozum.urun && urun) {
      const temizYerelUrun = yerelCozum.urun.replace(/\s+[bcçdfgğhjklmnprsştvyzqxw]$/iu, '').trim();
      const yerelMarkali = urunGirisi.sozlukteMarkaVarMi && urunGirisi.sozlukteMarkaVarMi(temizYerelUrun);
      const hakemMarkali = urunGirisi.sozlukteMarkaVarMi && urunGirisi.sozlukteMarkaVarMi(urun);
      if (yerelMarkali && !hakemMarkali) {
        urun = temizYerelUrun;
      } else if (/^v\s+yaka\b/iu.test(temizYerelUrun) && !/^v\s+yaka\b/iu.test(urun) && urun.toLocaleLowerCase('tr-TR') === temizYerelUrun.replace(/^v\s+yaka\s+/iu, '').toLocaleLowerCase('tr-TR')) {
        urun = temizYerelUrun;
      }
    }
    // Not: Kullanıcı onaylamadan (Kaydet'e basmadan) AI tahminini kalıcı sözlüğe otomatik yazma (yanlış marka tahmininin kalıcılaşmasını önler)
    // Eğer yerel çözümde ürün adı yoksa (veya ekrandaki mevcut ürünün devamıysa), istemcinin açık karta ekleme yapabilmesi için boş bırak
    let acikKartaEkleme = false;
    if (mevcutDurum && mevcutDurum.urun) {
      const mLow = String(mevcutDurum.urun).toLocaleLowerCase('tr-TR').trim();
      const uLow = urun.toLocaleLowerCase('tr-TR').trim();
      if (!yerelCozum.urun || !urun || uLow === mLow || mLow.includes(uLow) || uLow.includes(mLow)) {
        urun = '';
        acikKartaEkleme = true;
      }
    }
    const hamFiyat = parsed.fiyat ?? parsed['fiyat'];
    let fiyat = Number.isFinite(Number(hamFiyat)) && Number(hamFiyat) > 0 ? Number(hamFiyat) : (yerelCozum.fiyat || null);
    if (yerelCozum.fiyat && yerelCozum.fiyat % 50 === 0 && fiyat && fiyat % 50 !== 0) {
      fiyat = yerelCozum.fiyat;
    }
    if (!yerelCozum.fiyat && fiyat && fiyat <= 200 && Array.isArray(yerelCozum.satirlar) && yerelCozum.satirlar.some(s => s.beden === `${fiyat}ML`)) {
      fiyat = null;
    }
    const hamSatirlar = Array.isArray(parsed.satirlar || parsed['satırlar']) ? (parsed.satirlar || parsed['satırlar']) : [];
    let satirlar = hamSatirlar
      .map(s => ({
        renk: String(s.renk || '').toLocaleUpperCase('tr-TR').trim(),
        beden: String(s.beden || '').toLocaleUpperCase('tr-TR').replace(/^L(\d{2})$/i, '$1').trim(),
        adet: s.adet != null && Number.isFinite(Number(s.adet)) && Number(s.adet) > 0 ? Math.round(Number(s.adet)) : null
      }))
      .filter(s => s.renk || s.beden || s.adet != null);

    if (fiyat > 0 && (!yerelCozum.satirlar || yerelCozum.satirlar.length === 0) && !/\b(?:adet|tane|beden|numara|renk)\b/iu.test(metin || '')) {
      satirlar = [];
    }

    if (Array.isArray(yerelCozum.satirlar) && yerelCozum.satirlar.length === 1) {
      const ys = yerelCozum.satirlar[0];
      if (ys.renk && ys.renk.includes(' ') && satirlar.length > 1) {
        satirlar = yerelCozum.satirlar;
      } else if (ys.beden && ys.adet != null && satirlar.length === 1) {
        if (!satirlar[0].beden || /^(?:L|M|S)$/i.test(satirlar[0].beden) && /^\d{2}$/.test(ys.beden)) {
          satirlar[0].beden = ys.beden;
        }
        if (satirlar[0].adet == null) satirlar[0].adet = ys.adet;
        if (ys.renk && ys.renk.includes(' ')) satirlar[0].renk = ys.renk;
      }
    }

    const sonSatirlar = (satirlar.length > 0 ? satirlar : (yerelCozum.satirlar || [])).filter(s => s && (s.renk || s.beden || (s.adet != null && s.adet > 0)));
    if (!urun && sonSatirlar.length === 0 && !fiyat) {
      return {
        urun: '',
        fiyat: null,
        satirlar: [],
        halusinasyon: true,
        hakemOnayli: true,
        hakemNotu: 'Anlamlı envanter verisi bulunamadı (halüsinasyon engellendi)',
        hakemSureMs: Date.now() - baslangic
      };
    }
    const temizSoz = String(parsed.temiz_soz || '').trim();
    return {
      urun: acikKartaEkleme ? '' : (urun || ''),
      fiyat,
      satirlar: sonSatirlar,
      temizSoz,
      uyarilar: [],
      hakemOnayli: true,
      hakemNotu: String(parsed.aciklama || 'DeepSeek Hakem doğruladı').slice(0, 120),
      hakemSureMs: Date.now() - baslangic
    };
  } catch (_) {
    return null;
  }
}

function barkodlaZenginlestir(cozum, gun) {
  if (!cozum || typeof cozum !== 'object') return cozum;
  if (cozum.urun) {
    const banka = urunDeposu.urunBarkodBilgisi(cozum.urun, gun);
    const anaBarkod = cozum.barkod || (banka && (banka.anaBarkod || banka.barkod)) || urunGirisi.otomatikBarkodUret(cozum.urun);
    cozum.otomatikBarkod = anaBarkod;
    cozum.veriBankasindaKayitli = Boolean(banka && (banka.kayitli || banka.bulundu));
    if (!cozum.fiyat && banka && banka.fiyat) {
      cozum.onerilenFiyat = banka.fiyat;
    } else if (!cozum.fiyat && !cozum.onerilenFiyat && typeof urunDeposu.barkodBankasiListesi === 'function') {
      const kelimeler = cozum.urun.toLocaleLowerCase('tr-TR').split(/\s+/).filter(k => k.length >= 3);
      if (kelimeler.length > 0) {
        const bListeObj = urunDeposu.barkodBankasiListesi();
        const bListe = Array.isArray(bListeObj) ? bListeObj : (Array.isArray(bListeObj && bListeObj.kayitlar) ? bListeObj.kayitlar : []);
        const katalogEs = bListe.find(x => {
          if (!x || !x.urun || !(Number(x.fiyat) > 0)) return false;
          const xLow = x.urun.toLocaleLowerCase('tr-TR');
          return kelimeler.every(k => xLow.includes(k));
        });
        if (katalogEs && katalogEs.fiyat) {
          cozum.onerilenFiyat = katalogEs.fiyat;
        }
      }
    }
    if (Array.isArray(cozum.satirlar)) {
      cozum.satirlar = cozum.satirlar.map(s => ({
        ...s,
        barkod: s.barkod || urunGirisi.otomatikBarkodUret(cozum.urun, s.renk, s.beden)
      }));
    }
  }
  if (Array.isArray(cozum.kalemler)) {
    cozum.kalemler = cozum.kalemler.map(k => ({
      ...k,
      barkod: k.barkod || (k.urun ? urunGirisi.otomatikBarkodUret(k.urun) : ''),
      satirlar: Array.isArray(k.satirlar)
        ? k.satirlar.map(s => ({
          ...s,
          barkod: s.barkod || (k.urun ? urunGirisi.otomatikBarkodUret(k.urun, s.renk, s.beden) : '')
        }))
        : []
    }));
  }
  return cozum;
}

// --- 📊 EXCEL GÖNDER / EXCEL'DEN YÜKLE / PDF RAPOR MOTORU ---
function masaustuKlasoruBul() {
  const ev = os.homedir();
  const adaylar = [
    path.join(ev, 'Desktop'),
    path.join(ev, 'OneDrive', 'Desktop'),
    path.join(ev, 'OneDrive', 'Masaüstü'),
    path.join(ev, 'Masaüstü')
  ];
  for (const a of adaylar) {
    try { if (fs.existsSync(a)) return a; } catch (_) {}
  }
  return DATA_DIR;
}

function excelTabloSatirlariniCikar(gun) {
  const kayitlar = urunDeposu.oku(gun);
  const satirlar = [];
  let sira = 0;
  let toplamAdet = 0;
  let toplamTutar = 0;
  for (const k of kayitlar) {
    // 🛡️ BOŞ ÜRÜN VE BOŞ SATIR FİLTRESİ:
    if (!k || !k.urun || !String(k.urun).trim() || k.urun.toLowerCase() === 'isimsiz ürün') continue;
    const d = urunGirisi.durumu(k);
    if (!d || !Array.isArray(d.satirlar) || !d.satirlar.length) continue;
    const gecerliSatirlar = d.satirlar.filter(s => s && (Number(s.kalan || s.basta || s.adet || 0) > 0 || s.renk || s.beden));
    if (!gecerliSatirlar.length) continue;

    sira += 1;
    const birimFiyat = k.fiyat != null && Number(k.fiyat) > 0 ? Number(k.fiyat) : 0;
    const saat = k.zamanMs ? new Date(k.zamanMs).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) : '';
    const giren = k.devir ? `Dünden kalan (${k.devir.gun})${k.giren ? `, ${k.giren}` : ''}` : (k.giren || '');
    const anaBarkod = k.barkod || urunGirisi.otomatikBarkodUret(k.urun || `URUN-${sira}`);
    for (const s of gecerliSatirlar) {
      const kalan = Math.max(0, Number(s.kalan || 0));
      toplamAdet += kalan;
      toplamTutar += kalan * birimFiyat;
      const varyantBarkod = s.barkod || urunGirisi.otomatikBarkodUret(k.urun || `URUN-${sira}`, s.renk, s.beden) || anaBarkod;
      let beden = String(s.beden || k.beden || '').trim();
      if (!beden && varyantBarkod) {
        const m = varyantBarkod.match(/-(XS|S|M|L|XL|XXL|3XL|4XL|5XL|\d{2,3})$/i);
        if (m) beden = m[1].toUpperCase();
      }
      satirlar.push({
        sira,
        urun: k.urun || '',
        anaBarkod,
        barkod: varyantBarkod,
        renk: s.renk || '',
        beden,
        basta: Number(s.basta || 0),
        satilan: Number(s.satilan || 0),
        kalan,
        fiyat: birimFiyat || '',
        tutar: birimFiyat ? kalan * birimFiyat : '',
        giren,
        saat
      });
    }
  }
  return { kayitlar, satirlar, urunSayisi: kayitlar.length, toplamAdet, toplamTutar };
}

function excelHtmlTabloUret(gun, veri) {
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const trSatirlar = veri.satirlar.map(r => `
    <tr>
      <td style="text-align:center">${esc(r.sira)}</td>
      <td style="font-weight:bold;font-family:Consolas,monospace;color:#1e3a8a">${esc(r.barkod)}</td>
      <td style="font-weight:bold">${esc(r.urun)}</td>
      <td>${esc(r.renk)}</td>
      <td style="text-align:center;font-weight:bold">${esc(r.beden)}</td>
      <td style="text-align:right;font-weight:bold">${esc(r.kalan)}</td>
      <td style="text-align:right">${esc(r.fiyat)}</td>
      <td style="text-align:right">${esc(r.tutar)}</td>
      <td>${esc(r.giren)}</td>
      <td style="text-align:center">${esc(r.saat)}</td>
    </tr>`).join('');
  return `\uFEFF<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>Mezatron Barkodlu Envanter ${esc(gun)}</title></head>
<body>
  <table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:11pt">
    <thead>
      <tr style="background:#0f172a;color:#ffffff;font-weight:bold">
        <th colspan="10" style="font-size:13pt;padding:8px">MEZATRON AI · BARKODLU DEPO ENVANTER SAYIM LİSTESİ (${esc(gun)})</th>
      </tr>
      <tr style="background:#1e293b;color:#38bdf8;font-weight:bold">
        <th>Sıra</th><th>Barkod Numarası</th><th>Ürün Adı</th><th>Renk</th><th>Beden</th><th>Sayılan Adet</th><th>Birim Fiyat (TL)</th><th>Toplam Tutar (TL)</th><th>Sayımı Yapan</th><th>Saat</th>
      </tr>
    </thead>
    <tbody>${trSatirlar}</tbody>
    <tfoot>
      <tr style="background:#ecfdf5;font-weight:bold">
        <td colspan="5" style="text-align:right">GENEL ENVANTER TOPLAMI (${veri.urunSayisi} Ürün Kalemi):</td>
        <td style="text-align:right">${veri.toplamAdet} Adet</td>
        <td></td>
        <td style="text-align:right">${veri.toplamTutar ? veri.toplamTutar.toLocaleString('tr-TR') + ' TL' : ''}</td>
        <td colspan="2"></td>
      </tr>
    </tfoot>
  </table>
</body></html>`;
}

function excelDisaAktarHazirla(gun) {
  const veri = excelTabloSatirlariniCikar(gun);
  const csvBaslik = ['Sıra', 'Barkod Numarası', 'Ürün Adı', 'Renk', 'Beden', 'Sayılan Adet', 'Birim Fiyat (TL)', 'Toplam Tutar (TL)', 'Sayımı Yapan', 'Saat'];
  const csvSatirlar = veri.satirlar.map(r => [r.sira, r.barkod, r.urun, r.renk, r.beden, r.kalan, r.fiyat, r.tutar, r.giren, r.saat]);
  const csvIcerik = '\uFEFF' + [csvBaslik, ...csvSatirlar]
    .map(satir => satir.map(h => `"${String(h ?? '').replace(/"/g, '""')}"`).join(';'))
    .join('\r\n');
  const xlsIcerik = excelHtmlTabloUret(gun, veri);
  const tsvBaslik = ['Sıra', 'Barkod Numarası', 'Ürün Adı', 'Renk', 'Beden', 'Sayılan Adet', 'Birim Fiyat', 'Toplam Tutar', 'Sayımı Yapan', 'Saat'].join('\t');
  const tsvSatirlar = veri.satirlar.map(r => [r.sira, r.barkod, r.urun, r.renk, r.beden, r.kalan, r.fiyat, r.tutar, r.giren, r.saat].join('\t'));
  const tsvIcerik = [tsvBaslik, ...tsvSatirlar].join('\r\n');

  const masaustu = masaustuKlasoruBul();
  const raporDir = path.join(DATA_DIR, 'raporlar');
  try { fs.mkdirSync(raporDir, { recursive: true }); } catch (_) {}

  const csvAd = `Mezatron-Envanter-${gun}.csv`;
  const xlsAd = `Mezatron-Envanter-${gun}.xls`;
  const kaliciCsvAd = 'Mezatron-Kalici-Envanter-Listesi.csv';
  const kaliciXlsAd = 'Mezatron-Kalici-Envanter-Listesi.xls';
  const masaustuCsvYol = path.join(masaustu, kaliciCsvAd);
  const masaustuXlsYol = path.join(masaustu, kaliciXlsAd);

  try { fs.writeFileSync(path.join(masaustu, csvAd), csvIcerik, 'utf8'); } catch (_) {}
  try { fs.writeFileSync(path.join(masaustu, xlsAd), xlsIcerik, 'utf8'); } catch (_) {}
  try { fs.writeFileSync(masaustuCsvYol, csvIcerik, 'utf8'); } catch (_) {}
  try { fs.writeFileSync(masaustuXlsYol, xlsIcerik, 'utf8'); } catch (_) {}
  try { fs.writeFileSync(path.join(raporDir, csvAd), csvIcerik, 'utf8'); } catch (_) {}
  try { fs.writeFileSync(path.join(raporDir, xlsAd), xlsIcerik, 'utf8'); } catch (_) {}
  try { fs.writeFileSync(path.join(raporDir, kaliciCsvAd), csvIcerik, 'utf8'); } catch (_) {}
  try { fs.writeFileSync(path.join(raporDir, kaliciXlsAd), xlsIcerik, 'utf8'); } catch (_) {}

  return {
    success: true,
    gun,
    urunSayisi: veri.urunSayisi,
    satirSayisi: veri.satirlar.length,
    toplamAdet: veri.toplamAdet,
    toplamTutar: veri.toplamTutar,
    masaustuCsvYol,
    masaustuXlsYol,
    csvIcerik,
    tsvIcerik,
    satirlar: veri.satirlar
  };
}

function pdfAsciiTemizle(metin) {
  return String(metin == null ? '' : metin)
    .replace(/ğ/g, 'g').replace(/Ğ/g, 'G')
    .replace(/ü/g, 'u').replace(/Ü/g, 'U')
    .replace(/ş/g, 's').replace(/Ş/g, 'S')
    .replace(/ı/g, 'i').replace(/İ/g, 'I')
    .replace(/ö/g, 'o').replace(/Ö/g, 'O')
    .replace(/ç/g, 'c').replace(/Ç/g, 'C')
    .replace(/₺/g, 'TL')
    .replace(/[^\x20-\x7E]/g, ' ')
    .replace(/([()\\])/g, '\\$1');
}

function pdfTamponuUret(gun) {
  const veri = excelTabloSatirlariniCikar(gun);
  const satirBasiYukseklik = 16;
  const sayfaBasinaSatir = 38;
  const sayfalar = [];
  const tumSatirlar = veri.satirlar.length > 0 ? veri.satirlar : [{ sira: 1, urun: 'Henuz kayit girilmedi', barkod: '-', renk: '-', beden: '-', kalan: 0, fiyat: '', giren: '' }];

  for (let i = 0; i < tumSatirlar.length; i += sayfaBasinaSatir) {
    sayfalar.push(tumSatirlar.slice(i, i + sayfaBasinaSatir));
  }

  const nesneler = [];
  const nesneEkle = icerik => {
    nesneler.push(icerik);
    return nesneler.length;
  };

  const fontNormalId = nesneEkle('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  const fontKalinId = nesneEkle('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  const sayfaIdleri = [];

  sayfalar.forEach((grup, sayfaIdx) => {
    const c = [];
    // Üst Lacivert Başlık Kutusu
    c.push('0.06 0.09 0.16 rg 30 770 535 46 re f');
    c.push('1 1 1 rg BT /F2 13 Tf 42 796 Td (' + pdfAsciiTemizle(`MEZATRON AI - SESLI ENVANTER VE DEPO RAPORU (${gun})`) + ') Tj ET');
    c.push('0.49 0.83 0.99 rg BT /F1 9 Tf 42 780 Td (' + pdfAsciiTemizle(`Sayfa ${sayfaIdx + 1}/${sayfalar.length}  |  Toplam Kalem: ${veri.urunSayisi}  |  Toplam Stok: ${veri.toplamAdet} Adet  |  Toplam Deger: ${veri.toplamTutar ? veri.toplamTutar.toLocaleString('tr-TR') + ' TL' : '-'}`) + ') Tj ET');

    // Tablo Başlık Satırı
    c.push('0.12 0.16 0.23 rg 30 746 535 20 re f');
    c.push('1 1 1 rg BT /F2 8.5 Tf');
    c.push('36 753 Td (No) Tj');
    c.push('24 0 Td (Urun Adi) Tj');
    c.push('165 0 Td (Barkod / SKU) Tj');
    c.push('88 0 Td (Renk) Tj');
    c.push('62 0 Td (Beden) Tj');
    c.push('42 0 Td (Adet) Tj');
    c.push('40 0 Td (Fiyat) Tj');
    c.push('50 0 Td (Giren) Tj ET');

    let y = 730;
    grup.forEach((r, idx) => {
      if (idx % 2 === 1) {
        c.push(`0.95 0.97 0.99 rg 30 ${y - 4} 535 15 re f`);
      }
      c.push('0.08 0.11 0.18 rg BT /F1 8 Tf');
      c.push(`36 ${y} Td (${pdfAsciiTemizle(r.sira)}) Tj`);
      c.push(`24 0 Td (${pdfAsciiTemizle(String(r.urun || '').slice(0, 30))}) Tj`);
      c.push(`165 0 Td (${pdfAsciiTemizle(String(r.barkod || '').slice(0, 16))}) Tj`);
      c.push(`88 0 Td (${pdfAsciiTemizle(String(r.renk || '').slice(0, 11))}) Tj`);
      c.push(`62 0 Td (${pdfAsciiTemizle(String(r.beden || '').slice(0, 7))}) Tj`);
      c.push(`42 0 Td (${pdfAsciiTemizle(r.kalan)}) Tj`);
      c.push(`40 0 Td (${pdfAsciiTemizle(r.fiyat ? r.fiyat + ' TL' : '-')}) Tj`);
      c.push(`50 0 Td (${pdfAsciiTemizle(String(r.giren || '').slice(0, 10))}) Tj ET`);
      y -= satirBasiYukseklik;
    });

    // Alt Özet Çizgisi
    c.push(`0.05 0.59 0.41 RG 1 w 30 ${y + 6} m 565 ${y + 6} l S`);
    c.push(`0.05 0.45 0.31 rg BT /F2 9 Tf 36 ${y - 8} Td (${pdfAsciiTemizle(`GENEL TOPLAM: ${veri.urunSayisi} Urun  |  ${veri.toplamAdet} Adet  |  ${veri.toplamTutar ? veri.toplamTutar.toLocaleString('tr-TR') + ' TL' : ''}`)}) Tj ET`);

    const akis = c.join('\n');
    const icerikId = nesneEkle(`<< /Length ${Buffer.byteLength(akis, 'utf8')} >>\nstream\n${akis}\nendstream`);
    const sayfaId = nesneEkle(`<< /Type /Page /Parent __PAGES_ID__ 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${fontNormalId} 0 R /F2 ${fontKalinId} 0 R >> >> /Contents ${icerikId} 0 R >>`);
    sayfaIdleri.push(sayfaId);
  });

  const pagesId = nesneEkle(`<< /Type /Pages /Kids [${sayfaIdleri.map(id => `${id} 0 R`).join(' ')}] /Count ${sayfaIdleri.length} >>`);
  const catalogId = nesneEkle(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);

  let pdf = '%PDF-1.4\n';
  const ofsetler = [0];
  for (let i = 0; i < nesneler.length; i++) {
    ofsetler.push(Buffer.byteLength(pdf, 'utf8'));
    const govde = nesneler[i].replace(/__PAGES_ID__/g, String(pagesId));
    pdf += `${i + 1} 0 obj\n${govde}\nendobj\n`;
  }
  const xrefKonum = Buffer.byteLength(pdf, 'utf8');
  pdf += `xref\n0 ${nesneler.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= nesneler.length; i++) {
    pdf += `${String(ofsetler[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${nesneler.length + 1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefKonum}\n%%EOF\n`;

  const tampon = Buffer.from(pdf, 'utf8');
  const masaustuPdfYol = path.join(masaustuKlasoruBul(), `Mezatron-Envanter-${gun}.pdf`);
  const raporDir = path.join(DATA_DIR, 'raporlar');
  try { fs.mkdirSync(raporDir, { recursive: true }); } catch (_) {}
  try { fs.writeFileSync(masaustuPdfYol, tampon); } catch (_) {}
  try { fs.writeFileSync(path.join(raporDir, `Mezatron-Envanter-${gun}.pdf`), tampon); } catch (_) {}

  return { tampon, masaustuPdfYol, veri };
}

function excelDosyalariniListele() {
  const ev = os.homedir();
  const klasorler = [
    { etiket: 'Masaüstü', yol: masaustuKlasoruBul() },
    { etiket: 'İndirilenler', yol: path.join(ev, 'Downloads') },
    { etiket: 'Raporlar', yol: path.join(DATA_DIR, 'raporlar') },
    { etiket: 'Veri Klasörü', yol: path.join(DATA_DIR, 'envanter') }
  ];
  const gorulen = new Set();
  const dosyalar = [];
  for (const k of klasorler) {
    try {
      if (!fs.existsSync(k.yol)) continue;
      const adlar = fs.readdirSync(k.yol);
      for (const ad of adlar) {
        if (!/\.(csv|xls|txt|tsv)$/i.test(ad)) continue;
        const tamYol = path.join(k.yol, ad);
        if (gorulen.has(tamYol)) continue;
        const st = fs.statSync(tamYol);
        if (!st.isFile() || st.size > 10 * 1024 * 1024) continue;
        gorulen.add(tamYol);
        dosyalar.push({
          ad,
          konum: k.etiket,
          tamYol,
          boyutKb: Math.max(1, Math.round(st.size / 1024)),
          zamanMs: st.mtimeMs
        });
      }
    } catch (_) {}
  }
  dosyalar.sort((a, b) => b.zamanMs - a.zamanMs);
  return dosyalar.slice(0, 25);
}

function excelMetniniEnvantereYukle({ icerik = '', gun = urunDeposu.gunAdi(), giren = 'Excel Aktarım' }) {
  let metin = String(icerik || '').replace(/^\uFEFF/, '').trim();
  if (!metin) return { success: false, error: 'Excel içeriği boş.' };

  // Eğer HTML tabanlı .xls ise <tr>...</tr> hücrelerini satırlara dönüştür
  if (/<table[\s>]/i.test(metin) && /<tr[\s>]/i.test(metin)) {
    const trList = metin.match(/<tr[\s\S]*?<\/tr>/gi) || [];
    const cikarilan = [];
    for (const tr of trList) {
      const hucreler = (tr.match(/<t[dh][\s\S]*?<\/t[dh]>/gi) || []).map(h =>
        h.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&').replace(/\s+/g, ' ').trim()
      );
      if (hucreler.length >= 2) cikarilan.push(hucreler.join(';'));
    }
    if (cikarilan.length > 0) metin = cikarilan.join('\n');
  }

  const hamSatirlar = metin.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (!hamSatirlar.length) return { success: false, error: 'Okunabilir satır bulunamadı.' };

  const hucreAyir = satir => {
    const ayrac = satir.includes('\t') ? '\t' : (satir.includes(';') ? ';' : (satir.includes(',') ? ',' : null));
    if (!ayrac) return [satir];
    return satir.split(ayrac).map(h => h.trim().replace(/^"(.*)"$/, '$1').replace(/""/g, '"').trim());
  };

  let baslikHaritasi = null;
  const urunGruplari = new Map();

  const grubaEkle = (urunAdi, renk, beden, adet, fiyat, barkod, kisi) => {
    const temizUrun = String(urunAdi || '').trim();
    if (!temizUrun || /^(?:urun|ürün|ürün adı|urun adi|sira|sıra|genel toplam|toplam|mezatron)/i.test(temizUrun) || /^\d+\s*(?:adet|tane|ürün|urun|çeşit|cesit)$/i.test(temizUrun) || /genel\s+toplam|envanter\s+listesi/i.test(temizUrun)) return;
    const anahtar = temizUrun.toLocaleLowerCase('tr-TR');
    if (!urunGruplari.has(anahtar)) {
      urunGruplari.set(anahtar, {
        urun: temizUrun,
        fiyat: fiyat != null && Number.isFinite(Number(fiyat)) && Number(fiyat) > 0 ? Number(fiyat) : null,
        barkod: barkod || '',
        giren: kisi || giren || 'Excel Aktarım',
        satirlar: []
      });
    }
    const g = urunGruplari.get(anahtar);
    if (g.fiyat == null && fiyat != null && Number.isFinite(Number(fiyat)) && Number(fiyat) > 0) {
      g.fiyat = Number(fiyat);
    }
    if (!g.barkod && barkod) g.barkod = barkod;
    const sayisalAdet = Math.max(1, Math.round(Number(String(adet || '1').replace(/[^\d.,]/g, '').replace(',', '.')) || 1));
    g.satirlar.push({
      renk: String(renk || '').toLocaleUpperCase('tr-TR').trim(),
      beden: String(beden || '').toLocaleUpperCase('tr-TR').replace(/^STD$/i, '').trim(),
      adet: sayisalAdet,
      ...(barkod ? { barkod } : {})
    });
  };

  for (let i = 0; i < hamSatirlar.length; i++) {
    const satir = hamSatirlar[i];
    if (/genel\s+toplam|mezatron\s+ai.*envanter\s+listesi/i.test(satir)) continue;
    const hucreler = hucreAyir(satir);

    // Başlık satırı tespiti
    if (!baslikHaritasi && i <= 6 && hucreler.length >= 2 && hucreler.some(h => /^(?:ürün|urun|ürün adı|urun adi|ürün ismi|urun ismi|model|marka|ürün açıklaması|stok adı|stok adi|açıklama)$/i.test(h))) {
      baslikHaritasi = {};
      hucreler.forEach((h, idx) => {
        const k = h.toLocaleLowerCase('tr-TR');
        if (/ürün|urun|model|marka/.test(k)) baslikHaritasi.urun = idx;
        else if (/barkod|sku|kod/.test(k)) baslikHaritasi.barkod = idx;
        else if (/renk/.test(k)) baslikHaritasi.renk = idx;
        else if (/beden|boy|numara/.test(k)) baslikHaritasi.beden = idx;
        else if (/kalan/.test(k)) baslikHaritasi.kalan = idx;
        else if (/adet|miktar|başlangıç|basta/.test(k) && baslikHaritasi.adet === undefined) baslikHaritasi.adet = idx;
        else if (/birim fiyat|^fiyat/.test(k)) baslikHaritasi.fiyat = idx;
        else if (/giren|personel/.test(k)) baslikHaritasi.giren = idx;
      });
      continue;
    }

    if (baslikHaritasi && hucreler.length >= 2) {
      const urunAdi = hucreler[baslikHaritasi.urun ?? 1] || '';
      const barkod = baslikHaritasi.barkod != null ? hucreler[baslikHaritasi.barkod] : '';
      const renk = baslikHaritasi.renk != null ? hucreler[baslikHaritasi.renk] : '';
      const beden = baslikHaritasi.beden != null ? hucreler[baslikHaritasi.beden] : 'STD';
      const adetHam = (baslikHaritasi.kalan != null && hucreler[baslikHaritasi.kalan] !== '')
        ? hucreler[baslikHaritasi.kalan]
        : (baslikHaritasi.adet != null ? hucreler[baslikHaritasi.adet] : '1');
      const fiyatHam = baslikHaritasi.fiyat != null ? String(hucreler[baslikHaritasi.fiyat] || '').replace(/[^\d.,]/g, '').replace(',', '.') : '';
      const kisi = baslikHaritasi.giren != null ? hucreler[baslikHaritasi.giren] : giren;
      grubaEkle(urunAdi, renk, beden, adetHam, fiyatHam ? Number(fiyatHam) : null, barkod, kisi);
      continue;
    }

    // Başlıksız çok sütunlu CSV/TSV satırı
    if (hucreler.length >= 4) {
      // Eğer ilk sütun sıra numarasıysa (1;Hermes Tişört;Siyah;M;10;...)
      const ilkSayiMi = /^\d{1,4}$/.test(hucreler[0]);
      if (ilkSayiMi && hucreler.length >= 5) {
        const urunAdi = hucreler[1];
        const renk = hucreler[2];
        const beden = hucreler[3];
        const adet = hucreler[6] != null && /^\d+$/.test(hucreler[6]) ? hucreler[6] : hucreler[4];
        const fiyatHam = String(hucreler[7] || hucreler[5] || '').replace(/[^\d.,]/g, '').replace(',', '.');
        grubaEkle(urunAdi, renk, beden, adet, fiyatHam ? Number(fiyatHam) : null, '', giren);
        continue;
      } else {
        // Ürün;Renk;Beden;Adet;Fiyat;Barkod
        const urunAdi = hucreler[0];
        const renk = hucreler[1] || '';
        const beden = hucreler[2] || 'STD';
        const adet = hucreler[3] || '1';
        const fiyatHam = String(hucreler[4] || '').replace(/[^\d.,]/g, '').replace(',', '.');
        const barkod = hucreler[5] || '';
        grubaEkle(urunAdi, renk, beden, adet, fiyatHam ? Number(fiyatHam) : null, barkod, giren);
        continue;
      }
    }

    // Serbest metin satırıysa doğrudan ses/metin çözücüsüyle (urunGirisi.coz) çöz!
    const cozulmus = urunGirisi.coz(satir);
    if (cozulmus && cozulmus.urun && Array.isArray(cozulmus.satirlar) && cozulmus.satirlar.length > 0) {
      for (const s of cozulmus.satirlar) {
        grubaEkle(cozulmus.urun, s.renk, s.beden || 'STD', s.adet || 1, cozulmus.fiyat, cozulmus.barkod || '', giren);
      }
    }
  }

  if (urunGruplari.size === 0) {
    return { success: false, error: 'Excel içeriğinde geçerli ürün satırı bulunamadı. (Örnek format: Ürün Adı ; Renk ; Beden ; Adet ; Fiyat)' };
  }

  let eklenenUrunSayisi = 0;
  let eklenenSatirSayisi = 0;
  let toplamAdet = 0;

  for (const g of urunGruplari.values()) {
    const anaBarkod = (!g.barkod || /^MZU-/i.test(g.barkod))
      ? urunGirisi.otomatikBarkodUret(g.urun)
      : g.barkod;
    let sonuc = urunDeposu.kaydet({
      gun,
      urun: g.urun,
      fiyat: g.fiyat,
      barkod: anaBarkod,
      giren: g.giren,
      satirlar: g.satirlar,
      soz: 'Excel Yükleme'
    });
    if (sonuc && sonuc.cift && sonuc.mevcut && sonuc.mevcut.id) {
      // Mevcut ürün varsa aynı renk/beden satırlarını ikiye katlamak yerine Excel'deki güncel adetlerle eşitle, farklı bedenleri koru
      const birlesikHarita = new Map();
      const satirAnahtari = s => `${String(s.renk || '').trim()}|${String(s.beden || '').replace(/^STD$/i, '').trim()}`;
      for (const es of (sonuc.mevcut.satirlar || [])) {
        birlesikHarita.set(satirAnahtari(es), { ...es, beden: String(es.beden || '').replace(/^STD$/i, '').trim() });
      }
      for (const ys of g.satirlar) {
        birlesikHarita.set(satirAnahtari(ys), { ...ys, beden: String(ys.beden || '').replace(/^STD$/i, '').trim() });
      }
      sonuc = urunDeposu.kaydet({
        gun,
        id: sonuc.mevcut.id,
        surum: sonuc.mevcut.surum,
        zorla: true,
        urun: g.urun,
        fiyat: g.fiyat != null ? g.fiyat : sonuc.mevcut.fiyat,
        barkod: anaBarkod,
        giren: g.giren,
        satirlar: [...birlesikHarita.values()],
        soz: 'Excel Yükleme'
      });
    }
    if (sonuc && sonuc.success) {
      eklenenUrunSayisi += 1;
      eklenenSatirSayisi += g.satirlar.length;
      toplamAdet += g.satirlar.reduce((t, s) => t + (Number(s.adet) || 0), 0);
    }
  }

  if (eklenenUrunSayisi > 0) {
    try { canliYedek.islemBildir('excel_yukleme'); } catch (_) {}
  }

  return {
    success: eklenenUrunSayisi > 0,
    eklenenUrunSayisi,
    eklenenSatirSayisi,
    toplamAdet,
    gun
  };
}

// =========================================================================
// 🖼️ GALERİ & GÖRSEL / XML DOSYA MERKEZİ (Etiket, Barkod, İrsaliye)
// =========================================================================
const GALERI_KLASORU = path.join(__dirname, 'data', 'galeri');
try { fs.mkdirSync(GALERI_KLASORU, { recursive: true }); } catch (_) {}

function galeriyeGorselKaydet(gorselDataUrl, tur = 'etiket') {
  try {
    const s = String(gorselDataUrl || '');
    const m = s.match(/^data:image\/(png|jpe?g|webp);base64,(.+)$/i);
    if (!m) return null;
    const uzanti = m[1].toLowerCase() === 'png' ? 'png' : (m[1].toLowerCase() === 'webp' ? 'webp' : 'jpg');
    const tampon = Buffer.from(m[2], 'base64');
    if (tampon.length < 256 || tampon.length > 12 * 1024 * 1024) return null;
    const temizTur = String(tur || 'gorsel').replace(/[^a-z0-9_-]/gi, '').slice(0, 16) || 'gorsel';
    const dosyaAdi = `${temizTur}-${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}.${uzanti}`;
    const tamYol = path.join(GALERI_KLASORU, dosyaAdi);
    fs.writeFileSync(tamYol, tampon);
    // En fazla son 24 görseli tut
    const mevcutlar = fs.readdirSync(GALERI_KLASORU)
      .filter(f => /\.(jpe?g|png|webp)$/i.test(f))
      .map(f => {
        const p = path.join(GALERI_KLASORU, f);
        return { p, t: fs.statSync(p).mtimeMs || 0 };
      })
      .sort((a, b) => b.t - a.t);
    for (const eski of mevcutlar.slice(24)) {
      try { fs.unlinkSync(eski.p); } catch (_) {}
    }
    return tamYol;
  } catch (_) {
    return null;
  }
}

function galeriDosyalariniListele(tur = 'gorsel') {
  const xmlMi = String(tur || '').toLowerCase() === 'xml';
  const klasorler = xmlMi
    ? [
        { ad: 'Masaüstü', yol: masaustuKlasoruBul() },
        { ad: 'İndirilenler', yol: path.join(os.homedir(), 'Downloads') },
        { ad: 'Veri Klasörü', yol: path.join(__dirname, 'data') }
      ]
    : [
        // Yalnızca uygulamanın kendi çektiği ve kendi hafızasında tuttuğu fotoğraflar
        { ad: 'Uygulama Hafızası', yol: GALERI_KLASORU }
      ];
  const uzantiDesen = xmlMi ? /\.xml$/i : /\.(jpe?g|png|webp|bmp)$/i;
  const bulunanlar = [];
  const gorulen = new Set();

  for (const k of klasorler) {
    try {
      if (!fs.existsSync(k.yol)) continue;
      const dosyalar = fs.readdirSync(k.yol);
      for (const ad of dosyalar) {
        if (!uzantiDesen.test(ad)) continue;
        if (/^(mezatron-3d|icon-|logo|favicon)/i.test(ad)) continue;
        const tamYol = path.join(k.yol, ad);
        if (gorulen.has(tamYol)) continue;
        const st = fs.statSync(tamYol);
        if (!st.isFile() || st.size <= 0 || st.size > 18 * 1024 * 1024) continue;
        gorulen.add(tamYol);
        bulunanlar.push({
          id: Buffer.from(tamYol, 'utf8').toString('base64url'),
          ad,
          konum: k.ad,
          tamYol,
          boyutKb: Math.max(1, Math.round(st.size / 1024)),
          tarihMs: st.mtimeMs || 0,
          tarih: new Date(st.mtimeMs || Date.now()).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })
        });
      }
    } catch (_) {}
  }

  return bulunanlar.sort((a, b) => b.tarihMs - a.tarihMs).slice(0, 30);
}

// =========================================================================
// 🧠 UYGULAMA İÇİ DOĞRULANMIŞ GÖRSEL & ETİKET HAFIZASI (Arka Plan Eşleştirme)
// Uygulamanın kendi çektiği ve doğru okunmuş/kaydedilmiş fotoğrafların
// görsel parmak izlerini (dHash + vHash + renkİmza) ve OCR köklerini saklar.
// Yeni çekilen fotoğrafta ışık, açı veya mesafe nedeniyle yazı tam okunamazsa
// arka planda kendi hafızasındaki doğrulanmış ürün fotoğraflarıyla eşleştirir.
// =========================================================================
const GORSEL_HAFIZA_YOLU = path.join(__dirname, 'data', 'gorsel-hafiza.json');
let gorselHafizaListesi = [];
let sonCekilenGorselBaglami = null;

function metinKokleriniCikar(metin) {
  const s = String(metin || '')
    .toLocaleLowerCase('tr-TR')
    .replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ş/g, 's')
    .replace(/ı/g, 'i').replace(/ö/g, 'o').replace(/ç/g, 'c')
    .replace(/[^a-z0-9\s]/g, ' ');
  const kelimeler = s.split(/\s+/).filter(k => k.length >= 3 && !/^(for|the|and|ile|made|turkiye|turkey|eau|parfum|parfume|edp|edt|beden|adet|lira)$/.test(k));
  return [...new Set(kelimeler)].slice(0, 18);
}

function gorselHafizayiYukle() {
  try {
    if (fs.existsSync(GORSEL_HAFIZA_YOLU)) {
      const veri = JSON.parse(fs.readFileSync(GORSEL_HAFIZA_YOLU, 'utf8'));
      if (Array.isArray(veri)) gorselHafizaListesi = veri;
    }
  } catch (_) {
    gorselHafizaListesi = [];
  }
  // Mevcut envanter ve ses günlüğündeki doğrulanmış etiket okumalarını da hafızaya tohumla
  try {
    const gunlukYol = path.join(__dirname, 'data', 'envanter-ses-gunlugu.jsonl');
    if (fs.existsSync(gunlukYol)) {
      const satirlar = fs.readFileSync(gunlukYol, 'utf8').split(/\r?\n/).filter(Boolean).slice(-200);
      for (const st of satirlar) {
        try {
          const o = JSON.parse(st);
          if (o && o.tur === 'etiket_okuma' && o.urun && o.ocrMetin) {
            const yenidenCoz = urunGirisi.etiketCoz({ etiketMetni: o.ocrMetin, model: o.seciliModel || '' });
            const temizUrun = (yenidenCoz && yenidenCoz.urun) ? yenidenCoz.urun : '';
            if (temizUrun && temizUrun.length >= 3) {
              gorselHafizaKaydet({
                urun: temizUrun,
                beden: (Array.isArray(yenidenCoz.bedenler) && yenidenCoz.bedenler[0]) || (Array.isArray(o.bedenler) && o.bedenler[0]) || '',
                ocrMetin: o.ocrMetin,
                kaydetDosyaya: false
              });
            }
          }
        } catch (_) {}
      }
    }
    try { fs.writeFileSync(GORSEL_HAFIZA_YOLU, JSON.stringify(gorselHafizaListesi.slice(-400), null, 2), 'utf8'); } catch (_) {}
  } catch (_) {}
}

function gorselHafizaKaydet({ urun, barkod = '', fiyat = null, renk = '', beden = '', gorselParmakIzi = null, ocrMetin = '', gorselYol = '', dogrulandi = false, kaydetDosyaya = true }) {
  const temizUrun = String(urun || '').trim();
  if (!temizUrun || temizUrun.length < 2) return null;
  if (/\b(?:iso|gmp|chp|skt|lot|clo|soovsz)\b/i.test(temizUrun)) return null;
  const dhash = gorselParmakIzi && typeof gorselParmakIzi.dhash === 'string' && gorselParmakIzi.dhash.length === 64 ? gorselParmakIzi.dhash : '';
  const vhash = gorselParmakIzi && typeof gorselParmakIzi.vhash === 'string' && gorselParmakIzi.vhash.length === 56 ? gorselParmakIzi.vhash : '';
  const renkImza = gorselParmakIzi && Array.isArray(gorselParmakIzi.renkImza) && gorselParmakIzi.renkImza.length === 9 ? gorselParmakIzi.renkImza : null;
  const ocrKokler = metinKokleriniCikar(`${ocrMetin || ''} ${temizUrun}`);
  if (!dhash && ocrKokler.length === 0) return null;

  const normUrun = temizUrun.toLocaleLowerCase('tr-TR');
  const mevcutIdx = gorselHafizaListesi.findIndex(k =>
    k.urun.toLocaleLowerCase('tr-TR') === normUrun &&
    ((dhash && k.dhash && hammingBenzerlik(dhash, k.dhash) >= 0.86) || (!dhash && !k.dhash))
  );

  const kayit = {
    urun: temizUrun,
    barkod: String(barkod || '').trim(),
    fiyat: Number.isFinite(Number(fiyat)) && Number(fiyat) > 0 ? Number(fiyat) : null,
    renk: String(renk || '').trim(),
    beden: String(beden || '').trim(),
    dhash,
    vhash,
    renkImza,
    ocrKokler,
    gorselYol: gorselYol || '',
    dogrulandi: Boolean(dogrulandi),
    zamanMs: Date.now()
  };

  if (mevcutIdx >= 0) {
    const eski = gorselHafizaListesi[mevcutIdx];
    gorselHafizaListesi[mevcutIdx] = {
      ...eski,
      ...kayit,
      barkod: kayit.barkod || eski.barkod || '',
      fiyat: kayit.fiyat || eski.fiyat || null,
      renk: kayit.renk || eski.renk || '',
      beden: kayit.beden || eski.beden || '',
      dhash: kayit.dhash || eski.dhash || '',
      vhash: kayit.vhash || eski.vhash || '',
      renkImza: kayit.renkImza || eski.renkImza || null,
      ocrKokler: [...new Set([...(eski.ocrKokler || []), ...ocrKokler])].slice(0, 24),
      dogrulandi: Boolean(eski.dogrulandi || dogrulandi)
    };
  } else {
    gorselHafizaListesi.push(kayit);
    if (gorselHafizaListesi.length > 400) {
      gorselHafizaListesi = gorselHafizaListesi.slice(-400);
    }
  }

  if (kaydetDosyaya) {
    try { fs.writeFileSync(GORSEL_HAFIZA_YOLU, JSON.stringify(gorselHafizaListesi, null, 2), 'utf8'); } catch (_) {}
  }
  return kayit;
}

function hammingBenzerlik(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let ayni = 0;
  for (let i = 0; i < a.length; i++) {
    if (a[i] === b[i]) ayni++;
  }
  return ayni / a.length;
}

function renkImzaBenzerlik(a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== 9 || b.length !== 9) return 0;
  let fark = 0;
  for (let i = 0; i < 9; i++) {
    fark += Math.abs((Number(a[i]) || 0) - (Number(b[i]) || 0));
  }
  return Math.max(0, 1 - (fark / 2.2));
}

function ocrKokBenzerlik(gelenKokler, adayKokler) {
  if (!gelenKokler.length || !adayKokler.length) return 0;
  let eslesen = 0;
  for (const gk of gelenKokler) {
    if (adayKokler.some(ak => ak === gk || (ak.length >= 4 && gk.length >= 4 && (ak.includes(gk) || gk.includes(ak))))) {
      eslesen++;
    }
  }
  return eslesen / Math.max(1, Math.min(gelenKokler.length, adayKokler.length));
}

function gorselHafizadanEslestir({ gorselParmakIzi = null, ocrMetin = '' }) {
  if (!gorselHafizaListesi.length) return null;
  const dhash = gorselParmakIzi && typeof gorselParmakIzi.dhash === 'string' && gorselParmakIzi.dhash.length === 64 ? gorselParmakIzi.dhash : '';
  const vhash = gorselParmakIzi && typeof gorselParmakIzi.vhash === 'string' && gorselParmakIzi.vhash.length === 56 ? gorselParmakIzi.vhash : '';
  const renkImza = gorselParmakIzi && Array.isArray(gorselParmakIzi.renkImza) && gorselParmakIzi.renkImza.length === 9 ? gorselParmakIzi.renkImza : null;
  const gelenKokler = metinKokleriniCikar(ocrMetin);

  let enIyi = null;
  let enIyiPuan = 0;

  for (const aday of gorselHafizaListesi) {
    let gorselPuan = 0;
    if (dhash && aday.dhash) {
      const dSim = hammingBenzerlik(dhash, aday.dhash);
      const vSim = (vhash && aday.vhash) ? hammingBenzerlik(vhash, aday.vhash) : dSim;
      const rSim = (renkImza && aday.renkImza) ? renkImzaBenzerlik(renkImza, aday.renkImza) : 0.7;
      gorselPuan = (dSim * 0.45) + (vSim * 0.30) + (rSim * 0.25);
    }
    const metinPuan = ocrKokBenzerlik(gelenKokler, aday.ocrKokler || []);
    let toplamPuan = 0;
    if (gorselPuan > 0 && metinPuan > 0) {
      toplamPuan = Math.max(gorselPuan, (gorselPuan * 0.65) + (metinPuan * 0.35) + 0.08);
    } else if (gorselPuan > 0) {
      toplamPuan = gorselPuan;
    } else if (metinPuan > 0) {
      toplamPuan = metinPuan * 0.85;
    }
    if (aday.dogrulandi) toplamPuan += 0.03;

    if (toplamPuan > enIyiPuan) {
      enIyiPuan = toplamPuan;
      enIyi = aday;
    }
  }

  if (enIyi && enIyiPuan >= 0.76) {
    return { ...enIyi, benzerlikPuan: Math.round(enIyiPuan * 100) / 100 };
  }
  return null;
}

gorselHafizayiYukle();



const requestHandler = async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const query = parsedUrl.query || {};

  // CORS ve Güvenlik Zırhı Başlıkları (Tarayıcı eklenti sızıntısı ve dış enjeksiyon koruması)
  const gelenOrigin = String(req.headers.origin || '');
  if (gelenOrigin && /^https?:\/\/(?:localhost|127\.0\.0\.1|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+)(?::\d+)?$/i.test(gelenOrigin)) {
    res.setHeader('Access-Control-Allow-Origin', gelenOrigin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-WebSpeech-Metin, X-Mevcut-Durum, X-Mezat-Pin');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'microphone=(self), camera=(self), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self' http: https: ws: wss: data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob: https://cdn.jsdelivr.net https://unpkg.com; worker-src 'self' blob:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https: http:; media-src 'self' data: blob: mediastream:; connect-src 'self' http: https: ws: wss: data: blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'self'");
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  const gonder = (kod, veri, ekBasliklar = {}) => {
    res.writeHead(kod, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...ekBasliklar });
    res.end(JSON.stringify(veri));
  };
  if (pathname.startsWith('/api/') && !istekKaynagiGuvenliMi(req)) {
    return gonder(403, { success: false, error: 'Bu istek başka bir siteden geldiği için reddedildi.' });
  }
  const gunGecerli = g => (/^\d{4}-\d{2}-\d{2}$/.test(String(g || '')) ? String(g) : urunDeposu.gunAdi());

  // --- 0a. 4 HANELİ PIN DOĞRULAMA & DURUM UÇ NOKTALARI ---
  if (req.method === 'GET' && pathname === '/api/pin-durum') {
    const yerel = istekYerelMi(req);
    const yetkili = istekPinYetkiliMi(req, query);
    return gonder(200, {
      success: true,
      yerelMi: yerel,
      pinGerekli: !yerel,
      yetkili,
      dogrulandi: yetkili,
      ...(yerel ? { aktifPin: gecerliPinOku() } : {})
    });
  }
  if (req.method === 'POST' && (pathname === '/api/pin-dogrula' || pathname === '/api/pin-degistir')) {
    let pinGovde = '';
    req.on('data', p => { pinGovde += p; if (pinGovde.length > 4096) req.destroy(); });
    req.on('end', () => {
      let pVeri = {};
      try { pVeri = JSON.parse(pinGovde || '{}'); } catch (_) {}
      if (!istekYerelMi(req) && !kullaniciOturumuCoz(req) && pinKilitliMi(req)) {
        return gonder(429, { success: false, error: 'Çok fazla hatalı PIN denemesi yapıldı. Lütfen 15 dakika bekleyin.' });
      }
      if (pathname === '/api/pin-degistir') {
        if (!istekPinYetkiliMi(req, query) && String(pVeri.mevcutPin || '').trim() !== gecerliPinOku()) {
          if (pVeri.mevcutPin) pinHatasiYaz(req, pVeri.mevcutPin);
          return gonder(401, { success: false, pinGerekli: true, error: 'Mevcut PIN kodu doğrulanamadı.' });
        }
        const sonuc = pinKaydet(pVeri.yeniPin || pVeri.pin);
        if (!sonuc.success) return gonder(400, sonuc);
        const token = pinTokenUret(sonuc.pin);
        return gonder(200, { success: true, pin: sonuc.pin, token, message: '4 haneli güvenlik PIN kodu güncellendi.' }, {
          'Set-Cookie': `mezat_pin_oturum=${token}; Path=/; Max-Age=2592000; HttpOnly; SameSite=Lax`
        });
      }
      const girilen = String(pVeri.pin || '').trim();
      const dogruPin = gecerliPinOku();
      if (girilen !== dogruPin) {
        pinHatasiYaz(req, girilen);
        return gonder(401, { success: false, pinGerekli: true, error: 'Hatalı PIN kodu! Bilgisayar ekranındaki 4 haneli PIN kodunu girin.' });
      }
      pinHataSayaci.delete(istekIpAl(req));
      const token = pinTokenUret(dogruPin);
      return gonder(200, { success: true, dogrulandi: true, token }, {
        'Set-Cookie': `mezat_pin_oturum=${token}; Path=/; Max-Age=2592000; HttpOnly; SameSite=Lax`
      });
    });
    return;
  }

  // ===== v116: 🛠️ YÖNETİCİ (GELİŞTİRİCİ) KONSOLU – kendi şifresiyle korunur (PIN kapısından bağımsız) =====
  if (pathname.startsWith('/api/yonetici/')) {
    return yoneticiIstegiIsle(req, pathname, query, gonder);
  }
  if (pathname.startsWith('/api/kullanici/')) {
    return kullaniciIstegiIsle(req, pathname, query, gonder);
  }
  // ===== v121: 💳 TİCARİ DENEME, DEMO & KART TANIMLAMA UÇ NOKTALARI =====
  if (pathname.startsWith('/api/ticari/')) {
    if (req.method === 'GET' && pathname === '/api/ticari/durum') {
      const toplamUrun = (urunDeposu.listele(urunDeposu.gunAdi()) || []).length;
      return gonder(200, Object.assign({ success: true }, ticariMotor.durumRaporu(toplamUrun)));
    }
    return gonder(404, { success: false, error: 'Bilinmeyen ticari istek.' });
  }

  // Ağdan (telefon/tablet) gelen tüm /api/* isteklerinde 4 haneli PIN kontrolü
  if (pathname.startsWith('/api/') && pathname !== '/api/mobil-baglanti' && pathname !== '/api/mobil-telemetri' && !istekPinYetkiliMi(req, query)) {
    if (pinKilitliMi(req)) return gonder(429, { success: false, error: 'Çok fazla hatalı şifre denemesi yapıldı. Lütfen 15 dakika bekleyin.' });
    return gonder(401, {
      success: false,
      pinGerekli: true,
      error: '🔒 Ağ güvenliği: Devam etmek için 4 haneli mağaza PIN kodunu girin.'
    });
  }

  if (req.method === 'GET' && pathname === '/api/mobil-baglanti') {
    const adresler = yerelAgAdresleriBul();
    const tercih = adresler.find(x => /wi-?fi|wlan|ethernet/i.test(x.arayuz || x.ag || '')) || adresler[0];
    const yerelIp = tercih ? (tercih.ip || tercih.adres) : '127.0.0.1';
    return gonder(200, {
      success: true,
      yerelIp,
      port: PORT,
      httpsPort: HTTPS_PORT,
      httpsAktif: Boolean(global.__MOBIL_HTTPS_AKTIF__),
      tlsParmakIzi: tlsParmakIziOku(),
      httpUrl: `http://${yerelIp}:${PORT}`,
      httpsUrl: `https://${yerelIp}:${HTTPS_PORT}`,
      okutHttpUrl: `http://${yerelIp}:${PORT}/okut.html`,
      okutHttpsUrl: `https://${yerelIp}:${HTTPS_PORT}/okut.html`,
      adresler
    });
  }

  // --- 0b. CANLI MOBİL TELEMETRİ & UZAKTAN KONTROL KÖPRÜSÜ ---
  // Telefona kendiliğinden "yenile" komutu gönderilmez: çalışırken sayfa yenilenip yarım iş kaybolmasın
  if (req.method === 'GET' && pathname === '/api/mobil-telemetri') {
    return gonder(200, {
      success: true,
      sonGorulmeMs: global.__SON_MOBIL_GORULME_MS__ || 0,
      istemciIp: global.__SON_MOBIL_IP__ || '',
      telemetri: global.__MOBIL_TELEMETRI__ || null,
      bekleyenKomut: global.__MOBIL_BEKLEYEN_KOMUT__ || null
    });
  }

  // Telefon uygulamasının bu bilgisayardaki sürümü: telefon kendi sürümüyle karşılaştırıp güncellemeyi önerir
  if (req.method === 'GET' && pathname === '/api/mobil/apk-bilgi') {
    return gonder(200, mobilApkBilgisi());
  }

  // --- 1. ENVANTER & BARKOD & İRSALİYE UÇ NOKTALARI ---
  if (req.method === 'GET' && pathname === '/api/envanter') {
    const istemciIp = String(req.socket && req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    if (istemciIp && istemciIp !== '127.0.0.1' && istemciIp !== '::1') {
      global.__SON_MOBIL_GORULME_MS__ = Date.now();
      global.__SON_MOBIL_IP__ = istemciIp;
    }
    const gun = gunGecerli(query.gun);
    const surum = urunDeposu.surum(gun);
    if (query.surum && Number(query.surum) === surum) return gonder(200, { gun, surum, degismedi: true });
    return gonder(200, { gun, surum, kayitlar: urunDeposu.oku(gun) });
  }
  if (req.method === 'GET' && pathname === '/api/envanter/barkod-bankasi') {
    const gun = gunGecerli(query.gun);
    return gonder(200, { ...urunDeposu.barkodBankasiListesi(query.q || '', gun), sifirlamaMs: urunDeposu.sifirlamaZamani() });
  }
  if (req.method === 'GET' && pathname === '/api/envanter/excel') {
    const gun = gunGecerli(query.gun);
    const r = excelDisaAktarHazirla(gun);
    if (query.tur === 'xls') {
      const xlsHtml = excelHtmlTabloUret(gun, excelTabloSatirlariniCikar(gun));
      res.writeHead(200, { 'Content-Type': 'application/vnd.ms-excel; charset=utf-8', 'Content-Disposition': `attachment; filename="Mezatron-Envanter-${gun}.xls"`, 'Cache-Control': 'no-store' });
      return res.end(xlsHtml);
    }
    res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="Mezatron-Envanter-${gun}.csv"`, 'Cache-Control': 'no-store' });
    return res.end(r.csvIcerik);
  }
  if (req.method === 'GET' && pathname === '/api/envanter/pdf') {
    const gun = gunGecerli(query.gun);
    const { tampon } = pdfTamponuUret(gun);
    res.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="Mezatron-Envanter-${gun}.pdf"`, 'Cache-Control': 'no-store', 'Content-Length': String(tampon.length) });
    return res.end(tampon);
  }
  if (req.method === 'GET' && pathname === '/api/envanter/excel-dosyalari') {
    return gonder(200, { success: true, dosyalar: excelDosyalariniListele() });
  }
  if (req.method === 'GET' && pathname === '/api/envanter/galeri-dosyalari') {
    const tur = String(query.tur || 'gorsel');
    return gonder(200, { success: true, dosyalar: galeriDosyalariniListele(tur) });
  }
  if (req.method === 'GET' && pathname === '/api/envanter/galeri-onizleme') {
    const id = String(query.id || '');
    const izinli = galeriDosyalariniListele('gorsel').find(d => d.id === id);
    if (!izinli || !fs.existsSync(izinli.tamYol)) {
      res.writeHead(404);
      return res.end();
    }
    const ext = path.extname(izinli.tamYol).toLowerCase();
    const mime = ext === '.png' ? 'image/png' : (ext === '.webp' ? 'image/webp' : (ext === '.bmp' ? 'image/bmp' : 'image/jpeg'));
    try {
      const buf = fs.readFileSync(izinli.tamYol);
      res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'max-age=60' });
      return res.end(buf);
    } catch (_) {
      res.writeHead(500);
      return res.end();
    }
  }
  if (req.method === 'GET' && pathname === '/api/envanter/motor') {
    const hazir = await isEngineReady();
    return gonder(200, {
      hazir: hazir || engineState.kip === 'webspeech',
      kip: hazir ? 'ses' : engineState.kip,
      kartAdi: engineState.kartAdi,
      hakemAktif: Boolean(DEEPSEEK_KEY),
      sesTanima: voiceIdentity.status(),
      gurultuFiltresi: '85-4200Hz Bandpass + DSP Noise Gate + AutoGain (-3 dBFS)'
    });
  }

  // --- 2. SESLİ ENVANTER DOKTORU, CANLI YEDEK VE İLK KURULUM UÇ NOKTALARI ---
  if (req.method === 'GET' && pathname === '/api/sistem/kurulum') {
    const rapor = await kurulumSihirbazi.durumRaporu();
    return gonder(200, rapor);
  }
  if (req.method === 'GET' && pathname === '/api/sistem/guncelleme-kontrol') {
    const rapor = await guncellemeKontrolu.kontrolEt({
      simuleYeniSurum: query.simule === '1',
      istemciYapimNo: query.istemciSurum || '',
      ...(query.githubRepo !== undefined ? { githubRepo: query.githubRepo } : {})
    });
    return gonder(200, rapor);
  }
  if (req.method === 'POST' && pathname === '/api/sistem/guncelleme-uygula') {
    const sonuc = await guncellemeKontrolu.guncellemeUygula();
    if (sonuc && sonuc.success) {
      try { zirhKoruma.sistemiMuhurle('guncelleme_sonrasi_muhur'); } catch (_) {}
    }
    return gonder(sonuc.success ? 200 : 400, sonuc);
  }
  if (req.method === 'GET' && pathname === '/api/sistem/zirh') {
    return gonder(200, zirhKoruma.butunlukDenetle());
  }
  if (req.method === 'POST' && pathname === '/api/sistem/zirh/muhurle') {
    zirhKoruma.sistemiMuhurle('kullanici_manuel_muhur');
    return gonder(200, {
      success: true,
      mesaj: '🛡️ Sistem dosyaları ve donanım parmak izi kriptografik olarak yeniden mühürlendi.',
      durum: zirhKoruma.butunlukDenetle()
    });
  }
  if (req.method === 'POST' && pathname === '/api/sistem/zirh/test') {
    return gonder(200, zirhKoruma.saldiriTestiCalistir());
  }
  if (req.method === 'GET' && pathname === '/api/sistem/yedekler') {
    return gonder(200, { success: true, ...canliYedek.durum() });
  }
  if (req.method === 'POST' && pathname === '/api/sistem/yedek-al') {
    const r = canliYedek.yedekAl({ sebep: 'kullanici_manuel', zorla: true });
    return gonder(r.success ? 200 : 500, { ...r, durum: canliYedek.durum() });
  }
  if (req.method === 'POST' && pathname === '/api/sistem/guvenli-kapat') {
    // Güvenli kapatma: Tüm verilerin ve sistem dosyalarının anında zorunlu yedeğini al
    try {
      const yedekSonuc = canliYedek.yedekAl({ sebep: 'guvenli_kapatma', zorla: true });
      return gonder(200, {
        success: true,
        mesaj: 'Tüm sistem verileri güvenle yedeklendi. Program kapatılmaya hazır.',
        yedek: yedekSonuc,
        durum: canliYedek.durum()
      });
    } catch (err) {
      return gonder(500, { success: false, error: 'Yedek alınamadı: ' + err.message });
    }
  }
  if (req.method === 'GET' && (pathname === '/api/sistem/tam-yedek-indir' || pathname === '/api/envanter/tam-yedek-indir')) {
    // Tüm sistem verilerini (envanter, barkodlar, sözlükler, ayarlar) tek bir JSON arşiv dosyası olarak indir
    try {
      const yedek = canliYedek.yedekAl({ sebep: 'manuel_disa_aktarim', zorla: true });
      const veriDosyalari = {};
      const taranacakKlasorler = [
        { klasor: DATA_DIR, onEk: '' },
        { klasor: path.join(DATA_DIR, 'envanter'), onEk: 'envanter/' }
      ];
      for (const { klasor, onEk } of taranacakKlasorler) {
        if (!fs.existsSync(klasor)) continue;
        for (const dosya of fs.readdirSync(klasor)) {
          if (dosya === 'yedekler' || dosya.endsWith('.tmp') || dosya.endsWith('-shm') || dosya.endsWith('-wal')) continue;
          if (dosya.endsWith('.json') || dosya.endsWith('.jsonl') || dosya.endsWith('.csv')) {
            try {
              const tamYol = path.join(klasor, dosya);
              veriDosyalari[onEk + dosya] = fs.readFileSync(tamYol, 'utf8');
            } catch (_) {}
          }
        }
      }
      const tamPaket = {
        yazilim: 'Mezatron AI Sesli Envanter & Depo Asistanı',
        surum: 'v4.0 PRO 365',
        olusturulma: new Date().toISOString(),
        projeAdi: 'Mezatron',
        sonYedekManifest: yedek,
        dosyalar: veriDosyalari
      };
      const ciktiJson = JSON.stringify(tamPaket, null, 2);
      const dosyaAdi = `Mezatron-Sistem-Tam-Yedek-${new Date().toISOString().slice(0, 10)}.json`;
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="${dosyaAdi}"`,
        'Cache-Control': 'no-cache'
      });
      return res.end(ciktiJson);
    } catch (err) {
      return gonder(500, { success: false, error: 'Tam yedek oluşturulamadı: ' + err.message });
    }
  }

  // --- 2b. FİRMA PROFİLİ VE SEKTÖREL BARKOD/ÜRÜN KATALOĞU UÇ NOKTALARI ---
  const FIRMA_PROFIL_DOSYA = path.join(DATA_DIR, 'firma_profili.json');
  function firmaProfiliOku() {
    try {
      if (fs.existsSync(FIRMA_PROFIL_DOSYA)) {
        return JSON.parse(fs.readFileSync(FIRMA_PROFIL_DOSYA, 'utf8'));
      }
    } catch (_) {}
    return {
      firmaAdi: 'MEZATRON TİCARET',
      unvan: '',
      sektor: 'giyim',
      sektorAdi: 'Tekstil, Giyim & Ayakkabı',
      yetkili: 'Ahmet Aksoy',
      telefon: '',
      adres: '',
      barkodOnEk: 'MZU',
      ozelKatalogYuklendi: false,
      guncellemeTarihi: new Date().toISOString()
    };
  }

  // Bilgisayarda ses tanıma: durum herkese, değiştirmek yalnız dükkan bilgisayarının kendisinden
  if (req.method === 'GET' && pathname === '/api/sistem/ses-motoru') {
    const bellekGB = Math.round(os.totalmem() / 1073741824 * 10) / 10;
    return gonder(200, { success: true, kapali: turkceAsrMotorlari.motorlarKapaliMi(), bellekGB, kapatmaOnerilir: bellekGB < 6 });
  }
  if (req.method === 'POST' && pathname === '/api/sistem/ses-motoru') {
    if (!istekYerelMi(req)) return gonder(403, { success: false, error: 'Bu ayar yalnız dükkan bilgisayarından değiştirilebilir.' });
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 4096) req.destroy(); });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      if (typeof v.kapali !== 'boolean') return gonder(400, { success: false, error: 'kapali: true ya da false olmalı.' });
      try {
        fs.writeFileSync(SES_MOTORU_AYAR_DOSYA, JSON.stringify({ bilgisayardaKapali: v.kapali, tarih: new Date().toISOString() }, null, 2), 'utf8');
      } catch (err) {
        return gonder(500, { success: false, error: 'Ayar yazılamadı: ' + err.message });
      }
      if (v.kapali) {
        turkceAsrMotorlari.motorlariKapat();
        engineState = { ...KAPALI_MOTOR_DURUMU };
      } else {
        turkceAsrMotorlari.motorlariAc();
        engineState = { kip: 'hazirlaniyor', kart: null, kartAdi: '', sebep: '', webspeechDestegi: true };
        ensureVoiceEngine().catch(() => {});
      }
      return gonder(200, { success: true, kapali: v.kapali, mesaj: v.kapali ? 'Bilgisayarda ses tanıma kapatıldı.' : 'Bilgisayarda ses tanıma açılıyor (birkaç saniye sürer).' });
    });
    return;
  }

  if (req.method === 'GET' && pathname === '/api/sistem/firma-profili') {
    return gonder(200, { success: true, profil: firmaProfiliOku() });
  }

  if (req.method === 'POST' && pathname === '/api/sistem/firma-profili') {
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 65536) req.destroy(); });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      const mevcut = firmaProfiliOku();
      const guncel = Object.assign({}, mevcut, {
        firmaAdi: String(v.firmaAdi || mevcut.firmaAdi || '').trim().toUpperCase(),
        unvan: String(v.unvan || mevcut.unvan || '').trim(),
        sektor: String(v.sektor || mevcut.sektor || 'giyim').trim().toLowerCase(),
        sektorAdi: String(v.sektorAdi || mevcut.sektorAdi || '').trim(),
        yetkili: String(v.yetkili || mevcut.yetkili || '').trim(),
        telefon: String(v.telefon || mevcut.telefon || '').trim(),
        adres: String(v.adres || mevcut.adres || '').trim(),
        barkodOnEk: String(v.barkodOnEk || mevcut.barkodOnEk || 'MZU').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6) || 'MZU',
        guncellemeTarihi: new Date().toISOString()
      });
      try {
        fs.writeFileSync(FIRMA_PROFIL_DOSYA, JSON.stringify(guncel, null, 2), 'utf8');
        return gonder(200, { success: true, mesaj: 'Firma profili kaydedildi.', profil: guncel });
      } catch (err) {
        return gonder(500, { success: false, error: 'Firma profili yazılamadı: ' + err.message });
      }
    });
    return;
  }

  if (req.method === 'POST' && pathname === '/api/sistem/sektor-katalog-yukle') {
    // Sektöre özel hazır ürün/barkod bankası ve marka sözlüğü yükleme
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 5 * 1024 * 1024) req.destroy(); });
    req.on('end', () => {
      let v = {};
      try { v = JSON.parse(govde || '{}'); } catch (_) {}
      const sektor = String(v.sektor || 'giyim').toLowerCase();
      const urunler = Array.isArray(v.urunler) ? v.urunler : [];
      let eklenenBarkodSayisi = 0;

      // 1. Barkod Bankasına Ürünleri İşle
      const barkodDosya = path.join(DATA_DIR, 'envanter', 'barkodlar.json');
      let mevcutBarkodlar = {};
      try {
        if (fs.existsSync(barkodDosya)) mevcutBarkodlar = JSON.parse(fs.readFileSync(barkodDosya, 'utf8'));
      } catch (_) {}

      for (const item of urunler) {
        if (!item || !item.urun) continue;
        const urunAdi = String(item.urun).trim();
        const barkod = String(item.barkod || '').trim() || `MZU-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
        if (!mevcutBarkodlar[barkod]) {
          mevcutBarkodlar[barkod] = {
            barkod,
            urun: urunAdi,
            fiyat: Number(item.fiyat) || 0,
            renk: String(item.renk || '').trim().toUpperCase(),
            beden: String(item.beden || '').trim().toUpperCase(),
            kategori: String(item.kategori || sektor).trim(),
            sektor,
            zamanMs: Date.now()
          };
          eklenenBarkodSayisi++;
        }
      }

      try {
        fs.writeFileSync(barkodDosya, JSON.stringify(mevcutBarkodlar, null, 2), 'utf8');
      } catch (_) {}

      // 2. Firma profilini güncelle
      const profil = firmaProfiliOku();
      profil.sektor = sektor;
      if (v.sektorAdi) profil.sektorAdi = v.sektorAdi;
      profil.ozelKatalogYuklendi = true;
      try { fs.writeFileSync(FIRMA_PROFIL_DOSYA, JSON.stringify(profil, null, 2), 'utf8'); } catch (_) {}

      try { canliYedek.islemBildir('sektor_katalog_yukleme'); } catch (_) {}
      return gonder(200, {
        success: true,
        mesaj: `${sektor.toUpperCase()} sektörüne ait ${eklenenBarkodSayisi} adet ürün ve barkod kataloğu başarıyla yüklendi.`,
        eklenenSayi: eklenenBarkodSayisi,
        toplamBarkodBankasi: Object.keys(mevcutBarkodlar).length,
        profil
      });
    });
    return;
  }
  if (req.method === 'GET' && (pathname === '/api/doktor' || pathname === '/api/envanter/doktor')) {
    const teshis = envanterDoktoru.analizEt(query.gun);
    return gonder(200, { success: true, teshis, canliYedek: canliYedek.durum(), ...teshis });
  }
  if (req.method === 'POST' && (pathname === '/api/doktor/rapor' || pathname === '/api/envanter/doktor/rapor')) {
    const r = envanterDoktoru.raporYaz(query.gun);
    return gonder(200, { success: true, ...r });
  }

  // --- 3. MEZATRON ENTEGRASYON KÖPRÜSÜ UÇ NOKTALARI ---
  if (req.method === 'GET' && (pathname === '/api/entegrasyon/durum' || pathname === '/api/mezatron-koprusu/durum')) {
    const d = await mezatronKoprusu.durum();
    return gonder(200, { success: true, ...d });
  }

  // --- 3b. SSE OLAY AKIŞI VE DEPO ETİKET / BARKOD OKUTMA UÇ NOKTALARI ---
  if (req.method === 'GET' && pathname === '/api/events') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive'
    });
    res.write(': ok\n\n');
    sseClients.add(res);
    req.on('close', () => sseClients.delete(res));
    return;
  }
  if (req.method === 'GET' && pathname === '/api/etiket/kuyruk') {
    return gonder(200, {
      ayar: labelSettings,
      bekleyen: productLabelQueue.filter(p => p.etiket && p.etiket.durum === 'BEKLIYOR'),
      gonderilen: productLabelQueue.filter(p => p.etiket && p.etiket.durum === 'GONDERILDI').slice(0, 30),
      urunEtiketBekleyen: productLabelQueue.filter(p => p.etiket && p.etiket.durum === 'BEKLIYOR').length,
      iptalUyarilari: []
    });
  }
  if (req.method === 'GET' && pathname === '/api/etiket/ayar') {
    return gonder(200, labelSettings);
  }
  if (req.method === 'GET' && pathname === '/api/etiket/okutma-ozeti') {
    return gonder(200, depoScanSummary({ tamYetki: istekYerelMi(req) }));
  }
  if (req.method === 'GET' && pathname === '/api/poset-foto/liste') {
    return gonder(200, posetFotoListeHazirla(query.q || ''));
  }
  if (req.method === 'GET' && pathname.startsWith('/api/poset-foto/gorsel/')) {
    const id = path.basename(pathname.replace('/api/poset-foto/gorsel/', '')).replace(/[^a-zA-Z0-9_-]/g, '');
    const kayit = posetFotolariniOku().find(k => k.id === id);
    const dosyaAdi = kayit ? kayit.dosyaAdi : `${id}.jpg`;
    const tamYol = path.join(POSET_FOTO_DIR, dosyaAdi);
    if (!fs.existsSync(tamYol)) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Görsel bulunamadı');
    }
    const ext = path.extname(tamYol).toLowerCase();
    res.writeHead(200, {
      'Content-Type': ext === '.png' ? 'image/png' : 'image/jpeg',
      'Cache-Control': 'public, max-age=86400'
    });
    return fs.createReadStream(tamYol).pipe(res);
  }

  // --- 4. DEPO GÖREVLİSİ SES İZİ DOĞRULAMA ---
  if (req.method === 'GET' && (pathname === '/api/voice/identity' || pathname === '/api/ses-izi/durum')) {
    const st = voiceIdentity.status();
    return gonder(200, { success: true, kayitli: Boolean(st && st.enrolled), ornekSayisi: (st && st.samples) || 0, ...st });
  }
  if (req.method === 'POST' && (pathname === '/api/voice/enroll' || pathname === '/api/ses-izi/kaydet')) {
    const chunks = [];
    let size = 0;
    req.on('data', c => { size += c.length; if (size <= MAX_VOICE_BODY_BYTES) chunks.push(c); });
    req.on('end', () => {
      const sonuc = size > MAX_VOICE_BODY_BYTES
        ? { success: false, message: 'Ses kaydı çok uzun.' }
        : voiceIdentity.enroll(Buffer.concat(chunks));
      gonder(200, sonuc);
    });
    return;
  }

  // --- 5. SES KAYDI ÇÖZÜMLEME (DSP GÜRÜLTÜ TEMİZLEMELİ + TARAYICI WEBSPEECH HİBRİT DESTEKLİ) ---
  if (req.method === 'POST' && pathname === '/api/envanter/ses') {
    const parcalar = [];
    let boyut = 0;
    req.on('data', parca => { boyut += parca.length; if (boyut <= MAX_VOICE_BODY_BYTES) parcalar.push(parca); });
    req.on('end', async () => {
      if (boyut > MAX_VOICE_BODY_BYTES) return gonder(413, { success: false, error: 'Kayıt çok uzun. Bir ürünü kısa söyleyin.' });
      let yedekMetin = '';
      let mevcutDurum = null;
      try {
        if (req.headers['x-webspeech-metin']) {
          yedekMetin = decodeURIComponent(String(req.headers['x-webspeech-metin'])).trim();
        }
        if (req.headers['x-mevcut-durum']) {
          mevcutDurum = JSON.parse(decodeURIComponent(String(req.headers['x-mevcut-durum'])));
        }
      } catch (_) {}
      const motorHazir = await isEngineReady();
      if (!motorHazir && !yedekMetin) {
        return gonder(503, { success: false, error: 'Yerel ses motoru açık değil. Tarayıcı sesini veya yazı kutusunu kullanabilirsiniz.' });
      }
      try {
        const duyulan = motorHazir
          ? await transcribeInventoryVoice(Buffer.concat(parcalar))
          : { text: yedekMetin, rawText: yedekMetin, motorMs: 12, confidence: { seviye: 'yuksek', neden: 'Tarayıcı WebSpeech' }, konusmaci: { status: 'KAPALI', blocked: false }, sesAnalizi: { snrDb: 20, noiseFloorDb: -45, uygulananKazanc: 1 } };
        if (duyulan.konusmaci && duyulan.konusmaci.blocked) {
          envanterDoktoru.olayKaydet({ tur: 'yabanci_ses_engellendi', metin: duyulan.rawText, benzerlik: duyulan.konusmaci.score, sesAnalizi: duyulan.sesAnalizi });
          return gonder(200, {
            success: false,
            error: `Arka plan / yabancı ses engellendi (Benzerlik: ${duyulan.konusmaci.score}). Yalnız tanıtılan depo görevlisinin sesi kabul edilir.`,
            konusmaci: duyulan.konusmaci,
            sesAnalizi: duyulan.sesAnalizi
          });
        }
        let metin = (duyulan.text || '').trim();
        const whisperBozukMu = !metin
          || metin.length < 3
          || /^[,.\s\-_!?;:]+$/.test(metin)
          || /^(?:yens|ndem|vrey|oth|nd|thank|you|uh|um|teşekkür\p{L}*|sağ\s*ol\p{L}*|iyi\s+seyirler|hoşça\s*kal\p{L}*|görüşmek\s+üzere|abone\s+ol\p{L}*)\b/iu.test(metin)
          || (duyulan.confidence && duyulan.confidence.seviye === 'dusuk' && yedekMetin.length > metin.length);
        if (whisperBozukMu && yedekMetin) {
          metin = yedekMetin;
        } else if (whisperBozukMu && !yedekMetin) {
          metin = '';
        } else if (metin && yedekMetin) {
          // Whisper ürün adını kaçırdıysa ama WebSpeech yakaladıysa karşılaştır ve daha zengin olanı seç
          const cWhisper = urunGirisi.coz(metin);
          const cWeb = urunGirisi.coz(yedekMetin);
          const wPuan = (cWhisper.urun ? 2 : 0) + (cWhisper.fiyat ? 2 : 0) + ((cWhisper.satirlar || []).length ? 2 : 0) - ((cWhisper.uyarilar || []).length);
          const webPuan = (cWeb.urun ? 2 : 0) + (cWeb.fiyat ? 2 : 0) + ((cWeb.satirlar || []).length ? 2 : 0) - ((cWeb.uyarilar || []).length);
          if (webPuan > wPuan + 1) {
            metin = yedekMetin;
          }
        }
        if (!metin) {
          envanterDoktoru.olayKaydet({ tur: 'bos_ses', motorMs: duyulan.motorMs, sesAnalizi: duyulan.sesAnalizi });
          return gonder(200, { success: false, error: 'Ses kısık veya kısa geldi, tekrar söyleyin.', metin: '', sesAnalizi: duyulan.sesAnalizi });
        }
        const balbalMetin = (duyulan.balbalText || '').trim();
        const mihuMetin = (duyulan.mihuText || '').trim();
        const sedaMetin = (duyulan.sedaText || '').trim();
        const cWhisper = urunGirisi.coz(metin);
        const cBalbal = balbalMetin ? urunGirisi.coz(balbalMetin) : null;
        const cSeda = sedaMetin ? urunGirisi.coz(sedaMetin) : null;
        const cYedek = yedekMetin ? urunGirisi.coz(yedekMetin) : null;
        let yerelCozum = ucluMotorYerelBirlestir(cWhisper, cBalbal, cSeda, cYedek);
        // Yerel Fonetik İkiz Motoru (<1 ms): Ürün adı henüz çıkmadıysa veya sözlük dışıysa Barkod Bankasından eşleştir
        if (!yerelCozum.urun && urunGirisi.kolektifUrunAdaylariBul) {
          const acikUrunYok = !(mevcutDurum && mevcutDurum.urun && String(mevcutDurum.urun).trim().length >= 2);
          const urunSoylendi = /\b(?:ürün|urun|ürünü|urunu)\b/iu.test(`${metin} ${balbalMetin} ${sedaMetin} ${yedekMetin || ''}`);
          if (acikUrunYok || urunSoylendi) {
            const hizliAdaylar = urunGirisi.kolektifUrunAdaylariBul(`${metin} ${balbalMetin} ${sedaMetin} ${yedekMetin || ''}`, magazaUrunIsimleriGetir());
            if (hizliAdaylar.length > 0 && hizliAdaylar[0].skor >= 0.78) {
              yerelCozum.urun = hizliAdaylar[0].urun;
            }
          }
        }
        let kurtarilanHakemCozum = null;
        if (!urunGirisi.gecerliEnvanterSozuMu(metin, yerelCozum, mevcutDurum)) {
          const yedekCozum = yedekMetin ? urunGirisi.coz(yedekMetin) : null;
          if (yedekMetin && urunGirisi.gecerliEnvanterSozuMu(yedekMetin, yedekCozum, mevcutDurum)) {
            metin = yedekMetin;
            yerelCozum = yedekCozum;
          } else {
            const kelimeSayisi = metin.split(/\s+/).filter(Boolean).length;
            const konusmaOrani = (duyulan.sesAnalizi && duyulan.sesAnalizi.konusmaOrani) || 0;
            const gercektenTvGibiUzunMu = kelimeSayisi > 6 && konusmaOrani >= 0.45;
            if (!gercektenTvGibiUzunMu && kelimeSayisi <= 8) {
              const adaylar = urunGirisi.kolektifUrunAdaylariBul ? urunGirisi.kolektifUrunAdaylariBul(`${metin} ${balbalMetin} ${mihuMetin} ${sedaMetin} ${yedekMetin || ''}`, magazaUrunIsimleriGetir()) : [];
              if (adaylar.length > 0 && adaylar[0].skor >= 0.72) {
                yerelCozum.urun = adaylar[0].urun;
              } else {
                const denemeHakem = await envanterHakemineSor({ metin, yedekMetin, balbalMetin, mihuMetin, sedaMetin, yerelCozum, mevcutDurum });
                if (denemeHakem && (denemeHakem.urun || denemeHakem.fiyat || (Array.isArray(denemeHakem.satirlar) && denemeHakem.satirlar.length > 0))) {
                  kurtarilanHakemCozum = denemeHakem;
                }
              }
            }
            if (!kurtarilanHakemCozum && !urunGirisi.gecerliEnvanterSozuMu(metin, yerelCozum, mevcutDurum)) {
              envanterDoktoru.olayKaydet({ tur: gercektenTvGibiUzunMu ? 'ortam_sesi_reddedildi' : 'bos_ses', metin, balbalMetin, mihuMetin, sedaMetin, sesAnalizi: duyulan.sesAnalizi });
              return gonder(200, {
                success: false,
                ortamSesiReddedildi: gercektenTvGibiUzunMu,
                error: gercektenTvGibiUzunMu
                  ? '⚠️ Uzun sohbet / arka plan cümlesi algılandı, ürün olarak kaydedilmedi.'
                  : '🎙️ Ses kısık veya net duyulmadı, ürün adını ya da beden/adedi tekrar söyleyin.',
                metin: '',
                sesAnalizi: duyulan.sesAnalizi
              });
            }
          }
        }
        let secilenCozum = kurtarilanHakemCozum || yerelCozum;
        if (!kurtarilanHakemCozum && hakemGerekliMi(yerelCozum, duyulan, mevcutDurum)) {
          const hakemCozum = await envanterHakemineSor({ metin, yedekMetin, balbalMetin, mihuMetin, sedaMetin, yerelCozum, mevcutDurum });
          if (hakemSonucuKullanilsinMi(yerelCozum, hakemCozum)) secilenCozum = hakemCozum;
        }
        const anlamliSatirlar = Array.isArray(secilenCozum.satirlar)
          ? secilenCozum.satirlar.filter(s => s && (s.renk || s.beden || (s.adet != null && Number(s.adet) > 0)))
          : [];
        if (secilenCozum.halusinasyon || (!secilenCozum.urun && !secilenCozum.fiyat && anlamliSatirlar.length === 0)) {
          envanterDoktoru.olayKaydet({ tur: 'halusinasyon_engellendi', metin, hamMetin: duyulan.rawText, balbalMetin, mihuMetin, sedaMetin, sesAnalizi: duyulan.sesAnalizi });
          return gonder(200, {
            success: false,
            error: '🛡️ Kolektif Konsey: Ses net duyulmadı veya ortam hışırtısı/halüsinasyon engellendi. Lütfen tekrar söyleyin.',
            metin: '',
            sesAnalizi: duyulan.sesAnalizi
          });
        }
        const cozum = barkodlaZenginlestir(secilenCozum);
        const temizMetin = temizEnvanterMetniUret(metin, cozum);
        envanterDoktoru.olayKaydet({
          tur: 'ses_cozum',
          metin: temizMetin,
          hamMetin: duyulan.rawText,
          balbalMetin,
          mihuMetin,
          sedaMetin,
          balbalModel: duyulan.balbalModel || 'balbal-v2-manas',
          balbalMs: duyulan.balbalMs || 0,
          mihuMs: duyulan.mihuMs || 0,
          sedaMs: duyulan.sedaMs || 0,
          urun: cozum.urun,
          fiyat: cozum.fiyat,
          satirSayisi: (cozum.satirlar || []).length,
          hakemOnayli: Boolean(cozum.hakemOnayli),
          hakemSureMs: cozum.hakemSureMs || 0,
          motorMs: duyulan.motorMs,
          guven: duyulan.confidence,
          konusmaci: duyulan.konusmaci,
          sesAnalizi: duyulan.sesAnalizi
        });
        return gonder(200, {
          success: true,
          metin: temizMetin,
          hamMetin: duyulan.rawText,
          balbalMetin,
          mihuMetin,
          sedaMetin,
          motorMs: duyulan.motorMs,
          guven: duyulan.confidence,
          konusmaci: duyulan.konusmaci,
          sesAnalizi: duyulan.sesAnalizi,
          ...cozum
        });
      } catch (err) {
        return gonder(502, { success: false, error: 'Ses yazıya çevrilemedi: ' + err.message });
      }
    });
    return;
  }

  // --- 6. JSON GÖVDELİ POST İSTEKLERİ ---
  if (req.method === 'POST') {
    let govde = '';
    req.on('data', p => { govde += p; if (govde.length > 15 * 1024 * 1024) req.destroy(); });
    // İşlem sırasında hata olursa (disk dolu vb.) istek cevapsız kalmaz, hata telefona/ekrana döner
    req.on('end', () => postGovdeIsle().catch(err => {
      console.error('[SUNUCU] İstek işlenemedi:', pathname, err && err.message);
      try { if (!res.headersSent) gonder(500, { success: false, error: (err && err.message) || 'İşlem yapılamadı.' }); } catch (_) {}
    }));
    const postGovdeIsle = async () => {
      let veri = {};
      try { veri = JSON.parse(govde || '{}'); } catch (_) { return gonder(400, { success: false, error: 'Geçersiz JSON.' }); }
      if (pathname === '/api/mobil-telemetri') {
        const istemciIp = String(req.socket && req.socket.remoteAddress || '').replace(/^::ffff:/, '');
        if (veri.komutAta) {
          if (!istekYerelMi(req)) return gonder(403, { success: false, error: 'Telefona komut yalnız bilgisayardan verilebilir.' });
          global.__MOBIL_BEKLEYEN_KOMUT__ = veri.komutAta;
          return gonder(200, { success: true, atananKomut: global.__MOBIL_BEKLEYEN_KOMUT__ });
        }
        global.__SON_MOBIL_GORULME_MS__ = Date.now();
        if (istemciIp) global.__SON_MOBIL_IP__ = istemciIp;
        global.__MOBIL_TELEMETRI__ = { ...veri, zamanMs: Date.now(), ip: istemciIp };
        let komut = global.__MOBIL_BEKLEYEN_KOMUT__ || null;
        if (komut) global.__MOBIL_BEKLEYEN_KOMUT__ = null;
        // Komut yalnız bilgisayardan elle verilir; sürüm farkı yüzünden sayfa kendiliğinden yenilenmez
        return gonder(200, { success: true, ...(komut ? { mobilKomut: komut } : {}) });
      }
      if (pathname === '/api/poset-foto/kaydet') {
        const sonuc = posetFotoKaydet(veri);
        if (sonuc.success) canliYedek.islemBildir('poset_foto_kayit');
        return gonder(sonuc.success ? 200 : 400, sonuc);
      }
      if (pathname === '/api/poset-foto/sil') {
        const id = String(veri.id || '').trim();
        const liste = posetFotolariniOku();
        const idx = liste.findIndex(k => k.id === id);
        if (idx === -1) return gonder(404, { success: false, error: 'Fotoğraf kaydı bulunamadı.' });
        const [silinen] = liste.splice(idx, 1);
        posetFotolariniYaz(liste);
        try {
          if (silinen && silinen.dosyaAdi) {
            const p = path.join(POSET_FOTO_DIR, silinen.dosyaAdi);
            if (fs.existsSync(p)) fs.unlinkSync(p);
          }
        } catch (_) {}
        return gonder(200, { success: true, silinenId: id });
      }
      const zDenetim = zirhKoruma.istekVerisiDenetle(veri, pathname);
      veri = zDenetim.veri;
      if ((pathname === '/api/envanter/barkod' || pathname === '/api/entegrasyon/canli-yayina-ac' || pathname === '/api/active-product/barkod') && !zDenetim.temiz) {
        return gonder(400, { success: false, error: '🛡️ Güvenlik Zırhı: Barkod veya ürün verisinde zararlı komut/enjeksiyon tespit edildi ve engellendi!' });
      }

      if (pathname === '/api/envanter/coz') {
        const metin = String(veri.metin || '').slice(0, 2000);
        if (!metin.trim()) return gonder(400, { success: false, error: 'Söz boş.' });
        const yerelCozum = urunGirisi.coz(metin);
        let secilenCozum = yerelCozum;
        if (hakemGerekliMi(yerelCozum, null, veri.mevcutDurum || null)) {
          const hakemCozum = await envanterHakemineSor({ metin, yedekMetin: '', yerelCozum, mevcutDurum: veri.mevcutDurum || null });
          if (hakemCozum) secilenCozum = hakemCozum;
        }
        const anlamliSatirlar = Array.isArray(secilenCozum.satirlar)
          ? secilenCozum.satirlar.filter(s => s && (s.renk || s.beden || (s.adet != null && Number(s.adet) > 0)))
          : [];
        if (secilenCozum.halusinasyon || (!secilenCozum.urun && !secilenCozum.fiyat && anlamliSatirlar.length === 0)) {
          return gonder(200, {
            success: false,
            halusinasyonEngellendi: true,
            error: '🛡️ Kolektif Konsey: Geçerli bir ürün, renk, beden veya fiyat algılanamadı (halüsinasyon engellendi).'
          });
        }
        const cozum = barkodlaZenginlestir(secilenCozum);
        const temizMetin = temizEnvanterMetniUret(metin, cozum);
        return gonder(200, { success: true, metin: temizMetin, hamMetin: metin, ...cozum });
      }
      if (pathname === '/api/envanter/marka-sozlugu') {
        const icerik = String(veri.icerik || '').trim();
        if (!icerik || !icerik.includes('|')) {
          return gonder(400, { success: false, error: 'Geçerli bir Markdown (.md) tablo içeriği gönderilmedi.' });
        }
        const kip = veri.kip === 'degistir' ? 'degistir' : 'birlestir';
        const ustYol = path.join(__dirname, '..', 'MARKA_TELAFFUZ_SOZLUGU.md');
        const publicYol = path.join(__dirname, 'public', 'MARKA_TELAFFUZ_SOZLUGU.md');
        let yeniMd = icerik;
        if (kip === 'birlestir' && fs.existsSync(ustYol)) {
          const mevcutMd = fs.readFileSync(ustYol, 'utf8');
          yeniMd = `${mevcutMd.trim()}\n\n---\n\n## Eklenen Sektör / Marka Sözlüğü (${new Date().toLocaleDateString('tr-TR')})\n\n${icerik}\n`;
        }
        try { fs.writeFileSync(ustYol, yeniMd, 'utf8'); } catch (_) {}
        try { fs.writeFileSync(publicYol, yeniMd, 'utf8'); } catch (_) {}
        const satirSayisi = (yeniMd.match(/^\|\s*\*\*(.+?)\*\*\s*\|/gm) || []).length;
        return gonder(200, { success: true, toplamMarka: satirSayisi, md: yeniMd });
      }
      if (pathname === '/api/envanter/irsaliye') {
        let irsMetni = String(veri.irsaliyeMetni || veri.metin || '').trim();
        let ocrSonuc = null;
        if (veri.gorsel) {
          try { galeriyeGorselKaydet(veri.gorsel, 'irsaliye'); } catch (_) {}
        }
        if (veri.gorsel && !irsMetni) {
          ocrSonuc = await ocrMotoru.gorseldenMetinOku(veri.gorsel);
          if (ocrSonuc && ocrSonuc.metin) {
            irsMetni = ocrSonuc.metin;
          }
        }
        let bulunanIrsNo = String(veri.irsaliyeNo || '').trim();
        if (!bulunanIrsNo && irsMetni) {
          const irsNoEslesme = irsMetni.match(/(?:irsaliye\s*(?:no|numaras[ıi])?|belge\s*no|seri\s*no)\s*[:#-]?\s*([A-Z0-9-]{4,24})/i)
            || irsMetni.match(/\b(IRS[-A-Z0-9]{4,20}|GIB\d{9,16})\b/i);
          if (irsNoEslesme) bulunanIrsNo = irsNoEslesme[1].toUpperCase();
        }
        const cozum = barkodlaZenginlestir(urunGirisi.irsaliyeCoz({
          irsaliyeNo: bulunanIrsNo,
          irsaliyeMetni: irsMetni,
          kalemler: veri.kalemler || [],
          urun: veri.urun || '',
          renk: veri.renk || '',
          fiyat: veri.fiyat,
          soz: veri.soz || '',
          kalemIndeks: veri.kalemIndeks
        }));
        envanterDoktoru.olayKaydet({ tur: 'irsaliye_okuma', irsaliyeNo: cozum.irsaliyeNo, urun: cozum.urun, toplamIrsaliyeAdet: cozum.toplamIrsaliyeAdet });
        return gonder(200, {
          success: true,
          ocrMetin: ocrSonuc ? ocrSonuc.metin : irsMetni,
          ocrSatirlar: ocrSonuc ? ocrSonuc.satirlar : [],
          ...cozum
        });
      }
      if (pathname === '/api/envanter/fotograf') {
        let ocrSonuc = null;
        let kaydedilenFotoYol = '';
        if (veri.gorsel) {
          try { kaydedilenFotoYol = galeriyeGorselKaydet(veri.gorsel, 'etiket') || ''; } catch (_) {}
          ocrSonuc = await ocrMotoru.gorseldenMetinOku(veri.gorsel);
          if (ocrSonuc && ocrSonuc.metin) {
            const mevcutEtiket = String(veri.etiketMetni || veri.metin || '').trim();
            veri.etiketMetni = mevcutEtiket ? `${mevcutEtiket}\n${ocrSonuc.metin}` : ocrSonuc.metin;
          }
          if (ocrSonuc && ocrSonuc.ilkBarkod && !String(veri.barkod || '').trim()) {
            veri.barkod = ocrSonuc.ilkBarkod;
          }
        }
        let hamCozum = urunGirisi.etiketCoz(veri);
        let hafizadanDogrulandi = false;
        // Eğer fotoğrafta fabrika barkodu (868...) veya MZU barkodu varsa ve katalogda kayıtlıysa doğrudan market kasası gibi getir!
        const okunanBarkod = String(hamCozum.barkod || veri.barkod || (ocrSonuc && ocrSonuc.ilkBarkod) || '').trim();
        if (okunanBarkod) {
          const katBul = urunDeposu.barkodBul(okunanBarkod);
          if (katBul && katBul.bulundu && katBul.urun) {
            if (!hamCozum.urun) hamCozum.urun = katBul.urun;
            if (!hamCozum.fiyat && katBul.fiyat) hamCozum.fiyat = katBul.fiyat;
            if ((!Array.isArray(hamCozum.bedenler) || hamCozum.bedenler.length === 0) && katBul.beden) {
              hamCozum.bedenler = [katBul.beden];
              hamCozum.satirlar = [{ renk: katBul.renk || hamCozum.renk || '', beden: katBul.beden, adet: 1, barkod: okunanBarkod }];
              hamCozum.uyarilar = [];
            }
          }
        }
        // 🧠 ARKA PLAN GÖRSEL HAFIZA EŞLEŞTİRMESİ:
        // Işık parlaması, tutuş açısı veya mesafe nedeniyle ürün adı/beden okunamadıysa veya eksik kaldıysa,
        // uygulamanın daha önce kendi çektiği ve doğruladığı fotoğraflarla arka planda karşılaştır!
        if (!hamCozum.urun || !Array.isArray(hamCozum.bedenler) || hamCozum.bedenler.length === 0) {
          const hafizaEslesme = gorselHafizadanEslestir({
            gorselParmakIzi: veri.gorselParmakIzi || null,
            ocrMetin: veri.etiketMetni || ''
          });
          if (hafizaEslesme && hafizaEslesme.urun) {
            if (!hamCozum.urun) {
              hamCozum.urun = hafizaEslesme.urun;
              hafizadanDogrulandi = true;
            }
            if (!hamCozum.barkod && hafizaEslesme.barkod) {
              hamCozum.barkod = hafizaEslesme.barkod;
            }
            if (!hamCozum.fiyat && hafizaEslesme.fiyat) {
              hamCozum.fiyat = hafizaEslesme.fiyat;
            }
            if ((!Array.isArray(hamCozum.bedenler) || hamCozum.bedenler.length === 0) && hafizaEslesme.beden) {
              hamCozum.bedenler = [hafizaEslesme.beden];
              hamCozum.satirlar = [{
                renk: hafizaEslesme.renk || hamCozum.renk || '',
                beden: hafizaEslesme.beden,
                adet: 1
              }];
              hamCozum.uyarilar = [];
              hafizadanDogrulandi = true;
            }
          }
        }
        // OCR metni var ancak yerel etiket çözücü marka veya bedeni tam çıkaramadıysa DeepSeek Hakem ile tamamla
        const birlesikEtiketMetin = String(veri.etiketMetni || '').trim();
        if (birlesikEtiketMetin && hamCozum.urun && (!Array.isArray(hamCozum.bedenler) || hamCozum.bedenler.length === 0)) {
          try {
            const hakemCozum = await envanterHakemineSor({
              metin: `${birlesikEtiketMetin} ${veri.model || ''} ${veri.renk || ''}`.trim(),
              yedekMetin: '',
              yerelCozum: hamCozum,
              mevcutDurum: null
            });
            if (hakemCozum) {
              if (!hamCozum.urun && hakemCozum.urun && !/\b(?:iso|gmp|chp|skt|lot|clo)\b/i.test(hakemCozum.urun)) {
                hamCozum.urun = hakemCozum.urun;
              }
              if ((!hamCozum.satirlar || !hamCozum.satirlar[0] || !hamCozum.satirlar[0].beden) && Array.isArray(hakemCozum.satirlar) && hakemCozum.satirlar.length > 0) {
                const hs = hakemCozum.satirlar[0];
                if (hs.beden) {
                  hamCozum.bedenler = [hs.beden];
                  hamCozum.satirlar = [{
                    renk: hs.renk || hamCozum.renk || '',
                    beden: hs.beden,
                    adet: 1
                  }];
                  hamCozum.uyarilar = [];
                }
              }
            }
          } catch (_) {}
        }
        const cozum = barkodlaZenginlestir(hamCozum);
        sonCekilenGorselBaglami = {
          gorselParmakIzi: veri.gorselParmakIzi || null,
          ocrMetin: ocrSonuc ? ocrSonuc.metin : (veri.etiketMetni || ''),
          gorselYol: kaydedilenFotoYol,
          zamanMs: Date.now()
        };
        if (cozum.urun) {
          gorselHafizaKaydet({
            urun: cozum.urun,
            barkod: okunanBarkod || cozum.barkod || '',
            fiyat: cozum.fiyat || cozum.onerilenFiyat || null,
            renk: (cozum.satirlar && cozum.satirlar[0] && cozum.satirlar[0].renk) || '',
            beden: (cozum.bedenler && cozum.bedenler[0]) || '',
            gorselParmakIzi: veri.gorselParmakIzi || null,
            ocrMetin: ocrSonuc ? ocrSonuc.metin : (veri.etiketMetni || ''),
            gorselYol: kaydedilenFotoYol,
            dogrulandi: false
          });
        }
        // Fotoğraftan okunan bilgi barkod listesine kendiliğinden yazılmaz; kişi Kaydet'e basınca yazılır
        try {
          envanterDoktoru.olayKaydet({
            tur: 'etiket_okuma',
            ocrMetin: ocrSonuc ? ocrSonuc.metin : (veri.etiketMetni || ''),
            seciliModel: veri.model || '',
            tahminRenk: veri.renk || '',
            urun: cozum.urun || '',
            bedenler: cozum.bedenler || [],
            satirSayisi: Array.isArray(cozum.satirlar) ? cozum.satirlar.length : 0,
            uyariSayisi: Array.isArray(cozum.uyarilar) ? cozum.uyarilar.length : 0
          });
        } catch (_) {}
        return gonder(200, {
          success: true,
          hafizadanDogrulandi,
          ocrMetin: ocrSonuc ? ocrSonuc.metin : (veri.etiketMetni || ''),
          ocrBarkodlar: ocrSonuc ? ocrSonuc.barkodlar : [],
          ...cozum
        });
      }
      if (pathname === '/api/kamera/barkod-ocr') {
        if (!veri.gorsel) return gonder(400, { success: false, error: 'Kamera görüntüsü gönderilmedi.' });
        const ocrSonuc = await ocrMotoru.gorseldenMetinOku(veri.gorsel);
        let bulunanKod = ocrSonuc && ocrSonuc.ilkBarkod ? ocrSonuc.ilkBarkod : '';
        const hamMetin = String((ocrSonuc && ocrSonuc.metin) || '').trim();
        const ustMetin = hamMetin.toLocaleUpperCase('tr-TR');
        if (!bulunanKod && ustMetin) {
          // Etiket kuyruğundaki sipariş numaraları veya müşteri isimleriyle eşleştir
          for (const p of productLabelQueue) {
            const adayKodlar = [p.orderId, p.siparisNo, p.barkod, p.etiket && p.etiket.barkod].filter(Boolean);
            for (const ak of adayKodlar) {
              if (ustMetin.includes(String(ak).toUpperCase())) {
                bulunanKod = String(ak).toUpperCase();
                break;
              }
            }
            if (bulunanKod) break;
            if (p.musteri && p.musteri.length >= 4 && ustMetin.includes(String(p.musteri).toLocaleUpperCase('tr-TR'))) {
              bulunanKod = String(p.orderId || p.siparisNo || '');
              break;
            }
          }
        }
        // Eğer Barkod Okut kamerasına ürün kutusu/etiketi tutulduysa etiketten ürün adını ve ML/beden bilgisini de çöz!
        let etiketCozum = null;
        if (hamMetin) {
          try {
            const ec = barkodlaZenginlestir(urunGirisi.etiketCoz({ etiketMetni: hamMetin, barkod: bulunanKod }));
            if (ec && (ec.urun || (Array.isArray(ec.bedenler) && ec.bedenler.length > 0))) {
              etiketCozum = ec;
              if (!bulunanKod && ec.barkod && (gecerliFabrikaBarkodu(ec.barkod) || /^MZU?-/i.test(ec.barkod))) {
                bulunanKod = ec.barkod;
              } else if (!bulunanKod && veri.manuelTetik && ec.otomatikBarkod) {
                const katKontrol = urunDeposu.barkodBul(ec.otomatikBarkod);
                if (katKontrol && katKontrol.bulundu) bulunanKod = ec.otomatikBarkod;
              }
              // Okunan bilgi barkod listesine kendiliğinden yazılmaz
            }
          } catch (_) {}
        }
        if (!bulunanKod && (!etiketCozum || !etiketCozum.urun) && veri.manuelTetik) {
          const hafizaEs = gorselHafizadanEslestir({
            gorselParmakIzi: veri.gorselParmakIzi || null,
            ocrMetin: hamMetin
          });
          if (hafizaEs && hafizaEs.urun) {
            etiketCozum = barkodlaZenginlestir({
              urun: hafizaEs.urun,
              barkod: hafizaEs.barkod || '',
              fiyat: hafizaEs.fiyat || null,
              bedenler: hafizaEs.beden ? [hafizaEs.beden] : [],
              satirlar: hafizaEs.beden ? [{ renk: hafizaEs.renk || '', beden: hafizaEs.beden, adet: 1 }] : [],
              hafizadanDogrulandi: true
            });
            // Görünüş benzerliği yalnız öneridir; barkod okunmuş gibi stoğa işlenmez
          }
        }
        if (bulunanKod || veri.manuelTetik) {
          try { galeriyeGorselKaydet(veri.gorsel, 'barkod'); } catch (_) {}
        }
        let okutmaSonucu = null;
        if (bulunanKod && veri.otomatikOkut) {
          okutmaSonucu = depoScanLabel(bulunanKod);
        }
        return gonder(200, {
          success: Boolean(bulunanKod || hamMetin),
          bulunanKod,
          barkodlar: (ocrSonuc && ocrSonuc.barkodlar) || [],
          ocrMetin: hamMetin,
          ocrSatirlar: (ocrSonuc && ocrSonuc.satirlar) || [],
          etiketCozum,
          okutmaSonucu
        });
      }
      if (pathname === '/api/envanter/barkod') {
        if (veri.islem === 'kaydet') {
          const k = urunDeposu.barkodKaydet(veri);
          if (k.success) canliYedek.islemBildir('barkod_kayit');
          return gonder(k.success ? 200 : 400, k);
        }
        if (veri.islem === 'fiyat') {
          const f = urunDeposu.barkodFiyatGuncelle(veri);
          if (f.success && !f.degismedi) canliYedek.islemBildir('barkod_fiyat');
          return gonder(f.success ? 200 : 400, f);
        }
        if (veri.islem === 'satis-dus' || veri.islem === 'stok-ekle' || veri.islem === 'sayim') {
          if (veri.islem === 'stok-ekle') veri.geriAl = true; // stoğu adet kadar arttır
          if (veri.islem === 'sayim') { veri.geriAl = false; veri.sayim = true; } else veri.sayim = false;
          const s = urunDeposu.barkodSatisDus(veri);
          if (s.success) canliYedek.islemBildir('barkod_stok_guncelle');
          return gonder(s.success ? 200 : 400, s);
        }
        const b = urunDeposu.barkodBul(veri.barkod, veri.gun);
        return gonder(b.success ? 200 : 400, b);
      }
      if (pathname === '/api/envanter/tumunu-sifirla') {
        const uzaktanIp = String(req.socket?.remoteAddress || '');
        const yerelMi = uzaktanIp === '127.0.0.1' || uzaktanIp === '::1' || uzaktanIp === '::ffff:127.0.0.1';
        const beklenenPin = process.env.MEZAT_ADMIN_PIN || '';
        if (!yerelMi && (!beklenenPin || String(veri.pin || '') !== beklenenPin)) {
          return gonder(403, { success: false, error: 'Tüm envanteri sıfırlama işlemi güvenlik gereği yalnızca ana bilgisayardan (localhost) yapılabilir.' });
        }
        canliYedek.yedekAl({ sebep: 'tumunu_sifirla_oncesi', zorla: true });
        const s = urunDeposu.tumunuSifirla();
        canliYedek.islemBildir('tumunu_sifirla');
        return gonder(200, s);
      }
      if (pathname === '/api/envanter/excel-disa-aktar') {
        const gun = gunGecerli(veri.gun);
        return gonder(200, excelDisaAktarHazirla(gun));
      }
      if (pathname === '/api/envanter/pdf-olustur') {
        const gun = gunGecerli(veri.gun);
        const { masaustuPdfYol, veri: tabloVeri } = pdfTamponuUret(gun);
        return gonder(200, {
          success: true,
          gun,
          masaustuPdfYol,
          pdfUrl: `/api/envanter/pdf?gun=${encodeURIComponent(gun)}&t=${Date.now()}`,
          urunSayisi: tabloVeri.urunSayisi,
          satirSayisi: tabloVeri.satirlar.length,
          toplamAdet: tabloVeri.toplamAdet,
          toplamTutar: tabloVeri.toplamTutar,
          satirlar: tabloVeri.satirlar
        });
      }
      if (pathname === '/api/envanter/excel-yukle') {
        const gun = gunGecerli(veri.gun);
        let icerik = String(veri.icerik || '').trim();
        let dosyaTampon = null;
        if (veri.dosyaBase64) {
          try { dosyaTampon = Buffer.from(String(veri.dosyaBase64), 'base64'); } catch (_) { dosyaTampon = null; }
          if (!dosyaTampon || !dosyaTampon.length) return gonder(400, { success: false, error: 'Dosya okunamadı.' });
        } else if (!icerik && veri.dosyaYolu) {
          const izinliDosya = excelDosyalariniListele().find(d => d.tamYol === veri.dosyaYolu);
          if (!izinliDosya) return gonder(400, { success: false, error: 'Seçilen Excel dosyası bulunamadı.' });
          try { dosyaTampon = fs.readFileSync(izinliDosya.tamYol); } catch (e) { return gonder(400, { success: false, error: 'Dosya okunamadı.' }); }
        }
        if (dosyaTampon) {
          const cevrim = excelOkuyucu.dosyayiMetneCevir(dosyaTampon);
          if (cevrim.hata) return gonder(400, { success: false, error: cevrim.hata });
          icerik = cevrim.metin;
        } else if (icerik && !excelOkuyucu.yaziMi(icerik)) {
          return gonder(400, { success: false, error: 'Dosya okunamadı: Excel (.xlsx) ya da CSV dosyası seçin.' });
        }
        const sonuc = excelMetniniEnvantereYukle({ icerik, gun, giren: veri.giren || 'Excel Aktarım' });
        return gonder(sonuc.success ? 200 : 400, sonuc);
      }
      if (pathname === '/api/envanter/galeri-kaydet') {
        const kaydedilenYol = galeriyeGorselKaydet(veri.gorsel, veri.tur || 'etiket');
        return gonder(200, { success: Boolean(kaydedilenYol), yol: kaydedilenYol });
      }
      if (pathname === '/api/envanter/galeri-dosya-oku') {
        const tur = String(veri.tur || 'gorsel');
        const liste = galeriDosyalariniListele(tur === 'xml' ? 'xml' : 'gorsel');
        const bulunan = liste.find(d => d.id === veri.id || d.tamYol === veri.dosyaYolu);
        if (!bulunan || !fs.existsSync(bulunan.tamYol)) {
          return gonder(404, { success: false, error: 'Seçilen dosya bulunamadı.' });
        }
        try {
          if (tur === 'xml' || /\.xml$/i.test(bulunan.ad)) {
            const xmlMetin = fs.readFileSync(bulunan.tamYol, 'utf8');
            return gonder(200, { success: true, ad: bulunan.ad, xmlMetin });
          }
          const buf = fs.readFileSync(bulunan.tamYol);
          const ext = path.extname(bulunan.tamYol).toLowerCase();
          const mime = ext === '.png' ? 'image/png' : (ext === '.webp' ? 'image/webp' : (ext === '.bmp' ? 'image/bmp' : 'image/jpeg'));
          return gonder(200, {
            success: true,
            ad: bulunan.ad,
            dataUrl: `data:${mime};base64,${buf.toString('base64')}`
          });
        } catch (e) {
          return gonder(500, { success: false, error: 'Görsel dosyası okunamadı.' });
        }
      }
      if (pathname === '/api/sistem/yedek-yukle') {
        const r = canliYedek.yedektenYukle(veri.yedekId || '');
        if (r.success && typeof urunDeposu.yenidenYukle === 'function') {
          try { urunDeposu.yenidenYukle(); } catch (_) {}
        }
        return gonder(r.success ? 200 : 400, { ...r, durum: canliYedek.durum() });
      }
      if (pathname === '/api/sistem/kurulum/indir') {
        const sonuc = veri.tumu
          ? await kurulumSihirbazi.tumEksikleriKur()
          : await kurulumSihirbazi.bilesenKur(String(veri.bilesenId || ''));
        const guncelDurum = await kurulumSihirbazi.durumRaporu();
        return gonder(sonuc.success ? 200 : 400, { ...sonuc, durum: guncelDurum });
      }
      if (pathname === '/api/sistem/guncelleme-kontrol') {
        const rapor = await guncellemeKontrolu.kontrolEt(veri);
        return gonder(200, rapor);
      }
      if (pathname === '/api/etiket/okut') {
        return gonder(200, depoScanLabel(veri.kod));
      }
      if (pathname === '/api/musteri/hizli-kaydet') {
        return gonder(200, hizliMusteriKaydet(veri));
      }
      if (pathname === '/api/etiket/ayar') {
        labelSettings = { ...labelSettings, ...veri, alanlar: { ...labelSettings.alanlar, ...(veri.alanlar || {}) } };
        try { fs.writeFileSync(LABEL_SETTINGS_PATH, JSON.stringify(labelSettings, null, 2)); } catch (_) {}
        return gonder(200, { success: true, ayar: labelSettings });
      }
      if (pathname === '/api/etiket/al') {
        const nextItem = productLabelQueue.find(p => p.etiket && p.etiket.durum === 'BEKLIYOR');
        return gonder(200, { success: true, etiket: nextItem || null });
      }
      if (pathname === '/api/etiket/gonderildi') {
        const item = productLabelQueue.find(p => p.orderId === veri.orderId || p.siparisNo === veri.orderId);
        if (item && item.etiket) {
          item.etiket.durum = 'GONDERILDI';
          item.etiket.gonderimSayisi = (item.etiket.gonderimSayisi || 0) + 1;
          item.etiket.ilkGonderimMs = item.etiket.ilkGonderimMs || Date.now();
          item.etiket.sonGonderimMs = Date.now();
          return gonder(200, { success: true, etiket: item.etiket });
        }
        return gonder(404, { success: false, error: 'Etiket bulunamadı.' });
      }
      if (pathname === '/api/etiket/yeniden') {
        const item = productLabelQueue.find(p => p.orderId === veri.orderId || p.siparisNo === veri.orderId);
        if (item && item.etiket) {
          item.etiket.durum = 'BEKLIYOR';
          item.etiket.kuyrukMs = Date.now();
          return gonder(200, { success: true });
        }
        return gonder(404, { success: false, error: 'Etiket bulunamadı.' });
      }
      if (pathname === '/api/etiket/hatali') {
        const item = productLabelQueue.find(p => p.orderId === veri.orderId || p.siparisNo === veri.orderId);
        if (item && item.etiket) {
          item.etiket.hatalar = item.etiket.hatalar || [];
          item.etiket.hatalar.push({ ad: veri.neden || 'Hata', not: veri.not || '' });
          return gonder(200, { success: true });
        }
        return gonder(404, { success: false, error: 'Etiket bulunamadı.' });
      }
      if (pathname === '/api/envanter/barkod-etiket-bas') {
        const gun = gunGecerli(veri.gun);
        let kayit = veri.id ? urunDeposu.bul(gun, String(veri.id)) : null;
        if (!kayit && veri.barkod) {
          const bSonuc = urunDeposu.barkodBul(veri.barkod, gun);
          if (bSonuc && bSonuc.bulundu) {
            kayit = {
              id: 'BANKA',
              urun: bSonuc.urun,
              fiyat: bSonuc.fiyat,
              barkod: bSonuc.anaBarkod || bSonuc.barkod,
              satirlar: Array.isArray(bSonuc.varyantlar) && bSonuc.varyantlar.length
                ? bSonuc.varyantlar.map(v => ({ renk: v.renk || '', beden: v.beden || '', adet: v.sonAdet || 1, barkod: v.barkod }))
                : [{ renk: bSonuc.renk || '', beden: bSonuc.beden || '', adet: 1, barkod: bSonuc.barkod }]
            };
          }
        }
        if (!kayit && veri.urun) kayit = veri;
        if (!kayit) return gonder(404, { success: false, error: 'Barkod etiketi basılacak ürün bulunamadı.' });
        const basim = enqueueProductLabels(kayit, { kip: veri.kip || 'varyant', satirIndeks: veri.satirIndeks });
        return gonder(basim.success ? 200 : 400, basim);
      }
      if (pathname === '/api/envanter/kaydet') {
        const toplamUrun = (urunDeposu.listele(veri.gun || urunDeposu.gunAdi()) || []).length;
        const ticariRapor = ticariMotor.durumRaporu(toplamUrun);
        if (ticariRapor.kilitli) {
          return gonder(403, { success: false, kilitli: true, error: ticariRapor.mesaj, yapimci: ticariRapor.yapimci, destekEposta: ticariRapor.destekEposta });
        }
        // v115: Ağdan gelen kayıtta "Giren" (sorumlu kişi) zorunlu
        if (!istekYerelMi(req)) {
          const oturum = kullaniciOturumuCoz(req);
          if (oturum) veri.giren = oturum.ad; // oturumdaki kişi kesin sorumludur
          let kul = '';
          try { kul = decodeURIComponent(String(req.headers['x-mezat-kullanici'] || '')).trim(); } catch (_) {}
          if (!String(veri.giren || '').trim() && kul) veri.giren = kul.slice(0, 40);
          if (!String(veri.giren || '').trim()) {
            return gonder(400, { success: false, error: '👤 Kaydı yapan kişinin adı zorunludur. Lütfen adınızla giriş yapın.' });
          }
        }
        const sonuc = urunDeposu.kaydet(veri);
        if (!sonuc.success) return gonder(409, sonuc);
        // Kullanıcı ürünü onaylayıp kaydettiğinde çekilen fotoğrafın parmak izini doğrulanmış olarak hafızaya mühürle
        try {
          const aktifBaglam = (sonCekilenGorselBaglami && (Date.now() - sonCekilenGorselBaglami.zamanMs < 10 * 60 * 1000)) ? sonCekilenGorselBaglami : null;
          const parmakIzi = veri.gorselParmakIzi || (aktifBaglam && aktifBaglam.gorselParmakIzi) || null;
          const ocrM = veri.ocrMetin || (aktifBaglam && aktifBaglam.ocrMetin) || '';
          if (sonuc.kayit && sonuc.kayit.urun && (parmakIzi || ocrM)) {
            const ilkSatir = (sonuc.kayit.satirlar && sonuc.kayit.satirlar[0]) || {};
            gorselHafizaKaydet({
              urun: sonuc.kayit.urun,
              barkod: sonuc.kayit.barkod || '',
              fiyat: sonuc.kayit.fiyat || null,
              renk: ilkSatir.renk || '',
              beden: ilkSatir.beden || '',
              gorselParmakIzi: parmakIzi,
              ocrMetin: ocrM,
              gorselYol: (aktifBaglam && aktifBaglam.gorselYol) || '',
              dogrulandi: true
            });
            sonCekilenGorselBaglami = null;
          }
        } catch (_) {}
        let etiketBasim = null;
        if (veri.etiketBas) {
          etiketBasim = enqueueProductLabels(sonuc.kayit, { kip: veri.etiketKip || 'varyant' });
        }
        canliYedek.islemBildir('envanter_kayit');
        envanterDoktoru.olayKaydet({
          tur: 'envanter_kayit',
          urun: sonuc.kayit.urun,
          fiyat: sonuc.kayit.fiyat,
          barkod: sonuc.kayit.barkod,
          satirSayisi: (sonuc.kayit.satirlar || []).length
        });
        // Otomatik Mezatron senkronizasyonu (açık olan Mezatron sunucularına anında gönderir)
        const mezatronSenkron = await mezatronKoprusu.kaydiMezatronaAktar(sonuc.kayit);
        return gonder(200, { ...sonuc, ...(etiketBasim ? { etiketBasim } : {}), mezatronSenkron });
      }
      if (pathname === '/api/envanter/sil') {
        const gun = gunGecerli(veri.gun);
        const sonuc = urunDeposu.sil(gun, veri.id, String(veri.silen || veri.giren || '').trim());
        return gonder(sonuc.success ? 200 : 404, sonuc);
      }
      if (pathname === '/api/entegrasyon/tumunu-aktar' || pathname === '/api/mezatron-koprusu/senkronize-et') {
        const gun = gunGecerli(veri.gun);
        const kayitlar = urunDeposu.oku(gun);
        const r = await mezatronKoprusu.tumEnvanteriSenkronizeEt(kayitlar);
        return gonder(200, { success: true, ...r });
      }
      if (pathname === '/api/entegrasyon/canli-yayina-ac' || pathname === '/api/active-product/barkod') {
        const r = await mezatronKoprusu.canliYayinaUrunAc(veri.barkod, veri.hedefUrl);
        return gonder(r.success ? 200 : 404, r);
      }
      if (pathname === '/api/entegrasyon/ayar') {
        return gonder(200, { success: true, ayar: mezatronKoprusu.ayarGuncelle(veri) });
      }
      if (pathname === '/api/voice/identity' || pathname === '/api/ses-izi/sil') {
        if (pathname === '/api/ses-izi/sil') {
          return gonder(200, voiceIdentity.update({ forget: true }));
        }
        return gonder(200, voiceIdentity.update(veri));
      }
      return gonder(404, { success: false, error: 'Bulunamadı.' });
    };
    return;
  }

  // --- 7. STATİK DOSYALAR (Ana sayfa doğrudan Sesli Envanter Arayüzünü açar) ---
  if (req.method === 'GET' && (pathname === '/indir' || pathname === '/indir/' || pathname === '/apk')) {
    const html = `<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <title>Mezatron Envanter Telefon Uygulaması</title>
  <style>
    body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center; background:#040812; color:#f8fafc; font-family:system-ui,-apple-system,sans-serif; padding:18px; box-sizing:border-box; }
    .kart { width:100%; max-width:420px; background:linear-gradient(160deg,#0f172a,#1e1b4b); border:2px solid rgba(56,189,248,0.45); border-radius:20px; padding:24px 20px; text-align:center; box-shadow:0 20px 50px rgba(0,0,0,0.75); }
    h1 { font-size:1.35rem; margin:0 0 8px; color:#38bdf8; font-weight:900; }
    p { font-size:0.92rem; color:#cbd5e1; line-height:1.45; margin:0 0 18px; }
    .btn { display:block; width:100%; box-sizing:border-box; padding:16px 14px; border-radius:14px; background:linear-gradient(135deg,#059669,#10b981); color:#fff; font-size:1.08rem; font-weight:900; text-decoration:none; box-shadow:0 8px 24px rgba(16,185,129,0.4); margin-bottom:12px; }
    .not { font-size:0.8rem; color:#fde68a; background:rgba(245,158,11,0.14); border:1px solid rgba(245,158,11,0.35); border-radius:10px; padding:10px; line-height:1.4; }
  </style>
</head>
<body>
  <div class="kart">
    <h1>📲 Mezatron Envanter v3.0 APK</h1>
    <p>Otomatik telefon ana menüsüne çıkış (<b>⏻ Çıkış</b>), galeri seçici ve barkod stoktan düşme destekli güncel Android uygulaması.</p>
    <a class="btn" id="apk-indir-link" href="/Mezatron-Envanter.apk?v=${Date.now()}" download="Mezatron-Envanter.apk">⬇️ YENİ APK'YI İNDİR VE GÜNCELLE</a>
    <div class="not">İndirme otomatik başladı. İndirilen <b>Mezatron-Envanter.apk</b> dosyasına dokunup <b>"Güncelle / Yükle"</b> demeniz yeterlidir (mevcut verileriniz silinmez).</div>
  </div>
  <script>
    setTimeout(function() {
      window.location.href = '/Mezatron-Envanter.apk?v=' + Date.now();
    }, 400);
  </script>
</body>
</html>`;
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end(html);
  }
  const publicDir = path.join(__dirname, 'public');
  let targetFile = pathname === '/' ? 'urun-girisi.html' : pathname.replace(/^\/+/, '');
  if (pathname === '/masaustu' || pathname === '/desktop') targetFile = 'masaustu.html';
  const filePath = path.join(publicDir, targetFile);
  if (!filePath.startsWith(publicDir + path.sep) && filePath !== publicDir) {
    res.writeHead(404);
    return res.end('404');
  }
  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.apk': 'application/vnd.android.package-archive'
  };
  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('404 Bulunamadı');
    }
    const ext = path.extname(filePath).toLowerCase();
    let body = content;
    if (ext === '.html') {
      const ts = Date.now();
      const htmlStr = content.toString('utf8').replace(/\.(js|css)\?v=[A-Za-z0-9_.-]+/g, `.$1?v=${ts}`);
      body = Buffer.from(htmlStr, 'utf8');
    }
    const extraHeaders = ext === '.apk'
      ? { 'Content-Disposition': `attachment; filename="${path.basename(filePath)}"`, 'Content-Length': String(body.length) }
      : {};
    res.writeHead(200, {
      'Content-Type': mimeTypes[ext] || 'application/octet-stream',
      'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
      'Pragma': 'no-cache',
      'Expires': '0',
      ...extraHeaders
    });
    res.end(body);
  });
};

// Telefonun bilgisayar kapalıyken kullandığı anlama kodu her açılışta buradaki koddan yeniden üretilir
try { require('./scripts/telefon_cozucu_uret').uret(__dirname); } catch (e) { console.error('[TELEFON COZUCU] Uretilemedi:', e.message); }
const server = http.createServer(requestHandler);

process.on('uncaughtException', err => {
  console.error('⚠️ Yakalanmamış Hata (Sunucu çalışmaya devam ediyor):', err && err.message ? err.message : err);
});
process.on('unhandledRejection', reason => {
  console.error('⚠️ İşlenmemiş Promise Hatası (Sunucu çalışmaya devam ediyor):', reason);
});

server.on('error', err => {
  if (err.code === 'EADDRINUSE') {
    console.log(`⚠️ Port ${PORT} zaten kullanımda. Sesli Envanter Asistanı zaten açık: http://localhost:${PORT}`);
    process.exit(0);
  }
  console.error('Sunucu hatası:', err);
});

server.listen(PORT, '0.0.0.0', () => {
  const adresler = yerelAgAdresleriBul();
  const tercih = adresler.find(x => /wi-?fi|wlan|ethernet/i.test(x.arayuz || x.ag || '')) || adresler[0];
  const yerelIp = tercih ? (tercih.ip || tercih.adres) : '127.0.0.1';
  const tlsBilgi = mobilTlsSertifikasiHazirla(yerelIp);
  if (tlsBilgi) {
    try {
      const httpsServer = https.createServer(tlsBilgi, requestHandler);
      httpsServer.on('error', () => {});
      httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
        global.__MOBIL_HTTPS_AKTIF__ = true;
        console.log(`📱 Cep Telefonu Canlı Mikrofon & Kamera (HTTPS): https://${yerelIp}:${HTTPS_PORT}`);
      });
    } catch (_) {}
  }
  console.log('====================================================');
  console.log('🎙️ BAĞIMSIZ SESLİ ENVANTER & DEPO ASİSTANI AKTİF!');
  console.log(`👉 Bilgisayar Arayüzü : http://localhost:${PORT}`);
  console.log(`📱 Cep Telefonu (Wi-Fi): http://${yerelIp}:${PORT}`);
  if (tlsBilgi) console.log(`🔒 Cep Telefonu (HTTPS): https://${yerelIp}:${HTTPS_PORT}`);
  console.log(`🔐 Mobil / Ağ Giriş PIN Kodu : ${gecerliPinOku()}`);
  console.log('🔊 Gürültü Filtresi: 85-4200Hz Bandpass + DSP Noise Gate + AutoGain');
  console.log('💾 Canlı Gölge Yedek: data/yedekler/ (5 dk & 10 kayıt otomatik)');
  console.log('🔗 Mezatron Köprüsü: Port 3000 & Port 3001 Otomatik Senkron');
  console.log('====================================================');
  // Sunucu 2 dakika sorunsuz çalıştıysa ardışık çökme sayacını sıfırla
  setTimeout(() => {
    try { fs.unlinkSync(path.join(DATA_DIR, 'cokme-sayaci.txt')); } catch (_) {}
  }, 2 * 60 * 1000).unref();
});

module.exports = { server, requestHandler };
