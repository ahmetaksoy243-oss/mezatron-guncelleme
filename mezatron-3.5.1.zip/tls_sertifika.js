/**
 * Telefon bağlantısı için güvenli bağlantı dosyası (kendinden imzalı sertifika).
 * Dışarıdan hiçbir araç (openssl) gerekmez: anahtar ve sertifika Node'un kendisiyle üretilir.
 * Telefon uygulaması bilgisayarı bu sertifikanın parmak iziyle tanır (kare kodla eşleme).
 */
const crypto = require('crypto');

function uzunluk(n) {
  if (n < 0x80) return Buffer.from([n]);
  const b = [];
  while (n > 0) { b.unshift(n & 0xff); n >>= 8; }
  return Buffer.from([0x80 | b.length, ...b]);
}
const tlv = (etiket, icerik) => Buffer.concat([Buffer.from([etiket]), uzunluk(icerik.length), icerik]);
const dizi = (...p) => tlv(0x30, Buffer.concat(p));
const kume = (...p) => tlv(0x31, Buffer.concat(p));

function oid(metin) {
  const s = metin.split('.').map(Number);
  const b = [40 * s[0] + s[1]];
  for (const n of s.slice(2)) {
    const p = [n & 0x7f];
    let k = Math.floor(n / 128);
    while (k > 0) { p.unshift(0x80 | (k & 0x7f)); k = Math.floor(k / 128); }
    b.push(...p);
  }
  return tlv(0x06, Buffer.from(b));
}

function zaman(t) {
  const iki = n => String(n).padStart(2, '0');
  const y = t.getUTCFullYear();
  const govde = `${iki(t.getUTCMonth() + 1)}${iki(t.getUTCDate())}${iki(t.getUTCHours())}${iki(t.getUTCMinutes())}${iki(t.getUTCSeconds())}Z`;
  return y < 2050 ? tlv(0x17, Buffer.from(String(y).slice(2) + govde)) : tlv(0x18, Buffer.from(y + govde));
}

function ipBaytlari(ip) {
  const p = String(ip).split('.').map(Number);
  return p.length === 4 && p.every(x => Number.isInteger(x) && x >= 0 && x <= 255) ? Buffer.from(p) : null;
}

// ad: sertifikadaki ad; dnsler / ipler: sertifikanın geçerli olduğu adresler; gun: geçerlilik süresi
function sertifikaUret({ ad = 'Mezatron-Sesli-Envanter', dnsler = ['localhost'], ipler = ['127.0.0.1'], gun = 3650 } = {}) {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const imzaTuru = dizi(oid('1.2.840.113549.1.1.11'), Buffer.from([0x05, 0x00]));
  const isim = dizi(kume(dizi(oid('2.5.4.3'), tlv(0x0c, Buffer.from(ad, 'utf8')))));
  const seri = crypto.randomBytes(16); seri[0] &= 0x7f; if (seri[0] === 0) seri[0] = 1;
  const simdi = new Date(Date.now() - 60 * 1000);
  const bitis = new Date(simdi.getTime() + gun * 24 * 60 * 60 * 1000);
  const adlar = [
    ...dnsler.map(d => tlv(0x82, Buffer.from(String(d), 'ascii'))),
    ...[...new Set(ipler)].map(ipBaytlari).filter(Boolean).map(b => tlv(0x87, b))
  ];
  const uzantilar = tlv(0xa3, dizi(
    dizi(oid('2.5.29.19'), tlv(0x04, dizi())),                              // CA değil
    dizi(oid('2.5.29.17'), tlv(0x04, dizi(...adlar)))                       // geçerli adresler
  ));
  const govde = dizi(
    tlv(0xa0, tlv(0x02, Buffer.from([0x02]))),                             // sürüm 3
    tlv(0x02, seri),
    imzaTuru,
    isim,
    dizi(zaman(simdi), zaman(bitis)),
    isim,
    publicKey.export({ type: 'spki', format: 'der' }),
    uzantilar
  );
  const imza = crypto.sign('sha256', govde, privateKey);
  const der = dizi(govde, imzaTuru, tlv(0x03, Buffer.concat([Buffer.from([0]), imza])));
  const satirlar = der.toString('base64').match(/.{1,64}/g).join('\n');
  return {
    cert: `-----BEGIN CERTIFICATE-----\n${satirlar}\n-----END CERTIFICATE-----\n`,
    key: privateKey.export({ type: 'pkcs8', format: 'pem' })
  };
}

// ── iPhone için: kök sertifika + ona bağlı sunucu sertifikası ──
// Apple kuralı (support.apple.com/en-us/103769): sunucu sertifikası en çok 825 gün,
// RSA 2048+, SHA-2, adresler SAN içinde ve "sunucu kimliği" (serverAuth) kullanımı olmalı.
// Kullanıcının kurduğu kök sertifikaya 398 gün sınırı uygulanmaz (support.apple.com/en-us/102028).
const OID_KRITIK = tlv(0x01, Buffer.from([0xff]));
function anahtarKimligi(spkiDer) {
  // Açık anahtarın SHA-1 özeti; kökte ve ona bağlı sertifikada aynı yolla hesaplanır
  return crypto.createHash('sha1').update(spkiDer).digest();
}
function imzalaVeKapat(govde, imzaTuru, imzalayanAnahtar) {
  const imza = crypto.sign('sha256', govde, imzalayanAnahtar);
  const der = dizi(govde, imzaTuru, tlv(0x03, Buffer.concat([Buffer.from([0]), imza])));
  return { der, pem: `-----BEGIN CERTIFICATE-----\n${der.toString('base64').match(/.{1,64}/g).join('\n')}\n-----END CERTIFICATE-----\n` };
}
function kokSertifikaUret({ ad = 'Mezatron Yerel Kok', gun = 3650 } = {}) {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const imzaTuru = dizi(oid('1.2.840.113549.1.1.11'), Buffer.from([0x05, 0x00]));
  const isim = dizi(kume(dizi(oid('2.5.4.3'), tlv(0x0c, Buffer.from(ad, 'utf8')))));
  const seri = crypto.randomBytes(16); seri[0] &= 0x7f; if (seri[0] === 0) seri[0] = 1;
  const simdi = new Date(Date.now() - 60 * 1000);
  const bitis = new Date(simdi.getTime() + gun * 864e5);
  const spki = publicKey.export({ type: 'spki', format: 'der' });
  const ski = anahtarKimligi(spki);
  const uzantilar = tlv(0xa3, dizi(
    dizi(oid('2.5.29.19'), OID_KRITIK, tlv(0x04, dizi(tlv(0x01, Buffer.from([0xff]))))),   // CA: evet
    dizi(oid('2.5.29.15'), OID_KRITIK, tlv(0x04, tlv(0x03, Buffer.from([0x01, 0x06])))),   // sertifika imzalama
    dizi(oid('2.5.29.14'), tlv(0x04, tlv(0x04, ski)))
  ));
  const govde = dizi(tlv(0xa0, tlv(0x02, Buffer.from([0x02]))), tlv(0x02, seri), imzaTuru, isim,
    dizi(zaman(simdi), zaman(bitis)), isim, spki, uzantilar);
  const c = imzalaVeKapat(govde, imzaTuru, privateKey);
  return { cert: c.pem, der: c.der, key: privateKey.export({ type: 'pkcs8', format: 'pem' }) };
}
function kokaBagliSertifikaUret({ kokCert, kokKey, ad = 'Mezatron-iPhone', dnsler = ['localhost'], ipler = ['127.0.0.1'], gun = 800 } = {}) {
  // Kökün konu adı ve açık anahtarı DER'den alınır: tbs = [sürüm, seri, imzaTürü, veren, süre, konu, açıkAnahtar, ...]
  const tbs = derAlanlari(derAlanlari(new crypto.X509Certificate(kokCert).raw)[0].tam);
  const kokIsim = tbs[5].tam;
  const kokSpki = tbs[6].tam;
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const imzaTuru = dizi(oid('1.2.840.113549.1.1.11'), Buffer.from([0x05, 0x00]));
  const isim = dizi(kume(dizi(oid('2.5.4.3'), tlv(0x0c, Buffer.from(ad, 'utf8')))));
  const seri = crypto.randomBytes(16); seri[0] &= 0x7f; if (seri[0] === 0) seri[0] = 1;
  const simdi = new Date(Date.now() - 60 * 1000);
  const bitis = new Date(simdi.getTime() + Math.min(gun, 825) * 864e5);
  const spki = publicKey.export({ type: 'spki', format: 'der' });
  const adlar = [
    ...dnsler.map(d => tlv(0x82, Buffer.from(String(d), 'ascii'))),
    ...[...new Set(ipler)].map(ipBaytlari).filter(Boolean).map(b => tlv(0x87, b))
  ];
  const uzantilar = tlv(0xa3, dizi(
    dizi(oid('2.5.29.19'), OID_KRITIK, tlv(0x04, dizi())),                                // CA değil
    dizi(oid('2.5.29.15'), OID_KRITIK, tlv(0x04, tlv(0x03, Buffer.from([0x05, 0xa0])))),   // imza + anahtar şifreleme
    dizi(oid('2.5.29.37'), tlv(0x04, dizi(oid('1.3.6.1.5.5.7.3.1')))),                    // sunucu kimliği
    dizi(oid('2.5.29.17'), tlv(0x04, dizi(...adlar))),                                      // geçerli adresler
    dizi(oid('2.5.29.14'), tlv(0x04, tlv(0x04, anahtarKimligi(spki)))),
    dizi(oid('2.5.29.35'), tlv(0x04, dizi(tlv(0x80, anahtarKimligi(kokSpki)))))
  ));
  const govde = dizi(tlv(0xa0, tlv(0x02, Buffer.from([0x02]))), tlv(0x02, seri), imzaTuru, kokIsim,
    dizi(zaman(simdi), zaman(bitis)), isim, spki, uzantilar);
  const c = imzalaVeKapat(govde, imzaTuru, crypto.createPrivateKey(kokKey));
  return { cert: c.pem, key: privateKey.export({ type: 'pkcs8', format: 'pem' }) };
}
// Basit DER okuyucu: verilen SEQUENCE'ın içindeki alanları sırayla verir
function derAlanlari(seq) {
  const [bas, uz] = basVeUzunluk(seq, 0);
  const ic = seq.slice(bas, bas + uz);
  const sonuc = [];
  let i = 0;
  while (i < ic.length) {
    const [b2, u2] = basVeUzunluk(ic, i);
    sonuc.push({ etiket: ic[i], tam: ic.slice(i, b2 + u2) });
    i = b2 + u2;
  }
  return sonuc;
}
function basVeUzunluk(b, i) {
  let u = b[i + 1], bas = i + 2;
  if (u & 0x80) { const n = u & 0x7f; u = 0; for (let k = 0; k < n; k++) u = (u << 8) | b[i + 2 + k]; bas = i + 2 + n; }
  return [bas, u];
}

module.exports = { sertifikaUret, kokSertifikaUret, kokaBagliSertifikaUret };
