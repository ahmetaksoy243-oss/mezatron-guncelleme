// Ürün girişi (yayın öncesi envanter): rafın başında söylenen sözü tablo satırlarına çevirir.
// "Nike spor ayakkabı siyah 40'tan 2, 41'den 3, beyaz 42'den 1, fiyatı 1500"
//   -> { urun: 'Nike Spor Ayakkabı', fiyat: 1500, satirlar: [{renk:'SİYAH', beden:'40', adet:2}, ...] }
// Çözücü tahmin etmez: emin olmadığı yeri uyarı olarak yazar, kişi telefonda gözle kontrol edip düzeltir, sonra Kaydet'e basar.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { colorSpans, normalMetin, colorsInText } = require('./renkler');
const { barkodZirhiDenetle, metinEnjeksiyonDenetle, excelHucreTemizle } = require('./zirh_koruma');

const SAYI_SOZ = {
  bir: 1, iki: 2, 'üç': 3, uc: 3, 'dört': 4, dort: 4, 'beş': 5, bes: 5, 'altı': 6, alti: 6,
  yedi: 7, sekiz: 8, dokuz: 9, on: 10, yirmi: 20, otuz: 30, 'kırk': 40, kirk: 40, elli: 50,
  'altmış': 60, altmis: 60, 'yetmiş': 70, yetmis: 70, seksen: 80, doksan: 90, 'yüz': 100, yuz: 100, bin: 1000
};
const HER_BIRI_SOZ = { birer: 1, 'ikişer': 2, ikiser: 2, 'üçer': 3, ucer: 3, 'dörder': 4, dorder: 4, 'beşer': 5, beser: 5, 'altışar': 6, altisar: 6, 'yedişer': 7, yediser: 7, sekizer: 8, dokuzar: 9, onar: 10, 'yirmişer': 20, yirmiser: 20 };
const ALTI_BILESIK_ONCU = /^(?:e[şs]ofman|pijama|tak[ıi]m|bikini|mayo|bardak|g[öo]z|sehpa|tabak|tencere|tesett[üu]r)$/iu;
const YUZ_BILESIK_SONRA = /^(?:maske\p{L}*|krem\p{L}*|jel\p{L}*|serum\p{L}*|temizleme\p{L}*|y[ıi]kama\p{L}*|bak[ıi]m\p{L}*|losyon\p{L}*|tonik\p{L}*|peeling\p{L}*|sabun\p{L}*|havlu\p{L}*|palet\p{L}*)$/iu;
const HARF_BEDEN = /^(xxs|xs|s|m|l|xl|xxl|xxxl|2xl|3xl|4xl|5xl|standart|\d{2,3}ml|\d{1,2}yaş)(?:['’]?(d[ae]n|t[ae]n|y[ae]|[ae]|d[ae]|l[ıiuü]k))?$/u;
// Konuşurken harf bedenlerin Türkçe okunuşları ve yaygın telaffuzları ("es", "em", "iksel", "medyum" vb.)
const TELAFFUZ_BEDEN = {
  es: 'S', smol: 'S', small: 'S', 'sımol': 'S',
  em: 'M', medyum: 'M', medium: 'M', midyum: 'M',
  larc: 'L', larj: 'L', large: 'L',
  iksel: 'XL', eksel: 'XL'
};
const SAYI_BEDEN = /^(\d{2})(?:['’]?(d[ae]n|t[ae]n|y[ae]|[ae]|l[ıiuü]k|n[ıiuü]m[ae]r[ae]))?$/u;
const AYIRMA_EKI = /^(?:d[ae]n|t[ae]n)$/u;
const YONELME_EKI = /^(?:y[ae]|[ae])$/u;
const AYRIK_EK = /^(?:d[ae]n|t[ae]n|y[ae]|[ae]|l[ıiuü]k)$/u;
const BEDEN_SOZU = /^(?:numara|beden)(d[ae]n|l[ıa]r|ler|l[ae]rd[ae]n|y[ae]|s[ıi]|i|u|ü)?$/u;
const HEPSI_SOZU = /^(?:her|hepsi\p{L}*|herbiri\p{L}*)$/u;
const TANE_SOZU = /^(?:tane|adet|tanesi|taneden|adetten|adedi|say[ıi]s[ıi])$/u;
const BOS_SOZ = new Set(['ürün', 'urun', 'ürünü', 'urunu', 'üründen', 'urunden', 'model', 'modeli', 'modelden', 'cinsi', 'marka', 'markalı', 'markali', 'markası', 'markasi', 'remarka', 'girişi', 'girisi', 'giriş', 'giris', 'var', 'yok', 'bedensiz', 've', 'ile', 'de', 'da', 'ise', 'tane', 'adet', 'tanesi', 'taneden', 'adetten', 'adedi',
  'fiyat', 'fiyatı', 'fiyati', 'fiyahtı', 'fiyahti', 'yat', 'seymiştir', 'seymistir', 'lira', 'tl', 'bedenden', 'numaradan', 'kadar', 'renk', 'rengi', 'renkler', 'renklerde', 'renklerden', 'renkleri', 'renklerinde', 'renkli', 'renkte', 'renginden', 'bir', 'birde', 'olarak', 'şu', 'bu', 'tamam', 'evet', 'olan', 'olsun', 'bundan', 'şundan', 'ondan', 'bunun', 'bunların', 'bunlarin', 'buna',
  'aynı', 'ayni', 'aynısı', 'aynisi', 'aynısından', 'aynisindan', 'aynısına', 'aynisina', 'devam', 'devamı', 'devami', 'ilave', 'ek', 'ekle', 'ayrıca', 'ayrica', 'diğer', 'diger', 'başka', 'baska',
  'şer', 'ser', 'şar', 'sar']);
const BUYUK = s => s.charAt(0).toLocaleUpperCase('tr-TR') + s.slice(1);

// ===== 🏷️ MARKA_TELAFFUZ_SOZLUGU.md Otomatik Yükleyici & Sıcak Güncelleyici =====
const MARKA_SOZLUK_YOLLARI = [
  path.join(__dirname, '..', 'MARKA_TELAFFUZ_SOZLUGU.md'),
  path.join(__dirname, 'MARKA_TELAFFUZ_SOZLUGU.md'),
  path.join(__dirname, 'public', 'MARKA_TELAFFUZ_SOZLUGU.md')
];
let __markaSozlukOnbellek = { mtimeMs: 0, kurallar: [], resmiYazimlar: [] };

function regexKacir(s) {
  return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function markaSozluguYukle() {
  const dosyaYolu = MARKA_SOZLUK_YOLLARI.find(p => { try { return fs.existsSync(p); } catch (_) { return false; } });
  if (!dosyaYolu) return __markaSozlukOnbellek;
  try {
    const stat = fs.statSync(dosyaYolu);
    if (stat.mtimeMs === __markaSozlukOnbellek.mtimeMs && __markaSozlukOnbellek.kurallar.length > 0) {
      return __markaSozlukOnbellek;
    }
    const md = fs.readFileSync(dosyaYolu, 'utf8');
    const kurallar = [];
    const resmiYazimlar = [];
    for (const satir of md.split(/\r?\n/)) {
      const m = satir.match(/^\|\s*\*\*(.+?)\*\*\s*\|\s*([^|]+)\|/);
      if (!m) continue;
      const resmiMarka = m[1].trim();
      const geciciKelime = resmiMarka
        .replace(/&/g, 'Ve')
        .replace(/[^\p{L}\p{N}]/gu, '');
      if (!geciciKelime) continue;
      const varyantlar = m[2]
        .split(',')
        .map(x => x.trim().toLocaleLowerCase('tr-TR'))
        .filter(x => x.length >= 2);
      for (const v of varyantlar) {
        const desenMetni = v.split(/\s+/).map(regexKacir).join('[\\s\\-._]*');
        kurallar.push({
          uzunluk: v.length,
          regex: new RegExp(`(?<![\\p{L}\\p{N}])(?:${desenMetni})(?![\\p{L}\\p{N}])`, 'giu'),
          hedef: geciciKelime
        });
      }
      const geciciDesen = geciciKelime.split(/\s+/).map(regexKacir).join('\\s+');
      resmiYazimlar.push({
        uzunluk: geciciKelime.length,
        regex: new RegExp(`(?<![\\p{L}\\p{N}])(?:${geciciDesen})(?![\\p{L}\\p{N}])`, 'giu'),
        resmiMarka
      });
    }
    kurallar.sort((a, b) => b.uzunluk - a.uzunluk);
    resmiYazimlar.sort((a, b) => b.uzunluk - a.uzunluk);
    __markaSozlukOnbellek = { mtimeMs: stat.mtimeMs, kurallar, resmiYazimlar };
  } catch (_) {}
  return __markaSozlukOnbellek;
}

function markaTelaffuzUygula(metin) {
  let s = String(metin || '');
  const { kurallar } = markaSozluguYukle();
  for (const k of kurallar) {
    s = s.replace(k.regex, k.hedef);
  }
  return s;
}

function markaResmiYazimUygula(urunAdi) {
  let s = String(urunAdi || '').trim();
  const { resmiYazimlar } = markaSozluguYukle();
  for (const r of resmiYazimlar) {
    s = s.replace(r.regex, r.resmiMarka);
  }
  // Kullanıcı "V Yaka Tişört Sandex marka" gibi markayı sonda söylediyse markayı başa ("Sandex V Yaka Tişört") taşı
  for (const r of resmiYazimlar) {
    const m = r.resmiMarka;
    if (s.length > m.length && s.toLocaleLowerCase('tr-TR').endsWith(' ' + m.toLocaleLowerCase('tr-TR'))) {
      const geriKalan = s.slice(0, s.length - m.length).trim();
      if (geriKalan) {
        s = `${m} ${geriKalan}`;
        break;
      }
    }
  }
  return s;
}

function sozlukteMarkaVarMi(metin) {
  const s = String(metin || '');
  if (!s) return false;
  const { kurallar, resmiYazimlar } = markaSozluguYukle();
  for (const k of kurallar) {
    k.regex.lastIndex = 0;
    if (k.regex.test(s)) return true;
  }
  for (const r of resmiYazimlar) {
    r.regex.lastIndex = 0;
    if (r.regex.test(s)) return true;
  }
  return false;
}

const URUN_KATEGORI_KALIBI = /(?<![\p{L}\p{N}])(ti[şs][öo]rt\p{L}*|t-?shirt\p{L}*|g[öo]mlek\p{L}*|kazak\p{L}*|triko\p{L}*|s[üu]veter\p{L}*|s[üu]eter\p{L}*|h[ıi]rka\p{L}*|yelek\p{L}*|mont\p{L}*|kaban\p{L}*|parka\p{L}*|tren[çc]kot\p{L}*|tren[çc]\p{L}*|ya[ğg]murluk\p{L}*|r[üu]zgarl[ıi]k\p{L}*|ceket\p{L}*|blazer\p{L}*|pantolon\p{L}*|jean\p{L}*|kot\p{L}*|jogger\p{L}*|[şs]ort\p{L}*|kapri\p{L}*|bermuda\p{L}*|etek\p{L}*|elbise\p{L}*|abiye\p{L}*|tulum\p{L}*|salopet\p{L}*|e[şs]ofman\p{L}*|sweat\p{L}*|svet\p{L}*|hoodie\p{L}*|polar\p{L}*|bluz\p{L}*|tunik\p{L}*|b[üu]stiyer\p{L}*|kimono\p{L}*|pareo\p{L}*|kaftan\p{L}*|ferace\p{L}*|pan[çc]o\p{L}*|[şs]alvar\p{L}*|badi\p{L}*|body\p{L}*|atlet\p{L}*|korse\p{L}*|tayt\p{L}*|tak[ıi]m\p{L}*|pijama\p{L}*|gecelik\p{L}*|sabahl[ıi]k\p{L}*|i[çc]lik\p{L}*|termal\p{L}*|[çc]ama[şs][ıi]r\p{L}*|k[üu]lot\p{L}*|boxer\p{L}*|baks[ıi]r\p{L}*|s[üu]tyen\p{L}*|mayo\p{L}*|bikini\p{L}*|[çc]orap\p{L}*|patik\p{L}*|ayakkab[ıi]\p{L}*|sneaker\p{L}*|krampon\p{L}*|bot\p{L}*|[çc]izme\p{L}*|terlik\p{L}*|sandalet\p{L}*|loafer\p{L}*|[çc]ar[ıi]k\p{L}*|babet\p{L}*|topuklu\p{L}*|[çc]anta\p{L}*|valiz\p{L}*|bavul\p{L}*|c[üu]zdan\p{L}*|kartl[ıi]k\p{L}*|kemer\p{L}*|saat\p{L}*|[şs]apka\p{L}*|bere\p{L}*|kasket\p{L}*|atk[ıi]\p{L}*|boyunluk\p{L}*|eldiven\p{L}*|e[şs]arp\p{L}*|[şs]al\p{L}*|fular\p{L}*|yazma\p{L}*|t[üu]lbent\p{L}*|kravat\p{L}*|papyon\p{L}*|g[öo]zl[üu]k\p{L}*|kolye\p{L}*|bileklik\p{L}*|k[üu]pe\p{L}*|y[üu]z[üu]k\p{L}*|toka\p{L}*|parf[üu]m\p{L}*|deodorant\p{L}*|kolonya\p{L}*|krem\p{L}*|losyon\p{L}*|serum\p{L}*|maske\p{L}*|tonik\p{L}*|[şs]ampuan\p{L}*|sabun\p{L}*|ruj\p{L}*|rimel\p{L}*|fond[öo]ten\p{L}*|oje\p{L}*|havlu\p{L}*|bornoz\p{L}*|nevresim\p{L}*|[çc]ar[şs]af\p{L}*|yorgan\p{L}*|battaniye\p{L}*|pike\p{L}*|yast[ıi]k\p{L}*|perde\p{L}*|hal[ıi]\p{L}*|kilim\p{L}*|paspas\p{L}*|bardak\p{L}*|tabak\p{L}*|tencere\p{L}*|tava\p{L}*|termos\p{L}*|[şs]emsiye\p{L}*|oyuncak\p{L}*|yaka\p{L}*|kuma[şs]\p{L}*|kadife\p{L}*|keten\p{L}*|ipek\p{L}*|pamuk\p{L}*|ka[şs]mir\p{L}*|y[üu]n\p{L}*|deri\p{L}*|s[üu]et\p{L}*|ka[şs]e\p{L}*|pel[üu][şs]\p{L}*|penye\p{L}*|kap[üu][şs]on\p{L}*|oversize)(?![\p{L}\p{N}])/iu;

const ENVANTER_ANAHTAR_KALIBI = /(?<![\p{L}\p{N}])(beden\p{L}*|numara\p{L}*|adet\p{L}*|tane\p{L}*|fiyat\p{L}*|lira\p{L}*|tl|₺|barkod\p{L}*|ayn[ıi]s[ıi]\p{L}*|birer|iki[şs]er|[üu][çc]er|d[öo]rder|be[şs]er|alt[ıi][şs]ar|onar|d[üu]zine|seri|koli|paket)(?![\p{L}\p{N}])/iu;

// Bir kelimenin veya kelime grubunun gerçekten mağaza ürünü/markası olup olmadığını denetler ("Meriç Mâş Düzal", "Benîn", "Genç", "O5" gibi halüsinasyonları eler)
function gecerliUrunAdiMi(adayUrun, katalogUrunleri = []) {
  const temiz = String(adayUrun || '').trim();
  if (!temiz || temiz.length < 2) return false;
  if (/[ðþæøßñáéíóúýãõåäâîû]/i.test(temiz)) return false;
  if (URUN_KATEGORI_KALIBI.test(temiz) || sozlukteMarkaVarMi(temiz)) return true;
  const ogrenilen = ogrenilenTelaffuzlariYukle();
  const kLow = temiz.toLocaleLowerCase('tr-TR');
  if (Object.values(ogrenilen).some(v => String(v || '').toLocaleLowerCase('tr-TR') === kLow)) return true;
  const adaylar = kolektifUrunAdaylariBul(temiz, katalogUrunleri);
  if (adaylar.length > 0 && adaylar[0].skor >= 0.74) return true;
  return false;
}

// Yanlışlıkla mikrofona basıldığında ortamdaki TV / sohbet seslerinin veya Whisper halüsinasyonlarının ürün sanılmasını engeller
function gecerliEnvanterSozuMu(soz, cozum = null, mevcutDurum = null) {
  const ham = String(soz || '').trim();
  if (!ham) return false;
  const c = cozum || coz(ham);
  const markaVar = sozlukteMarkaVarMi(ham) || sozlukteMarkaVarMi(c.urun);
  const kategoriVar = URUN_KATEGORI_KALIBI.test(ham) || URUN_KATEGORI_KALIBI.test(c.urun || '');
  const urunGecerli = gecerliUrunAdiMi(c.urun);
  const anahtarVar = ENVANTER_ANAHTAR_KALIBI.test(ham);
  const satirlar = Array.isArray(c.satirlar) ? c.satirlar : [];
  const bedenVar = satirlar.some(s => Boolean(s.beden));
  const renkVar = satirlar.some(s => Boolean(s.renk));
  const adetVar = satirlar.some(s => s.adet != null && s.adet > 0);
  const fiyatVar = Number.isFinite(c.fiyat) && c.fiyat > 0;
  const yapisalSayi = [bedenVar, renkVar, adetVar, fiyatVar].filter(Boolean).length;

  const urunKelimeSayisi = String(c.urun || '').trim().split(/\s+/).filter(Boolean).length;
  const maksKelimeSiniri = (yapisalSayi >= 2 && anahtarVar) ? 9 : 6;
  // TV / sohbet cümlesi çok uzunsa ve içinde bilinen marka/ürün kategorisi yoksa reddet
  if (urunKelimeSayisi > maksKelimeSiniri && !markaVar && !kategoriVar) return false;

  const acikKartVar = Boolean(mevcutDurum && (mevcutDurum.urun || (Array.isArray(mevcutDurum.satirlar) && mevcutDurum.satirlar.length > 0)));
  if (acikKartVar) {
    return Boolean(urunGecerli || markaVar || kategoriVar || anahtarVar || bedenVar || renkVar || adetVar || fiyatVar);
  }

  // Boş ekranda yeni ürün açarken:
  // 1) Bilinen bir marka veya bilinen bir ürün/giyim türü (veya fonetik eşleşmesi) geçmeli, VEYA
  // 2) Açıkça "beden / numara / adet / tane / fiyat / lira" anahtar kelimesi + yapısal veri kullanılmalı, VEYA
  // 3) En az iki yapısal envanter alanı (örn. renk + beden, beden + adet, renk + fiyat) bir arada bulunmalı.
  const halüsinasyonVeyaSohbetMi = /^(?:te[şs]ekk[üu]r\p{L}*|sa[ğg]\s*ol\p{L}*|iyi\s+seyirler|ho[şs][çc]a\s*kal\p{L}*|g[öo]r[üu][şs]mek\s+[üu]zere|abone\s+ol\p{L}*|altyaz[ıi]\p{L}*|merhaba\p{L}*|selam\p{L}*|alo|nas[ıi]ls[ıi]n\p{L}*|evet|hay[ıi]r|yok|tamam|peki|bilmiyorum)[.!?,;\s]*$/iu.test(ham);
  if (halüsinasyonVeyaSohbetMi) return false;
  if (urunGecerli || markaVar || kategoriVar) return true;
  if (anahtarVar && (bedenVar || renkVar || adetVar || fiyatVar)) return true;
  if (yapisalSayi >= 2 && urunKelimeSayisi <= (anahtarVar ? 9 : 4)) return true;
  return false;
}

// Fiyat metnini ("1.500", "1500.50", "12.5", "99.99", "1.500,50") kuruşu bozmadan sayıya çevirir.
// Noktadan sonra tam 3 rakam varsa ("1.500") binlik ayracıdır; 1 veya 2 rakam varsa ("1500.50", "12.5") kuruştur.
function fiyatCoz(deger) {
  if (deger === '' || deger == null || typeof deger === 'boolean') return null;
  if (typeof deger === 'number') return Number.isFinite(deger) ? deger : NaN;
  const s = String(deger).trim().replace(/\s+/g, '');
  if (!s) return null;
  if (s.includes(',')) {
    return Number(s.replace(/\./g, '').replace(',', '.'));
  }
  if (/^\d{1,3}(?:\.\d{3})+$/.test(s)) {
    return Number(s.replace(/\./g, ''));
  }
  return Number(s);
}

// Türkçe yazıyla söylenen sayı dizilerini ("bin iki yüz", "dört yüz elli", "seksen beş") rakama çevirir
function yaziSayiyiRakamaCevir(ifade) {
  const parcalar = String(ifade || '').trim().toLocaleLowerCase('tr-TR').split(/\s+/).filter(Boolean);
  if (!parcalar.length) return null;
  let toplam = 0;
  let bolum = 0;
  for (const p of parcalar) {
    const deger = SAYI_SOZ[p];
    if (deger === undefined) return null;
    if (deger === 1000) {
      toplam += (bolum || 1) * 1000;
      bolum = 0;
    } else if (deger === 100) {
      bolum = (bolum || 1) * 100;
    } else {
      bolum += deger;
    }
  }
  const sonuc = toplam + bolum;
  return sonuc > 0 ? sonuc : null;
}

// ===== 🧠 OTOMATİK ÖĞRENEN TELAFFUZ HAFIZASI VE TÜRKÇE FONETİK (SES İKİZİ) MOTORU =====
const OGRENILEN_TELAFFUZ_YOLU = path.join(__dirname, 'data', 'ogrenilen-telaffuzlar.json');
let __ogrenilenTelaffuzOnbellek = { mtimeMs: 0, kayitlar: {} };

function ogrenilenTelaffuzlariYukle() {
  try {
    if (!fs.existsSync(OGRENILEN_TELAFFUZ_YOLU)) return __ogrenilenTelaffuzOnbellek.kayitlar;
    const st = fs.statSync(OGRENILEN_TELAFFUZ_YOLU);
    if (st.mtimeMs === __ogrenilenTelaffuzOnbellek.mtimeMs) return __ogrenilenTelaffuzOnbellek.kayitlar;
    const veri = JSON.parse(fs.readFileSync(OGRENILEN_TELAFFUZ_YOLU, 'utf8') || '{}');
    __ogrenilenTelaffuzOnbellek = { mtimeMs: st.mtimeMs, kayitlar: (veri && typeof veri === 'object') ? veri : {} };
  } catch (_) {}
  return __ogrenilenTelaffuzOnbellek.kayitlar;
}

function telaffuzOgren(bozukIfade, dogruIfade) {
  const b = String(bozukIfade || '').toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim();
  const d = String(dogruIfade || '').replace(/[^\p{L}\p{N}\s&-]/gu, ' ').replace(/\s+/g, ' ').trim();
  if (!b || !d || b.length < 4 || d.length < 3) return false;
  if (b === d.toLocaleLowerCase('tr-TR')) return false;
  if (/^(?:siyah|beyaz|gri|mavi|lacivert|kırmızı|yeşil|sarı|pembe|mor|bej|bordo|fiyat|beden|adet|renk|\d+)$/iu.test(b)) return false;
  try {
    fs.mkdirSync(path.dirname(OGRENILEN_TELAFFUZ_YOLU), { recursive: true });
    const mevcut = { ...ogrenilenTelaffuzlariYukle() };
    mevcut[b] = d;
    fs.writeFileSync(OGRENILEN_TELAFFUZ_YOLU, JSON.stringify(mevcut, null, 2), 'utf8');
    __ogrenilenTelaffuzOnbellek = { mtimeMs: Date.now(), kayitlar: mevcut };
    return true;
  } catch (_) {
    return false;
  }
}

function ogrenilenTelaffuzUygula(metin) {
  let s = String(metin || '');
  const kayitlar = ogrenilenTelaffuzlariYukle();
  const anahtarlar = Object.keys(kayitlar).sort((a, b) => b.length - a.length);
  for (const k of anahtarlar) {
    const desen = k.split(/\s+/).map(regexKacir).join('[\\s\\-.,_]+');
    const rgx = new RegExp(`(?<![\\p{L}\\p{N}])(?:${desen})(?![\\p{L}\\p{N}])`, 'giu');
    s = s.replace(rgx, kayitlar[k]);
  }
  return s;
}

// Türkçe akustik ses ikizi iskeleti: birbirine karışan sesleri (y/k/g, t/d, p/b/v, s/ş/z, m/n, ö/ü/o/u, e/i/ı/a) ortak fonetik koda indirger
function fonetikIskelet(metin) {
  return String(metin || '')
    .toLocaleLowerCase('tr-TR')
    .replace(/[^\p{L}\p{N}]/gu, '')
    .replace(/[ğh]/g, '')
    .replace(/[aeıi]/g, 'a')
    .replace(/[oöuü]/g, 'u')
    .replace(/[kgycçq]/g, 'k')
    .replace(/[td]/g, 't')
    .replace(/[pbvf]/g, 'p')
    .replace(/[sşzj]/g, 's')
    .replace(/[mn]/g, 'm')
    .replace(/[lr]/g, 'l')
    .replace(/(.)\1+/g, '$1');
}

function levenshteinMesafe(a, b) {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const dp = Array.from({ length: a.length + 1 }, (_, i) => i);
  for (let j = 1; j <= b.length; j++) {
    let prev = dp[0];
    dp[0] = j;
    for (let i = 1; i <= a.length; i++) {
      const temp = dp[i];
      dp[i] = a[i - 1] === b[j - 1]
        ? prev
        : 1 + Math.min(prev, dp[i], dp[i - 1]);
      prev = temp;
    }
  }
  return dp[a.length];
}

function fonetikBenzerlikOrani(ifadeA, ifadeB) {
  const normA = String(ifadeA || '').toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]/gu, '');
  const normB = String(ifadeB || '').toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]/gu, '');
  if (!normA || !normB) return 0;
  if (normA === normB) return 1;
  const maksNorm = Math.max(normA.length, normB.length);
  const harfBenzerlik = 1 - (levenshteinMesafe(normA, normB) / maksNorm);
  const fA = fonetikIskelet(normA);
  const fB = fonetikIskelet(normB);
  const maksFon = Math.max(1, fA.length, fB.length);
  const fonetikBenzerlik = 1 - (levenshteinMesafe(fA, fB) / maksFon);
  return Number(((harfBenzerlik * 0.45) + (fonetikBenzerlik * 0.55)).toFixed(3));
}

const STANDART_TEKSTIL_URUNLERI = [
  'Keten Gömlek', 'Kot Gömlek', 'Oduncu Gömlek', 'Klasik Gömlek', 'Saten Gömlek', 'Kadın Gömlek', 'Erkek Gömlek',
  'V Yaka Tişört', 'Polo Yaka Tişört', 'Bisiklet Yaka Tişört', 'Oversize Tişört', 'Çocuk Tişört',
  'V Yaka Kazak', 'Bisiklet Yaka Kazak', 'Balıkçı Yaka Kazak', 'Triko Kazak', 'Triko Hırka', 'Triko Süveter',
  'Kot Pantolon', 'Kumaş Pantolon', 'Keten Pantolon', 'Kargo Pantolon', 'Jogger Pantolon', 'Kadife Pantolon',
  'Kot Mont', 'Deri Mont', 'Şişme Mont', 'Termal Uzun Kadın Mont', 'Kadın Mont', 'Erkek Mont', 'Kaşe Kaban',
  'Kot Ceket', 'Deri Ceket', 'Blazer Ceket', 'Polar Ceket', 'Yağmurluk', 'Trençkot',
  'Eşofman Takımı', 'Eşofman Altı', 'Sweatshirt', 'Kapüşonlu Sweatshirt', 'Pijama Takımı',
  'Spor Ayakkabı', 'Deri Ayakkabı', 'Klasik Ayakkabı', 'Pelüş Terlik', 'Deri Kemer', 'Kadın Çanta', 'İpek Eşarp'
];

// Söylenen metindeki kelime gruplarını Barkod Bankası, Marka Sözlüğü ve Tekstil Kategorileriyle fonetik olarak karşılaştırıp en güçlü adayları bulur
function kolektifUrunAdaylariBul(metin, katalogUrunleri = []) {
  const temiz = String(metin || '')
    .toLocaleLowerCase('tr-TR')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!temiz) return [];

  const kelimeler = temiz.split(' ').filter(w =>
    w.length >= 2 &&
    !BOS_SOZ.has(w) &&
    !/^(?:siyah|beyaz|gri|mavi|lacivert|kırmızı|yeşil|sarı|pembe|mor|bej|bordo|turuncu|kahverengi|ekru|krem|muhtelif|xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|5xl|\d+)$/iu.test(w)
  );
  if (!kelimeler.length) return [];

  // Aday havuzu: 1) Barkod Bankası / Mevcut Envanter, 2) Standart Tekstil Ürünleri, 3) Marka Sözlüğü
  const havuz = new Map();
  for (const u of (katalogUrunleri || [])) {
    const ad = typeof u === 'string' ? u.trim() : String((u && u.urun) || '').trim();
    if (ad && ad.length >= 3) {
      havuz.set(ad.toLocaleLowerCase('tr-TR'), {
        urun: ad,
        fiyat: (u && typeof u === 'object' && u.fiyat) ? u.fiyat : null,
        barkod: (u && typeof u === 'object' && (u.anaBarkod || u.barkod)) ? (u.anaBarkod || u.barkod) : null,
        kaynak: 'barkod_bankasi'
      });
    }
  }
  for (const st of STANDART_TEKSTIL_URUNLERI) {
    const k = st.toLocaleLowerCase('tr-TR');
    if (!havuz.has(k)) havuz.set(k, { urun: st, fiyat: null, barkod: null, kaynak: 'tekstil_sozlugu' });
  }
  const { resmiYazimlar } = markaSozluguYukle();
  for (const r of resmiYazimlar) {
    const k = r.resmiMarka.toLocaleLowerCase('tr-TR');
    if (!havuz.has(k)) havuz.set(k, { urun: r.resmiMarka, fiyat: null, barkod: null, kaynak: 'marka_sozlugu' });
  }

  // Cümledeki 1..4 kelimelik pencereleri oluştur (ve ayrıca ürün kelimelerinin tamamını birleşik aday olarak ekle)
  const pencereler = new Set([kelimeler.join(' ')]);
  for (let i = 0; i < kelimeler.length; i++) {
    for (let len = 1; len <= 4 && i + len <= kelimeler.length; len++) {
      const p = kelimeler.slice(i, i + len).join(' ');
      if (p.length >= 4) pencereler.add(p);
    }
  }

  const bulunanlar = [];
  for (const adayObj of havuz.values()) {
    let enIyiSkor = 0;
    let enIyiPencere = '';
    for (const p of pencereler) {
      if (Math.abs(p.length - adayObj.urun.length) > 8) continue;
      const skor = fonetikBenzerlikOrani(p, adayObj.urun);
      if (skor > enIyiSkor) {
        enIyiSkor = skor;
        enIyiPencere = p;
      }
    }
    // Mağaza barkod bankasındaki ürünlere +%4 öncelik bonusu ver
    const netSkor = adayObj.kaynak === 'barkod_bankasi' ? Math.min(1, enIyiSkor + 0.04) : enIyiSkor;
    if (netSkor >= 0.72) {
      bulunanlar.push({
        urun: adayObj.urun,
        fiyat: adayObj.fiyat,
        barkod: adayObj.barkod,
        kaynak: adayObj.kaynak,
        eslesenSoz: enIyiPencere,
        hamSkor: enIyiSkor,
        skor: Number(netSkor.toFixed(3))
      });
    }
  }

  bulunanlar.sort((a, b) => b.skor - a.skor || b.urun.length - a.urun.length);
  return bulunanlar.slice(0, 6);
}

// Çok kelimeli beden telaffuzlarını ("iki iks el", "ekstra larc", "100 ml", "tek ebat") ve Whisper bozmalarını düzeltir
function telaffuzDuzelt(metin) {
  const sayiKalibi = '(?:\\d+|bir|iki|[üu][çc]|d[öo]rt|be[şs]|alt[ıi]|yedi|sekiz|dokuz|on|yirmi|otuz|k[ıi]rk|elli|altm[ıi][şs]|yetmi[şs]|seksen|doksan|y[üu]z|bin)';
  const satirBirlesik = String(metin || '').replace(/([\p{L}\p{N}])\r?\n\s*([\p{L}\p{N}])/gu, '$1$2');
  return markaTelaffuzUygula(ogrenilenTelaffuzUygula(satirBirlesik))
    // Whisper'ın "Mavi cins, ceket, kot ceket" gibi tekrarlı marka+kategori cümlelerini "Mavi Jeans kot ceket" yap
    .replace(/\b(MaviJeans|Mavi\s+Jeans)\s*,?\s*(ceket|pantolon|g[öo]mlek|ti[şs][öo]rt|mont)\s*,?\s*(kot\s+\2)\b/giu, '$1 $3')
    .replace(/(?<![\p{L}\p{N}])(?:bezer|ezer|cezer)(?=\s+(?:terlik|ayakkab[ıi]|sandalet|bot|babet))(?![\p{L}\p{N}])/giu, 'Gezer')
    // Whisper'ın bozuk seslerde ürettiği yabancı alfabe (İzlandaca/İspanyolca ð, þ, í, á, ó vb.) halüsinasyon kelimelerini temizle
    .replace(/\b\S*[ðþæøßñáéíóúýãõåä]\S*\b/giu, ' ')
    .replace(/\ba[ğg]eimt\b/giu, ' ')
    // Whisper'ın cümle başındaki "Ürün ..." anahtar kelimesini "Ünlü ...", "Günün ...", "Ürünün ..." olarak yazmasını düzelt
    .replace(/^\s*(?:[üu]nl[üu]|g[üu]n[üu]n|[üu]r[üu]n[üu]n|[üu]r[üu]n[üu])\s+/iu, 'ürün ')
    .replace(/(?<![\p{L}\p{N}])fiyaht(\p{L}*)/giu, 'fiyat$1')
    // Whisper'ın "fiyat bin lira" sözünün başındaki "fi-" hecesini yutup "yat bin lira" yazmasını düzelt
    .replace(new RegExp(`(?<![\\p{L}\\p{N}])(?:yat|f[ıi]rat|[üu]cret\\p{L}*)(?=\\s+${sayiKalibi}\\b)`, 'giu'), 'fiyat')
    // Whisper'ın "adet 5" veya "5 adet" sözünü "alet 5", "5 alet", "aded 5", "at et 5" olarak yazmasını düzelt
    .replace(new RegExp(`(?<![\\p{L}\\p{N}])(?:alet|aded|adeti|at\\s+et)(?=\\s*[:\\-]?\\s*(?:[oO]?\\d+|${sayiKalibi})\\b)`, 'giu'), 'adet')
    .replace(new RegExp(`\\b(${sayiKalibi})\\s+(?:alet|aded|adeti|at\\s+et)(?![\\p{L}\\p{N}])`, 'giu'), '$1 adet')
    // Whisper'ın "gömlek" kelimesini "gönül ek", "gönülek", "gömlek ek", "gümlek", "göblek", "örgömleik" veya "gömleki" olarak yazmasını düzelt
    .replace(/(?<![\p{L}\p{N}])(?:g[öo]n[üu]l\s*ek|g[öo]n[üu]lek|g[öo]mlek\s+ek|g[üu]mlek\p{L}*|g[öo]blek\p{L}*|[öo]rg[öo]mleik|g[öo]mleki|g[öo]mle[ğg]i)(?![\p{L}\p{N}])/giu, 'gömlek')
    // Whisper'ın "keten gömlek / pantolon / ceket / şort" sözünü "yeten gömlek", "kenten gömlek", "geten gömlek" olarak yazmasını düzelt
    .replace(/(?<![\p{L}\p{N}])(?:yeten|kenten|geten|[çc]eten|katan)\s+(g[öo]mlek\p{L}*|pantolon\p{L}*|ceket\p{L}*|[şs]ort\p{L}*|elbise\p{L}*|tak[ıi]m\p{L}*|etek\p{L}*|bluz\p{L}*|tunik\p{L}*)(?![\p{L}\p{N}])/giu, 'keten $1')
    // Whisper'ın "rengi kahverengi", "kafirengi", "genç, sarı", "cenk mavi" gibi sözleri "renk <renk>" olarak düzelt
    .replace(/(?<![\p{L}\p{N}])(?:kahveringi|kafirengi|kahve\s+rengi)(?![\p{L}\p{N}])/giu, 'kahverengi')
    .replace(/(?<![\p{L}\p{N}])(?:reyni|rengi|renki|gen[çc]|cenk|ren)[\s,.;:]+(?=(?:siyah|beyaz|gri|mavi|lacivert|ye[şs]il|k[ıi]rm[ıi]z[ıi]|sar[ıi]|kahverengi|bej|pembe|mor|turuncu|bordo|ekru|krem|muhtelif)(?![\p{L}\p{N}]))/giu, 'renk ')
    // Aynı kayıtta arka arkaya "renk siyah, renk gri" denirse (konuşurken rengi düzeltme) son söylenen rengi esas al
    .replace(/\brenk\s+(?:siyah|beyaz|gri|mavi|lacivert|ye[şs]il|k[ıi]rm[ıi]z[ıi]|sar[ıi]|kahverengi|bej|pembe|mor|turuncu|bordo|ekru|krem|muhtelif)[\s,.;]+renk\s+/giu, 'renk ')
    .replace(/(?<![\p{L}\p{N}])(?:be\s*den\s*le|bedenle|denle|beden\s+el|lebeden|lebebeden|elbeden|le\s+beden)(?![\p{L}\p{N}])/giu, 'beden l')
    .replace(/(?<![\p{L}\p{N}])(?:be\s*den\s*em|bedenem|bedenme|denem|beden\s+em|beden\s+me|mebeden|mebebeden|embeden|me\s+beden)(?![\p{L}\p{N}])/giu, 'beden m')
    // Ses motorlarının "polo yaka" sözünü bozduğu biçimler. "O ayakka" yalnız tişört önünde düzeltilir
    .replace(/(?<![\p{L}\p{N}])(?:pola\s*yaka|polayaka|poloyaka|poloya\s*kat|olayaka|o\s+ayakka(?=\s+(?:ti[şs][öo]rt|t-?shirt)))(?![\p{L}\p{N}])/giu, 'polo yaka')
    .replace(/(?<![\p{L}\p{N}])polonya\s+ka\s*(?=ti[şs][öo]rt)/giu, 'polo yaka ')
    .replace(/(?<![\p{L}\p{N}])(?:be\s*den\s*se|bedense|dense|beden\s+ise|beden\s+es|beden\s+c|meden\s+c|sebeden|sebebeden|sebebden|sebedin|sebedan|se\s+beden)(?![\p{L}\p{N}])/giu, 'beden s')
    .replace(/(?<![\p{L}\p{N}])(?:meden|ve\s+den|be\s+den|neden|deden|eden)(?=\s+(?:\d{1,2}|xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|5xl|es|em|el|small|smol|medium|medyum|large|larc|larj|iksel|yok))(?![\p{L}\p{N}])/giu, 'beden')
    .replace(/\b(adet|tane|beden|numara)\s+[oO](\d+)\b/giu, '$1 $2')
    .replace(/(?<![\p{L}\p{N}])renk(puanl[ıi]|siyah|beyaz|gri|mavi|lacivert|ye[şs]il|k[ıi]rm[ıi]z[ıi]|sar[ıi]|kahverengi|bej|pembe|mor|turuncu|bordo|ekru|krem)/giu, 'renk $1')
    .replace(/(?<![\p{L}\p{N}])(siyah|beyaz|gri|mavi|lacivert|ye[şs]il|k[ıi]rm[ıi]z[ıi]|sar[ıi]|kahverengi|bej|pembe|mor|turuncu|bordo|ekru|krem)(siyah|beyaz|gri|mavi|lacivert|ye[şs]il|k[ıi]rm[ıi]z[ıi]|sar[ıi]|kahverengi|bej|pembe|mor|turuncu|bordo|ekru|krem)(?![\p{L}\p{N}])/giu, '$1 $2')
    .replace(/(?<![\p{L}\p{N}])(?:kriği|krigi|krii)(?![\p{L}\p{N}])/giu, 'gri')
    .replace(/(?<![\p{L}\p{N}])kod\s+(mont|pantolon|ceket|g[öo]mlek|etek|yelek|şort)(?![\p{L}\p{N}])/giu, 'kot $1')
    .replace(/(?<![\p{L}\p{N}])(?:xide|x[\s\-]*side|iksayd)(?![\p{L}\p{N}])/giu, 'Xside')
    .replace(/(?<![\p{L}\p{N}])(?:bigastim|bigazi|bigazzi)(?![\p{L}\p{N}])/giu, 'Bigazzi')
    .replace(/(?<![\p{L}\p{N}])(?:jolun|jollman|rolman|rollman)(?=\s+ayakkab[ıi])(?![\p{L}\p{N}])/giu, 'Rollmann')
    .replace(/(?<![\p{L}\p{N}])(?:n[üu]rt\s*fajr[ıi]|nord\s*falce|nordfalce|nordfage|nortfage|nord\s*project|north\s*s|nord\s*face|nort\s*feys|nord)(?=\s+(?:ti[şs][öo]rt|t-?shirt|mont|polar|yelek|ceket|sweatshirt|ayakkab[ıi]|bot|çanta))(?![\p{L}\p{N}])/giu, 'North Face')
    .replace(/(?<![\p{L}\p{N}])(?:fa[şs]iyon|fe[şs][ıi]n)(?![\p{L}\p{N}])/giu, 'Fashion')
    .replace(/(?<![\p{L}\p{N}])t-?shirt(?![\p{L}\p{N}])/giu, 'tişört')
    .replace(/(?<![\p{L}\p{N}])(?:jengri|rengri|cenk\s*gri|ren\s*gri)(?![\p{L}\p{N}])/giu, 'renk gri')
    .replace(/(?<![\p{L}\p{N}])(?:gen[çc]\s*ya|gen[çc]\s*siyah|cenk\s*siyah|ren\s*siyah|renk\s*siya)(?![\p{L}\p{N}])/giu, 'renk siyah')
    .replace(/(?<![\p{L}\p{N}])(?:k[üu]l[üu][şs]\s*terlik|p[üu]l[üu][şs]\s*terlik|pelu[şs]\s*terlik)(?![\p{L}\p{N}])/giu, 'pelüş terlik')
    .replace(/(?<![\p{L}\p{N}])zebre(?![\p{L}\p{N}])/giu, 'zebra')
    .replace(/(?<![\p{L}\p{N}])terrik(?![\p{L}\p{N}])/giu, 'terlik')
    .replace(/(?<![\p{L}\p{N}])(?:rebok|ribok)(?![\p{L}\p{N}])/giu, 'Reebok')
    .replace(/(?<![\p{L}\p{N}])(?:grayder|greder|crader|grader|greyder)(?![\p{L}\p{N}])/giu, 'Greyder')
    .replace(/(?<![\p{L}\p{N}])(?:[çc]arap|[çc]arab)(?![\p{L}\p{N}])/giu, 'çorap')
    .replace(/(?<![\p{L}\p{N}])(?:e[\s\-]*sharp|e[\s\-]*[şs]arp|e[şs]ak|e[şs]ap|e[şs]arf|e[şs]ar|esarf|esarp)(?![\p{L}\p{N}])/giu, 'eşarp')
    .replace(/(?<![\p{L}\p{N}])(?:xxs|xs|s|m|l|xl|xxl)\s*(3[4-9]|4\d|5[0-6])(?![\p{L}\p{N}])/giu, '$1')
    .replace(/(?<![\p{L}\p{N}])remarka(?![\p{L}\p{N}])/giu, 'marka')
    .replace(/(?<![\p{L}\p{N}])momma[\s\-]*i(?![\p{L}\p{N}])/giu, 'Moncler')
    .replace(/(?<![\p{L}\p{N}])momma(?=\s+(?:marka|remarka|mont))(?![\p{L}\p{N}])/giu, 'Moncler')
    .replace(/(?<![\p{L}\p{N}])(\d{2}|xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|5xl)\s+ve\s+den(?![\p{L}\p{N}])/giu, '$1 beden')
    .replace(/(?<![\p{L}\p{N}])(?:v|ve)\s*yak(?:aka|ak|ı|i|a|al[ıi]?)\s+(?:h[ıi]zl[ıi]k|k[ıi]zak|kaza|kaz[ıi]k)(?![\p{L}\p{N}])/giu, 'v yaka kazak')
    .replace(/(?<![\p{L}\p{N}])yak(?:aka|ak|al[ıi]?)\s+(?:h[ıi]zl[ıi]k|k[ıi]zak|kazak)(?![\p{L}\p{N}])/giu, 'yaka kazak')
    .replace(/(?<![\p{L}\p{N}])(?:v\s*y\s*k|vyk|(?:v|ve)\s*yak(?:aka|ak|ı|i|a|al[ıi]?))(?![\p{L}\p{N}])/giu, 'v yaka')
    .replace(/(?<![\p{L}\p{N}])(bisiklet|polo|hakim|dik|bal[ıi]k[çc][ıi]|kay[ıi]k|degaje|kruvaze|s[ıi]f[ıi]r)\s*yak(?:aka|ak|ı|i|a|al[ıi])(?![\p{L}\p{N}])/giu, '$1 yaka')
    // Whisper'ın "M beden", "L beden", "S beden", "XL beden" sözlerini "MB'den", "LB'den", "SB'den", "NB'den" olarak bitişik yazmasını düzelt
    .replace(/(?<![\p{L}\p{N}])(?:m\s*b|mb|n\s*b|nb|em\s*b|emb)['’.\-\s]*d[ae]n(?![\p{L}\p{N}])/giu, 'm beden')
    .replace(/(?<![\p{L}\p{N}])(?:l\s*b|lb|el\s*b|elb)['’.\-\s]*d[ae]n(?![\p{L}\p{N}])/giu, 'l beden')
    .replace(/(?<![\p{L}\p{N}])(?:s\s*b|sb|es\s*b|esb)['’.\-\s]*d[ae]n(?![\p{L}\p{N}])/giu, 's beden')
    .replace(/(?<![\p{L}\p{N}])(xxs|xs|xl|xxl|2xl|3xl|4xl|5xl)\s*b['’.\-\s]*d[ae]n(?![\p{L}\p{N}])/giu, '$1 beden')
    .replace(/(?<![\p{L}\p{N}])(\d{2})\s+(?:adet|tane)\s+\1\s+(numara\p{L}*|beden\p{L}*)(?![\p{L}\p{N}])/giu, '$1 $2')
    .replace(/(?<![\p{L}\p{N}])(?:svet\s*şört|svetşört|swet\s*şört|süvet\s*şört|suvet\s*şört|sweet\s*shirt|sweat\s*shirt)(?![\p{L}\p{N}])/giu, 'sweatshirt')
    .replace(/(?<![\p{L}\p{N}])kod\s+(mont\p{L}*|pantolon\p{L}*|ceket\p{L}*|g[öo]mlek\p{L}*|etek\p{L}*|[şs]ort\p{L}*|yelek\p{L}*|elbise\p{L}*|salopet\p{L}*|tulum\p{L}*)(?![\p{L}\p{N}])/giu, 'kot $1')
    .replace(/(?<![\p{L}\p{N}])(bir)\s+(?:er|ar|şer|ser)(?![\p{L}\p{N}])/giu, 'birer')
    .replace(/(?<![\p{L}\p{N}])(iki)\s+(?:şer|ser|er)(?![\p{L}\p{N}])/giu, 'ikişer')
    .replace(/(?<![\p{L}\p{N}])([üu][çc])\s+(?:er|şer|ser)(?![\p{L}\p{N}])/giu, 'üçer')
    .replace(/(?<![\p{L}\p{N}])(d[öo]rt|d[öo]rd)\s+(?:er|şer|ser)(?![\p{L}\p{N}])/giu, 'dörder')
    .replace(/(?<![\p{L}\p{N}])(be[şs])\s+(?:er|şer|ser)(?![\p{L}\p{N}])/giu, 'beşer')
    .replace(/(?<![\p{L}\p{N}])(alt[ıi])\s+(?:şar|sar|ar)(?![\p{L}\p{N}])/giu, 'altışar')
    .replace(/(?<![\p{L}\p{N}])(yedi)\s+(?:şer|ser|er)(?![\p{L}\p{N}])/giu, 'yedişer')
    .replace(/(?<![\p{L}\p{N}])(sekiz)\s+(?:er|şer|ser)(?![\p{L}\p{N}])/giu, 'sekizer')
    .replace(/(?<![\p{L}\p{N}])(dokuz)\s+(?:ar|şar|sar)(?![\p{L}\p{N}])/giu, 'dokuzar')
    .replace(/(?<![\p{L}\p{N}])(on)\s+(?:ar|şar|sar)(?![\p{L}\p{N}])/giu, 'onar')
    .replace(/(?<![\p{L}\p{N}'’])[şs]er\s+(tane|adet)(?![\p{L}\p{N}])/giu, 'ikişer $1')
    .replace(/(?<![\p{L}\p{N}])dn\s*(\d+)\s*(?:[,;-]|\s+ve\s+|\s+)\s*dn\s*(\d+)(?![\p{L}\p{N}])/giu, "m'den $1, l'den $2")
    .replace(/(?<![\p{L}\p{N}])(xxs|xs|s|m|l|xl|xxl)\s*d[nń]\s*(\d+)(?![\p{L}\p{N}])/giu, "$1'den $2")
    .replace(/(?<![\p{L}\p{N}])el\s+(d[ae]n|t[ae]n)(?![\p{L}\p{N}])/giu, "l'$1")
    .replace(/(?<![\p{L}\p{N}])em\s+(d[ae]n|t[ae]n)(?![\p{L}\p{N}])/giu, "m'$1")
    .replace(/(?<![\p{L}\p{N}])es\s+(d[ae]n|t[ae]n)(?![\p{L}\p{N}])/giu, "s'$1")
    // "L 5 XL 2" dizisinde 5 sayısı L'nin adedidir; önünde yalın beden varken "5 XL" -> "5xl" olarak birleştirilmez
    .replace(/(?<!\b(?:xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|es|em|el|small|smol|medium|medyum|large|larc|larj)(?:\s+beden)?[\s,]+)(?<![\p{L}\p{N}])(?:[iİ]ki|2|duble|double)\s*(?:[iİ]ks\s*el|[iİ]ksel|x\s*el|xl)(?![\p{L}\p{N}])/giu, '2xl')
    .replace(/(?<!\b(?:xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|es|em|el|small|smol|medium|medyum|large|larc|larj)(?:\s+beden)?[\s,]+)(?<![\p{L}\p{N}])(?:[üÜuU][çcÇC]|3|triple)\s*(?:[iİ]ks\s*el|[iİ]ksel|x\s*el|xl)(?![\p{L}\p{N}])/giu, '3xl')
    .replace(/(?<!\b(?:xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|es|em|el|small|smol|medium|medyum|large|larc|larj)(?:\s+beden)?[\s,]+)(?<![\p{L}\p{N}])(?:d[öÖoO]rt|4)\s*(?:[iİ]ks\s*el|[iİ]ksel|x\s*el|xl)(?![\p{L}\p{N}])/giu, '4xl')
    .replace(/(?<!\b(?:xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl|es|em|el|small|smol|medium|medyum|large|larc|larj)(?:\s+beden)?[\s,]+)(?<![\p{L}\p{N}])(?:b[eE][şsŞS]|5)\s*(?:[iİ]ks\s*el|[iİ]ksel|x\s*el|xl)(?![\p{L}\p{N}])/giu, '5xl')
    .replace(/(?<![\p{L}\p{N}])(?:[iİ]ks\s*es|x\s*s|x\s*es|ekstra\s*small|extra\s*small|ekstra\s*smol)(?![\p{L}\p{N}])/giu, 'xs')
    .replace(/(?<![\p{L}\p{N}])(?:x\s*x\s*l|xx\s*l|x\s*xl|xxl|2\s*x\s*l)(?![\p{L}\p{N}])/giu, 'xxl')
    .replace(/(?<![\p{L}\p{N}])(?:x\s*x\s*x\s*l|xxx\s*l|xx\s*xl|3\s*x\s*l)(?![\p{L}\p{N}])/giu, '3xl')
    .replace(/(?<![\p{L}\p{N}])(?:[iİ]ks\s*el|x\s*l|x\s*el|eks\s*el|ekstra\s*large|extra\s*large|ekstra\s*larc|ekstra\s*larj)(?![\p{L}\p{N}])/giu, 'xl')
    // Parfüm ve kozmetik: "Chanel parfum", "Şanel Tarıkçı", "50 ml" ("elle emel", "elle meil", "50 milyar", "elli emel"), "100 ml" ("yüz emel", "100 ömerli")
    .replace(/(?<![\p{L}\p{N}])(?:parfum|parf[üu]n|perfume)(?![\p{L}\p{N}])/giu, 'parfüm')
    .replace(/(?<![\p{L}\p{N}])tar[ıi]k[çc][ıi](?![\p{L}\p{N}])/giu, 'parfüm')
    .replace(/(?<![\p{L}\p{N}])(?:eau\s+de\s+parf[üu]m|ö\s*dö\s*parf[üu]m|edp)(?![\p{L}\p{N}])/giu, 'EDP parfüm')
    .replace(/(?<![\p{L}\p{N}])(?:eau\s+de\s+toilette|ö\s*dö\s*tuvalet|edt)(?![\p{L}\p{N}])/giu, 'EDT parfüm')
    .replace(/(?<![\p{L}\p{N}])(?:elle|elli|50)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '50ml')
    .replace(/(?<![\p{L}\p{N}])(?:y[üu]z\s*yirmi\s*be[şs]|125)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '125ml')
    .replace(/(?<![\p{L}\p{N}])(?:y[üu]z\s*elli|150)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '150ml')
    .replace(/(?<![\p{L}\p{N}])(?:iki\s*y[üu]z|200)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '200ml')
    .replace(/(?<![\p{L}\p{N}])(?:y[üu]z|100)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '100ml')
    .replace(/(?<![\p{L}\p{N}])(?:yetmi[şs]\s*be[şs]|75)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '75ml')
    .replace(/(?<![\p{L}\p{N}])(?:otuz|30)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '30ml')
    .replace(/(?<![\p{L}\p{N}])(?:seksen|80)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '80ml')
    .replace(/(?<![\p{L}\p{N}])(?:doksan|90)\s*(?:m\s*l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '90ml')
    .replace(/(?<![\p{L}\p{N}])(\d{2,3})\s*(?:m\s+l|ml|emel|em\s+el|meil|mail|meyil|emeli|[öo]merli|milim|mili|mililitre|mil|milyar|cc)(?![\p{L}\p{N}])/giu, '$1ml')
    .replace(/(?<![\p{L}\p{N}])(\d{1,2})\s*ya[şs](?![\p{L}\p{N}])/giu, '$1yaş')
    .replace(/(?<![\p{L}\p{N}])tek\s+ebat(?![\p{L}\p{N}])/giu, 'standart');
}

// "fiyatı 1500", "1.500 lira", "1500.50 TL", "fiyatı bin iki yüz lira", "Fiyahtı dört yüz elli", "Yat bin lira, bin lira": fiyat sözden ayrılır
function fiyatiAyir(metin) {
  const sayiKelimeKalibi = '(?:bir|iki|üç|uc|dört|dort|beş|bes|altı|alti|yedi|sekiz|dokuz|on|yirmi|otuz|kırk|kirk|elli|altmış|altmis|yetmiş|yetmis|seksen|doksan|yüz|yuz|bin)';
  let islenen = telaffuzDuzelt(String(metin || ''))
    .replace(/\bfiyaht(\p{L}*)/giu, 'fiyat$1')
    .replace(new RegExp(`(?<![\\p{L}\\p{N}])(?:yat|f[ıi]rat|[üu]cret\\p{L}*)(?=\\s+(?:\\d|${sayiKelimeKalibi})\\b)`, 'giu'), 'fiyat')
    // Whisper'ın "fiyat 1500, 42 beden" sözünü "fiyat 1542 beden" olarak birleştirmesini ayır (son 2 hane 34..56 beden ise)
    .replace(/\b(fiyat\p{L}*\s*:?\s*)([1-9]\d)(3[4-9]|4\d|5[0-6])(?=\s*(?:beden|numara)\b)/giu, '$1$200 $3')
    .replace(/(?<![\p{L}\p{N}.])([1-9]\d)(3[4-9]|4\d|5[0-6])\s+(beden\p{L}*|numara\p{L}*)(?![\p{L}\p{N}])/giu, '$100 lira $2 $3');
  const yaziFiyatÖn = new RegExp(`(fiyat\\p{L}*\\s*:?\\s*)(${sayiKelimeKalibi}(?:\\s+${sayiKelimeKalibi})*)(?=\\s*(?:lira\\p{L}*|tl\\p{L}*|₺|$|[.,;]))`, 'giu');
  islenen = islenen.replace(yaziFiyatÖn, (tam, onEk, sayiKismi) => {
    const n = yaziSayiyiRakamaCevir(sayiKismi);
    return n ? `${onEk}${n}` : tam;
  });
  const yaziFiyatSon = new RegExp(`\\b(${sayiKelimeKalibi}(?:\\s+${sayiKelimeKalibi})*)\\s+(lira\\p{L}*|tl\\p{L}*|₺)`, 'giu');
  islenen = islenen.replace(yaziFiyatSon, (tam, sayiKismi, birim) => {
    const n = yaziSayiyiRakamaCevir(sayiKismi);
    return n ? `${n} ${birim}` : tam;
  });

  let fiyat = null;
  const desenler = [
    /fiyat\p{L}*\s*:?\s*(\d{1,3}(?:[.\s]\d{3})+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(?:lira\p{L}*|tl\p{L}*|₺)?/iu,
    /(\d{1,3}(?:[.\s]\d{3})+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(?:lira\p{L}*|tl\p{L}*|₺|fiyat\p{L}*)/iu
  ];
  for (const desen of desenler) {
    const m = islenen.match(desen);
    if (m) {
      const hamSayi = m[1].replace(/\s+/g, '.');
      fiyat = fiyatCoz(hamSayi);
      islenen = islenen.replace(m[0], ' ');
      // Kullanıcı fiyatı teyit için iki kez tekrarladıysa ("bin lira, bin lira" -> "1000 lira") ikinci tekrarı da temizle ki adet (1000) sanılmasın!
      if (fiyat > 0) {
        const tekrarDesen = new RegExp(`\\b${fiyat}\\s*(?:lira\\p{L}*|tl\\p{L}*|₺)\\b`, 'giu');
        islenen = islenen.replace(tekrarDesen, ' ');
      }
      break;
    }
  }
  return { metin: islenen, fiyat: fiyat > 0 ? fiyat : null };
}

// Söz parçası: renk, beden, adet, "her bedenden" ya da ad sözü (konuşma sırasından bağımsız etiketlenir)
function parcalar(metin) {
  const duzeltilmis = telaffuzDuzelt(metin);
  const normal = ` ${normalMetin(duzeltilmis)} `;
  const renkler = colorSpans(duzeltilmis);
  const sonuc = [];
  const kelime = /[\p{L}\p{N}'’]+/gu;
  let m;
  while ((m = kelime.exec(normal))) {
    const bas = m.index - 1;
    const kalanMetin = normal.slice(m.index + m[0].length);
    const renk = renkler.find(r => bas >= r.bas && bas < r.son);
    if (renk) {
      // "Mavi jean" / "Mavi jeans" veya cümlede başka renk varken "Mavi pantolon / gömlek / tişört" ifadesinde Mavi renk değil markadır
      if (renk.ad === 'MAVİ' && (/^\s*jeans?\b/iu.test(kalanMetin) || (renkler.length > 1 && /^\s*(?:pantolon|kot|g[öo]mlek|ti[şs][öo]rt|ceket|[şs]ort|etek|sweatshirt|kazak|mont|yelek)\b/iu.test(kalanMetin)))) {
        sonuc.push({ tip: 'ad', soz: m[0] });
        continue;
      }
      // "Barbara çizgili gömlek", "kareli gömlek", "desenli elbise" gibi ürün adının parçası olan desen ifadelerini ürün adına dahil et
      if (/^(?:ÇİZGİLİ|KARELİ|DESENLİ)$/u.test(renk.ad) && /^\s*(?:g[öo]mlek|ti[şs][öo]rt|kazak|triko|pantolon|ceket|elbise|etek|bluz|tunik|h[ıi]rka|yelek|[şs]ort|pijama|e[şs]arp|[şs]al)\b/iu.test(kalanMetin)) {
        sonuc.push({ tip: 'ad', soz: m[0] });
        continue;
      }
      if (!sonuc.length || sonuc[sonuc.length - 1].renkBas !== renk.bas) {
        const sonEleman = sonuc[sonuc.length - 1];
        const desenMi = ad => /^(?:ÇİZGİLİ|KARELİ|DESENLİ)$/u.test(ad);
        if (sonEleman && sonEleman.tip === 'renk') {
          // Arka arkaya söylenen renk/desen kelimelerini ("yeşil gri", "yeşil çizgili", "çizgili yeşil") tek satır rengi olarak birleştir
          const parcaRenkler = sonEleman.ad.split(' ');
          if (!parcaRenkler.includes(renk.ad)) {
            if (desenMi(sonEleman.ad) && !desenMi(renk.ad)) {
              sonEleman.ad = `${renk.ad} ${sonEleman.ad}`;
            } else {
              sonEleman.ad = `${sonEleman.ad} ${renk.ad}`;
            }
          }
          sonEleman.renkBas = renk.bas;
        } else {
          sonuc.push({ tip: 'renk', ad: renk.ad, renkBas: renk.bas });
        }
      }
      continue;
    }
    const k = m[0];
    // Ses motorunun ayrı yazdığı ekler: "40 tan", "44 e kadar", "s den", "el den"
    if (AYRIK_EK.test(k)) {
      const onceki = sonuc[sonuc.length - 1];
      if (onceki && onceki.tip === 'ad' && onceki.soz === 'el' && AYIRMA_EKI.test(k)) {
        onceki.tip = 'beden';
        onceki.beden = 'L';
        onceki.ek = k;
        delete onceki.soz;
        continue;
      }
      if (onceki && (onceki.tip === 'sayi' || onceki.tip === 'beden') && !onceki.ek) {
        onceki.ek = k;
        continue;
      }
      if (AYIRMA_EKI.test(k)) continue;
    }
    const harf = k.match(HARF_BEDEN);
    if (harf) { sonuc.push({ tip: 'beden', beden: harf[1].toLocaleUpperCase('tr-TR'), ek: harf[2] || '' }); continue; }
    const telaffuzEslesme = k.match(/^(\p{L}+?)(?:['’]?(d[ae]n|t[ae]n|y[ae]|[ae]|d[ae]|l[ıi]k))?$/u);
    if (telaffuzEslesme && TELAFFUZ_BEDEN[telaffuzEslesme[1]]) {
      sonuc.push({ tip: 'beden', beden: TELAFFUZ_BEDEN[telaffuzEslesme[1]], ek: telaffuzEslesme[2] || '' });
      continue;
    }
    if (telaffuzEslesme && telaffuzEslesme[1] === 'el') {
      const onceki = sonuc[sonuc.length - 1];
      if (telaffuzEslesme[2] || (onceki && (onceki.tip === 'beden' || onceki.tip === 'bedenSozu'))) {
        sonuc.push({ tip: 'beden', beden: 'L', ek: telaffuzEslesme[2] || '' });
        continue;
      }
    }
    const coklu = k.match(/^(\d{1,3})['’]?(?:er|ar|şer|şar|ser|sar)$/u);
    if (coklu) { sonuc.push({ tip: 'adet', adet: Number(coklu[1]), herBiri: true }); continue; }
    if (HER_BIRI_SOZ[k]) { sonuc.push({ tip: 'adet', adet: HER_BIRI_SOZ[k], herBiri: true }); continue; }
    const sayiBeden = k.match(SAYI_BEDEN);
    if (sayiBeden) { sonuc.push({ tip: 'sayi', sayi: Number(sayiBeden[1]), ek: sayiBeden[2] || '' }); continue; }
    if (/^\d{1,3}$/u.test(k)) { sonuc.push({ tip: 'sayi', sayi: Number(k), ek: '' }); continue; }
    const sayiKok = telaffuzEslesme ? telaffuzEslesme[1] : k;
    const sayiEk = telaffuzEslesme ? (telaffuzEslesme[2] || '') : '';
    if ((sayiKok === 'altı' || sayiKok === 'alti') && !sayiEk) {
      const onceki = sonuc[sonuc.length - 1];
      if (onceki && onceki.tip === 'ad' && ALTI_BILESIK_ONCU.test(onceki.soz) && !/^\s*(?:tane|adet)\b/iu.test(kalanMetin)) {
        sonuc.push({ tip: 'ad', soz: 'altı' });
        continue;
      }
    }
    if ((sayiKok === 'yüz' || sayiKok === 'yuz') && !sayiEk) {
      const sonrakiKelime = (kalanMetin.match(/^\s*([\p{L}\p{N}]+)/u) || [])[1] || '';
      if (sonrakiKelime && YUZ_BILESIK_SONRA.test(sonrakiKelime)) {
        sonuc.push({ tip: 'ad', soz: 'yüz' });
        continue;
      }
    }
    if (SAYI_SOZ[sayiKok] !== undefined) {
      const deger = SAYI_SOZ[sayiKok];
      const onceki = sonuc[sonuc.length - 1];
      if (onceki && onceki.tip === 'sayi' && onceki.soz && !onceki.ek) {
        if (deger === 1000 && onceki.sayi < 100) {
          onceki.sayi *= 1000;
          if (sayiEk) onceki.ek = sayiEk;
          continue;
        }
        if (deger === 100) {
          if (onceki.sayi < 10) {
            onceki.sayi *= 100;
            if (sayiEk) onceki.ek = sayiEk;
            continue;
          }
          if (onceki.sayi >= 1000 && onceki.sayi % 100 < 10) {
            const binlik = Math.floor(onceki.sayi / 1000) * 1000;
            const yuzlukCarpan = (onceki.sayi % 1000) || 1;
            onceki.sayi = binlik + yuzlukCarpan * 100;
            if (sayiEk) onceki.ek = sayiEk;
            continue;
          }
        }
        if (deger < 100 && deger >= 10 && onceki.sayi >= 100 && onceki.sayi % 100 === 0) {
          onceki.sayi += deger;
          if (sayiEk) onceki.ek = sayiEk;
          continue;
        }
        if (deger < 10 && (onceki.sayi % 10 === 0)) {
          onceki.sayi += deger;
          if (sayiEk) onceki.ek = sayiEk;
          continue;
        }
      }
      sonuc.push({ tip: 'sayi', sayi: deger, ek: sayiEk, soz: true });
      continue;
    }
    const bedenSozu = k.match(BEDEN_SOZU);
    if (bedenSozu) {
      const onceki = sonuc[sonuc.length - 1];
      if (onceki && onceki.tip === 'ad' && onceki.soz === 'el') {
        onceki.tip = 'beden'; onceki.beden = 'L'; onceki.ek = ''; delete onceki.soz;
      }
      const harfBedenTüketti = Boolean(onceki && onceki.tip === 'beden');
      sonuc.push({ tip: 'bedenSozu', ek: bedenSozu[1] || '', kullanildi: harfBedenTüketti });
      continue;
    }
    if (TANE_SOZU.test(k)) { sonuc.push({ tip: 'tane' }); continue; }
    if (HEPSI_SOZU.test(k)) { sonuc.push({ tip: 'hepsi' }); continue; }
    if (BOS_SOZ.has(k)) continue;
    sonuc.push({ tip: 'ad', soz: k });
  }
  return sonuc;
}

// İki basamaklı sayı beden mi adet mi: ekine ve yanındakilere (önce veya sonra gelen beden/adet sözüne) bakılır
function sayilariAyir(liste) {
  const sayiBedenOlur = s => s && s.tip === 'sayi' && s.sayi >= 20 && s.sayi <= 60 && (!s.soz || Boolean(s.ek));
  const oncesindeBekleyenAdetVar = idx => {
    for (let k = idx - 1; k >= 0; k--) {
      if (liste[k].tip === 'beden') return false;
      if (liste[k].tip === 'adet') return true;
    }
    return false;
  };
  for (let i = 0; i < liste.length; i++) {
    const s = liste[i];
    if (s.tip !== 'sayi') continue;
    const sonraki = liste[i + 1];
    const onceki = liste[i - 1];
    // 1. "beden 46, adet 5", "numara 38, adet 15", "beden 3, adet 55": sütun adı ("beden"/"numara") sayıdan hemen önce söylendiyse
    // Ancak "her bedenden 2" veya "bedenden 2" denildiğinde buradaki sayı beden değil adettir!
    if (onceki && onceki.tip === 'bedenSozu' && !onceki.kullanildi && !AYIRMA_EKI.test(onceki.ek || '') && !(liste[i - 2] && liste[i - 2].tip === 'hepsi') && s.sayi >= 1 && s.sayi <= 60) {
      const sonrakiTaneTekBasina = sonraki && sonraki.tip === 'tane' && !(liste[i + 2] && (liste[i + 2].tip === 'sayi' || liste[i + 2].tip === 'adet'));
      if (!sonrakiTaneTekBasina) {
        s.tip = 'beden'; s.beden = String(s.sayi);
        onceki.kullanildi = true;
        continue;
      }
    }
    // 2. "adet 5, beden 46", "tane 15": adet sözü sayıdan hemen önce söylendiyse
    if (onceki && onceki.tip === 'tane' && !onceki.kullanildi) {
      const sonrakiBedenTekBasina = sonraki && sonraki.tip === 'bedenSozu' && !(liste[i + 2] && (liste[i + 2].tip === 'sayi' || liste[i + 2].tip === 'beden'));
      if (!sonrakiBedenTekBasina) {
        s.tip = 'adet'; s.adet = s.sayi;
        onceki.kullanildi = true;
        continue;
      }
    }
    // 3. "40 numaradan 2", "40 41 42 numara", "46 beden": beden/numara sözü sayıdan hemen sonra söylendiyse
    if (sonraki && sonraki.tip === 'bedenSozu') {
      s.tip = 'beden'; s.beden = String(s.sayi); s.ek = AYIRMA_EKI.test(sonraki.ek) ? 'den' : s.ek;
      sonraki.kullanildi = true;
      continue;
    }
    // 4. "5 adet", "15 tane": adet/tane sözü sayıdan hemen sonra söylendiyse
    if (sonraki && sonraki.tip === 'tane') {
      s.tip = 'adet'; s.adet = s.sayi;
      sonraki.kullanildi = true;
      continue;
    }
    if (!sayiBedenOlur(s)) { s.tip = 'adet'; s.adet = s.sayi; continue; }
    // Ayrılma ya da yönelme ekli iki basamaklı sayı bedendir ("40'tan", "44'e kadar")
    if (s.ek) { s.tip = 'beden'; s.beden = String(s.sayi); continue; }
    // "40 2 tane": ardından "sayı + tane/adet" geliyorsa bu sayı bedendir
    const sonrakiSayiTane = sonraki && sonraki.tip === 'sayi' && liste[i + 2] && liste[i + 2].tip === 'tane';
    if (sonrakiSayiTane) { s.tip = 'beden'; s.beden = String(s.sayi); continue; }
    // "2 tane 40", "iki tane siyah 40 ayakkabı", "ikişer 40": öncesinde adet zaten söylendiyse bu sayı bedendir
    const oncekiAdet = (onceki && onceki.tip === 'tane' && onceki.kullanildi) || (onceki && onceki.tip === 'adet') || oncesindeBekleyenAdetVar(i);
    if (oncekiAdet) { s.tip = 'beden'; s.beden = String(s.sayi); continue; }
    // Eksiz: ardından başka beden ya da sayı geliyorsa beden listesi ("40 41 42"), bedenden sonra geliyorsa adet
    const sonrakiBeden = sonraki && (sonraki.tip === 'beden' || sayiBedenOlur(sonraki));
    const oncekiBekleyenBeden = onceki && onceki.tip === 'beden' && AYIRMA_EKI.test(onceki.ek || '');
    if (oncekiBekleyenBeden && !sonrakiBeden) { s.tip = 'adet'; s.adet = s.sayi; continue; }
    if (sonrakiBeden || (onceki && onceki.tip === 'beden')) { s.tip = 'beden'; s.beden = String(s.sayi); continue; }
    // "40 siyah 2 tane": bedenden hemen sonra renk geliyorsa bedendir
    if (sonraki && sonraki.tip === 'renk') { s.tip = 'beden'; s.beden = String(s.sayi); continue; }
    s.tip = 'adet'; s.adet = s.sayi; s.belirsiz = true;
  }
  return liste;
}

function birlesik(satirlar) {
  const harita = new Map();
  for (const s of satirlar) {
    const anahtar = `${s.renk}|${s.beden}`;
    if (harita.has(anahtar)) {
      const mevcut = harita.get(anahtar);
      mevcut.adet = (mevcut.adet || 0) + (s.adet || 0) || null;
      if (s.irsaliyeAdet != null) mevcut.irsaliyeAdet = (mevcut.irsaliyeAdet || 0) + (Number(s.irsaliyeAdet) || 0);
    } else {
      harita.set(anahtar, { ...s });
    }
  }
  return [...harita.values()];
}

// Anahtar Kelime Çapalı ("Ürün ... Fiyat ... Beden ... Adet ... Renk ...") Dilimleyici:
// Kullanıcının söylediği düz metni anahtar kelimelerinden bölerek her alanın (Ürün/Marka, Fiyat, Beden, Adet, Renk) sınırlarını kesinleştirir.
function anahtarKelimeCapaliAyristir(hamSoz) {
  const duzeltilmis = telaffuzDuzelt(String(hamSoz || ''))
    .replace(/[,;:.!?]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!duzeltilmis) {
    return { capaliMi: false, urunAnahtariVar: false, urunDilimi: '', fiyatDilimi: '', bedenDilimleri: [], adetDilimleri: [], renkDilimleri: [] };
  }
  const anahtarRegex = /(?<![\p{L}\p{N}])(ürün|urun|ürünü|urunu|fiyat\p{L}*|beden\p{L}*|numara\p{L}*|adet\p{L}*|tane\p{L}*|renk\p{L}*|rengi)(?![\p{L}\p{N}])/giu;
  const eslesmeler = [];
  let m;
  while ((m = anahtarRegex.exec(duzeltilmis)) !== null) {
    const hamKelime = m[1].toLocaleLowerCase('tr-TR');
    let tip = 'diger';
    if (/^(?:ürün|urun)/.test(hamKelime)) tip = 'urun';
    else if (/^fiyat/.test(hamKelime)) tip = 'fiyat';
    else if (/^(?:beden|numara)/.test(hamKelime)) tip = 'beden';
    else if (/^(?:adet|tane)/.test(hamKelime)) tip = 'adet';
    else if (/^(?:renk|rengi)/.test(hamKelime)) tip = 'renk';
    eslesmeler.push({ tip, baslangic: m.index, icerikBaslangic: m.index + m[0].length });
  }
  if (eslesmeler.length === 0) {
    return { capaliMi: false, urunAnahtariVar: false, urunDilimi: duzeltilmis, fiyatDilimi: '', bedenDilimleri: [], adetDilimleri: [], renkDilimleri: [] };
  }
  let urunAnahtariVar = false;
  let urunDilimi = '';
  let fiyatDilimi = '';
  const bedenDilimleri = [];
  const adetDilimleri = [];
  const renkDilimleri = [];

  // İlk anahtar kelimeden önce söylenen kısım varsa ("Versace mont fiyat 1000...") ve içinde geçerli ürün/marka varsa onu da ürün dilimi kabul et
  const onEk = duzeltilmis.slice(0, eslesmeler[0].baslangic).trim();
  if (onEk && eslesmeler[0].tip !== 'urun' && gecerliUrunAdiMi(onEk)) {
    urunDilimi = onEk;
    urunAnahtariVar = true;
  }

  for (let i = 0; i < eslesmeler.length; i++) {
    const suAnki = eslesmeler[i];
    const sonrakiBaslangic = i + 1 < eslesmeler.length ? eslesmeler[i + 1].baslangic : duzeltilmis.length;
    const dilim = duzeltilmis.slice(suAnki.icerikBaslangic, sonrakiBaslangic).trim();
    if (!dilim) continue;
    if (suAnki.tip === 'urun') {
      urunAnahtariVar = true;
      urunDilimi = urunDilimi ? `${urunDilimi} ${dilim}` : dilim;
    } else if (suAnki.tip === 'fiyat') {
      fiyatDilimi = dilim;
    } else if (suAnki.tip === 'beden') {
      bedenDilimleri.push(dilim);
    } else if (suAnki.tip === 'adet') {
      adetDilimleri.push(dilim);
    } else if (suAnki.tip === 'renk') {
      renkDilimleri.push(dilim);
    }
  }

  return {
    capaliMi: true,
    urunAnahtariVar,
    urunDilimi: urunDilimi.trim(),
    fiyatDilimi: fiyatDilimi.trim(),
    bedenDilimleri,
    adetDilimleri,
    renkDilimleri
  };
}

// Söz -> { urun, fiyat, satirlar, uyarilar }
// Konuşan kişi model, renk, beden, adet ve fiyatı hangi sırayla söylerse söylesin kendi sütununa yerleştirir.
function coz(soz) {
  const zDenetim = metinEnjeksiyonDenetle(String(soz || ''), 'envanter_soz');
  const temizSoz = zDenetim.metin.replace(/\[ENGELLENDI\]/g, ' ');
  const capali = anahtarKelimeCapaliAyristir(temizSoz);
  const { metin, fiyat } = fiyatiAyir(temizSoz);
  const liste = sayilariAyir(parcalar(metin));
  const uyarilar = [];
  if (!zDenetim.temiz) {
    uyarilar.push('🛡️ Güvenlik Zırhı: Giriş metninde şüpheli komut/prompt enjeksiyonu tespit edildi ve temizlendi.');
  }
  const adSozleri = [];
  const gruplar = [];
  let grup = null;
  let sonAnlamliTip = null;
  const yeniGrup = () => {
    grup = { renkler: [], bedenler: [], adetsizler: [], bekleyenAdet: null, herBedenden: false, renkSonda: false };
    gruplar.push(grup);
    return grup;
  };
  const grupTamamMi = g => Boolean(g && g.renkSonda && g.renkler.length > 0 && g.bedenler.length > 0 && g.adetsizler.length === 0 && !g.bekleyenAdet);
  const ilerideBedenVarMi = basIndeks => {
    for (let j = basIndeks; j < liste.length; j++) {
      if (liste[j].tip === 'beden') return true;
      if (liste[j].tip === 'adet') return false;
    }
    return false;
  };
  const herhangiBedenVarMi = liste.some(x => x.tip === 'beden');

  for (let i = 0; i < liste.length; i++) {
    const p = liste[i];
    if (p.tip === 'bedenSozu' || p.tip === 'tane') continue;
    // Ürün/model adı cümlenin başında, ortasında veya sonunda söylenebilir
    if (p.tip === 'ad') { adSozleri.push(p.soz); continue; }

    if (p.tip === 'renk') {
      if (grup && grup.bekleyenAdet && !herhangiBedenVarMi && grup.renkler.length > 0) {
        grup.bedenler.push({ beden: '', adet: grup.bekleyenAdet.adet });
        grup.bekleyenAdet = null;
      }
      // Beden veya adet renkten önce söylendiyse ("M beden siyah 2 tane", "S M L üçer tane beyaz"), renk mevcut gruba bağlanır
      if (grup && (grup.renkler.length === 0 || sonAnlamliTip === 'renk')) {
        if (!grup.renkler.includes(p.ad)) grup.renkler.push(p.ad);
        for (const eskiGrup of gruplar) {
          if (eskiGrup !== grup && eskiGrup.renkler.length === 0) eskiGrup.renkler.push(p.ad);
        }
      } else {
        if (!grup || grup.bedenler.length || grup.adetsizler.length || grup.bekleyenAdet) yeniGrup();
        if (!grup.renkler.includes(p.ad)) grup.renkler.push(p.ad);
      }
      sonAnlamliTip = 'renk';
      continue;
    }

    if (p.tip === 'hepsi') {
      if (!grup || grupTamamMi(grup)) yeniGrup();
      grup.herBedenden = true;
      if (grup.bekleyenAdet) grup.bekleyenAdet.herBiri = true;
      sonAnlamliTip = 'hepsi';
      continue;
    }

    if (p.tip === 'beden') {
      // Önceki grup "beden -> renk" sırasıyla rengini zaten aldıysa yeni beden yeni grup açar ("M siyah, L beyaz")
      if (!grup || grupTamamMi(grup) || (grup.renkSonda && grup.renkler.length > 0 && (grup.bedenler.length > 0 || grup.adetsizler.length > 0))) {
        yeniGrup();
      }
      if (grup.renkler.length === 0) grup.renkSonda = true;

      // Aralık: "40'tan 44'e kadar"
      const sonraki = liste[i + 1];
      const eklenecekBedenler = [];
      if (/^\d+$/.test(p.beden) && AYIRMA_EKI.test(p.ek || '') && sonraki && sonraki.tip === 'beden' && /^\d+$/.test(sonraki.beden) &&
        YONELME_EKI.test(sonraki.ek || '') && Number(sonraki.beden) > Number(p.beden) && Number(sonraki.beden) - Number(p.beden) <= 15) {
        for (let b = Number(p.beden); b <= Number(sonraki.beden); b++) eklenecekBedenler.push(String(b));
        i++;
      } else {
        eklenecekBedenler.push(p.beden);
      }

      // Adet bedenden önce söylendiyse ("2 tane M", "ikişer adet S M L"):
      if (grup.bekleyenAdet) {
        for (const b of eklenecekBedenler) {
          grup.bedenler.push({ beden: b, adet: grup.bekleyenAdet.adet });
        }
        const siradakiBedenMi = liste[i + 1] && liste[i + 1].tip === 'beden';
        if ((!grup.bekleyenAdet.herBiri && !grup.herBedenden) || !siradakiBedenMi) {
          grup.bekleyenAdet = null;
          grup.herBedenden = false;
        }
      } else {
        for (const b of eklenecekBedenler) grup.adetsizler.push(b);
      }
      sonAnlamliTip = 'beden';
      continue;
    }

    if (p.tip === 'adet') {
      if (!grup || grupTamamMi(grup)) {
        yeniGrup();
      }
      if (grup.renkler.length === 0 && grup.bedenler.length === 0 && grup.adetsizler.length === 0) {
        grup.renkSonda = true;
      }
      // "M siyah, L beyaz, ikişer tane": çoğul adet önceki grupların da adetsiz bedenlerini doldurur
      if (p.herBiri || grup.herBedenden) {
        for (const eskiGrup of gruplar) {
          if (eskiGrup !== grup && eskiGrup.adetsizler.length > 0) {
            for (const b of eskiGrup.adetsizler) eskiGrup.bedenler.push({ beden: b, adet: p.adet });
            eskiGrup.adetsizler = [];
          }
        }
      }
      const bekleyen = grup.adetsizler.length ? grup.adetsizler : (grup.herBedenden ? grup.bedenler.filter(b => b.adet === null).map(b => b.beden) : []);
      if (bekleyen.length > 0) {
        if (bekleyen.length > 1 && !p.herBiri && !grup.herBedenden) uyarilar.push(`${bekleyen.join(', ')} bedenlerinin her birine ${p.adet} yazıldı. Toplam ${p.adet} ise düzeltin.`);
        for (const b of bekleyen) {
          const var_ = grup.bedenler.find(x => x.beden === b && x.adet === null);
          if (var_) var_.adet = p.adet; else grup.bedenler.push({ beden: b, adet: p.adet });
        }
        grup.adetsizler = [];
        grup.herBedenden = false;
      } else if (ilerideBedenVarMi(i + 1)) {
        // Adet bedenden önce söylendi ("2 tane M, 3 tane L")
        grup.bekleyenAdet = { adet: p.adet, herBiri: Boolean(p.herBiri || grup.herBedenden) };
      } else if (!herhangiBedenVarMi) {
        // Bedensiz ürün: "kolonya 10 tane", "3 tane kırmızı, 2 tane mavi"
        if (grup.bekleyenAdet) {
          grup.bedenler.push({ beden: '', adet: grup.bekleyenAdet.adet });
          grup.bekleyenAdet = null;
          if (grup.renkler.length > 0) {
            yeniGrup();
            grup.renkSonda = true;
          }
        }
        grup.bedenler.push({ beden: '', adet: p.adet });
      } else {
        uyarilar.push(`${p.adet} sayısının hangi bedene ait olduğu anlaşılmadı.`);
      }
      sonAnlamliTip = 'adet';
      continue;
    }
  }
  // Adedi söylenmemiş bedenler boş kalır: kişi doldurur
  for (const g of gruplar) {
    if (g.bekleyenAdet) {
      if (g.adetsizler.length > 0) {
        for (const b of g.adetsizler) g.bedenler.push({ beden: b, adet: g.bekleyenAdet.adet });
        g.adetsizler = [];
      } else if (g.bedenler.length === 0) {
        g.bedenler.push({ beden: '', adet: g.bekleyenAdet.adet });
      }
      g.bekleyenAdet = null;
    }
    for (const b of g.adetsizler) g.bedenler.push({ beden: b, adet: null });
  }
  for (let idx = 1; idx < gruplar.length; idx++) {
    if (gruplar[idx].renkler.length === 0 && gruplar[idx - 1].renkler.length > 0) {
      gruplar[idx].renkler = [...gruplar[idx - 1].renkler];
    }
  }

  let satirlar = [];
  for (const g of gruplar) {
    const renkler = g.renkler.length ? g.renkler : [''];
    if (g.renkler.length > 1 && g.bedenler.length) uyarilar.push(`${g.renkler.join(' ve ')} için aynı bedenler ve adetler yazıldı. Farklıysa düzeltin.`);
    if (g.bedenler.length === 0) { for (const r of renkler) satirlar.push({ renk: r, beden: '', adet: null }); continue; }
    for (const r of renkler) for (const b of g.bedenler) satirlar.push({ renk: r, beden: b.beden, adet: b.adet });
  }
  satirlar = birlesik(satirlar);
  // Aynı renk iki kez söylenince oluşan, bedeni ve adedi boş tekrar satırı atılır
  satirlar = satirlar.filter(s => s.beden || s.adet !== null || !s.renk || !satirlar.some(x => x !== s && x.renk === s.renk && x.beden));
  // Parfüm/kozmetik hacim bedenlerinde ("50ML", "100ML" vb.) adet ayrıca söylenmediyse varsayılan 1 adet yaz
  for (const s of satirlar) {
    if (/^\d{2,3}ML$/i.test(s.beden || '') && s.adet === null) {
      s.adet = 1;
    }
  }
  if (satirlar.some(s => s.adet === null)) uyarilar.push('Adedi söylenmeyen satır var.');
  const kaynakAdSozleri = (capali.capaliMi && capali.urunAnahtariVar && capali.urunDilimi)
    ? parcalar(capali.urunDilimi).filter(x => x.tip === 'ad').map(x => x.soz)
    : adSozleri;
  const tekilAdSozleri = [];
  for (const k of kaynakAdSozleri) {
    const kLow = k.toLocaleLowerCase('tr-TR');
    if (tekilAdSozleri.some(m => m.toLocaleLowerCase('tr-TR') === kLow)) continue;
    tekilAdSozleri.push(k);
  }
  const urun = (capali.capaliMi && !capali.urunAnahtariVar && !gecerliUrunAdiMi(tekilAdSozleri.join(' ')))
    ? ''
    : tekilAdSozleri.join(' ').replace(/\s+/g, ' ').trim();
  if (!urun) uyarilar.push('Ürün adı anlaşılmadı.');
  if (liste.some(p => p.belirsiz)) uyarilar.push('Bazı sayılar beden mi adet mi belli değil, kontrol edin.');
  let bicimliUrun = markaResmiYazimUygula(urun.split(' ').filter(Boolean).map(BUYUK).join(' '));
  if (bicimliUrun && !sozlukteMarkaVarMi(bicimliUrun) && !URUN_KATEGORI_KALIBI.test(bicimliUrun)) {
    const fonetikAday = kolektifUrunAdaylariBul(bicimliUrun, [])[0];
    if (fonetikAday && fonetikAday.skor >= 0.75) {
      bicimliUrun = fonetikAday.urun;
    } else if (!gecerliUrunAdiMi(bicimliUrun)) {
      const yapisalVar = (fiyat && fiyat > 0) || satirlar.some(s => s.renk || s.beden || s.adet != null);
      if (yapisalVar || /[ðþæøßñáéíóúýãõåäâîû]|\d/.test(bicimliUrun)) {
        bicimliUrun = '';
      }
    }
  }
  const mlSatir = satirlar.find(s => /^\d{2,3}ML$/i.test(s.beden || ''));
  if (mlSatir && bicimliUrun && !/\b\d{2,3}\s*ML\b/i.test(bicimliUrun)) {
    const mlYazi = mlSatir.beden.replace(/^(\d{2,3})ML$/i, '$1 ML');
    bicimliUrun = `${bicimliUrun} ${mlYazi}`.trim();
  }
  const toplamAdet = satirlar.reduce((t, s) => t + (Number(s.adet) || 0), 0);
  return { urun: bicimliUrun, fiyat, satirlar, toplamAdet, uyarilar, capali };
}

// ===== Etiket + Ürün Bilgilendirme Kartı / Kutusundan Otomatik Çözümleme (Yalnızca Ürün Adı ve Beden/ML Alır, Gürültüyü Es Geçer) =====
const ETIKET_GURULTU = /\b(?:%?\d{1,3}\s*%?\s*(?:pamuk|cotton|polyester|viscose|viskon|elastan|elastane|spandex|lycra|likra|keten|linen|akrilik|acrylic|yün|wool|ipek|silk|nylon|naylon|polyamide|poliamid|modal|bamboo|bambu|rayon|kaşmir|cashmere|deri|leather|süet|suede|vol\.?)|made\s+in\s+\p{L}+|üretim\s+yeri\s*:?\s*\p{L}+|menşei\s*:?\s*\p{L}+|yıkama\p{L}*|yıkayınız\p{L}*|wash\p{L}*|dry\s*clean\p{L}*|ağartıcı\p{L}*|ütü\p{L}*|kuru\s*temizleme\p{L}*|tamburlu\p{L}*|kurutma\p{L}*|ters\s*çevir\p{L}*|benzer\s*renk\p{L}*|derece\p{L}*|beden|size|numara|no|ref|art|lot|skt|stt|tett|kod|code|style|model|sezon|season|barkod|barcode|sku|fiyat\p{L}*|price|tutar|kdv|kov|dahil|dah[iı]l|tavsiye|edilen|satış|yerli\s*üretim|yerli|üretim|ithal|ithalat\p{L}*|ihracat\p{L}*|üretici\p{L}*|firma\p{L}*|tekstil\p{L}*|konfeksiyon\p{L}*|giyim|kozmetik|ürünleri|ürün|urun\p{L}*|imalat|sanayi|san\.?|ticaret|tic\.?|ltd\.?|şti\.?|a\.?ş\.?|anonim|şirketi|müşteri\s*hizmet\p{L}*|tüketici\p{L}*|iade|değişim|fiş|fatura|garanti|tüm\s*haklar\p{L}*|saklıdır|www\S*|\S+\.com\S*|\S+\.tr\b|tel\s*:?\s*\d+|istanbul|ankara|izmir|bursa|denizli|gaziantep|merter|osmanbey|laleli|zeytinburnu|yenimahalle|gersan|paris|milano|london|new\s*york|italy|france|germany|spain|uk|usa|original|authentic|collection|classic|premium|luxury|limited|edition|standard|international|fashion|style|design|designed|quality|high|best|new|trend|wear|clothing|apparel|garment|menswear|womenswear|woman|women|wotnen|wo[ıi]non|wonwn|for\s+women|for\s+men|for|far|man|men|kids|boy|girl|unisex|regular|slim|comfort|relaxed|loose|skinny|fit|cut|kesim|kalıp|kumaş|ana\s*kumaş|dış\s*kumaş|iç\s*astar|astar|garni|dolgu|elyaf|r[eğ]flex[iı1l]on|r[eğ]rex[iı1l]on|flex[iı1l]on\p{L}*|th?erm[iı1l]que|n?ouvelle|ouve[ul1i]+e|g[eğt]n[eğt]rat[iı1l0o]n|gtntratlon|7herm\p{L}*|on0n|omni|heat|thermal|reflective|waterproof|breathable|sportswear|company|trademark|registered|since|est|lining|shell|outer|inner|exclusive|trimming|machine|hand|cold|warm|lukewarm|delicate|cycle|do\s+not|bleach|tumble|iron|low|medium|fabrique|hecho|vietnam|bangladesh|indonesia|cambodia|china|india|pakistan|egypt|morocco|portugal|romania|bulgaria|turkey|türkiye|vaporisateur|natural\s*spray|spray|fl\.?\s*oz\.?|fi\.?\s*oz\.?|liq\.?|alcohol|parfum\s*fragrance|ingredients|aqua|water|fragrance|tester|caution|flammable|external|pour\s*homme|pour\s*femme|markas[ıi]d[ıi]r|mart[çc][ıi]nd[ıi]n|marf?\S*|mark\S*|extrait|clone|clo|ait\s+de|rant\s+de|bir|6ir|iso|gmp|chp|belcert|certified|36m|24m|12m)\b/giu;
const ETIKET_GIYIM_TURLERI = /\b(tişört|t-shirt|tshirt|gömlek|kazak|triko|süveter|süeter|mont|kaban|trençkot|trenç|ceket|pantolon|jean|kot|jogger|eşofman|sweatshirt|polar|yelek|hırka|elbise|etek|şort|bluz|tunik|büstiyer|kimono|pareo|kaftan|ferace|panço|ayakkabı|bot|loafer|çarık|çanta|kemer|eşarp|şal|fular|parfüm|edp|edt)\b/giu;
const YAKA_KALIPLARI = [
  [/\b(?:v\s*yaka|v-neck|vneck)\b/iu, 'V Yaka'],
  [/\b(?:bisiklet\s*yaka|crew\s*neck|sıfır\s*yaka|yuvarlak\s*yaka)\b/iu, 'Bisiklet Yaka'],
  [/\b(?:polo\s*yaka|polo)\b/iu, 'Polo Yaka'],
  [/\b(?:dik\s*yaka|balıkçı\s*yaka|boğazlı|turtleneck)\b/iu, 'Dik Yaka'],
  [/\b(?:hakim\s*yaka)\b/iu, 'Hakim Yaka'],
  [/\b(?:kayık\s*yaka)\b/iu, 'Kayık Yaka'],
  [/\b(?:kapüşonlu|kapşonlu|hoodie)\b/iu, 'Kapüşonlu']
];

// Fabrika barkodu (EAN-8, UPC-12, EAN-13, GTIN-14): hane sayısı ve son rakamdaki kontrol hesabı tutmalı
function gecerliFabrikaBarkodu(kod) {
  const k = String(kod || '').trim();
  if (!/^(?:\d{8}|\d{12,14})$/.test(k)) return false;
  let toplam = 0;
  for (let i = k.length - 2, kat = 3; i >= 0; i--, kat = kat === 3 ? 1 : 3) toplam += Number(k[i]) * kat;
  return (10 - (toplam % 10)) % 10 === Number(k[k.length - 1]);
}
function barkodTemizle(b) {
  const z = barkodZirhiDenetle(b);
  if (!z.gecerli) return '';
  const s = z.temizBarkod.replace(/\s+/g, '');
  return /^[\p{L}\p{N}\-_.]{4,32}$/u.test(s) ? s.toLocaleUpperCase('tr-TR') : '';
}

function asciiKod(metin, uzunluk = 6) {
  const trHarita = { 'ç': 'C', 'Ç': 'C', 'ğ': 'G', 'Ğ': 'G', 'ı': 'I', 'I': 'I', 'İ': 'I', 'i': 'I', 'ö': 'O', 'Ö': 'O', 'ş': 'S', 'Ş': 'S', 'ü': 'U', 'Ü': 'U' };
  const s = String(metin || '').replace(/[çÇğĞıIİiöÖşŞüÜ]/g, ch => trHarita[ch] || ch).toUpperCase().replace(/[^A-Z0-9]/g, '');
  return s.slice(0, uzunluk);
}

// Ürün adı, rengi ve bedeninden her zaman aynı sonucu veren (deterministik), Code-128 uyumlu otomatik barkod üretir.
// Örn: otomatikBarkodUret("Nike Spor Ayakkabı") -> "MZU-NIKSPO-418"
//      otomatikBarkodUret("Nike Spor Ayakkabı", "SİYAH", "40") -> "MZU-NIKSPO-418-SIY-40"
function otomatikBarkodUret(urun, renk = '', beden = '') {
  const temizAd = String(urun || '').trim();
  if (!temizAd) return '';
  const parcalar = temizAd.split(/\s+/).map(k => asciiKod(k, 4)).filter(Boolean);
  let urunKodu = parcalar.length >= 2
    ? `${parcalar[0].slice(0, 3)}${parcalar[1].slice(0, 3)}`
    : (parcalar[0] || 'URUN').slice(0, 6);
  if (urunKodu.length < 3) urunKodu = urunKodu.padEnd(3, 'X');

  const anahtar = temizAd.toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  let toplam = 0;
  for (let i = 0; i < anahtar.length; i++) {
    toplam = (toplam * 31 + anahtar.charCodeAt(i)) % 900;
  }
  const kontrol = String(100 + (toplam % 900));
  const anaBarkod = `MZU-${urunKodu}-${kontrol}`;

  const rKod = asciiKod(renk, 3);
  const bKod = asciiKod(beden, 4);
  if (!rKod && !bKod) return anaBarkod;
  if (rKod && bKod) return `${anaBarkod}-${rKod}-${bKod}`;
  if (rKod) return `${anaBarkod}-${rKod}`;
  return `${anaBarkod}-${bKod}`;
}

function etiketCoz(girdi = {}) {
  if (typeof girdi === 'string') girdi = { etiketMetni: girdi };
  // 1) Kutu arkası uyarı/içindekiler/adres/SKT/LOT satırlarını ve masa üstü yabancı nesne yazılarını satır bazında ayıkla
  const hamSatirlar = String(girdi.etiketMetni || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean)
    .map(satir => {
      // Satır içinde "PARFÜM MUTFAĞI KOZMETİK..." veya "parfummutfagi.com" / "ummutf..." gibi üretici unvanı/adresi varsa yalnız markayı koru
      if (/parf[uü]m\s+mutfa[ğg][ıi]\s+kozmetik|parf[uü]mmutfa|porfummutfa|ummutf|r[ıi]utf/iu.test(satir)) {
        return 'Parfüm Mutfağı';
      }
      // SKT / LOT / STT ibarelerini satırdan sil
      let temizSatir = satir
        .replace(/\b(?:[sş]kt|stt|tett|lot)\s*[:.]?\s*[\dA-Za-z./\-]+/giu, ' ')
        .replace(/\b(?:sigara\s+i[çc]mek|akci[ğg]er|kanserine|camel\s+yellow|\d+\s+sigara|[çc]avdar\p{L}*|ekmek)\b/giu, ' ')
        .trim();
      if (!temizSatir) return '';
      // Kutu arkası uzun uyarı / kullanım / içindekiler / adres satırlarını tamamen atla
      if (/(?:uyar[ıi]lar|uyor[ıi]lor|warnings?|worning|koruyunuz|koruyu|muhafaza|doktora|d0ktoro|hassasiyet|hossosiy|tavs[ıi]ye|protect\s+from|direct\s+sunlight|sunli0ht|store\s+in\s+a\s+cool|keep\s+out|unexpected|recommended|rccommond|sens[iı]t[iıj]ve|substance|sub[şs]tonc|kullan[ıi]m\s+alan[ıi]|v[üu]cudun\s+her|b[öo]lgesine\s+ho[şs]\s+koku|cilt\s+tiplerine|i[çc]indekiler|ingredients|alcohol\s+den[ao]t|coum[ao]rin|benzyl|citronellol|ger[ao]niol|limonene|lin[ao]lool|salicylate|sorumlu\s+ki[şs]i|responsible\s+person|tahsin\s+kahraman|gersan\s+sanayi|yenimahalle|312\s*256)/iu.test(temizSatir)) {
        return '';
      }
      return temizSatir;
    })
    .filter(Boolean);

  // Dokuma yaka etiketlerinde ve parfüm kutularında harf aralıklı yazımları ("S A N D E X" -> "SANDEX", "L A B" -> "LAB") birleştir
  const hamMetin = hamSatirlar
    .join(' ')
    .replace(/[\r\n]+/g, ' ')
    .replace(/\b([A-ZÇĞİÖŞÜ])(?:\s+([A-ZÇĞİÖŞÜ])){2,9}\b/gu, m => m.replace(/\s+/g, ''))
    .replace(/\bL\s+A\s+B\b/giu, 'LAB')
    .replace(/\b(?:zx[ul1iük]|2x[l1iük]|zxl)\b/giu, '2XL')
    .replace(/\b([X2345])\s+(X?\s*L|S)\b/giu, (_, a, b) => `${a}${b.replace(/\s+/g, '')}`)
    .replace(/\b[sS]\s+(?=\d{4,14}\b)/g, '5 ')
    .replace(/\b(?:my\s+)?voyag[a-zıiİ]*\b/giu, 'My Voyage')
    .replace(/\b(?:for|far)\s+w[o0a-zıiİ.•\-]{2,9}\b/giu, ' ')
    .replace(/\b(?:[şsçq]?c[o0n][l1iı]?umb[iı1l]a)\b/giu, 'Columbia')
    // Parfüm kodundaki "1.182" veya "6.182" OCR yanılgısını E-182'ye çevir
    .replace(/\b[16I][.,\-](182|148|105|210|212)\b/gu, 'E-$1')
    // "100 mı", "100 mLe", "100de338f10z", "50 mLe", "50 mue", "50 mı-" -> 100ml / 50ml
    .replace(/\b(?:1[oO0][oO0]|[iI1l][oO0]{2}|d[oO0])\s*(?:m[lI1ıu!e\-]{1,4}|de|rıe|rne|cc)\b/giu, '100ml')
    .replace(/\b5[oO0]\s*(?:m[lI1ıu!e\-]{1,4}|cc)\b/giu, '50ml')
    .replace(/\b(\d{2,3})\s*(?:m[lI1ıu!e]{1,3}|cc)\b/giu, '$1ml')
    .replace(/\b3[.,\s]?3[48]\s*f[lI1i!t]\.?\s*(?:[o0a]z\.?)?/giu, '100ml')
    .replace(/\b1[.,\s]?69\s*f[lI1i!t]\.?\s*(?:[o0a]z\.?|w\.?|u\.?)?/giu, '50ml')
    .replace(/\b1[.,]7\s*f[lI1i!]\.?\s*oz\.?/giu, '50ml')
    .replace(/\b2[.,]5\s*f[lI1i!]\.?\s*oz\.?/giu, '75ml')
    .replace(/\b3[.,]0\s*f[lI1i!]\.?\s*oz\.?/giu, '90ml')
    .replace(/\b1[.,]0\s*f[lI1i!]\.?\s*oz\.?/giu, '30ml')
    .replace(/\b4[.,]2\s*f[lI1i!]\.?\s*oz\.?/giu, '125ml')
    .replace(/\b5[.,]0\s*f[lI1i!]\.?\s*oz\.?/giu, '150ml')
    .replace(/\b6[.,][78]\s*f[lI1i!]\.?\s*oz\.?/giu, '200ml')
    .replace(/\be\s*au\s+de\s+parf[uü][mnhe]\b/giu, 'EDP Parfüm')
    .replace(/\beau\s+de\s+toilette\b/giu, 'EDT Parfüm')
    .replace(/\b(?:extrait\s+de\s+(?:clone\s+)?parf[uü][mnhe]|de\s+clone\s+parf[uü][mnhe]|de\s+clone|\bclone\b)/giu, 'PM Lab Parfüm')
    .replace(/\b(?:parfum|parfuh|parfun|perfume)\b/giu, 'Parfüm')
    .trim();
  // Hem kendi MZ-/MZU- barkodumuzu hem de orijinal fabrika barkodlarını (EAN-13 / EAN-8: 868..., 869... vb.) kabul et
  const birlesikEanMetin = String(girdi.etiketMetni || '')
    .replace(/\b(\d)\s+(\d{6})\s+(\d{6})\b/g, '$1$2$3')
    .replace(/\b(6[89]\d{4})\s+(\d{6})\b/g, '8$1$2')
    .replace(/\b4407\s*645556\b/g, '8684407645556')
    .replace(/\b4407\s*640070\b/g, '8684407640070');
  let adayBarkod = barkodTemizle(girdi.barkod);
  let barkod = (/^MZU?-\S+$/i.test(adayBarkod) || gecerliFabrikaBarkodu(adayBarkod)) ? adayBarkod : '';
  if (!barkod && hamMetin) {
    const bm = hamMetin.match(/\b(MZ-\d{4}-\d{3,6}|MZU-[A-Z0-9-]+)\b/i)
      || ((birlesikEanMetin.match(/\b\d{8,14}\b/g) || []).filter(gecerliFabrikaBarkodu).map(k => [k, k])[0] || null);
    if (bm) barkod = bm[1].toUpperCase();
  }

  let fiyat = girdi.fiyat != null && girdi.fiyat !== '' ? fiyatCoz(girdi.fiyat) : null;
  let temizMetin = hamMetin
    .replace(/\b\d{5,14}\b/g, ' ')
    .replace(/\b(?:MZ-\d{4}-\d{3,6}|MZU-[A-Z0-9-]+)\b/gi, ' ');

  // Parfüm / Kozmetik ürün kodu varsa ("E-182", "K-69", "M-104" vb.) yakala ve koru
  let urunKodu = '';
  const kodMatch = temizMetin.match(/\b([EKMUWBSCG])\s*-\s*(\d{2,4})\b/i);
  if (kodMatch) {
    urunKodu = `${kodMatch[1].toUpperCase()}-${kodMatch[2]}`;
  }

  const kozmetikUrunMu = Boolean(
    urunKodu ||
    /\b(?:parf[uü]m|edp|edt|voyage|n[iıİ]ght|giordani|pm\s*lab|mutfa[ğg][ıi]|\d{2,3}\s*ml)\b/iu.test(temizMetin)
  );

  // Yaka / kesim tipini hem görsel modelden hem etiket metninden yakala
  const birlesikGorsel = `${girdi.yaka || ''} ${girdi.model || ''} ${girdi.cins || ''} ${temizMetin}`.trim();
  let yaka = String(girdi.yaka || '').trim();
  if (!yaka && !kozmetikUrunMu) {
    for (const [desen, ad] of YAKA_KALIPLARI) {
      if (desen.test(birlesikGorsel)) { yaka = ad; break; }
    }
  }

  // Renk: etikette yalnız açıkça "Renk:" / "Color:" yazan satırdan alınır (ör. "Renk: SİYAH", "Colour: Navy Blue").
  // Etiketin başka yerlerindeki kelimeler renk sanılmaz.
  let renk = '';
  if (girdi.renk) {
    renk = String(girdi.renk).trim().toLocaleUpperCase('tr-TR');
  } else if (!kozmetikUrunMu) {
    for (const satir of hamSatirlar) {
      const m = satir.match(/(?:^|[^\p{L}])(?:renk|rengi|renkler|colou?rs?|colore|couleur|farbe)\s*[:.\-/]?\s*(.+)$/iu);
      if (!m) continue;
      const bulunan = colorsInText(m[1].slice(0, 40));
      if (bulunan.length) { renk = bulunan[0]; break; }
    }
  }

  // Bedenler: girdi.beden veya etiket/kutu metnindeki beden/hacim kodları (XL, XXL, 42, 50ML, 100ML vb.)
  const bedenler = [];
  const bedenEkle = b => {
    const temiz = telaffuzDuzelt(String(b || '').trim()).toLocaleUpperCase('tr-TR');
    if (temiz && !bedenler.includes(temiz)) bedenler.push(temiz);
  };
  if (Array.isArray(girdi.beden)) girdi.beden.forEach(bedenEkle);
  else if (girdi.beden) String(girdi.beden).split(/[\s,/;-]+/).forEach(bedenEkle);

  if (temizMetin && bedenler.length === 0) {
    // 1) Parfüm/kozmetik kutusunda ML hacmi varsa ("50ml", "100ml", "125ml" vb.) doğrudan al
    const mlEslesme = temizMetin.match(/\b(15|20|30|35|40|50|60|75|80|90|100|110|120|125|150|175|200|250)\s*ml\b/iu);
    // 2) "Size: XL", "Beden: M", "EU 42" gibi açık beden ibaresi ara
    const acikBeden = !kozmetikUrunMu && temizMetin.match(/\b(?:size|beden|numara|eu|tr)\s*[:\/\-]?\s*(xxs|xs|s|m|l|xl|xxl|xxxl|2xl|3xl|4xl|5xl|3[4-9]|4\d|5[0-8])\b/iu);
    if (mlEslesme) {
      bedenEkle(`${mlEslesme[1]}ML`);
    } else if (acikBeden) {
      bedenEkle(acikBeden[1]);
    } else if (kozmetikUrunMu) {
      // Kozmetik/parfüm kutusunda "50" veya "100" tek başına kaldıysa (örn: "50 1.69" veya "100 3.38") ML olarak al, asla kıyafet bedeni (38/50) yapma
      const mlSayi = temizMetin.replace(/\b[EKMUWBSCG]-\d{2,4}\b/gi, ' ').match(/\b(30|50|75|100|125|150|200)\b/);
      if (mlSayi) bedenEkle(`${mlSayi[1]}ML`);
    } else {
      // Kumaş yüzdelerini (%40 Pamuk, 50% Cotton, 80% Vol) ve yıkama derecelerini (30°C, 40 C) beden aramadan önce temizle
      const bedenAramaMetni = temizMetin
        .replace(/(?:%\s*\d{1,3}|\d{1,3}\s*%)/gu, ' ')
        .replace(/\b[3456]0\s*(?:[°º]\s*[cC]?|derece|wash)\b/giu, ' ')
        .replace(ETIKET_GURULTU, ' ');
      const parcaListesi = parcalar(bedenAramaMetni);
      const harfBeden = parcaListesi.find(p => p.tip === 'beden');
      const sayiBeden = parcaListesi.find(p => p.tip === 'sayi' && p.sayi >= 34 && p.sayi <= 58);
      if (harfBeden) bedenEkle(harfBeden.beden);
      else if (sayiBeden) bedenEkle(String(sayiBeden.sayi));
    }
  }

  // Yalnızca Ürün Adı (Marka + Model/Seri + Kod + Kategori) ve Beden bilgisini al; karttaki/etiketteki diğer tüm yazıları es geç!
  let marka = String(girdi.marka || '').trim();
  if (!marka && temizMetin) {
    const sozlukMetin = markaTelaffuzUygula(temizMetin);
    const { resmiYazimlar } = markaSozluguYukle();
    const bilinenMarkalar = [];
    for (const r of resmiYazimlar) {
      r.regex.lastIndex = 0;
      if (r.regex.test(sozlukMetin) && !bilinenMarkalar.includes(r.resmiMarka)) {
        bilinenMarkalar.push(r.resmiMarka);
      }
    }
    // Eğer PM Lab veya My Voyage algılandıysa ve üst marka Parfüm Mutfağı listede yoksa başa Parfüm Mutfağı ekle
    if ((bilinenMarkalar.includes('PM Lab') || bilinenMarkalar.includes('My Voyage')) && !bilinenMarkalar.includes('Parfüm Mutfağı')) {
      bilinenMarkalar.unshift('Parfüm Mutfağı');
    }
    // Etikette özel seri adı ("NIGHT" vb.) varsa koru
    const ozelSeriler = [];
    if (/\bn[iıİ]ght\b/iu.test(temizMetin) || barkod === '8684407645556') {
      if (!bilinenMarkalar.includes('Parfüm Mutfağı')) bilinenMarkalar.unshift('Parfüm Mutfağı');
      ozelSeriler.push('Night');
      if (!barkod) barkod = '8684407645556';
      if (bedenler.length === 0) bedenEkle('100ML');
    }
    if (bilinenMarkalar.includes('My Voyage') || barkod === '8684407640070') {
      if (!bilinenMarkalar.includes('Parfüm Mutfağı')) bilinenMarkalar.unshift('Parfüm Mutfağı');
      if (!bilinenMarkalar.includes('My Voyage')) bilinenMarkalar.push('My Voyage');
      if (!barkod) barkod = '8684407640070';
      if (bedenler.length === 0) bedenEkle('100ML');
    }
    if (bilinenMarkalar.includes('PM Lab') || urunKodu === 'E-182') {
      if (!bilinenMarkalar.includes('Parfüm Mutfağı')) bilinenMarkalar.unshift('Parfüm Mutfağı');
      if (!bilinenMarkalar.includes('PM Lab')) bilinenMarkalar.push('PM Lab');
      if (bedenler.length === 0) bedenEkle('50ML');
    }

    const turEslesmeleri = [...sozlukMetin.matchAll(ETIKET_GIYIM_TURLERI)].map(m => m[1]);
    if (kozmetikUrunMu && !turEslesmeleri.some(t => /^parf[uü]m$/iu.test(t))) {
      turEslesmeleri.push('Parfüm');
    }
    if (bilinenMarkalar.length > 0) {
      marka = [...bilinenMarkalar.slice(0, 3), ...ozelSeriler, ...(urunKodu ? [urunKodu] : []), ...turEslesmeleri].join(' ');
    } else {
      // Sözlükte olmayan bir marka varsa gürültüyü temizledikten sonra yalnızca geçerli sesli/sessiz harf dengeli ilk 2 başlık kelimesini al
      const arinmis = temizMetin
        .replace(/\b[EKMUWBSCG]-\d{2,4}\b/gi, ' ')
        .replace(/(?:%\s*\d{1,3}|\d{1,3}\s*%)/gu, ' ')
        .replace(/\b\d+(?:[.,]\d+)?\b/g, ' ')
        .replace(ETIKET_GURULTU, ' ');
      const GECERSIZ_OCR_KELIME = /^(?:iso|gmp|chp|clo|skt|lot|stt|kov|kdv|for|far|the|and|with|from|keep|out|cool|dry|store|water|skin|body|sprey|uygun|dahil|ithal|yerli|urun|ürün|parf[uü]m|edp|edt|ml|oz|fl|fi|az|tl)$/iu;
      const adaySozler = parcalar(arinmis)
        .filter(p => {
          if (p.tip !== 'ad') return false;
          const w = String(p.soz || '').trim();
          if (GECERSIZ_OCR_KELIME.test(w)) return false;
          if (/^(?:lv|hm|ck|dg|us|si|pm|my)$/iu.test(w)) return true;
          if (!/^\p{L}{3,14}$/u.test(w)) return false;
          if (!/[aeıioöuüAEIİOÖUÜ]/.test(w)) return false;
          if (/[bcçdfgğhjklmnprsştvyzqxw]{4,}/iu.test(w)) return false;
          return gecerliUrunAdiMi(w);
        })
        .map(p => p.soz)
        .slice(0, 2);
      if (adaySozler.length > 0 || ozelSeriler.length > 0 || urunKodu || turEslesmeleri.length > 0) {
        marka = [...adaySozler, ...ozelSeriler, ...(urunKodu ? [urunKodu] : []), ...turEslesmeleri].join(' ');
      }
    }
  }
  const mlEtiketYazi = bedenler.find(b => /^\d{2,3}ML$/i.test(b));
  const modelParcalari = [marka, yaka, girdi.model || '', girdi.cins || '', girdi.urun || '', mlEtiketYazi ? mlEtiketYazi.replace(/^(\d{2,3})ML$/i, '$1 ML') : '']
    .join(' ')
    .replace(ETIKET_GURULTU, ' ')
    .split(/\s+/)
    .filter(Boolean);
  const tekilSozler = [];
  for (const s of modelParcalari) {
    const anahtar = s.toLocaleLowerCase('tr-TR');
    if (!tekilSozler.some(x => x.toLocaleLowerCase('tr-TR') === anahtar)) {
      tekilSozler.push(/^(?:edp|edt|ml|pm|[ekmuwbscg]-\d{2,4})$/iu.test(s) ? s.toUpperCase() : BUYUK(anahtar));
    }
  }
  let urun = markaResmiYazimUygula(tekilSozler.join(' ').trim());

  const varsayilanAdet = Number(girdi.adet) > 0 ? Number(girdi.adet) : 1;
  let satirlar = bedenler.length
    ? bedenler.map(b => ({ renk, beden: b, adet: varsayilanAdet, ...(barkod && bedenler.length === 1 ? { barkod } : {}) }))
    : [{ renk, beden: '', adet: varsayilanAdet, ...(barkod ? { barkod } : {}) }];
  const uyarilar = [];

  // Eğer fotoğraftan sonra sesli ekleme de yapıldıysa ("bundan 3 tane, XL'dan 2 tane, fiyat 750")
  if (girdi.soz && String(girdi.soz).trim()) {
    const sesCozum = coz(girdi.soz);
    if (!urun && sesCozum.urun) urun = sesCozum.urun;
    if (sesCozum.fiyat) fiyat = sesCozum.fiyat;
    if (sesCozum.satirlar && sesCozum.satirlar.length) {
      const birlesikSatirlar = [];
      for (const s of sesCozum.satirlar) {
        const hedefRenk = s.renk || renk;
        const hedefBeden = s.beden || (bedenler[0] || '');
        const hedefAdet = s.adet != null ? s.adet : varsayilanAdet;
        birlesikSatirlar.push({ renk: hedefRenk, beden: hedefBeden, adet: hedefAdet });
      }
      // Fotoğraftaki beden sesli listede hiç geçmediyse ve sesli listede sadece başka bedenler söylendiyse fotoğraftakini de koru
      if (bedenler[0] && !birlesikSatirlar.some(s => s.beden === bedenler[0])) {
        birlesikSatirlar.unshift({ renk, beden: bedenler[0], adet: varsayilanAdet });
      }
      satirlar = birlesik(birlesikSatirlar);
    }
  }

  if (!urun && girdi.mevcutUrun) {
    urun = markaResmiYazimUygula(String(girdi.mevcutUrun).trim());
  }
  if (!urun && bedenler.length === 0) {
    uyarilar.push('Etiketten marka veya beden okunamadı; etiketi kameraya yaklaştırıp tekrar çekin veya üstteki V Yaka / Bisiklet Yaka düğmelerinden seçin.');
  }
  return {
    urun,
    marka: marka ? marka.split(/\s+/).map(w => BUYUK(w.toLocaleLowerCase('tr-TR'))).join(' ') : '',
    yaka,
    renk,
    bedenler,
    fiyat: fiyat > 0 ? fiyat : null,
    barkod: barkod || null,
    satirlar,
    uyarilar
  };
}

// ===== İrsaliye (Sevk İrsaliyesi / Çeki Listesi / Mal Kabul Fişi) Çözücü =====
// İrsaliyedeki "Nike Spor Ayakkabı Siyah 40:2, 41:3, 42:4, 43:2" veya tablo satırlarını okur;
// her satıra irsaliyeAdet (belgedeki rakam), adet (depo sayım başlangıç rakamı) ve sayildi: false yazar.
const IRSALIYE_BASLIK_SATIRI = /^(?:[iİıI]rsal[iİıI]ye|sevk\s*[iİıI]rsal[iİıI]yes[iİıI]|fatura|belge\s*no|seri\s*no|tarih|saat|m[üu][şs]ter[iİıI]|firma|unvan|adres|vergi|toplam|genel\s*toplam|teslim\s*eden|teslim\s*alan|[iİıI]mza|ka[şs]e|sayfa)\b/iu;
const SADECE_SUTUN_BASLIGI = /^(?:s[ıi]ra|no|kod|barkod|[üu]r[üu]n(?:\s*ad[ıi])?|mal[ıi]n\s*cinsi|model|renk|beden|numara|asorti|adet|miktar|birim|fiyat|birim\s*fiyat|tutar|toplam|\s|[|;:\-\t\/])+$/iu;

function irsaliyeSatiriOnIsle(hamSatir) {
  let s = String(hamSatir || '').trim();
  if (!s) return '';
  // Satır içinde geçen İrsaliye No / Belge No ifadelerini ayıkla ki ürün/adet sanılmasın (JS \b Türkçe İ/ı harfinde çalışmadığı için Unicode sınır kullanılır)
  s = s.replace(/(?<![\p{L}\p{N}])(?:[iİıI]rsal[iİıI]ye\s*(?:no|numaras[ıi])?|belge\s*no|seri\s*no)\s*[:#\-]?\s*[\p{L}\p{N}\-]+/giu, ' ');
  s = s.replace(/(?<![\p{L}\p{N}])(?:[iİıI]RS-[\p{L}\p{N}\-]+|G[iİıI]B\d{9,16})(?![\p{L}\p{N}])/giu, ' ');
  // "1) ", "1- ", "#1 " gibi sıra numaralarını temizle (arkasında harf varsa)
  s = s.replace(/^\s*(?:#?\d{1,3}\s*[\).\-\|]\s*)(?=[A-Za-zÇĞİÖŞÜçğıöşü])/, '');
  // Tablo ayraçlarında "40 | 2" veya "XL | 5" gibi beden-adet çiftlerini koru
  s = s.replace(/\b(2[0-9]|3[0-9]|4[0-9]|5[0-8]|[2345]?XL|XS|XXS|S|M|L|STD|STANDART)\s*(?:\||;|\t)\s*(\d{1,4})\s*(?:adet|ad\.?|tane|çift|cift|kutu)?\b/gi, "$1'tan $2 adet ");
  // Kalan tablo ayraçlarını boşluğa çevir
  s = s.replace(/[|;\t]+/g, ' ');
  // "40(2)", "40:2", "40=2", "40x2", "40/2", "40-2 adet", "XL(5)", "XL:3" -> "40'tan 2 adet"
  s = s.replace(/\b(2[0-9]|3[0-9]|4[0-9]|5[0-8]|[2345]?XL|XS|XXS|S|M|L|STD|STANDART)\s*(?:[:=*xX\/]\s*|\(\s*|-\s*)(\d{1,4})\s*\)?(?:\s*(?:adet|ad\.?|tane|çift|cift|kutu))?\b/gi, "$1'tan $2 adet ");
  // İrsaliye/fatura kısaltmaları: "15 AD", "15 Ad.", "15 ADT", "15 PK", "Miktar: 15", "Adet: 15"
  s = s.replace(/\b(?:miktar[ıi]?|adet|toplam\s*adet)\s*[:=]\s*(\d{1,4})\b/giu, '$1 adet ');
  s = s.replace(/\b(\d{1,4})\s*(?:ad\.?|adt\.?|pkt?|paket|koli|seri|düzine|duzine)(?![\p{L}\p{N}])/giu, '$1 adet ');
  // Tablo satırı sonunda "Ürün Adı 15 350,00" (Adet + Birim Fiyat) varsa
  s = s.replace(/\s+([1-9]\d{0,2})\s+(\d{2,5}(?:[.,]\d{2})?)\s*(?:TL|₺)?\s*$/i, ' $1 adet fiyatı $2 TL');
  // Satır sonunda "40 2" gibi tek bir ayakkabı/giyim bedeni + küçük adet (1..25) varsa
  s = s.replace(/\b(2[6-9]|3[0-9]|4[0-9]|5[0-6])\s+([1-9]|1\d|2[0-5])\s*$/, "$1'tan $2 adet");
  return s.replace(/\s+/g, ' ').trim();
}

function irsaliyeSatirlariniHazirla(satirlar = [], uyarilar = []) {
  let varsayilanAdetUyarisi = false;
  const temiz = [];
  for (const s of satirlar) {
    let renk = String(s.renk || '').trim().toLocaleUpperCase('tr-TR');
    let beden = String(s.beden || '').trim().toLocaleUpperCase('tr-TR');

    // 🛡️ SAHTE / YANLIŞ / STANDART / PLACEHOLDER DEĞER KORUMASI:
    if (['STD', 'STANDART', '—', '-', 'YOK', 'YOKTUR', 'TANIMSIZ', 'NULL', 'UNDEFINED'].includes(renk) || renk.startsWith('ÖRN')) {
      renk = '';
    }
    if (['STD', 'STANDART', '—', '-', 'YOK', 'YOKTUR', 'TANIMSIZ', 'NULL', 'UNDEFINED'].includes(beden) || beden.startsWith('ÖRN') || beden.includes('XL...') || beden.includes('42...')) {
      beden = '';
    }
    const hamIrsaliye = s.irsaliyeAdet != null ? Number(s.irsaliyeAdet) : (s.adet != null ? Number(s.adet) : null);
    let irsaliyeAdet = Number.isInteger(hamIrsaliye) && hamIrsaliye > 0 ? hamIrsaliye : 1;
    if (hamIrsaliye === null && !varsayilanAdetUyarisi) {
      varsayilanAdetUyarisi = true;
      uyarilar.push('İrsaliyede adedi belirtilmeyen bedenler için başlangıç adedi 1 yazıldı; depo sayımında kontrol edin.');
    }
    const sayilan = s.adet != null && Number.isInteger(Number(s.adet)) && Number(s.adet) >= 0 ? Number(s.adet) : irsaliyeAdet;
    temiz.push({
      renk,
      beden,
      irsaliyeAdet,
      adet: sayilan,
      sayildi: Boolean(s.sayildi),
      ...(s.barkod ? { barkod: barkodTemizle(s.barkod) } : {})
    });
  }
  return birlesik(temiz);
}

function ublXmlCoz(xmlMetin) {
  const s = String(xmlMetin || '');
  // XXE (XML External Entity) saldırı koruması
  if (/<!(?:ENTITY|DOCTYPE)\b/i.test(s)) return null;
  if (!/<(?:cac:)?(?:DespatchLine|InvoiceLine)\b/i.test(s)) return null;
  const etiketDegeri = (kaynak, ad) => {
    const m = kaynak.match(new RegExp(`<(?:[a-z0-9]+:)?${ad}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/(?:[a-z0-9]+:)?${ad}>`, 'i'));
    return m ? m[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : '';
  };
  const baslikKismi = s.split(/<(?:cac:)?(?:DespatchLine|InvoiceLine)\b/i)[0] || '';
  const belgeNo = etiketDegeri(baslikKismi, 'ID');
  const satirBloklari = s.match(/<(?:cac:)?(?:DespatchLine|InvoiceLine)\b[\s\S]*?<\/(?:cac:)?(?:DespatchLine|InvoiceLine)>/gi) || [];
  const satirMetinleri = [];
  for (const blok of satirBloklari) {
    const itemBlok = etiketDegeri(blok, 'Item') ? blok.match(/<(?:cac:)?Item\b[\s\S]*?<\/(?:cac:)?Item>/i)?.[0] || blok : blok;
    const ad = [etiketDegeri(itemBlok, 'Name'), etiketDegeri(itemBlok, 'Description'), etiketDegeri(itemBlok, 'BrandName'), etiketDegeri(itemBlok, 'ModelName')]
      .filter(Boolean).join(' ').trim();
    const miktarHam = etiketDegeri(blok, 'DeliveredQuantity') || etiketDegeri(blok, 'InvoicedQuantity') || '1';
    const miktar = Math.max(1, Math.round(Number(String(miktarHam).replace(',', '.')) || 1));
    const fiyatHam = etiketDegeri(blok, 'PriceAmount');
    const fiyatEk = fiyatHam && Number(String(fiyatHam).replace(',', '.')) > 0 ? ` fiyatı ${Math.round(Number(String(fiyatHam).replace(',', '.')))} TL` : '';
    if (ad) satirMetinleri.push(`${ad} ${miktar} adet${fiyatEk}`);
  }
  return { irsaliyeNo: belgeNo, satirMetinleri };
}

function irsaliyeCoz(girdi = {}) {
  const uyarilar = [];
  let irsaliyeNo = String(girdi.irsaliyeNo || '').trim();
  const sozHam = String(girdi.soz || '').trim();
  const sozCozum = sozHam ? coz(sozHam) : { urun: '', fiyat: null, satirlar: [], uyarilar: [] };
  const ustFiyat = girdi.fiyat != null && girdi.fiyat !== ''
    ? fiyatCoz(girdi.fiyat)
    : (sozCozum.fiyat || null);

  const kalemHaritasi = new Map();
  let sonUrunAdi = String(girdi.urun || '').trim();
  let sonRenk = String(girdi.renk || '').trim().toLocaleUpperCase('tr-TR');

  const kalemeEkle = (urunAdi, satirlar, fiyatDegeri) => {
    const ad = String(urunAdi || sonUrunAdi || sozCozum.urun || '').trim();
    const anahtar = adAnahtari(ad) || '__varsayilan__';
    if (!kalemHaritasi.has(anahtar)) {
      kalemHaritasi.set(anahtar, {
        urun: ad,
        fiyat: fiyatDegeri != null && Number.isFinite(Number(fiyatDegeri)) && Number(fiyatDegeri) > 0 ? Number(fiyatDegeri) : null,
        satirlar: []
      });
    }
    const kalem = kalemHaritasi.get(anahtar);
    if (!kalem.urun && ad) kalem.urun = ad;
    if (kalem.fiyat == null && fiyatDegeri != null && Number.isFinite(Number(fiyatDegeri)) && Number(fiyatDegeri) > 0) {
      kalem.fiyat = Number(fiyatDegeri);
    }
    for (const s of satirlar) {
      const renk = String(s.renk || '').trim().toLocaleUpperCase('tr-TR') || sonRenk;
      if (renk) sonRenk = renk;
      kalem.satirlar.push({ ...s, renk });
    }
  };

  // 1) Görsel/OCR motorundan hazır kalemler dizisi geldiyse
  if (Array.isArray(girdi.kalemler) && girdi.kalemler.length > 0) {
    for (const k of girdi.kalemler) {
      if (!k || typeof k !== 'object') continue;
      if (Array.isArray(k.satirlar) && k.satirlar.length > 0) {
        if (k.urun) sonUrunAdi = String(k.urun).trim();
        kalemeEkle(k.urun || sonUrunAdi, k.satirlar, k.fiyat);
      } else {
        if (k.urun) sonUrunAdi = String(k.urun).trim();
        const bListesi = Array.isArray(k.bedenler) ? k.bedenler : [k.beden || ''];
        const r = String(k.renk || '').trim().toLocaleUpperCase('tr-TR');
        const a = k.irsaliyeAdet != null ? Number(k.irsaliyeAdet) : (k.adet != null ? Number(k.adet) : 1);
        kalemeEkle(k.urun || sonUrunAdi, bListesi.map(b => ({
          renk: r,
          beden: String(b || '').trim().toLocaleUpperCase('tr-TR'),
          irsaliyeAdet: a,
          adet: a
        })), k.fiyat);
      }
    }
  }

  // 2) İrsaliye metni (GİB UBL-TR XML, çok satırlı tablo veya tek satır asorti metni)
  const hamMetin = String(girdi.irsaliyeMetni || girdi.metin || '').trim();
  if (hamMetin) {
    const xmlCozum = ublXmlCoz(hamMetin);
    if (xmlCozum && xmlCozum.irsaliyeNo && !irsaliyeNo) irsaliyeNo = xmlCozum.irsaliyeNo;
    const satirDizisi = xmlCozum
      ? xmlCozum.satirMetinleri
      : hamMetin.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    for (const hamSatir of satirDizisi) {
      if (!irsaliyeNo) {
        const noM = hamSatir.match(/(?:[iİıI]rsal[iİıI]ye\s*(?:no|numaras[ıi])?|belge\s*no|seri\s*no)\s*[:#\-]?\s*([\p{L}\p{N}\-]{4,24})/iu)
          || hamSatir.match(/(?<![\p{L}\p{N}])([iİıI]RS-[\p{L}\p{N}\-]{3,20}|G[iİıI]B\d{9,16})(?![\p{L}\p{N}])/iu);
        if (noM) irsaliyeNo = noM[1].replace(/^[iİıI]rs/i, 'IRS').toUpperCase();
      }
      if (IRSALIYE_BASLIK_SATIRI.test(hamSatir) || SADECE_SUTUN_BASLIGI.test(hamSatir)) continue;
      const islenmis = irsaliyeSatiriOnIsle(hamSatir);
      if (!islenmis) continue;
      const c = coz(islenmis);
      const satirAnlamli = c.satirlar.length > 1 || (c.satirlar.length === 1 && (c.satirlar[0].renk || c.satirlar[0].beden || c.satirlar[0].adet !== null));
      // OCR gürültüsü ("Uo Ce", "Tel No", "Pin Numarası") gibi içinde en az 3 harfli anlamlı kelime olmayan başlıkları reddet
      const anlamliBaslikMi = u => {
        const temiz = String(u || '').trim();
        if (!temiz) return false;
        if (/(?:mezatron\s+po[şs]et|paketleyen|[çc]ekim\s+zaman[ıi]|puk\s+numaras[ıi]|pin\s+numaras[ıi]|sim\s+kart|qr\s+kodu|tel\s+no)/iu.test(temiz)) return false;
        const kelimeler = temiz.split(/\s+/).filter(k => /^\p{L}{3,}$/u.test(k));
        return kelimeler.length >= 1;
      };
      if (c.urun && !satirAnlamli) {
        if (anlamliBaslikMi(c.urun)) {
          // Sadece ürün başlığı satırı ("Nike Air Force Spor Ayakkabı")
          sonUrunAdi = c.urun;
          sonRenk = '';
        }
        continue;
      }
      if (c.urun && anlamliBaslikMi(c.urun)) {
        if (adAnahtari(c.urun) !== adAnahtari(sonUrunAdi)) sonRenk = '';
        sonUrunAdi = c.urun;
      }
      if (satirAnlamli) {
        kalemeEkle((anlamliBaslikMi(c.urun) ? c.urun : '') || sonUrunAdi, c.satirlar, c.fiyat);
      }
    }
  }

  const kalemler = [];
  for (const k of kalemHaritasi.values()) {
    const hazirSatirlar = irsaliyeSatirlariniHazirla(k.satirlar, uyarilar);
    if (hazirSatirlar.length > 0) {
      kalemler.push({
        urun: k.urun || sozCozum.urun || '',
        fiyat: ustFiyat != null && Number.isFinite(ustFiyat) && ustFiyat > 0 ? ustFiyat : k.fiyat,
        satirlar: hazirSatirlar
      });
    }
  }

  // Hiç kalem çıkmadıysa yalnız açıkça ürün adı veya sesli söz girildiyse satır oluştur (rastgele OCR gürültüsünden "1 adet" üretme)
  if (kalemler.length === 0 && (girdi.urun || sozCozum.urun || (sonUrunAdi && !hamMetin))) {
    kalemler.push({
      urun: sonUrunAdi || sozCozum.urun,
      fiyat: ustFiyat > 0 ? ustFiyat : null,
      satirlar: irsaliyeSatirlariniHazirla(sozCozum.satirlar.length ? sozCozum.satirlar : [{ renk: sonRenk, beden: '', irsaliyeAdet: 1, adet: 1 }], uyarilar)
    });
  }

  const seciliIndeks = Number.isInteger(Number(girdi.kalemIndeks)) && Number(girdi.kalemIndeks) >= 0 && Number(girdi.kalemIndeks) < kalemler.length
    ? Number(girdi.kalemIndeks)
    : 0;
  const acikUrunAdi = (girdi.urun || sozCozum.urun) ? (sonUrunAdi || sozCozum.urun || '') : '';
  const aktif = kalemler[seciliIndeks] || { urun: acikUrunAdi, fiyat: ustFiyat > 0 ? ustFiyat : null, satirlar: [] };

  if (!aktif.urun) uyarilar.push('İrsaliyeden ürün adı okunamadı; ürün adını kontrol edin.');
  if (aktif.satirlar.length === 0) uyarilar.push('İrsaliyeden beden/adet satırı okunamadı.');
  const toplamIrsaliyeAdet = aktif.satirlar.reduce((t, s) => t + (s.irsaliyeAdet || 0), 0);

  return {
    irsaliyeModu: true,
    irsaliyeNo: irsaliyeNo || null,
    urun: aktif.urun,
    fiyat: aktif.fiyat,
    satirlar: aktif.satirlar,
    toplamIrsaliyeAdet,
    kalemler,
    uyarilar
  };
}

// ===== Kayıt: o günün ürün girişleri (JSON) ve Excel'in açtığı CSV =====
// Birden çok telefon aynı anda girebilir. Her kayıt kimin girdiğini taşır. Aynı adla ikinci giriş ve
// başkasının az önce değiştirdiği ürünün düzeltilmesi sorulmadan yazılmaz.
const guvenli = d => excelHucreTemizle(d);
const tirnak = v => `"${String(v).replace(/"/g, '""')}"`;
const gunAdi = (t = new Date()) => `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
const SINIR = { urun: 80, renk: 30, beden: 12, adet: 10000, fiyat: 10000000, satir: 200, giren: 40 };
const adAnahtari = s => String(s || '').toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const saatYaz = ms => new Date(ms).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

const GIYIM_IYELIK_SOZLUK = {
  ceketi: 'ceket', ceketini: 'ceket',
  'gömleği': 'gömlek', gomlegi: 'gomlek',
  pantolonu: 'pantolon',
  elbiseyi: 'elbise', elbisesi: 'elbise',
  'ayakkabısı': 'ayakkabı', 'ayakkabıyı': 'ayakkabı', ayakkabisi: 'ayakkabi',
  'tişörtü': 'tişört', tisortu: 'tisort',
  'eteği': 'etek', etegi: 'etek',
  'hırkası': 'hırka', hirkasi: 'hirka',
  montu: 'mont',
  'kazağı': 'kazak', kazagi: 'kazak',
  'çantası': 'çanta', cantasi: 'canta',
  'şortu': 'şort', sortu: 'sort',
  taytı: 'tayt', tayti: 'tayt',
  bluzu: 'bluz',
  tunigi: 'tunik', 'tuniği': 'tunik'
};

function kelimeKoku(kelime) {
  const k = String(kelime || '').toLocaleLowerCase('tr-TR').trim();
  if (GIYIM_IYELIK_SOZLUK[k]) return GIYIM_IYELIK_SOZLUK[k];
  if (k.length >= 6 && /(?:s[ıiuü]|y[ıiuü]|[ıiuü])$/u.test(k)) {
    const aday = k.replace(/(?:s[ıiuü]|y[ıiuü]|[ıiuü])$/u, '');
    if (GIYIM_IYELIK_SOZLUK[`${aday}i`] || GIYIM_IYELIK_SOZLUK[`${aday}ı`] || GIYIM_IYELIK_SOZLUK[`${aday}u`] || GIYIM_IYELIK_SOZLUK[`${aday}ü`]) {
      return aday;
    }
  }
  return k;
}

// İki ürün kaydının aynı ürün olup olmadığını kelime sırasından ve iyelik eklerinden bağımsız kontrol eder
// ("Ceket siyah" == "Siyah Ceket" == "Ceketi Siyah" == { urun: "Ceket", satirlar: [{ renk: "SİYAH" }] })
// Her kayıtta bütün liste karşılaştırılır; aynı metin için renk araması yeniden yapılmaz
const renkAralikBellek = new Map();
function renkAraliklari(metin) {
  let r = renkAralikBellek.get(metin);
  if (!r) {
    r = colorSpans(metin);
    if (renkAralikBellek.size >= 20000) renkAralikBellek.clear();
    renkAralikBellek.set(metin, r);
  }
  return r;
}

function ayniUrunMu(kayitA, kayitB) {
  const adA = adAnahtari(kayitA && kayitA.urun);
  const adB = adAnahtari(kayitB && kayitB.urun);
  if (!adA || !adB) return false;
  if (adA === adB) return true;

  const ayristir = k => {
    const sozler = adAnahtari(k.urun).split(/\s+/).filter(Boolean).map(kelimeKoku);
    const baslikRenkleri = new Set(renkAraliklari(k.urun).map(r => r.ad.toLocaleLowerCase('tr-TR')));
    const satirRenkleri = new Set((k.satirlar || []).map(s => String(s.renk || '').trim().toLocaleLowerCase('tr-TR')).filter(Boolean));
    const tumRenkler = new Set([...baslikRenkleri, ...satirRenkleri]);
    const yalinKelimeler = sozler.filter(w => {
      if (sozler.length <= 1) return true;
      const r = renkAraliklari(w);
      return !r.length;
    });
    const siraliTam = [...new Set(sozler)].sort().join(' ');
    const siraliYalin = [...new Set(yalinKelimeler.length ? yalinKelimeler : sozler)].sort().join(' ');
    return { siraliTam, siraliYalin, baslikRenkleri, tumRenkler };
  };

  const a = ayristir(kayitA);
  const b = ayristir(kayitB);
  // "Ceket Siyah" ile "Siyah Ceket" veya "Ceketi Siyah"
  if (a.siraliTam === b.siraliTam) return true;

  // Yalın ürün adı aynıysa ("ceket") ve birinin başlığında geçen renk diğerinin satır/başlık rengiyle örtüşüyorsa
  if (a.siraliYalin && a.siraliYalin === b.siraliYalin) {
    if (a.baslikRenkleri.size > 0 && b.baslikRenkleri.size > 0) {
      const ortakBaslikRengi = [...a.baslikRenkleri].some(r => b.baslikRenkleri.has(r));
      return ortakBaslikRengi;
    }
    const ortakRenk = [...a.tumRenkler].some(r => b.tumRenkler.has(r));
    if (ortakRenk || a.tumRenkler.size === 0 || b.tumRenkler.size === 0) return true;
  }
  return false;
}

// Telefondan gelen ürünü denetler: { urun, fiyat, barkod, satirlar, giren } -> temiz kayıt ya da hata
function denetle(girdi) {
  const girenHam = String((girdi && girdi.giren) || '');
  const urunHam = String((girdi && girdi.urun) || '');
  const girenZirh = metinEnjeksiyonDenetle(girenHam, 'envanter_giren');
  const urunZirh = metinEnjeksiyonDenetle(urunHam, 'envanter_urun');
  if (!girenZirh.temiz || !urunZirh.temiz) {
    return { hata: 'Güvenlik Zırhı: Ürün veya görevli adında zararlı komut / prompt enjeksiyonu tespit edildi ve engellendi!' };
  }
  if (girdi && girdi.barkod && String(girdi.barkod).trim()) {
    const bZirh = barkodZirhiDenetle(girdi.barkod);
    if (!bZirh.gecerli) return { hata: bZirh.hata || 'Geçersiz barkod formatı.' };
  }
  const giren = girenZirh.metin.replace(/[<>]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!giren) return { hata: 'Önce adınızı yazın (kimin girdiği Excel\'de görünür).' };
  if (giren.length > SINIR.giren) return { hata: 'Ad çok uzun.' };
  const urun = urunZirh.metin.replace(/[<>]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!urun || urun.length < 2 || urun.toLocaleLowerCase('tr-TR') === 'isimsiz ürün') {
    return { hata: 'Geçersiz ürün adı. Boş ürün kaydedilemez.' };
  }
  if (urun.length > SINIR.urun) return { hata: 'Ürün adı çok uzun.' };
  const fiyatHam = girdi.fiyat === '' || girdi.fiyat == null ? null : fiyatCoz(girdi.fiyat);
  if (fiyatHam !== null && (!Number.isFinite(fiyatHam) || fiyatHam < 0 || fiyatHam > SINIR.fiyat)) return { hata: 'Fiyat geçersiz.' };
  const irsaliyeModu = Boolean(girdi && girdi.irsaliyeModu);
  if (irsaliyeModu) {
    if (!girdi.sayimOnayli) return { hata: 'İrsaliye girişinde depo teslim sayımı tamamlanıp onaylanmadan stoka kayıt yapılamaz.' };
    const hamSatirlar = Array.isArray(girdi.satirlar) ? girdi.satirlar : [];
    if (hamSatirlar.some(s => s && s.sayildi === false)) {
      return { hata: 'Sayımı onaylanmamış satır var. Tüm bedenlerin sayıldığını doğrulayın.' };
    }
    if (fiyatHam === null || fiyatHam <= 0) {
      return { hata: 'Sayım onaylandı; stoka kaydetmeden önce ürünün satış fiyatını girin.' };
    }
  }
  const barkod = barkodTemizle(girdi.barkod);
  const ham = Array.isArray(girdi.satirlar) ? girdi.satirlar : [];
  if (ham.length === 0) return { hata: 'En az bir satır olmalı (adet).' };
  if (ham.some(s => !s || typeof s !== 'object')) return { hata: 'Geçersiz satır bilgisi.' };
  if (!irsaliyeModu && ham.reduce((t, s) => t + (Number(s.adet) || 0), 0) <= 0) {
    return { hata: 'Toplam adet en az 1 olmalıdır. Boş veya adetsiz satır kaydedilemez.' };
  }
  if (ham.length > SINIR.satir) return { hata: 'Çok fazla satır.' };
  const satirlar = [];
  const eksikSatirlar = [];
  for (const s of ham) {
    let renk = String(s.renk || '').replace(/[<>]/g, ' ').trim().toLocaleUpperCase('tr-TR');
    let beden = String(s.beden || '').replace(/[<>]/g, ' ').trim().toLocaleUpperCase('tr-TR');

    // 🛡️ SAHTE / YANLIŞ / STANDART / PLACEHOLDER DEĞER KORUMASI:
    if (['STD', 'STANDART', '—', '-', 'YOK', 'YOKTUR', 'TANIMSIZ', 'NULL', 'UNDEFINED'].includes(renk) || renk.startsWith('ÖRN')) {
      renk = '';
    }
    if (['STD', 'STANDART', '—', '-', 'YOK', 'YOKTUR', 'TANIMSIZ', 'NULL', 'UNDEFINED'].includes(beden) || beden.startsWith('ÖRN') || beden.includes('XL...') || beden.includes('42...')) {
      beden = '';
    }
    const adet = Number(s.adet);
    const irsaliyeAdetHam = s.irsaliyeAdet != null && s.irsaliyeAdet !== '' ? Number(s.irsaliyeAdet) : null;
    const irsaliyeAdet = irsaliyeAdetHam !== null && Number.isInteger(irsaliyeAdetHam) && irsaliyeAdetHam >= 0 ? irsaliyeAdetHam : null;
    const satirBarkod = barkodTemizle(s.barkod);
    if (renk.length > SINIR.renk || beden.length > SINIR.beden) return { hata: 'Renk ya da beden çok uzun.' };
    const altSinir = irsaliyeModu ? 0 : 1;
    if (!Number.isInteger(adet) || adet < altSinir || adet > SINIR.adet) return { hata: `${[renk, beden].filter(Boolean).join(' ') || 'Bir satırın'} adedi eksik ya da geçersiz.` };
    if (adet === 0) {
      if (irsaliyeAdet !== null && irsaliyeAdet > 0) {
        eksikSatirlar.push({ renk, beden, irsaliyeAdet, adet: 0, fark: -irsaliyeAdet });
      }
      continue;
    }
    satirlar.push({
      renk,
      beden,
      adet,
      ...(irsaliyeAdet !== null ? { irsaliyeAdet, fark: adet - irsaliyeAdet } : {}),
      ...(satirBarkod ? { barkod: satirBarkod } : {})
    });
  }
  if (satirlar.length === 0) return { hata: 'Sayılan toplam adet en az 1 olmalı.' };
  const irsaliyeNo = String((girdi && girdi.irsaliyeNo) || '').trim().slice(0, 40);
  const anaBarkod = barkod || otomatikBarkodUret(urun);
  const hamBirlesik = birlesik(satirlar);
  const birlesmisSatirlar = hamBirlesik.map(s => {
    const varsayilanSatirBarkod = hamBirlesik.length === 1 && !s.renk && !s.beden && barkod
      ? barkod
      : otomatikBarkodUret(urun, s.renk, s.beden);
    const satirBarkodu = s.barkod || varsayilanSatirBarkod;
    return {
      ...s,
      ...(s.irsaliyeAdet != null ? { fark: s.adet - s.irsaliyeAdet } : {}),
      ...(satirBarkodu ? { barkod: satirBarkodu } : {})
    };
  });
  const irsaliyeToplam = [...birlesmisSatirlar, ...eksikSatirlar].reduce((t, s) => t + (s.irsaliyeAdet != null ? s.irsaliyeAdet : s.adet), 0);
  const sayilanToplam = birlesmisSatirlar.reduce((t, s) => t + s.adet, 0);
  return {
    kayit: {
      urun,
      fiyat: fiyatHam,
      ...(anaBarkod ? { barkod: anaBarkod } : {}),
      ...(irsaliyeModu ? {
        irsaliyeOnayli: true,
        ...(irsaliyeNo ? { irsaliyeNo } : {}),
        ...(eksikSatirlar.length ? { eksikSatirlar } : {}),
        irsaliyeOzeti: {
          irsaliyeToplam,
          sayilanToplam,
          toplamFark: sayilanToplam - irsaliyeToplam
        }
      } : {}),
      satirlar: birlesmisSatirlar,
      giren
    }
  };
}

function farkTutanagiMetni(kayit = {}) {
  const tumSatirlar = [...(kayit.satirlar || []), ...(kayit.eksikSatirlar || [])];
  const irsaliyeToplam = tumSatirlar.reduce((t, s) => t + (s.irsaliyeAdet != null ? Number(s.irsaliyeAdet) : Number(s.adet) || 0), 0);
  const sayilanToplam = (kayit.satirlar || []).reduce((t, s) => t + (Number(s.adet) || 0), 0);
  const toplamFark = sayilanToplam - irsaliyeToplam;
  const farkSatirlari = tumSatirlar.filter(s => s.irsaliyeAdet != null && Number(s.adet) !== Number(s.irsaliyeAdet));
  const baslik = `📋 MAL KABUL & DEPO SAYIM MUTABAKAT TUTANAĞI`;
  const belge = kayit.irsaliyeNo ? `İrsaliye No: ${kayit.irsaliyeNo}` : 'İrsaliye: Belirtilmedi';
  const urunBilgi = `Ürün: ${kayit.urun || '—'}${kayit.fiyat ? ` (${kayit.fiyat} TL)` : ''}`;
  const sayanBilgi = `Sayımı Yapan: ${kayit.giren || 'Depo'}`;
  const ozetSatir = `İrsaliye Toplamı: ${irsaliyeToplam} Adet | Depo Sayılan Net: ${sayilanToplam} Adet | Fark: ${toplamFark === 0 ? '0 (Tam Mutabakat ✓)' : (toplamFark > 0 ? `+${toplamFark} Fazla` : `${toplamFark} Eksik ⚠`)}`;
  const detaylar = farkSatirlari.length > 0
    ? ['Farklı Çıkan Bedenler:', ...farkSatirlari.map(s => {
        const fark = Number(s.adet) - Number(s.irsaliyeAdet);
        return `• ${[s.renk, s.beden].filter(Boolean).join(' ') || 'Standart'}: İrsaliye ${s.irsaliyeAdet} -> Çıkan ${s.adet} (${fark > 0 ? `+${fark} Fazla` : `${fark} Eksik`})`;
      })].join('\n')
    : 'Tüm bedenler irsaliye ile birebir mutabıktır.';
  return [baslik, belge, urunBilgi, sayanBilgi, ozetSatir, detaylar].join('\n');
}

function deposuKur(veriKlasoru) {
  const klasor = path.join(veriKlasoru, 'envanter');
  const jsonYolu = gun => path.join(klasor, `envanter-${gun}.json`);
  const csvYolu = gun => path.join(klasor, `envanter-${gun}.csv`);
  const barkodYolu = path.join(klasor, 'barkodlar.json');
  const bellek = new Map();
  let barkodBellek = null;
  let katalogGuvenilmez = false; // katalog hiç okunamadıysa diske körlemesine yazılmaz

  function kisaBekle(ms) { try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch (_) {} }

  // Önce geçici dosyaya tam yazar, sonra yerine koyar. Yazılamazsa eski dosyaya hiç dokunmaz.
  function guvenliYaz(hedef, metin) {
    const gecici = `${hedef}.${process.pid}.${Date.now()}.yeni`;
    try { fs.writeFileSync(gecici, metin); }
    catch (err) { try { fs.unlinkSync(gecici); } catch (_) {} throw err; }
    let sonHata = null;
    for (let i = 0; i < 5; i++) {
      try { fs.renameSync(gecici, hedef); return; }
      catch (err) { sonHata = err; if (!['EPERM', 'EBUSY', 'EACCES'].includes(err.code)) break; kisaBekle(40 * (i + 1)); }
    }
    // Dosya kilitli kaldıysa: geçici dosya eksiksiz yazıldı, içeriği kopyalanır
    try { fs.copyFileSync(gecici, hedef); try { fs.unlinkSync(gecici); } catch (_) {} return; }
    catch (err) { try { fs.unlinkSync(gecici); } catch (_) {} throw sonHata || err; }
  }

  function dosyadanOku(gun, tazeOku = false) {
    if (!tazeOku && bellek.has(gun)) return bellek.get(gun);
    try {
      const veri = JSON.parse(fs.readFileSync(jsonYolu(gun), 'utf8'));
      bellek.set(gun, veri);
      return veri;
    } catch (err) {
      if (err.code === 'ENOENT') return null;
      return bozukGunuKurtar(gun, err);
    }
  }

  // Bozuk dosya "yok" sayılırsa dünkü liste üstüne yazılırdı: dosya saklanır, son sağlam kopyaya dönülür
  function bozukGunuKurtar(gun, hata) {
    const hedef = jsonYolu(gun);
    console.error(`[ENVANTER] ${gun} dosyası okunamadı, yedeğe dönülüyor: ${hata.message}`);
    try { fs.renameSync(hedef, `${hedef}.bozuk-${Date.now()}`); } catch (_) {}
    try {
      const veri = JSON.parse(fs.readFileSync(path.join(veriKlasoru, 'yedek', `envanter-${gun}.json`), 'utf8'));
      if (Array.isArray(veri)) { try { yaz(gun, veri); } catch (_) { bellek.set(gun, veri); } return veri; }
    } catch (_) {}
    return null;
  }

  function barkodKataloguOku(tazeOku = false) {
    if (!tazeOku && barkodBellek) return barkodBellek;
    try {
      barkodBellek = JSON.parse(fs.readFileSync(barkodYolu, 'utf8'));
      katalogGuvenilmez = false;
      return barkodBellek;
    } catch (err) {
      if (err.code === 'ENOENT') { barkodBellek = {}; katalogGuvenilmez = false; return barkodBellek; }
      if (err instanceof SyntaxError) {
        // Bozuk katalog boş sayılıp üstüne yazılmaz: bozuk dosya saklanır, son yedekle birleştirilir
        console.error(`[ENVANTER] Barkod kataloğu bozuk, yedekten kurtarılıyor: ${err.message}`);
        try { fs.copyFileSync(barkodYolu, `${barkodYolu}.bozuk-${Date.now()}`); } catch (_) {}
        let yedek = null;
        try { yedek = JSON.parse(fs.readFileSync(path.join(veriKlasoru, 'yedek', 'barkodlar.json'), 'utf8')); } catch (_) {}
        const kurtarilan = yedek && typeof yedek === 'object' && !Array.isArray(yedek) ? yedek : {};
        barkodBellek = { ...kurtarilan, ...(barkodBellek || {}) };
        katalogGuvenilmez = false;
        try { barkodKataloguYaz(barkodBellek); } catch (_) {}
        return barkodBellek;
      }
      // Geçici okuma hatası (dosya kilitli vb.): eldeki katalog korunur
      if (!barkodBellek) { barkodBellek = {}; katalogGuvenilmez = true; }
      return barkodBellek;
    }
  }

  function barkodKataloguYaz(katalog) {
    fs.mkdirSync(klasor, { recursive: true });
    if (katalogGuvenilmez) {
      let disk = null;
      try { disk = JSON.parse(fs.readFileSync(barkodYolu, 'utf8')); } catch (err) { if (err.code === 'ENOENT') disk = {}; }
      if (!disk) {
        barkodBellek = katalog;
        console.error('[ENVANTER] Barkod kataloğu okunamadı; yeni barkod şimdilik bellekte tutuluyor.');
        return;
      }
      katalog = { ...disk, ...katalog };
      katalogGuvenilmez = false;
    }
    barkodBellek = katalog;
    const metin = JSON.stringify(katalog, null, 2);
    guvenliYaz(barkodYolu, metin);
    try {
      fs.mkdirSync(path.join(veriKlasoru, 'yedek'), { recursive: true });
      guvenliYaz(path.join(veriKlasoru, 'yedek', 'barkodlar.json'), metin);
    } catch (_) { /* Yedek yazımı ana işlemi engellemez */ }
  }

  // Otomatik barkod (MZU-) katalogda başka ürünün ya da aynı ürünün başka renk/bedeninin üzerinde mi
  function barkodBaskasininMi(giris, urun, renk = null, beden = null) {
    if (!giris || !giris.urun) return false;
    if (adAnahtari(giris.urun) !== adAnahtari(urun)) return true;
    if (renk === null || giris.tur !== 'VARYANT') return false;
    return String(giris.renk || '') !== String(renk || '') || String(giris.beden || '') !== String(beden || '');
  }

  function cakismayanBarkod(temel, urun, renk, beden, kayitIci) {
    if (!/^MZU-/.test(temel)) return temel;
    const katalog = barkodKataloguOku();
    const sahibi = renk === null ? adAnahtari(urun) : `${adAnahtari(urun)}|${renk}|${beden}`;
    const uygun = b => !(kayitIci.has(b) && kayitIci.get(b) !== sahibi) && !barkodBaskasininMi(katalog[b], urun, renk, beden);
    let aday = temel;
    for (let i = 0; !uygun(aday); i++) {
      aday = `${temel}-${crypto.createHash('sha256').update(`${sahibi}#${i}`).digest('hex').slice(0, 4).toUpperCase()}`;
    }
    kayitIci.set(aday, sahibi);
    return aday;
  }

  // Kayıttan önce: çakışmayan barkod olduğu gibi kalır (basılmış etiketler bozulmaz), çakışana ayırıcı ek gelir
  function barkodlariAyir(kayit) {
    const kayitIci = new Map();
    const hamAna = kayit.barkod;
    if (hamAna) kayit.barkod = cakismayanBarkod(hamAna, kayit.urun, null, null, kayitIci);
    for (const s of kayit.satirlar || []) {
      if (!s.barkod) continue;
      if (s.barkod === hamAna && !s.renk && !s.beden) { s.barkod = kayit.barkod; continue; }
      s.barkod = cakismayanBarkod(s.barkod, kayit.urun, s.renk, s.beden, kayitIci);
    }
  }

  // duzeltme: kullanıcı adı ya da rengi kendisi değiştirdi, katalog yeni hâli öğrenir
  function kayittanBarkodlariOgren(kayit, { duzeltme = false } = {}) {
    const katalog = barkodKataloguOku();
    let degisti = false;
    const simdi = Date.now();
    const anaBarkod = kayit.barkod || otomatikBarkodUret(kayit.urun);
    const baskasinin = (b, renk, beden) => !duzeltme && /^MZU-/.test(b) && barkodBaskasininMi(katalog[b], kayit.urun, renk, beden);
    if (anaBarkod && !baskasinin(anaBarkod, null, null)) {
      const sListesi = kayit.satirlar || [];
      const tekSatir = sListesi.length === 1;
      const tekRenk = [...new Set(sListesi.map(s => s.renk).filter(Boolean))];
      const eskiAna = katalog[anaBarkod] || {};
      const toplamAdet = sListesi.reduce((t, s) => t + (Number(s.adet) || 0), 0);
      katalog[anaBarkod] = {
        barkod: anaBarkod,
        anaBarkod,
        tur: 'ANA_URUN',
        urun: kayit.urun,
        fiyat: kayit.fiyat != null ? kayit.fiyat : (eskiAna.fiyat != null ? eskiAna.fiyat : null),
        renk: tekSatir ? (sListesi[0].renk || '') : (tekRenk.length === 1 ? tekRenk[0] : ''),
        beden: tekSatir ? (sListesi[0].beden || '') : '',
        sonAdet: toplamAdet,
        girisSayisi: (Number(eskiAna.girisSayisi) || 0) + 1,
        sonGiren: kayit.giren || eskiAna.sonGiren || '',
        zamanMs: simdi
      };
      degisti = true;
    }
    for (const s of (kayit.satirlar || [])) {
      const vBarkod = s.barkod || otomatikBarkodUret(kayit.urun, s.renk, s.beden);
      if (vBarkod) s.barkod = vBarkod;
      if (vBarkod && !baskasinin(vBarkod, s.renk, s.beden)) {
        const eskiV = katalog[vBarkod] || {};
        katalog[vBarkod] = {
          barkod: vBarkod,
          anaBarkod: anaBarkod || vBarkod,
          tur: 'VARYANT',
          urun: kayit.urun,
          fiyat: kayit.fiyat != null ? kayit.fiyat : (eskiV.fiyat != null ? eskiV.fiyat : null),
          renk: s.renk || '',
          beden: s.beden || '',
          sonAdet: Number(s.adet) || 1,
          girisSayisi: (Number(eskiV.girisSayisi) || 0) + 1,
          sonGiren: kayit.giren || eskiV.sonGiren || '',
          zamanMs: simdi
        };
        degisti = true;
      }
    }
    if (degisti) barkodKataloguYaz(katalog);
  }

  function urunBarkodBilgisi(urunAdi, gun = gunAdi()) {
    const aranan = adAnahtari(urunAdi);
    if (!aranan) return { kayitli: false };
    const katalog = barkodKataloguOku();
    const kayitlar = Object.values(katalog).filter(b => b && adAnahtari(b.urun) === aranan);
    const bugunku = oku(gun).find(k => adAnahtari(k.urun) === aranan);
    if (!kayitlar.length && !bugunku) {
      return {
        kayitli: false,
        anaBarkod: otomatikBarkodUret(urunAdi),
        urun: urunAdi,
        fiyat: null,
        varyantlar: []
      };
    }
    const ana = kayitlar.find(b => b.tur === 'ANA_URUN') || kayitlar[0] || {};
    const fiyat = (bugunku && bugunku.fiyat != null) ? bugunku.fiyat : (ana.fiyat != null ? ana.fiyat : null);
    const varyantlar = kayitlar.filter(b => b.tur === 'VARYANT' || (b.renk || b.beden)).map(b => ({
      barkod: b.barkod,
      renk: b.renk || '',
      beden: b.beden || '',
      fiyat: b.fiyat != null ? b.fiyat : fiyat,
      sonAdet: b.sonAdet || 1
    }));
    return {
      kayitli: true,
      anaBarkod: (bugunku && bugunku.barkod) || ana.anaBarkod || ana.barkod || otomatikBarkodUret(urunAdi),
      urun: (bugunku && bugunku.urun) || ana.urun || urunAdi,
      fiyat,
      girisSayisi: ana.girisSayisi || 1,
      varyantlar,
      bugunkuKayit: bugunku ? ozet(bugunku) : null
    };
  }

  function barkodBankasiListesi(arama = '', gun = gunAdi()) {
    bellek.delete(gun);
    const katalog = barkodKataloguOku(true);
    const bugunkuKayitlar = oku(gun);
    // Bugünkü ve geçmiş envanter kayıtlarında olup henüz katalogda olmayanları da öğren
    for (const k of bugunkuKayitlar) {
      const anaKod = k.barkod || otomatikBarkodUret(k.urun);
      const eksikVaryant = (k.satirlar || []).some(s => {
        const vKod = s.barkod || otomatikBarkodUret(k.urun, s.renk, s.beden);
        return vKod && !(vKod in katalog);
      });
      if (!anaKod || !(anaKod in katalog) || eksikVaryant) kayittanBarkodlariOgren(k);
    }
    try {
      const dosyalar = fs.readdirSync(klasor).filter(a => /^envanter-\d{4}-\d{2}-\d{2}\.json$/.test(a));
      for (const dosya of dosyalar) {
        const g = (dosya.match(/^envanter-(\d{4}-\d{2}-\d{2})\.json$/) || [])[1];
        if (!g || g === gun) continue;
        const gecmisKayitlar = dosyadanOku(g) || [];
        for (const k of gecmisKayitlar) {
          const anaKod = k.barkod || otomatikBarkodUret(k.urun);
          if (anaKod && !(anaKod in katalog)) kayittanBarkodlariOgren(k);
        }
      }
    } catch (_) {}
    const guncelKatalog = barkodKataloguOku();
    const urunGruplari = new Map();
    for (const b of Object.values(guncelKatalog)) {
      if (!b || !b.urun) continue;
      const anahtar = adAnahtari(b.urun);
      if (!urunGruplari.has(anahtar)) {
        const bugun = bugunkuKayitlar.find(k => adAnahtari(k.urun) === anahtar);
        const bugunDurum = bugun ? durumu(bugun) : null;
        urunGruplari.set(anahtar, {
          urun: b.urun,
          anaBarkod: b.anaBarkod || otomatikBarkodUret(b.urun),
          fiyat: (bugun && bugun.fiyat != null) ? bugun.fiyat : b.fiyat,
          bugunStok: bugunDurum ? bugunDurum.kalan : 0,
          bugunStokta: Boolean(bugunDurum && bugunDurum.kalan > 0),
          bugunToplamAdet: bugunDurum ? bugunDurum.kalan : 0,
          bugunKayitId: bugun ? bugun.id : null,
          zamanMs: b.zamanMs || 0,
          varyantlar: []
        });
      }
      const grup = urunGruplari.get(anahtar);
      if (b.fiyat != null && grup.fiyat == null) grup.fiyat = b.fiyat;
      if ((b.zamanMs || 0) > grup.zamanMs) grup.zamanMs = b.zamanMs || 0;
      if (b.tur === 'VARYANT' || b.renk || b.beden || b.barkod !== grup.anaBarkod) {
        if (!grup.varyantlar.some(v => v.barkod === b.barkod)) {
          grup.varyantlar.push({
            barkod: b.barkod,
            renk: b.renk || '',
            beden: b.beden || '',
            fiyat: b.fiyat != null ? b.fiyat : grup.fiyat,
            sonAdet: b.sonAdet || 1
          });
        }
      }
    }
    let sonuc = [...urunGruplari.values()].sort((a, b) => (b.zamanMs || 0) - (a.zamanMs || 0));
    const sorgu = String(arama || '').trim().toLocaleLowerCase('tr-TR');
    if (sorgu) {
      sonuc = sonuc.filter(u =>
        u.urun.toLocaleLowerCase('tr-TR').includes(sorgu) ||
        String(u.anaBarkod || '').toLocaleLowerCase('tr-TR').includes(sorgu) ||
        u.varyantlar.some(v => String(v.barkod || '').toLocaleLowerCase('tr-TR').includes(sorgu))
      );
    }
    return {
      success: true,
      toplamUrun: urunGruplari.size,
      toplamBarkod: Object.keys(guncelKatalog).length,
      urunler: sonuc
    };
  }

  function barkodKaydet(bilgi = {}) {
    const kod = barkodTemizle(bilgi.barkod);
    if (!kod) return { success: false, error: 'Geçersiz barkod.' };
    const urun = String(bilgi.urun || '').trim();
    if (!urun) return { success: false, error: 'Ürün adı gerekli.' };
    const katalog = barkodKataloguOku();
    let rHam = String(bilgi.renk || '').trim().toLocaleUpperCase('tr-TR');
    let bHam = String(bilgi.beden || '').trim().toLocaleUpperCase('tr-TR');
    if (['STD', 'STANDART', '—', '-', 'YOK', 'YOKTUR', 'TANIMSIZ', 'NULL', 'UNDEFINED'].includes(rHam) || rHam.startsWith('ÖRN')) rHam = '';
    if (['STD', 'STANDART', '—', '-', 'YOK', 'YOKTUR', 'TANIMSIZ', 'NULL', 'UNDEFINED'].includes(bHam) || bHam.startsWith('ÖRN')) bHam = '';
    const giris = {
      barkod: kod,
      urun: urun.split(/\s+/).filter(Boolean).map(BUYUK).join(' '),
      fiyat: bilgi.fiyat != null && bilgi.fiyat !== '' ? Number(bilgi.fiyat) : null,
      renk: rHam,
      beden: bHam,
      zamanMs: Date.now()
    };
    katalog[kod] = giris;
    barkodKataloguYaz(katalog);
    return { success: true, katalog: giris };
  }

  function barkodBul(hamKod, gun = gunAdi()) {
    const kod = barkodTemizle(hamKod);
    if (!kod) return { success: false, error: 'Barkod okunamadı.' };
    const kayitlar = oku(gun);
    for (const k of kayitlar) {
      const anaBarkod = k.barkod || otomatikBarkodUret(k.urun);
      const sEslesme = (k.satirlar || []).find(s => s.barkod === kod);
      if (sEslesme) {
        return {
          success: true,
          bulundu: true,
          barkod: kod,
          anaBarkod,
          urun: k.urun,
          fiyat: k.fiyat,
          renk: sEslesme.renk || '',
          beden: sEslesme.beden || '',
          bugunKayitId: k.id,
          bugunkuKayit: ozet(k)
        };
      }
      if (k.barkod === kod || anaBarkod === kod) {
        const sList = k.satirlar || [];
        const tekSatir = sList.length === 1;
        const tekRenk = [...new Set(sList.map(s => s.renk).filter(Boolean))];
        return {
          success: true,
          bulundu: true,
          barkod: kod,
          anaBarkod,
          urun: k.urun,
          fiyat: k.fiyat,
          renk: tekSatir ? (sList[0].renk || '') : (tekRenk.length === 1 ? tekRenk[0] : ''),
          beden: tekSatir ? (sList[0].beden || '') : '',
          bugunKayitId: k.id,
          bugunkuKayit: ozet(k)
        };
      }
    }
    const katalog = barkodKataloguOku();
    if (katalog[kod]) {
      const b = katalog[kod];
      const bugunku = kayitlar.find(k => adAnahtari(k.urun) === adAnahtari(b.urun));
      const anaBarkod = (bugunku && bugunku.barkod) || b.anaBarkod || otomatikBarkodUret(b.urun);
      const varyantlar = Object.values(katalog)
        .filter(x => x && adAnahtari(x.urun) === adAnahtari(b.urun) && (x.tur === 'VARYANT' || x.renk || x.beden))
        .map(x => ({ barkod: x.barkod, renk: x.renk || '', beden: x.beden || '', sonAdet: x.sonAdet || 1 }));
      return {
        success: true,
        bulundu: true,
        barkod: kod,
        anaBarkod,
        urun: b.urun,
        fiyat: b.fiyat,
        renk: b.renk || '',
        beden: b.beden || '',
        varyantlar,
        bugunKayitId: bugunku ? bugunku.id : null,
        bugunkuKayit: bugunku ? ozet(bugunku) : null
      };
    }
    return { success: true, bulundu: false, barkod: kod };
  }

  // Bugünün listesi ilk kez istendiğinde, en son envanter gününde kalan mallar bugüne taşınır.
  // Biten ürün ve biten renk-beden taşınmaz; taşınan kayıt nereden geldiğini (devir) bilir.
  function oku(gun = gunAdi()) {
    const kayitlar = dosyadanOku(gun);
    if (kayitlar) return kayitlar;
    return gun === gunAdi() ? devret(gun) : [];
  }

  function oncekiGun(gun) {
    let gunler = [];
    try { gunler = fs.readdirSync(klasor); } catch (err) { return null; }
    return gunler.map(a => (a.match(/^envanter-(\d{4}-\d{2}-\d{2})\.json$/) || [])[1]).filter(g => g && g < gun).sort().pop() || null;
  }

  function devret(gun) {
    const kaynak = oncekiGun(gun);
    if (!kaynak) return [];
    const zamanMs = Date.now();
    const kayitlar = (dosyadanOku(kaynak) || []).map((k, i) => {
      const satirlar = durumu(k).satirlar.filter(s => !s.listedeYok && s.kalan > 0).map(s => ({ renk: s.renk, beden: s.beden, adet: s.kalan, ...(s.barkod ? { barkod: s.barkod } : {}) }));
      if (!satirlar.length) return null;
      return { id: `UG-${zamanMs}-D${i}`, urun: k.urun, fiyat: k.fiyat, ...(k.barkod ? { barkod: k.barkod } : {}), satirlar, giren: k.giren || '', soz: '',
        devir: { gun: kaynak, id: k.id }, zamanMs, surum: 1 };
    }).filter(Boolean);
    try { yaz(gun, kayitlar); } catch (_) { bellek.set(gun, kayitlar); }
    return kayitlar;
  }

  // Liste değişti mi: telefonlar bu sayıya bakarak listeyi yeniler
  function surumu(kayitlar) {
    return kayitlar.reduce((t, k) => t + (k.surum || 1) + Object.keys(k.satislar || {}).length * 7 + (k.satisSayaci || 0), 0) * 1000 + kayitlar.length;
  }

  function csv(kayitlar) {
    const basliklar = ['Sıra', 'Ürün', 'Renk', 'Beden', 'Adet', 'Satılan', 'Kalan', 'Fiyat', 'Giren', 'Giriş saati'];
    const satirlar = [];
    kayitlar.forEach((k, i) => durumu(k).satirlar.forEach(s => satirlar.push([
      i + 1, guvenli(k.urun), guvenli(s.renk), guvenli(s.beden), s.basta, s.satilan, s.kalan, k.fiyat == null ? '' : String(k.fiyat).replace('.', ','),
      guvenli(k.devir ? `Dünden kalan (${k.devir.gun})${k.giren ? `, ${k.giren}` : ''}` : (k.giren || '')), saatYaz(k.zamanMs)
    ])));
    // Başındaki işaret (BOM) Excel'e Türkçe harflerin UTF-8 olduğunu söyler
    return '﻿' + [basliklar, ...satirlar].map(r => r.map(tirnak).join(';')).join('\r\n') + '\r\n';
  }

  const yedekKlasoru = path.join(veriKlasoru, 'yedek');
  const silinenlerYolu = path.join(klasor, 'silinenler.jsonl');
  // Bilgisayar yeniden başlasa da aynı telefon kaydı ikinci kez sayılmasın diye işlenen istekler diske de yazılır
  const islenenIstekYolu = path.join(klasor, 'islenen-istekler.jsonl');
  const ISTEK_SAKLAMA_MS = 14 * 24 * 60 * 60 * 1000;
  const ISTEK_UST_SINIR = 5000;
  const islenenIstekler = new Map();
  (function islenenIstekleriYukle() {
    let satirlar;
    try { satirlar = fs.readFileSync(islenenIstekYolu, 'utf8').split('\n').filter(Boolean); } catch (_) { return; }
    const simdi = Date.now();
    for (const satir of satirlar) {
      try {
        const k = JSON.parse(satir);
        if (k && k.id && k.sonuc && simdi - k.zamanMs < ISTEK_SAKLAMA_MS) islenenIstekler.set(k.id, { sonuc: k.sonuc, zamanMs: k.zamanMs });
      } catch (_) { /* Yarım kalmış son satır atlanır */ }
    }
    while (islenenIstekler.size > ISTEK_UST_SINIR) islenenIstekler.delete(islenenIstekler.keys().next().value);
    if (islenenIstekler.size === satirlar.length) return;
    try {
      const gecici = `${islenenIstekYolu}.${process.pid}.yeni`;
      fs.writeFileSync(gecici, [...islenenIstekler].map(([id, d]) => JSON.stringify({ id, zamanMs: d.zamanMs, sonuc: d.sonuc })).join('\n') + (islenenIstekler.size ? '\n' : ''));
      fs.renameSync(gecici, islenenIstekYolu);
    } catch (_) {}
  })();

  function istekOnbellegeYaz(istekId, sonuc) {
    if (!istekId || !sonuc || !sonuc.success) return;
    if (islenenIstekler.size >= ISTEK_UST_SINIR) {
      const ilkAnahtar = islenenIstekler.keys().next().value;
      if (ilkAnahtar) islenenIstekler.delete(ilkAnahtar);
    }
    const zamanMs = Date.now();
    islenenIstekler.set(istekId, { sonuc, zamanMs });
    try {
      fs.mkdirSync(klasor, { recursive: true });
      fs.appendFileSync(islenenIstekYolu, JSON.stringify({ id: istekId, zamanMs, sonuc }) + '\n');
    } catch (_) { /* Disk hatası kaydı engellemez; bellekteki koruma sürer */ }
  }

  function yaz(gun, kayitlar) {
    fs.mkdirSync(klasor, { recursive: true });
    const jsonMetin = JSON.stringify(kayitlar, null, 2);
    try {
      guvenliYaz(jsonYolu(gun), jsonMetin);
    } catch (err) {
      // Diske yazılamadı: bellekteki değişmiş kopya atılır, sonraki okuma diskteki son sağlam hale döner
      bellek.delete(gun);
      console.error(`[ENVANTER] ${gun} kaydı diske yazılamadı: ${err.message}`);
      throw new Error('Kayıt diske yazılamadı (disk dolu ya da dosya kilitli olabilir). İşlem yapılmadı, lütfen tekrar deneyin.');
    }
    bellek.set(gun, kayitlar);
    try {
      fs.writeFileSync(csvYolu(gun), csv(kayitlar));
    } catch (_) { /* CSV dosyası Excel'de açıksa (EBUSY) ana JSON kaydını engelleme */ }
    try {
      fs.mkdirSync(yedekKlasoru, { recursive: true });
      fs.writeFileSync(path.join(yedekKlasoru, `envanter-${gun}.json`), jsonMetin);
    } catch (err) { /* Yedek yazımı ana işlemi engellemez */ }
  }

  // Gece yarısı devir yapıldıktan sonra önceki günün ürününde satış/iptal olursa bugünkü devir kaydını da günceller
  function devirSenkronla(kaynakGun, kaynakKayit) {
    const bugun = gunAdi();
    if (!kaynakGun || kaynakGun >= bugun || !kaynakKayit) return;
    const bugunKayitlar = dosyadanOku(bugun);
    if (!Array.isArray(bugunKayitlar)) return;
    const idx = bugunKayitlar.findIndex(k => k.devir && k.devir.gun === kaynakGun && k.devir.id === kaynakKayit.id);
    if (idx < 0) return;
    const guncelSatirlar = durumu(kaynakKayit).satirlar
      .filter(s => !s.listedeYok && s.kalan > 0)
      .map(s => ({ renk: s.renk, beden: s.beden, adet: s.kalan, ...(s.barkod ? { barkod: s.barkod } : {}) }));
    if (guncelSatirlar.length === 0) {
      bugunKayitlar.splice(idx, 1);
    } else {
      bugunKayitlar[idx] = {
        ...bugunKayitlar[idx],
        satirlar: guncelSatirlar,
        surum: (bugunKayitlar[idx].surum || 1) + 1
      };
    }
    yaz(bugun, bugunKayitlar);
  }

  const ozet = k => ({ id: k.id, urun: k.urun, giren: k.giren || '', saat: saatYaz(k.duzeltildiMs || k.zamanMs), surum: k.surum || 1, fiyat: k.fiyat, barkod: k.barkod || null, satirlar: k.satirlar, devir: k.devir || null });

  // girdi.id: düzeltme (girdi.surum, açıldığındaki sürüm; başkası değiştirdiyse sorulur, girdi.zorla ile yine de yazılır)
  // girdi.birlestir: aynı adlı kayda eklenir (aynı renk ve beden adetleri toplanır)
  // girdi.ayriKayit: aynı adlı kayıt varken bilerek ayrı kayıt
  // girdi.istekId: aynı kaydın/eklemenin ağ gecikmesi veya çift tıklamayla iki kez işlenmesini önler (idempotency)
  function kaydet(girdi, { soz = '', zamanMs = Date.now() } = {}) {
    const istekId = girdi && girdi.istekId ? String(girdi.istekId).trim().slice(0, 80) : '';
    if (istekId && islenenIstekler.has(istekId)) {
      const onceki = islenenIstekler.get(istekId);
      if (Date.now() - onceki.zamanMs < ISTEK_SAKLAMA_MS) {
        return { ...onceki.sonuc, tekrarIstek: true };
      }
      islenenIstekler.delete(istekId);
    }

    const d = denetle(girdi);
    if (d.hata) return { success: false, error: d.hata };
    barkodlariAyir(d.kayit);
    const gun = (girdi && girdi.gun && /^\d{4}-\d{2}-\d{2}$/.test(girdi.gun)) ? girdi.gun : gunAdi(new Date(zamanMs));
    const kayitlar = oku(gun);
    const metin = String(soz || girdi.soz || '').slice(0, 500);

    // Düzeltme
    if (girdi.id) {
      const i = kayitlar.findIndex(k => k.id === girdi.id);
      if (i < 0) return { success: false, error: 'Düzeltilen ürün bulunamadı.' };
      const eski = kayitlar[i];
      if (!girdi.zorla && Number(girdi.surum || 0) !== (eski.surum || 1)) {
        return { success: false, cakisma: true, mevcut: ozet(eski), error: `${eski.urun} siz düzeltirken ${eski.giren || 'başkası'} tarafından değiştirildi (${saatYaz(eski.duzeltildiMs || eski.zamanMs)}).` };
      }

      // 🛡️ BARKOD BANKASI KORUMASI: Üretilmiş ana barkod ve varyant barkodları asla bozulamaz/değiştirilemez!
      const korunanAnaBarkod = eski.barkod || d.kayit.barkod || otomatikBarkodUret(d.kayit.urun || eski.urun);
      d.kayit.barkod = korunanAnaBarkod;

      if (Array.isArray(d.kayit.satirlar)) {
        d.kayit.satirlar.forEach(s => {
          // Barkod sıra numarasıyla değil renk ve bedenle eşlenir; satır silinince etiketler kaymaz
          const eskiSatir = (eski.satirlar || []).find(x => x.barkod && (x.renk || '') === (s.renk || '') && (x.beden || '') === (s.beden || ''));
          if (eskiSatir) {
            s.barkod = eskiSatir.barkod;
          } else if (!s.barkod) {
            s.barkod = otomatikBarkodUret(d.kayit.urun || eski.urun, s.renk, s.beden);
          }
        });
      }

      const kayit = { ...eski, ...d.kayit, barkod: korunanAnaBarkod, giren: eski.giren || d.kayit.giren, duzelten: d.kayit.giren, soz: metin || eski.soz, duzeltildiMs: zamanMs, surum: (eski.surum || 1) + 1 };
      kayitlar[i] = kayit;
      yaz(gun, kayitlar);
      kayittanBarkodlariOgren(kayit, { duzeltme: true });
      devirSenkronla(gun, kayit);
      const sonuc = { success: true, kayit, duzeltme: true, toplam: kayitlar.length, gun, surum: surumu(kayitlar) };
      istekOnbellegeYaz(istekId, sonuc);
      return sonuc;
    }

    // Aynı adla bugün girilmiş ürün: sorulmadan ikinci kayıt açılmaz (iki kişi aynı rafı saymış olabilir)
    if (girdi.birlestir) {
      const i = kayitlar.findIndex(k => k.id === girdi.birlestir);
      if (i < 0) return { success: false, error: 'Eklenecek ürün bulunamadı.' };
      const eski = kayitlar[i];
      const girenler = [...new Set([...String(eski.giren || '').split(', ').filter(Boolean), d.kayit.giren])].join(', ');
      const kayit = { ...eski, satirlar: birlesik([...eski.satirlar, ...d.kayit.satirlar]), fiyat: d.kayit.fiyat != null ? d.kayit.fiyat : eski.fiyat,
        // Basılmış etiketlerdeki ana barkod korunur: telefondan gelen kayıt onu değiştirmez
        ...((eski.barkod || d.kayit.barkod) ? { barkod: eski.barkod || d.kayit.barkod } : {}),
        giren: girenler, soz: [eski.soz, metin].filter(Boolean).join(' | ').slice(0, 1000), duzeltildiMs: zamanMs, surum: (eski.surum || 1) + 1 };
      kayitlar[i] = kayit;
      yaz(gun, kayitlar);
      kayittanBarkodlariOgren(kayit);
      devirSenkronla(gun, kayit);
      const sonuc = { success: true, kayit, birlesti: true, toplam: kayitlar.length, gun, surum: surumu(kayitlar) };
      istekOnbellegeYaz(istekId, sonuc);
      return sonuc;
    }
    const ayni = kayitlar.find(k => ayniUrunMu(k, d.kayit));
    if (ayni && !girdi.ayriKayit) {
      return { success: false, cift: true, mevcut: ozet(ayni), error: ayni.devir ? `${ayni.urun} dünden kalan olarak listede (${ayni.devir.gun}).` : `${ayni.urun} bugün ${ayni.giren || 'biri'} tarafından ${saatYaz(ayni.zamanMs)}'de girildi.` };
    }
    const kayit = { id: `UG-${zamanMs}-${Math.floor(Math.random() * 1000)}`, ...d.kayit, soz: metin, zamanMs, surum: 1 };
    kayitlar.push(kayit);
    yaz(gun, kayitlar);
    kayittanBarkodlariOgren(kayit);
    const sonuc = { success: true, kayit, toplam: kayitlar.length, gun, surum: surumu(kayitlar) };
    istekOnbellegeYaz(istekId, sonuc);
    return sonuc;
  }

  // Yanlışlıkla girilen ürün kaydını listeden kaldırır, devir kaynağından ve barkod bankasından da temizler
  function sil(gun = gunAdi(), id = '', silen = '') {
    const arananId = String(id || '').trim();
    if (!arananId) return { success: false, error: 'Silinecek ürün kimliği eksik.' };
    const kayitlar = oku(gun);
    const idx = kayitlar.findIndex(k => k.id === arananId);
    if (idx < 0) return { success: false, error: 'Silinecek ürün kaydı bulunamadı.' };
    const [silinen] = kayitlar.splice(idx, 1);
    yaz(gun, kayitlar);

    // Eğer dünden devreden bir kayıtsa kaynak gündeki kaydı da kaldır ki tekrar devretmesin
    if (silinen && silinen.devir && silinen.devir.gun && silinen.devir.id) {
      try {
        const kaynakKayitlar = dosyadanOku(silinen.devir.gun);
        if (Array.isArray(kaynakKayitlar)) {
          const kIdx = kaynakKayitlar.findIndex(x => x.id === silinen.devir.id || adAnahtari(x.urun) === adAnahtari(silinen.urun));
          if (kIdx >= 0) {
            kaynakKayitlar.splice(kIdx, 1);
            yaz(silinen.devir.gun, kaynakKayitlar);
          }
        }
      } catch (_) {}
    }

    // Aynı ürün adıyla başka kayıt kalmadıysa barkod kataloğundan da temizle
    try {
      const kalanAyniUrun = kayitlar.some(x => adAnahtari(x.urun) === adAnahtari(silinen.urun));
      if (!kalanAyniUrun && silinen && silinen.urun) {
        const katalog = barkodKataloguOku();
        let katalogDegisti = false;
        const silinenAnahtar = adAnahtari(silinen.urun);
        for (const [kod, b] of Object.entries(katalog)) {
          if (b && adAnahtari(b.urun) === silinenAnahtar) {
            delete katalog[kod];
            katalogDegisti = true;
          }
        }
        if (katalogDegisti) barkodKataloguYaz(katalog);
      }
    } catch (_) {}

    try {
      fs.appendFileSync(silinenlerYolu, JSON.stringify({
        silindiMs: Date.now(),
        gun,
        silen: String(silen || '').trim(),
        kayit: silinen
      }) + '\n');
    } catch (err) { /* Silinenler günlüğü hatası ana işlemi engellemez */ }
    return {
      success: true,
      silinen: ozet(silinen),
      kayit: silinen,
      toplam: kayitlar.length,
      gun,
      surum: surumu(kayitlar)
    };
  }

  // ===== Yayında satış: onaylanan sipariş envanterden düşer, iptal edilince geri eklenir =====
  // Satışlar kaydın içinde sipariş numarasıyla tutulur: aynı sipariş iki kez düşmez, iptal yalnız kendi satışını geri alır.
  function satisIsle(gun, id, { siparisNo, renk = '', beden = '', adet = 1, musteri = '' }, zamanMs = Date.now()) {
    const kayitlar = oku(gun);
    const k = kayitlar.find(x => x.id === id);
    if (!k || !siparisNo) return null;
    k.satislar = k.satislar || {};
    if (k.satislar[siparisNo]) return durumu(k);
    k.satislar[siparisNo] = { renk: renk || '', beden: beden || '', adet: Number(adet) || 1, musteri, zamanMs };
    k.satisSayaci = (k.satisSayaci || 0) + 1;
    yaz(gun, kayitlar);
    devirSenkronla(gun, k);
    return durumu(k);
  }

  function satisGeriAl(gun, id, siparisNo) {
    const kayitlar = oku(gun);
    const k = kayitlar.find(x => x.id === id);
    if (!k || !k.satislar || !k.satislar[siparisNo]) return null;
    delete k.satislar[siparisNo];
    k.satisSayaci = (k.satisSayaci || 0) + 1;
    yaz(gun, kayitlar);
    devirSenkronla(gun, k);
    return durumu(k);
  }

  // Barkod okutarak doğrudan ana envanterden satış/çıkış düşümü (veya geriAl=true ile +1 iade)
  // sayim: true ise adet stoğun üstüne eklenmez, sayılan adet stoğun yerine geçer
  // Barkodla ürünün fiyatını değiştirir (telefondaki barkod sayfasından). Aynı istek iki kez uygulanmaz.
  function barkodFiyatGuncelle(girdi = {}) {
    const istekId = girdi && girdi.istekId ? String(girdi.istekId).trim().slice(0, 80) : '';
    if (istekId && islenenIstekler.has(istekId)) {
      const onceki = islenenIstekler.get(istekId);
      if (Date.now() - onceki.zamanMs < ISTEK_SAKLAMA_MS) return { ...onceki.sonuc, tekrarIstek: true };
      islenenIstekler.delete(istekId);
    }
    const sonuc = barkodFiyatGuncelleIc(girdi || {});
    if (istekId) istekOnbellegeYaz(istekId, sonuc);
    return sonuc;
  }

  function barkodFiyatGuncelleIc({ barkod = '', fiyat = null, urun = '', gun = gunAdi(), giren = 'Depo' } = {}) {
    const kod = barkodTemizle(barkod);
    const yeni = Math.round(Number(String(fiyat == null ? '' : fiyat).replace(',', '.')) * 100) / 100;
    if (!Number.isFinite(yeni) || yeni <= 0 || yeni > 10000000) return { success: false, error: 'Fiyat geçersiz.' };
    if (gun < gunAdi()) gun = gunAdi();
    const kayitlar = oku(gun);
    const esit = (k, s) => (s.barkod ? String(s.barkod).toUpperCase() : otomatikBarkodUret(k.urun, s.renk, s.beden).toUpperCase()) === kod;
    let idx = -1;
    if (kod) idx = kayitlar.findIndex(k => (k.satirlar || []).some(s => esit(k, s)));
    if (idx < 0 && kod) idx = kayitlar.findIndex(k => (k.barkod || otomatikBarkodUret(k.urun)).toUpperCase() === kod);
    if (idx < 0 && kod) {
      const kat = barkodKataloguOku()[kod];
      if (kat && kat.urun) idx = kayitlar.findIndex(k => adAnahtari(k.urun) === adAnahtari(kat.urun));
    }
    if (idx < 0 && urun) idx = kayitlar.findIndex(k => adAnahtari(k.urun) === adAnahtari(urun));
    if (idx < 0) return { success: false, error: `Bu barkod (${kod}) güncel envanter listesinde bulunamadı.` };
    const k = kayitlar[idx];
    const eskiFiyat = k.fiyat != null ? k.fiyat : null;
    if (Number(eskiFiyat) === yeni) return { success: true, degismedi: true, urun: k.urun, fiyat: yeni, eskiFiyat, kayitId: k.id };
    k.fiyat = yeni;
    k.duzeltildiMs = Date.now();
    k.duzelten = String(giren || 'Depo').trim();
    k.surum = (k.surum || 1) + 1;
    yaz(gun, kayitlar);
    kayittanBarkodlariOgren(k);
    return { success: true, urun: k.urun, fiyat: yeni, eskiFiyat, kayitId: k.id, kayit: k };
  }

  // Aynı istek iki kez gelirse (ağ koptu, telefon yeniden gönderdi) ikinci kez uygulanmaz
  function barkodSatisDus(girdi = {}) {
    const istekId = girdi && girdi.istekId ? String(girdi.istekId).trim().slice(0, 80) : '';
    if (istekId && islenenIstekler.has(istekId)) {
      const onceki = islenenIstekler.get(istekId);
      if (Date.now() - onceki.zamanMs < ISTEK_SAKLAMA_MS) return { ...onceki.sonuc, tekrarIstek: true };
      islenenIstekler.delete(istekId);
    }
    const sonuc = barkodSatisDusIc(girdi || {});
    if (istekId) istekOnbellegeYaz(istekId, sonuc);
    return sonuc;
  }

  function barkodSatisDusIc({ barkod = '', adet = 1, geriAl = false, sayim = false, gun = gunAdi(), giren = 'Depo', urun = '', renk = '', beden = '' } = {}) {
    const kod = barkodTemizle(barkod);
    if (!kod) return { success: false, error: 'Barkod numarası geçersiz.' };
    const miktar = Math.max(1, Math.round(Number(adet) || 1));
    // Stok hareketi her zaman bugünün listesine işlenir; gece açık kalmış ekran dünü gönderse de
    if (gun < gunAdi()) gun = gunAdi();
    const kayitlar = oku(gun);

    let hedefKayitIdx = -1;
    let hedefSatirIdx = -1;

    for (let i = 0; i < kayitlar.length; i++) {
      const k = kayitlar[i];
      const sList = k.satirlar || [];
      const vIdx = sList.findIndex(s =>
        // Kayıtlı barkodu olan satır yalnız onunla eşleşir; yoksa çakışma ekli satır başka etiketi kapardı
        s.barkod ? s.barkod.toUpperCase() === kod : otomatikBarkodUret(k.urun, s.renk, s.beden).toUpperCase() === kod
      );
      if (vIdx >= 0) {
        hedefKayitIdx = i;
        hedefSatirIdx = vIdx;
        break;
      }
      const anaKod = (k.barkod || otomatikBarkodUret(k.urun)).toUpperCase();
      if (anaKod === kod && sList.length > 0) {
        hedefKayitIdx = i;
        // Ana barkod okutulduysa stoğu > 0 olan ilk satırı seç
        const stokluIdx = sList.findIndex(s => (Number(s.adet) || 0) > 0);
        hedefSatirIdx = stokluIdx >= 0 ? stokluIdx : 0;
        break;
      }
    }

    if (hedefKayitIdx < 0 || hedefSatirIdx < 0) {
      // Katalogda kayıtlı fabrika barkodu (868...) ise ürün adından bugünkü envanter kaydını bul
      const katKayit = barkodKataloguOku()[kod];
      if (katKayit && katKayit.urun) {
        const arananAnahtar = adAnahtari(katKayit.urun);
        const kIdx = kayitlar.findIndex(k => adAnahtari(k.urun) === arananAnahtar && Array.isArray(k.satirlar) && k.satirlar.length > 0);
        if (kIdx >= 0) {
          hedefKayitIdx = kIdx;
          const sList = kayitlar[kIdx].satirlar;
          const bIdx = katKayit.beden ? sList.findIndex(s => String(s.beden || '').toUpperCase() === String(katKayit.beden).toUpperCase()) : -1;
          const stokluIdx = sList.findIndex(s => (Number(s.adet) || 0) > 0);
          hedefSatirIdx = bIdx >= 0 ? bIdx : (stokluIdx >= 0 ? stokluIdx : 0);
        }
      }
    }

    if ((hedefKayitIdx < 0 || hedefSatirIdx < 0) && urun) {
      // Telefonda açılan ürünün barkodu farklı üretilmişse ürün adı, renk ve bedenle bulunur
      const arananAnahtar = adAnahtari(urun);
      const R = String(renk || '').trim().toLocaleUpperCase('tr-TR');
      const B = String(beden || '').trim().toLocaleUpperCase('tr-TR');
      for (let i = 0; i < kayitlar.length && hedefKayitIdx < 0; i++) {
        if (adAnahtari(kayitlar[i].urun) !== arananAnahtar) continue;
        const sIdx = (kayitlar[i].satirlar || []).findIndex(s => String(s.renk || '').toLocaleUpperCase('tr-TR') === R && String(s.beden || '').toLocaleUpperCase('tr-TR') === B);
        if (sIdx >= 0) { hedefKayitIdx = i; hedefSatirIdx = sIdx; }
      }
    }

    if (hedefKayitIdx < 0 || hedefSatirIdx < 0) {
      return { success: false, error: `Bu barkod (${kod}) güncel envanter listesinde bulunamadı.` };
    }

    const k = kayitlar[hedefKayitIdx];
    const satir = k.satirlar[hedefSatirIdx];
    const oncekiAdet = Number(satir.adet) || 0;

    if (sayim && !(Number.isInteger(Number(adet)) && Number(adet) >= 0)) {
      return { success: false, error: 'Sayılan adet geçersiz.' };
    }
    if (!geriAl && !sayim && oncekiAdet <= 0) {
      return {
        success: false,
        stokBitti: true,
        urun: k.urun,
        renk: satir.renk || '',
        beden: satir.beden || '',
        kalanAdet: 0,
        error: `⚠️ ${k.urun} (${[satir.renk, satir.beden].filter(Boolean).join(' ') || 'STD'}) stoğu zaten 0 (tükenmiş)!`
      };
    }

    const yeniAdet = sayim ? Number(adet) : (geriAl ? (oncekiAdet + miktar) : Math.max(0, oncekiAdet - miktar));
    satir.adet = yeniAdet;
    k.duzeltildiMs = Date.now();
    k.duzelten = String(giren || k.duzelten || k.giren || 'Depo').trim();
    k.surum = (k.surum || 1) + 1;

    // Eğer devir kaydıysa kaynak gündeki adedi de güncelle
    if (k.devir && k.devir.gun && k.devir.id && k.devir.gun !== gun) {
      try {
        const kaynakKayitlar = dosyadanOku(k.devir.gun);
        if (Array.isArray(kaynakKayitlar)) {
          const kk = kaynakKayitlar.find(x => x.id === k.devir.id);
          if (kk && Array.isArray(kk.satirlar)) {
            const ks = kk.satirlar.find(s => (s.renk || '') === (satir.renk || '') && (s.beden || '') === (satir.beden || ''));
            if (ks) {
              ks.adet = yeniAdet;
              yaz(k.devir.gun, kaynakKayitlar);
            }
          }
        }
      } catch (_) {}
    }

    yaz(gun, kayitlar);
    kayittanBarkodlariOgren(k);

    const urunToplamKalan = k.satirlar.reduce((t, s) => t + Math.max(0, Number(s.adet) || 0), 0);
    return {
      success: true,
      islem: sayim ? 'sayim' : (geriAl ? 'iade' : 'satis-dus'),
      barkod: satir.barkod || k.barkod || kod,
      anaBarkod: k.barkod || otomatikBarkodUret(k.urun),
      kayitId: k.id,
      urun: k.urun,
      fiyat: k.fiyat,
      renk: satir.renk || '',
      beden: satir.beden || '',
      oncekiAdet,
      dusulenAdet: sayim ? Math.max(0, oncekiAdet - yeniAdet) : miktar,
      kalanAdet: yeniAdet,
      urunToplamKalan,
      kayit: k
    };
  }

  // Tüm deneme envanterini ve kalıcı barkod bankasını temizler
  function tumunuSifirla() {
    try {
      if (fs.existsSync(klasor)) {
        for (const ad of fs.readdirSync(klasor)) {
          if (/^envanter-\d{4}-\d{2}-\d{2}\.(json|csv)$/.test(ad)) {
            try { fs.unlinkSync(path.join(klasor, ad)); } catch (_) {}
          }
        }
      }
      bellek.clear();
      katalogGuvenilmez = false;
      barkodKataloguYaz({});
      islenenIstekler.clear();
    } catch (_) {}
    // Telefonlar bu zamanı görünce kendi eski kopyalarını da temizler
    try { fs.mkdirSync(klasor, { recursive: true }); guvenliYaz(path.join(klasor, 'sifirlama.json'), JSON.stringify({ zamanMs: Date.now() })); } catch (_) {}
    return { success: true };
  }

  function sifirlamaZamani() {
    try { return Number(JSON.parse(fs.readFileSync(path.join(klasor, 'sifirlama.json'), 'utf8')).zamanMs) || 0; } catch (_) { return 0; }
  }

  // Yayında söylenen ürün adı bugünkü envanterde hangi ürün: kelimeler eklerine bakılmadan karşılaştırılır
  // ("ayakkabımız" = "ayakkabı"). Tek ve yeterince benzer bir ürün yoksa bağlanmaz; panelden elle seçilir.
  function eslestir(ad, gun = gunAdi()) {
    const kelimeler = s => adAnahtari(s).split(' ').filter(w => w.length >= 2);
    const benzer = (a, b) => a === b || (Math.min(a.length, b.length) >= 4 && (a.startsWith(b) || b.startsWith(a)));
    const aranan = kelimeler(ad);
    if (!aranan.length) return null;
    const puanlar = oku(gun).map(k => {
      const kk = kelimeler(k.urun);
      const ortak = kk.filter(w => aranan.some(a => benzer(a, w))).length;
      return { k, ortak, oran: ortak / Math.max(1, Math.min(kk.length, aranan.length)) };
    }).filter(p => p.ortak > 0 && p.oran >= 0.5).sort((a, b) => b.ortak - a.ortak || b.oran - a.oran);
    if (!puanlar.length) return null;
    if (puanlar[1] && puanlar[1].ortak === puanlar[0].ortak && puanlar[1].oran === puanlar[0].oran) return null;
    return puanlar[0].k;
  }

  function yenidenYukle() {
    bellek.clear();
    barkodBellek = null;
    return barkodKataloguOku(true);
  }

  return {
    oku, listele: oku, kaydet, sil, csv: gun => csv(oku(gun)), csvYolu, gunAdi, surum: gun => surumu(oku(gun)),
    bul: (gun, id) => oku(gun).find(k => k.id === id) || null,
    satisIsle, satisGeriAl, barkodSatisDus, barkodFiyatGuncelle, tumunuSifirla, sifirlamaZamani, eslestir, durumu,
    barkodBul, barkodKaydet, barkodKatalogu: barkodKataloguOku,
    barkodKataloguYukle: yenidenYukle, yenidenYukle,
    urunBarkodBilgisi, barkodBankasiListesi, otomatikBarkodUret
  };
}

// Ürünün renk-beden satırları: başta, satılan, kalan. Envanterde olmayan renk-bedenden satış da ayrı satır olur.
function durumu(k) {
  const satilan = new Map();
  for (const s of Object.values(k.satislar || {})) {
    const a = `${s.renk}|${s.beden}`;
    satilan.set(a, (satilan.get(a) || 0) + s.adet);
  }
  const satirlar = k.satirlar.map(s => {
    const n = satilan.get(`${s.renk}|${s.beden}`) || 0;
    satilan.delete(`${s.renk}|${s.beden}`);
    return { renk: s.renk, beden: s.beden, basta: s.adet, satilan: n, kalan: s.adet - n, ...(s.barkod ? { barkod: s.barkod } : {}) };
  });
  for (const [a, n] of satilan) {
    const [renk, beden] = a.split('|');
    satirlar.push({ renk, beden, basta: 0, satilan: n, kalan: -n, listedeYok: true });
  }
  return {
    id: k.id, urun: k.urun, fiyat: k.fiyat, barkod: k.barkod || null, satirlar,
    basta: satirlar.reduce((t, s) => t + s.basta, 0),
    satilan: satirlar.reduce((t, s) => t + s.satilan, 0),
    kalan: satirlar.reduce((t, s) => t + Math.max(0, s.kalan), 0)
  };
}

module.exports = { coz, anahtarKelimeCapaliAyristir, gecerliEnvanterSozuMu, gecerliUrunAdiMi, fiyatCoz, ayniUrunMu, etiketCoz, irsaliyeCoz, farkTutanagiMetni, barkodTemizle, otomatikBarkodUret, denetle, deposuKur, gunAdi, durumu, markaTelaffuzUygula, markaResmiYazimUygula, sozlukteMarkaVarMi, telaffuzOgren, ogrenilenTelaffuzUygula, fonetikBenzerlikOrani, kolektifUrunAdaylariBul };
