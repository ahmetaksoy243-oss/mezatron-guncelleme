# 📖 MEZATRON AI · SESLİ ENVANTER ASİSTANI — BENİ OKU VE KULLANIM KILAVUZU (v3.4)

Bu kılavuz; **Mezatron AI Sesli Envanter Asistanı**'nın telefon uygulamasını ve bilgisayar ekranını, sesli ürün girişini, barkod okutmayı, yedeklemeyi ve sık sorulan soruları adım adım anlatır.

Program iki parçadan oluşur:
- **Bilgisayar programı (Windows):** Bütün kayıtların tutulduğu ana yer. Ekranın sağ altındaki Mezatron tepsi simgesiyle çalışır.
- **Telefon uygulaması (Android):** Ürünleri sesle, barkodla veya yazarak girdiğiniz yer. Bilgisayar kapalıyken de çalışır.

---

## 1. GİRİŞ VE ÜST MENÜ (`☰ Menü`)

**Giriş:** Telefonda program açıldığında adınızı ve **kendi 4 haneli şifrenizi** yazarsınız. İlk girişte şifrenizi kendiniz belirlersiniz. İlk hesap (lisans sahibi) dükkan bilgisayarından açılır; sonraki hesaplar lisans sahibi bilgisayardan onaylayınca giriş yapabilir.

Telefon ekranının en üstünde **`🔄 Yenile`** ve **`☰ Menü`** tuşları bulunur. Menüde şunlar vardır:
- **👤 Kullanıcı:** Kayıtlarda "Giren" olarak görünen ad. Değiştirmek için dokunun, giriş ekranı yeniden açılır.
- **📱 Başka Telefonu Bağla (QR):** Yeni bir telefonu programa bağlamak için QR kodları gösterir.
- **🔄 Programı Güncelle & Sürüm Kontrolü:** Telefon uygulamasının yeni sürümü olup olmadığını gösterir.
- **📖 Yardım:** Kullanım rehberini açar.
- **☀️ Gece / Gündüz Modu:** Koyu ve açık tema arasında geçiş yapar.
- **🖨️ Mobil & BT Yazıcı:** Bluetooth termal yazıcı eşleştirme, etiket boyu seçimi ve telefonda bekleyen kayıtları bilgisayara gönderme bölümü.
- **🏦 Barkod Veri Bankası:** Üretilen bütün barkodların listesi.
- **🔐 4 Haneli Güvenlik PIN:** Bazı işlemlerde istenen, bilgisayar ekranında görünen mağaza şifresini girme yeri.
- **📊 Envanteri Excel'e Aktar / Excel'den Yükle**
- **⏻ Programı Güvenli Kapat (Kaydet & Çık)**

---

## 2. ÜÇ ANA SAYFA

Sayfalar arasında ekranın altındaki **3 büyük tuşla** ya da ekranı **sağa-sola kaydırarak** geçersiniz.

### 🎙️ 1. Sayfa: Sesli Giriş
- **`🎙️ ÜRÜN GİRİŞİ`** tuşuna basın ve ürünü doğal şekilde söyleyin:
  - *Örnek:* `"V yaka tişört siyah M beden 12 adet 350 lira"`
  - *Örnek:* `"Triko kazak lacivert L beden 8 adet, XL beden 6 adet 750 lira"`
- Konuşmanız bitince mikrofon tuşuna dokunun. Dokunmazsanız **yaklaşık 4 saniye susunca** mikrofon kendiliğinden kapanır ve ürün **Ürün Adı, Fiyat, Renk, Beden ve Adet** olarak tabloya yazılır.
- Ses tanıma telefonun içinde çalışır; bilgisayar kapalıyken de konuşarak giriş yapabilirsiniz.
- **`📷 ÜRÜN BİLGİSİ AL`:** Ürünün etiketini veya kutusunu çekip isim ve beden bilgisini doldurur. Bilgisayar kapalıyken telefon uygulaması fotoğrafı **kendisi okur** (ilk okumada birkaç saniye sürebilir).
- **`🏷️ BARKOD ÜRET`:** Barkodu olmayan ürüne yeni barkod verir.
- **`✓ KAYDET`:** Tabloyu kontrol ettikten sonra kaydeder.
- **`⋯ Diğer İşlemler`** menüsünde: **➕ Yeni Renk / Beden Ekle**, **✍️ Yazarak Gir**, **🖨️ KAYDET & BAS** (kaydedip etiketi yazıcıya gönderir) ve **🗑️ Temizle** bulunur.

### 📷 2. Sayfa: Barkod
- Kamera kendiliğinden açılır. Barkodu kameraya tutun; okunduğunda kısa bir bip sesi gelir ve **ürün adı, renk, beden, fiyat ve mevcut stok** gösterilir.
- Üstten **➕ GİRİŞ** (stoğa ekler) veya **➖ ÇIKIŞ** (stoktan düşer) seçin, adedi **− / +** ile ayarlayın ve **✓ KAYDET**'e basın.
- Barkodu okutmak tek başına kayıt yapmaz; her zaman siz onaylarsınız.
- Okunduktan sonra aynı barkodun yanlışlıkla ikinci kez okunmaması için kısa bir bekleme (yaklaşık 3,5 saniye) vardır.
- Barkodu veya ürün kodunu (E180 gibi) elle yazmak için **`⋯ Diğer İşlemler`**'e dokunun.

### 📋 3. Sayfa: Envanter
- Girilen bütün ürünleri gösterir. Ürün adı, renk, beden, fiyat veya barkodla arama yapabilirsiniz.
- Kayda dokunarak düzeltebilir, barkod etiketini yeniden basabilirsiniz.

---

## 3. SIKÇA SORULAN SORULAR (SSS)

1. **Soru: Programdan güvenli şekilde nasıl çıkarım?**
   - **Cevap:** `☰ Menü` en altındaki **`⏻ Programı Güvenli Kapat`** tuşuna basın. Kaydedilmemiş ürün varsa program önce sorar, ardından kayıtları kaydedip programı kapatır.

2. **Soru: Söylediğim marka veya renk yanlış yazılırsa ne yapmalıyım?**
   - **Cevap:** Tablodaki ilgili alana dokunup düzeltin ya da silip yeniden söyleyin. Kaydetmeden önce her şeyi değiştirebilirsiniz.

3. **Soru: Güneş altında yazılar silik görünürse ne yapmalıyım?**
   - **Cevap:** `☰ Menü` → **`☀️ Gece / Gündüz Modu`** ile açık temaya geçin.

4. **Soru: Bilgisayar kapalıyken telefondan girdiğim ürünler kaybolur mu?**
   - **Cevap:** Hayır. Telefon uygulaması bilgisayarsız çalışır; girilen ürünler telefonun kendi hafızasında bekler. Telefon bilgisayara yeniden bağlandığında kendiliğinden ya da `🖨️ Mobil & BT Yazıcı` bölümündeki **`🔄 Bekleyenleri PC'ye Aktar`** tuşuyla bilgisayara gönderilir. Etiket ve irsaliye fotoğrafları da telefonda okunur.

5. **Soru: Kaç kişi kullanabilir?**
   - **Cevap:** Standart lisans **3 kullanıcı** içindir (lisans sahibi + 2 çalışan). Daha fazla kullanıcı için lisans kodu gerekir.

6. **Soru: Program nasıl güncellenir?**
   - **Cevap:** Güncellemeler imzalı gelir. Bilgisayarda sağ alttaki **Mezatron tepsi simgesine** sağ tıklayıp **Güncellemeleri denetle**'yi seçin; yeni sürüm varsa aynı menüden kurulur. Yeni sürüm açılmazsa program önceki sürüme döner, verileriniz etkilenmez. Telefon uygulamasının yenisi de bu güncellemeyle gelir.

7. **Soru: Sistem ve envanter verilerini ne sıklıkla yedeklemeliyim?**
   - **Cevap:**
     - **Otomatik Yedek:** Program arka planda her 5 dakikada bir (veri değiştiyse) ve her 10 yeni kayıtta bir yedek alır.
     - **Güvenli Kapatmada Yedek:** **`⏻ Güvenli Kapat`** tuşuna bastığınızda envanterin, barkod bankasının ve ayarların son kopyası yedeklenir.
     - **Önerilen Yedekleme Düzeni:**
       - **Günlük:** Gün sonunda bilgisayarda `📁 Dosya` → **`💾 Tam Veritabanı Yedeği Al (.JSON)`** veya **Excel Dosyası Olarak İndir** yapıp dosyayı USB belleğe ya da Google Drive / OneDrive'a kopyalayın.
       - **Haftalık:** Haftanın son günü `📁 Dosya` → **`📦 Sistem & Dosyaların Tam Kopyasını İndir`** ile alınan dosyayı tarihli bir klasörde (örn: `Mezatron-Yedek-2026-Hafta45`) saklayın. Bilgisayar bozulursa bu yedekle kayıtlarınızı geri yükleyebilirsiniz.

---

## 4. BİLGİSAYAR EKRANI

1. **🏠 Giriş (Ana Sayfa):** Bütün envanteri Excel'e benzer bir tabloda gösterir. Barkod, adet, fiyat, beden ve renkle arama yapabilirsiniz.
2. **📁 Dosya Menüsü:** Excel indirme / yükleme, A4 liste yazdırma, tam yedek alma, Barkod & Termal Etiket İstasyonu ve Canlı Mezat Köprüsü buradadır.
3. **🔒 Barkod Kilidi:** Bir ürünü düzenlerken barkod numarası değiştirilemez; adet, renk, isim ve fiyat değiştirilebilir ve telefonlara da yansır.
4. **Görünüm & Ayarlar → 🎙️ Bilgisayarda Ses Tanıma:** Belleği az (örneğin 4 GB) bilgisayarlarda bilgisayardaki ses tanımayı kapatıp programı hızlandırır. Kapalıyken telefon uygulaması sesi kendisi çözmeye devam eder.
5. **Kullanıcı & PIN:** Yeni hesapları onaylama, şifre sıfırlama ve **🔑 Lisansı Aktifleştir** (3 kullanıcıdan fazlası için lisans kodu) buradadır.
6. **⏻ Güvenli Kapat:** Üst bardaki kırmızı **`⏻ Güvenli Kapat`** tuşu bütün verileri yedekler ve kısa bir geri sayımla programı kapatır.
